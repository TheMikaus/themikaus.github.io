import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

class DumpBitmap
{
    public static void main(String args[])
        throws IOException
    {
        String dirName = args[0];
        String hName = dirName+".h";
        String cName = dirName+".c";

        // Dump the header
        PrintWriter hFile = new PrintWriter(new BufferedWriter(new FileWriter(hName)));
        PrintWriter cFile = new PrintWriter(new BufferedWriter(new FileWriter(cName)));

        File dir = new File(dirName);
        File[] files = dir.listFiles();

        System.out.println(dirName + ": " + files.length + " files");

        if (files != null)
        {
            for (File file:files)
            {
                BufferedImage img = ImageIO.read(file);
                String fileName = file.getName();
                String objectName = fileName.substring(0, fileName.length() - 4);
                outputBitmap(objectName, hFile, cFile, img);
            }
        }
        else
        {
            System.out.println("NO FILES");
        }

        hFile.close();
        cFile.close();
    }

    public static void outputBitmap(String objectName, PrintWriter hFile, PrintWriter cFile, BufferedImage img)
    {
        int w = img.getWidth(null);
        int h = img.getHeight(null);

        hFile.println("#define " + objectName.toUpperCase() + "_WIDTH " + w);
        hFile.println("#define " + objectName.toUpperCase() + "_HEIGHT " + h);
        hFile.println("extern unsigned int " + objectName + "_data[" + (w * h) +"];");
        hFile.println("");
        hFile.println("");

        cFile.println("unsigned int " + objectName + "_data[" + (w*h) +"] = {");
        for (int y = 0; y < h; y++)
        {
            for (int x = 0; x < w; x++)
            {
                String colorWrong = Integer.toHexString(img.getRGB(x,y));
                String color = colorWrong.substring(0,2) +
                               colorWrong.substring(6,8) +
                               colorWrong.substring(4,6) +
                               colorWrong.substring(2,4);
                            

                while (color.length() < 6)
                {
                    color = "0" + color;
                }
            
                if (color.length() == 6)
                {
                    if (color.equals("000000")) color = "00" + color;
                    else color = "ff" + color;
                }
                else if(color.equals("ff000000")) color = "00000000";
                cFile.print("0x" + color + ", ");
            }
            cFile.println("");
        }
        cFile.println("};");
    }
}

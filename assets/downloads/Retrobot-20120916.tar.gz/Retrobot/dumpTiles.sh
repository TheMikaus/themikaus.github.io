#!/bin/bash
cd utils
java DumpBitmap ../tileImages
cd ..
mv tileImages.c tiles/tiles.cpp
mv tileImages.h tiles/tiles.h

#ifndef TEST_CODE_H
#define TEST_CODE_H

void test_input();

void test_graphics();

void test_renderer();

void test_entity();

#endif
#include "input_manager.h"
#include "psp_input_manager.h"

#include "graphics_manager.h"
#include "psp_renderer.h"

#include "entity_manager.h"
#include "player_entity.h"

#include "tiles.h"

#include <pspgu.h>
#include <pspgum.h>

#include <pspdebug.h>
#define printf pspDebugScreenPrintf

#include <stdlib.h>
#include <string.h>

extern int done;

void test_input()
{
	bool toggle = false;
	
	printf("Initializing input manager\n");
	InputManagerSystem* ims = InputManagerSystem::getInstance();
	PSPInputUpdateSystem* pius = new PSPInputUpdateSystem();
	ims->setInputUpdateSystem(pius);

	printf("Registering buttons\n");
	ButtonId AU = ims->registerButton("AnalogUp", PSPInputMap::AnalogUp);
	ButtonId AD = ims->registerButton("AnalogDown", PSPInputMap::AnalogDown);
	ButtonId AL = ims->registerButton("AnalogLeft", PSPInputMap::AnalogLeft);
	ButtonId AR = ims->registerButton("AnalogRight", PSPInputMap::AnalogRight);

	printf("Registering SelStart buttons\n");
	ButtonId SE = ims->registerButton("selectStart", PSPInputMap::Select);
	ButtonId ST = ims->registerButton("selectStart", PSPInputMap::Start);
	
	printf("Registering Pad\n");	
	ButtonId PU = ims->registerButton("Up", PSPInputMap::Up);
	ButtonId PD = ims->registerButton("Down", PSPInputMap::Down);
	ButtonId PL = ims->registerButton("Left", PSPInputMap::Left);
	ButtonId PR = ims->registerButton("Right", PSPInputMap::Right);
	
	printf("Registering mash\n");	
	ButtonId Mash = ims->registerButton("MASH", PSPInputMap::Cross);
	Mash = ims->registerButton("MASH", PSPInputMap::Square);
	Mash = ims->registerButton("MASH", PSPInputMap::Triangle);
	Mash = ims->registerButton("MASH", PSPInputMap::Circle);
	Mash = ims->registerButton("MASH", PSPInputMap::L);
	Mash = ims->registerButton("MASH", PSPInputMap::R);

	printf("Starting main loop\n");
	while(!done){
		pspDebugScreenSetXY(0, 2);
		printf("Retrobot");

		ims->updateButtons(1);
		
		if (ims->buttonWasPressed(Mash))
		{
			toggle = !toggle;
		}
		
		if (!toggle)
		{
			pspDebugScreenClear();
			printf("Button Pressed!");
		}
		else
		{
			printf("Analog %ld %ld %ld %ld\n",
				ims->buttonDown(AU), ims->buttonDown(AD),
				ims->buttonDown(AL), ims->buttonDown(AR));
				
			printf("Pad %ld %ld %ld %ld\n",
				ims->buttonDown(PU), ims->buttonDown(PD),
				ims->buttonDown(PL), ims->buttonDown(PR));
				
			printf("SelStart %ld %ld\n",
				ims->buttonDown(SE), ims->buttonDown(ST));
			
			printf("Mash %ld\n", ims->buttonDown(Mash));
		}
	}
}

void test_graphics()
{
	int manipulator = 0;
	int max = 0;
	InputManagerSystem* ims = InputManagerSystem::getInstance();
	PSPInputUpdateSystem* pius = new PSPInputUpdateSystem();
	GraphicsManager* gm = GraphicsManager::getInstance();
	ims->setInputUpdateSystem(pius);
	ButtonId Mash = ims->registerButton("MASH", PSPInputMap::Cross);
	ButtonId YRot = ims->registerButton("YRot", PSPInputMap::Square);
	ButtonId ZoomIn = ims->registerButton("ZoomIn", PSPInputMap::L);
	ButtonId ZoomOut = ims->registerButton("ZoomOut", PSPInputMap::R);
	ButtonId PU = ims->registerButton("Up", PSPInputMap::Up);
	ButtonId PD = ims->registerButton("Down", PSPInputMap::Down);
	ButtonId PL = ims->registerButton("Left", PSPInputMap::Left);
	ButtonId PR = ims->registerButton("Right", PSPInputMap::Right);
	ButtonId LU = ims->registerButton("LU", PSPInputMap::AnalogUp);
	ButtonId LD = ims->registerButton("LD", PSPInputMap::AnalogDown);
	ButtonId LT = ims->registerButton("LightToggle", PSPInputMap::AnalogLeft);
	ButtonId Sp1Toggle = ims->registerButton("Sp1Toggle", PSPInputMap::Select);
	ButtonId Sp2Toggle = ims->registerButton("Sp2Toggle", PSPInputMap::Start);
	
	PSPRenderer* renderer = new PSPRenderer();
	gm->setRenderer(renderer);

	CameraData cameraData;
	cameraData.pos[0] = cameraData.pos[1] = 0;
	cameraData.pos[2] = 2;
	cameraData.rot[0] = cameraData.rot[1] = cameraData.rot[2] = 0;

	// Set up local copies of SpriteData, GraphicData, BackgroundData
	SpriteData* spriteData = gm->getSpriteData(&max);
	GraphicData* graphicData = gm->getGraphicData(&max);
	
	for (int i = 0; i < 2; i++)
	{
		spriteData[i].pos[0] = spriteData[i].pos[1] = spriteData[i].pos[2] = 0;
		spriteData[i].rot[0] = spriteData[i].rot[1] = spriteData[i].rot[2] = 0;
		spriteData[i].graphicIndex = 0;
		spriteData[i].effectIndex = 0;
		spriteData[i].layerId = 0;
		spriteData[i].visible = true;
	}
	spriteData[1].graphicIndex = 1;
	
	spriteData[1].pos[0] = -1;
	spriteData[1].pos[2] = -5.0f;
	
	graphicData[0].width = 3;
	graphicData[0].height = 4;
	graphicData[0].depth = 1;
	graphicData[0].pixelData = (unsigned int*)malloc(sizeof(unsigned int) * graphicData[0].width*graphicData[0].height);
	graphicData[0].pixelData[0] = graphicData[0].pixelData[1] = graphicData[0].pixelData[2] = 0xff00ff00;
	graphicData[0].pixelData[3] = graphicData[0].pixelData[5] = 0x00000000;
	graphicData[0].pixelData[4] = 0xffffff00;
	graphicData[0].pixelData[6] = graphicData[0].pixelData[7] = graphicData[0].pixelData[8] = 0xff0000ff;
	graphicData[0].pixelData[9] = graphicData[0].pixelData[10] = graphicData[0].pixelData[11] = 0xffffffff;
	
	graphicData[1].width = 3;
	graphicData[1].height = 2;
	graphicData[1].depth = 3;
	graphicData[1].pixelData = (unsigned int*)malloc(sizeof(unsigned int) * graphicData[1].width*graphicData[1].height);
	graphicData[1].pixelData[0] = graphicData[1].pixelData[1] = graphicData[1].pixelData[2] = 0xffffffff;
	graphicData[1].pixelData[3] = graphicData[1].pixelData[5] = 0x00000000;
	graphicData[1].pixelData[4] = 0xffffffff;
	
	graphicData[2].width = 1;
	graphicData[2].height = 1;
	graphicData[2].depth = 10;
	graphicData[2].pixelData = (unsigned int*)malloc(sizeof(unsigned int));
	graphicData[2].pixelData[0] = 0xffff00ff;

	LightData* lightData = gm->getLightData(&max);
	lightData[0].type = lightData[1].type = lightData[2].type = lightData[3].type = LIGHT_DATA_NONE;
	lightData[0].type = LIGHT_DATA_POINT;
	lightData[0].pos[0] = spriteData[1].pos[0];
	lightData[0].pos[1] = 0;
	lightData[0].pos[2] = spriteData[1].pos[2];
	lightData[0].rot[0] = 0;
	lightData[0].rot[1] = 90 * (GU_PI/180.0f);
	lightData[0].rot[2] = 0;
	lightData[0].strength = 1.0f;
	lightData[0].color = 0xffffffff;
	
	lightData[1].type = LIGHT_DATA_SPOT;
	memcpy(lightData[1].pos, cameraData.pos, sizeof(float[3]));
	lightData[1].rot[2] = 0;
	lightData[1].strength = 1.0f;
	lightData[1].color = 0xff0000ff;
	
	
	BackgroundData* backgroundData = gm->getBackgroundData(&max);
	/*
	backgroundData[0].type = BACKGROUND_TYPE_TILED;
	backgroundData[0].width = 60;
	backgroundData[0].height = 10;
	backgroundData[0].display[0] = 0;
	backgroundData[0].display[1] = 0;
	backgroundData[0].display[2] = 0;
	backgroundData[0].info.tiledInfo.tileData = (int*)malloc(sizeof(int)*600);
	backgroundData[0].info.tiledInfo.srcXInTiles = 0;
	backgroundData[0].info.tiledInfo.srcYInTiles = 0;
	backgroundData[0].info.tiledInfo.tileWidth = 1;
	backgroundData[0].info.tiledInfo.tileHeight = 1;
	backgroundData[0].info.tiledInfo.displayWidthInTiles = 10;
	backgroundData[0].info.tiledInfo.displayHeightInTiles = 10;
	int tIdx;
	for (int y = 0; y < 10; y++)
	{
		for (int x = 0; x < 60; x++)
		{
			tIdx = y * 60 + x;
			if( y%2 == 1)
			{
				backgroundData[0].info.tiledInfo.tileData[tIdx] = 2;
			}
			else
			{
				backgroundData[0].info.tiledInfo.tileData[tIdx] = -1;
			}
		}
	}
	*/
	backgroundData[0].type = BACKGROUND_TYPE_PIXELED;
	backgroundData[0].width = DEMO_BACKGROUND_WIDTH;
	backgroundData[0].height = DEMO_BACKGROUND_HEIGHT;
	backgroundData[0].display[0] = 0;
	backgroundData[0].display[1] = 0;
	backgroundData[0].display[2] = 0;
	backgroundData[0].info.pixeledInfo.colorData = demo_background_data;
	backgroundData[0].info.pixeledInfo.srcX = 0;
	backgroundData[0].info.pixeledInfo.srcY = 0;
	backgroundData[0].info.pixeledInfo.pixelWidth = 0.25;
	backgroundData[0].info.pixeledInfo.pixelHeight = 0.25;
	backgroundData[0].info.pixeledInfo.pixelDepth = 10;
	backgroundData[0].info.pixeledInfo.displayWidthInPixels = 10;
	backgroundData[0].info.pixeledInfo.displayHeightInPixels = 10;
	
	while(!done)
	{
		ims->updateButtons(1);
		
		if (manipulator < 2)
		{
			if (ims->buttonDown(PU))
			{
				spriteData[manipulator].pos[1] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				spriteData[manipulator].pos[1] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				spriteData[manipulator].pos[0] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				spriteData[manipulator].pos[0] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				spriteData[manipulator].pos[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				spriteData[manipulator].pos[2] -= 0.1f;
			}
			else if (ims->buttonDown(Mash))
			{
				spriteData[manipulator].rot[0] += 2 * (GU_PI/180.0f);
			}
			else if (ims->buttonDown(YRot))
			{
				spriteData[manipulator].rot[1] += 2 * (GU_PI/180.0f);
			}
		}
		else if (manipulator == 2)
		{
			if (ims->buttonDown(PU))
			{
				cameraData.pos[1] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				cameraData.pos[1] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				cameraData.pos[0] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				cameraData.pos[0] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				cameraData.pos[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				cameraData.pos[2] -= 0.1f;
			}
			else if (ims->buttonDown(Mash))
			{
				cameraData.rot[0] += 2 * (GU_PI/180.0f);
			}
			else if (ims->buttonDown(YRot))
			{
				cameraData.rot[1] += 2 * (GU_PI/180.0f);
			}
		}
		else if (manipulator == 3)
		{
			if (ims->buttonDown(PU))
			{
				lightData[0].pos[1] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				lightData[0].pos[1] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				lightData[0].pos[0] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				lightData[0].pos[0] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				lightData[0].pos[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				lightData[0].pos[2] -= 0.1f;
			}
			else if (ims->buttonDown(Mash))
			{
				lightData[0].rot[0] += 2 * (GU_PI/180.0f);
			}
			else if (ims->buttonDown(YRot))
			{
				lightData[0].rot[1] += 2 * (GU_PI/180.0f);
			}
		}
		else if (manipulator == 4)
		{
			if (ims->buttonDown(PU))
			{
				lightData[1].rot[0] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				lightData[1].rot[0] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				lightData[1].rot[1] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				lightData[1].rot[1] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				lightData[1].rot[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				lightData[1].rot[2] -= 0.1f;
			}
			else if (ims->buttonWasPressed(Mash))
			{
				lightData[1].rot[0] = 0;
				lightData[1].rot[1] = 0;
				lightData[1].rot[2] = 0;
			}
		}
		
		if (ims->buttonWasPressed(Sp1Toggle))
		{
			manipulator++;
			manipulator%=5;
		}
		if (ims->buttonWasPressed(Sp2Toggle))
		{
			lightData[0].type++;
			lightData[0].type %= 4;
		}
		
		if (ims->buttonWasPressed(LT))
		{
			lightData[0].type++;
			lightData[0].type %= 2;
		}
		
		if (ims->buttonDown(LU))
		{
			lightData[0].strength += 0.05f;
		}
		if (ims->buttonDown(LD))
		{
			lightData[0].strength -= 0.05f;

		}
		memcpy(lightData[1].pos, cameraData.pos, sizeof(float[3]));
		
		gm->setCameraData(cameraData);
		gm->render(1);
		
		pspDebugScreenSetXY(0, 2);
		printf("Light rot %f %f %f\n", lightData[1].rot[0], lightData[1].rot[1], lightData[1].rot[2]);
	}
	
	delete renderer;
}

void test_renderer()
{
	int manipulator = 0;
	InputManagerSystem* ims = InputManagerSystem::getInstance();
	PSPInputUpdateSystem* pius = new PSPInputUpdateSystem();
	ims->setInputUpdateSystem(pius);
	ButtonId Mash = ims->registerButton("MASH", PSPInputMap::Cross);
	ButtonId YRot = ims->registerButton("YRot", PSPInputMap::Square);
	ButtonId ZoomIn = ims->registerButton("ZoomIn", PSPInputMap::L);
	ButtonId ZoomOut = ims->registerButton("ZoomOut", PSPInputMap::R);
	ButtonId PU = ims->registerButton("Up", PSPInputMap::Up);
	ButtonId PD = ims->registerButton("Down", PSPInputMap::Down);
	ButtonId PL = ims->registerButton("Left", PSPInputMap::Left);
	ButtonId PR = ims->registerButton("Right", PSPInputMap::Right);
	ButtonId LU = ims->registerButton("LU", PSPInputMap::AnalogUp);
	ButtonId LD = ims->registerButton("LD", PSPInputMap::AnalogDown);
	ButtonId LT = ims->registerButton("LightToggle", PSPInputMap::AnalogLeft);
	ButtonId Sp1Toggle = ims->registerButton("Sp1Toggle", PSPInputMap::Select);
	ButtonId Sp2Toggle = ims->registerButton("Sp2Toggle", PSPInputMap::Start);
	
	PSPRenderer* renderer = new PSPRenderer();

	CameraData cameraData;
	cameraData.pos[0] = cameraData.pos[1] = 0;
	cameraData.pos[2] = 2;
	cameraData.rot[0] = cameraData.rot[1] = cameraData.rot[2] = 0;

	// Set up local copies of SpriteData, GraphicData, BackgroundData
	SpriteData spriteData[2];
	GraphicData graphicData[2];
	
	for (int i = 0; i < 2; i++)
	{
		spriteData[i].pos[0] = spriteData[i].pos[1] = spriteData[i].pos[2] = 0;
		spriteData[i].rot[0] = spriteData[i].rot[1] = spriteData[i].rot[2] = 0;
		spriteData[i].graphicIndex = 0;
		spriteData[i].effectIndex = 0;
		spriteData[i].layerId = 0;
		spriteData[i].visible = true;
	}
	spriteData[1].graphicIndex = 1;
	
	spriteData[1].pos[0] = -1;
	spriteData[1].pos[2] = -5.0f;
	
	graphicData[0].width = 3;
	graphicData[0].height = 4;
	graphicData[0].depth = 1;
	graphicData[0].pixelData = (unsigned int*)malloc(sizeof(unsigned int) * graphicData[0].width*graphicData[0].height);
	graphicData[0].pixelData[0] = graphicData[0].pixelData[1] = graphicData[0].pixelData[2] = 0xff00ff00;
	graphicData[0].pixelData[3] = graphicData[0].pixelData[5] = 0x00000000;
	graphicData[0].pixelData[4] = 0xffffff00;
	graphicData[0].pixelData[6] = graphicData[0].pixelData[7] = graphicData[0].pixelData[8] = 0xff0000ff;
	graphicData[0].pixelData[9] = graphicData[0].pixelData[10] = graphicData[0].pixelData[11] = 0xffffffff;
	
	graphicData[1].width = 3;
	graphicData[1].height = 2;
	graphicData[1].depth = 3;
	graphicData[1].pixelData = (unsigned int*)malloc(sizeof(unsigned int) * graphicData[1].width*graphicData[1].height);
	graphicData[1].pixelData[0] = graphicData[1].pixelData[1] = graphicData[1].pixelData[2] = 0xffffffff;
	graphicData[1].pixelData[3] = graphicData[1].pixelData[5] = 0x00000000;
	graphicData[1].pixelData[4] = 0xffffffff;

	LightData lightData[4];
	lightData[0].type = lightData[1].type = lightData[2].type = lightData[3].type = LIGHT_DATA_NONE;
	lightData[0].type = LIGHT_DATA_POINT;
	lightData[0].pos[0] = spriteData[1].pos[0];
	lightData[0].pos[1] = 0;
	lightData[0].pos[2] = spriteData[1].pos[2];
	lightData[0].rot[0] = 0;
	lightData[0].rot[1] = 90 * (GU_PI/180.0f);
	lightData[0].rot[2] = 0;
	lightData[0].strength = 1.0f;
	lightData[0].color = 0xffffffff;
	
	lightData[1].type = LIGHT_DATA_SPOT;
	memcpy(lightData[1].pos, cameraData.pos, sizeof(float[3]));
	lightData[1].rot[2] = 0;
	lightData[1].strength = 1.0f;
	lightData[1].color = 0xff0000ff;
	
	
	renderer->setLightData(lightData, 4);
	
	renderer->setGraphicData(graphicData, 2);
	while(!done)
	{
		ims->updateButtons(1);
		
		if (manipulator < 2)
		{
			if (ims->buttonDown(PU))
			{
				spriteData[manipulator].pos[1] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				spriteData[manipulator].pos[1] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				spriteData[manipulator].pos[0] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				spriteData[manipulator].pos[0] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				spriteData[manipulator].pos[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				spriteData[manipulator].pos[2] -= 0.1f;
			}
			else if (ims->buttonDown(Mash))
			{
				spriteData[manipulator].rot[0] += 2 * (GU_PI/180.0f);
			}
			else if (ims->buttonDown(YRot))
			{
				spriteData[manipulator].rot[1] += 2 * (GU_PI/180.0f);
			}
		}
		else if (manipulator == 2)
		{
			if (ims->buttonDown(PU))
			{
				cameraData.pos[1] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				cameraData.pos[1] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				cameraData.pos[0] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				cameraData.pos[0] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				cameraData.pos[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				cameraData.pos[2] -= 0.1f;
			}
			else if (ims->buttonDown(Mash))
			{
				cameraData.rot[0] += 2 * (GU_PI/180.0f);
			}
			else if (ims->buttonDown(YRot))
			{
				cameraData.rot[1] += 2 * (GU_PI/180.0f);
			}
		}
		else if (manipulator == 3)
		{
			if (ims->buttonDown(PU))
			{
				lightData[0].pos[1] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				lightData[0].pos[1] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				lightData[0].pos[0] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				lightData[0].pos[0] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				lightData[0].pos[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				lightData[0].pos[2] -= 0.1f;
			}
			else if (ims->buttonDown(Mash))
			{
				lightData[0].rot[0] += 2 * (GU_PI/180.0f);
			}
			else if (ims->buttonDown(YRot))
			{
				lightData[0].rot[1] += 2 * (GU_PI/180.0f);
			}
		}
		else if (manipulator == 4)
		{
			if (ims->buttonDown(PU))
			{
				lightData[1].rot[0] += 0.1f;
			}
			else if (ims->buttonDown(PD))
			{
				lightData[1].rot[0] -= 0.1f;
			}
			else if (ims->buttonDown(PL))
			{
				lightData[1].rot[1] -= 0.1f;
			}
			else if (ims->buttonDown(PR))
			{
				lightData[1].rot[1] += 0.1f;
			}
			else if (ims->buttonDown(ZoomIn))
			{
				lightData[1].rot[2] += 0.1f;
			}
			else if (ims->buttonDown(ZoomOut))
			{
				lightData[1].rot[2] -= 0.1f;
			}
			else if (ims->buttonWasPressed(Mash))
			{
				lightData[1].rot[0] = 0;
				lightData[1].rot[1] = 0;
				lightData[1].rot[2] = 0;
			}
		}
		
		if (ims->buttonWasPressed(Sp1Toggle))
		{
			manipulator++;
			manipulator%=5;
		}
		if (ims->buttonWasPressed(Sp2Toggle))
		{
			lightData[0].type++;
			lightData[0].type %= 4;
		}
		
		if (ims->buttonWasPressed(LT))
		{
			lightData[0].type++;
			lightData[0].type %= 2;
		}
		
		if (ims->buttonDown(LU))
		{
			lightData[0].strength += 0.05f;
		}
		if (ims->buttonDown(LD))
		{
			lightData[0].strength -= 0.05f;

		}
		memcpy(lightData[1].pos, cameraData.pos, sizeof(float[3]));
		
		
		renderer->setLightData(lightData, 4);		
		renderer->setSpriteData((SpriteData*)(&spriteData), 2);
		renderer->setBackgroundData(NULL, 4);
		renderer->render(cameraData);
	}
	
	delete renderer;
}




void test_entity()
{
	float pos[3] = { -3, 0, 0 };
	float posb[3] = { 0, 0, 0 };
	float posc[3] = { -5, 0, 0 };
	float posd[3] = { 2, 2, 1};
	float rot[3] = { 0, 0, 0 };
	
	// Set up input
	InputManagerSystem* ims = InputManagerSystem::getInstance();
	PSPInputUpdateSystem* pius = new PSPInputUpdateSystem();
	ims->setInputUpdateSystem(pius);
	ButtonId MoveUp = ims->registerButton("MoveUp", PSPInputMap::Up);
	ButtonId MoveDown = ims->registerButton("MoveDown", PSPInputMap::Down);
	ButtonId MoveLeft = ims->registerButton("MoveLeft", PSPInputMap::Left);
	ButtonId MoveRight = ims->registerButton("MoveRight", PSPInputMap::Right);
	ButtonId ZoomIn = ims->registerButton("ZoomIn", PSPInputMap::L);
	ButtonId ZoomOut = ims->registerButton("ZoomOut", PSPInputMap::R);
	ButtonId CreateDummy = ims->registerButton("CreateDummy", PSPInputMap::Circle);
	ButtonId DeleteDummy = ims->registerButton("DeleteDummy", PSPInputMap::Cross);
	ButtonId togglePlayerCollision = ims->registerButton("PlayerCollision", PSPInputMap::Square);
	
	// Create the Renderer & graphics manager
	PSPRenderer* pspr = new PSPRenderer();
	GraphicsManager* gm = GraphicsManager::getInstance();
	int max;
	SpriteData* spriteData = gm->getSpriteData(&max);
	GraphicData* graphicData = gm->getGraphicData(&max);
	LightData* lightData = gm->getLightData(&max);
	BackgroundData* backgroundData = gm->getBackgroundData(&max);
	gm->setRenderer(pspr);
	
	// Set up the player graphic data
	graphicData[0].width = PLAYER_WIDTH;
	graphicData[0].height = PLAYER_HEIGHT;
	graphicData[0].depth = 0.25f;
	graphicData[0].pixelData = player_data;
	
	graphicData[1].width = 2;
	graphicData[1].height = 2;
	graphicData[1].depth = 5;
	graphicData[1].pixelData = (unsigned int*)malloc(sizeof(unsigned int) * graphicData[1].width *graphicData[1].height);
	graphicData[1].pixelData[0] = graphicData[1].pixelData[1] = 0xffff00ff;
	graphicData[1].pixelData[2] = graphicData[1].pixelData[3] = 0xff00ffff;
	graphicData[1].pixelData[3] = 0x00000000;
	
	graphicData[2].width = 1;
	graphicData[2].height = 1;
	graphicData[2].depth = 10.0f;
	graphicData[2].pixelData = (unsigned int*)malloc(sizeof(unsigned int));
	graphicData[2].pixelData[0] = 0xff00ff00;
	
	// Set up the CameraData
	CameraData cameraData;
	cameraData.pos[0] = cameraData.pos[1] = 0;
	cameraData.pos[2] = -4;
	cameraData.rot[0] = cameraData.rot[1] = cameraData.rot[2] = 0;
		
	// Set up the entity
	EntityManager* em = EntityManager::getInstance();	
	em->setupGroups(2, 1, 3);
	em->createEntity(0, "player", pos, rot, 0);
	em->createEntity(1, "dummy", posb, rot, 1);
	//em->createEntity(1, "player_following", posd, rot, 2);
	
	
	backgroundData[0].type = BACKGROUND_TYPE_PIXELED;
	backgroundData[0].width = MAP_BACKGROUND_WIDTH;
	backgroundData[0].height = MAP_BACKGROUND_HEIGHT;
	backgroundData[0].info.pixeledInfo.colorData = map_background_data;
	backgroundData[0].display[0] = -10;
	backgroundData[0].display[1] = 5;
	backgroundData[0].display[2] = 0;
	backgroundData[0].info.pixeledInfo.srcX = 0;
	backgroundData[0].info.pixeledInfo.srcY = 0;
	backgroundData[0].info.pixeledInfo.pixelWidth = 1;
	backgroundData[0].info.pixeledInfo.pixelHeight = 1;
	backgroundData[0].info.pixeledInfo.pixelDepth = 5;
	backgroundData[0].info.pixeledInfo.displayWidthInPixels = 40;
	backgroundData[0].info.pixeledInfo.displayHeightInPixels = 10;
	
	lightData[0].type = LIGHT_DATA_DIRECTION;
	lightData[0].color = 0xffffffff;
	lightData[0].strength = 1.0f;
	lightData[0].pos[0] = lightData[0].pos[1] = lightData[0].pos[2] = 0;
	lightData[0].pos[0] = 1;
	
	int dummyTag = -1;
	Entity* player = em->getEntity(0);
	float cz = -2;
	
	gm->updateAllGraphicBoxedData();
	gm->updateAllBackgroundBoxedData();
	
	while (!done)
	{
		ims->updateButtons(1);
		em->update(1);
		
		if (ims->buttonDown(ZoomIn))
		{
			cz -= 0.1f;
		}
		
		if (ims->buttonDown(ZoomOut))
		{
			cz += 0.1f;
		}
		
		if (ims->buttonWasPressed(CreateDummy) && dummyTag == -1)
		{
			dummyTag = em->createEntity(1, "dummy", posc, rot, 1);
		}
		
		if (ims->buttonWasPressed(DeleteDummy) && dummyTag != -1)
		{
			em->deleteEntity(dummyTag);
			dummyTag = -1;
		}
		
		if (ims->buttonWasPressed(togglePlayerCollision))
		{
			player->setIsPhysical(!player->isPhysical());
		}
		
		player->getPosition(cameraData.pos);
		cameraData.pos[0] *= -1;
		cameraData.pos[1] *= -1;
		cameraData.pos[2] = cz;
		
		gm->setCameraData(cameraData);
		gm->render(1);
	}
}
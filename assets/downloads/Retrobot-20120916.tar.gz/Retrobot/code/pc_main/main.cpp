#include <exception>
#include <stdlib.h>

#include <time.h>
#include <input_manager.h>
#include <graphics_manager.h>
#include <game_state_manager.h>

#include <sdl_input_manager.h>
#include <sdl_renderer.h>

void initInput()
{
        InputManagerSystem*ims = InputManagerSystem::getInstance();
        SDLInputUpdateSystem* sius = new SDLInputUpdateSystem();
        ims->setInputUpdateSystem(sius);

	ims->registerButton("StartButton", SDLInputMap::Start);
	ims->registerButton("SelectButton", SDLInputMap::Select);
	ims->registerButton("MoveUp", SDLInputMap::Up);
	ims->registerButton("MoveDown", SDLInputMap::Down);
	ims->registerButton("MoveLeft", SDLInputMap::Left);
	ims->registerButton("MoveRight", SDLInputMap::Right);
	ims->registerButton("Fire", SDLInputMap::Square);
}

void initRenderer()
{
        SDLRenderer* sdlr = new SDLRenderer();
        GraphicsManager* gm = GraphicsManager::getInstance();
        gm->setRenderer(sdlr);
}

void initGameStates()
{
	// Note that all GameState autoregister themselves
	// The Title screen GameState sets the new state automatically
}


int main(void)
{
	bool done = false;
	initInput();
	initRenderer();
	//initSound
	initGameStates();
	
	srand(clock());
	
	GameStateManager* gsm = GameStateManager::getInstance();
	unsigned int start = 0;
	unsigned int delta = 1;
	while(!gsm->isDone())
	{
		start = clock();
		gsm->update(delta);
		delta = clock() - start;
	}



	return 0;
}

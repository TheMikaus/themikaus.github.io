#include "input_manager.h"

#include "graphics_manager.h"

#include "entity_manager.h"
#include "player_entity.h"

#include "tiles.h"


#include <stdlib.h>
#include <string.h>

int done;

void test_entity()
{
	// Set up input
	InputManagerSystem* ims = InputManagerSystem::getInstance();
	
	/*
	PSPInputUpdateSystem* pius = new PSPInputUpdateSystem();
	ims->setInputUpdateSystem(pius);
	ButtonId MoveUp = ims->registerButton("MoveUp", PSPInputMap::Up);
	ButtonId MoveDown = ims->registerButton("MoveDown", PSPInputMap::Down);
	ButtonId MoveLeft = ims->registerButton("MoveLeft", PSPInputMap::Left);
	ButtonId MoveRight = ims->registerButton("MoveRight", PSPInputMap::Right);
	ButtonId ZoomIn = ims->registerButton("ZoomIn", PSPInputMap::L);
	ButtonId ZoomOut = ims->registerButton("ZoomOut", PSPInputMap::R);
	*/
	
	// Create the Renderer & graphics manager
	//PSPRenderer* pspr = new PSPRenderer();
	GraphicsManager* gm = GraphicsManager::getInstance();
	int max;
	SpriteData* spriteData = gm->getSpriteData(&max);
	GraphicData* graphicData = gm->getGraphicData(&max);
	LightData* lightData = gm->getLightData(&max);
	BackgroundData* backgroundData = gm->getBackgroundData(&max);
	//gm->setRenderer(pspr);
	
	// Set up the player graphic data
	graphicData[0].width = 1;
	graphicData[0].height = 3;
	graphicData[0].depth = 1;
	graphicData[0].pixelData = (unsigned int*)malloc(sizeof(unsigned int) * graphicData[1].width*graphicData[1].height);
	graphicData[0].pixelData[0] = 0xffffffff;
	graphicData[0].pixelData[1] = 0xffff0000;
	graphicData[0].pixelData[2] = 0xffaaaaaa;
	
	// Set up the CameraData
	CameraData cameraData;
	cameraData.pos[0] = cameraData.pos[1] = 0;
	cameraData.pos[2] = 2;
	cameraData.rot[0] = cameraData.rot[1] = cameraData.rot[2] = 0;
	
	// Set up the entity
	PlayerEntityCreator* pec = new PlayerEntityCreator();
	EntityManager* em = EntityManager::getInstance();
	float pos[3] = { 0, 0, 0 };
	float rot[3] = { 0, 0, 0 };
	em->registerEntityCreator(pec, "player");
	em->createEntity(-1, "player", pos, rot, 0);
	
	while (!done)
	{
		//ims->updateButtons(1);
		em->update(1);
		
		/*
		if (ims->buttonDown(ZoomIn))
		{
			cameraData.pos[2] -= 0.1f;
		}
		
		if (ims->buttonDown(ZoomOut))
		{
			cameraData.pos[2] += 0.1f;
		}
		
		gm->setCameraData(cameraData);
		gm->render(1);
		*/
	}
}
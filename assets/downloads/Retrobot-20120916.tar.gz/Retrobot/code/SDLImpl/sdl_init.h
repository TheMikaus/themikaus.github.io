#ifndef MY_SDL_INIT_H
#define MY_SDL_INIT_H

class SDLInit
{
        public:
                static SDLInit* getInstance();
                void init();
                void exit();

        private:
                SDLInit();
                static SDLInit* instance;
                bool initialized;
};


#endif

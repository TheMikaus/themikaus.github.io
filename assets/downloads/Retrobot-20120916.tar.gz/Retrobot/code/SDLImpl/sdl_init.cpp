#include <sdl_init.h>
#include <SDL/SDL.h>

SDLInit* SDLInit::instance = NULL;


SDLInit::SDLInit()
{
        initialized = false;
}

SDLInit* SDLInit::getInstance()
{
        if (instance == NULL)
        {
                instance = new SDLInit();
        }
        return instance;
}

void SDLInit::init()
{
        if (!initialized)
        {
                initialized = true;
                SDL_Init(SDL_INIT_JOYSTICK | SDL_INIT_VIDEO);
        }
}


void SDLInit::exit()
{
        if (initialized)
        {
                initialized = false;
                SDL_Quit();
        }
}

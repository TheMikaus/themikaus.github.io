#include "sdl_input_manager.h"
#include <sdl_init.h>

const InputMap SDLInputMap::AnalogLeft  =  1;
const InputMap SDLInputMap::AnalogRight =  2;
const InputMap SDLInputMap::AnalogUp    =  3;
const InputMap SDLInputMap::AnalogDown  =  4;
const InputMap SDLInputMap::Up          =  5;
const InputMap SDLInputMap::Down        =  6;
const InputMap SDLInputMap::Left        =  7;
const InputMap SDLInputMap::Right       =  8;
const InputMap SDLInputMap::Square      =  9;
const InputMap SDLInputMap::Triangle    = 10;
const InputMap SDLInputMap::Circle      = 11;
const InputMap SDLInputMap::Cross       = 12;
const InputMap SDLInputMap::L           = 13;
const InputMap SDLInputMap::R           = 14;
const InputMap SDLInputMap::Start       = 15;
const InputMap SDLInputMap::Select      = 16;

long SDLInputMap::mapToMask[17] =
	{	0,
		0, 0, 0, 0,
                0, 0, 0, 0,
                3, 0, 1, 2,
                6, 7, 9, 8
	};


SDLInputUpdateSystem::SDLInputUpdateSystem()
{
	SDLInit::getInstance()->init();
	if (SDL_NumJoysticks() > 0)
	{
		joy = SDL_JoystickOpen(0);
		printf("Opened Joystick 0\n");
		printf("Name: %s\n", SDL_JoystickName(0));
		printf("Number of Axes: %d\n", SDL_JoystickNumAxes(joy));
                printf("Number of Hats: %d\n", SDL_JoystickNumHats(joy));
		printf("Number of Buttons: %d\n", SDL_JoystickNumButtons(joy));
		printf("Number of Balls: %d\n", SDL_JoystickNumBalls(joy));
	}
	else
	{
		joy = NULL;
	}
}


SDLInputUpdateSystem::~SDLInputUpdateSystem()
{
	if (joy)
	{
		SDL_JoystickClose(joy);
	}
	SDLInit::getInstance()->exit();
}

bool SDLInputUpdateSystem::buttonDown(InputMap map)
{
	bool down = false;
	
	if (map < 0 || map >= 17)
	{
		throw new InputMapInvalidException(map);
	}

        if (joy == NULL) return false;
        
        if (map == SDLInputMap::AnalogLeft || map == SDLInputMap::Left)
        {
                down = (SDL_JoystickGetAxis(joy, 0) < 0);        
        }
        else if (map == SDLInputMap::AnalogRight || map == SDLInputMap::Right)
        {
                down = (SDL_JoystickGetAxis(joy, 0) > 0);
        }
        else if (map == SDLInputMap::AnalogUp || map == SDLInputMap::Up)
        {
                down = (SDL_JoystickGetAxis(joy, 1) < 0);
        }
        else if (map == SDLInputMap::AnalogDown || map == SDLInputMap::Down)
        {
                down = (SDL_JoystickGetAxis(joy, 1) > 0);
        }
        else
        {
                down = SDL_JoystickGetButton(joy, SDLInputMap::mapToMask[map]);
        }

	return down;
}

void SDLInputUpdateSystem::update()
{
	SDL_JoystickUpdate();
}

#ifndef SDL_INPUT_MANAGER_H
#define SDL_INPUT_MANAGER_H

#include "input_manager.h"
#include <SDL/SDL.h>
#include <stdio.h>

// List the input
class SDLInputMap
{
	public:
		static const InputMap AnalogLeft;
		static const InputMap AnalogRight;
		static const InputMap AnalogUp;
		static const InputMap AnalogDown;
		static const InputMap Up;
		static const InputMap Down;
		static const InputMap Left;
		static const InputMap Right;
		static const InputMap Square;
		static const InputMap Triangle;
		static const InputMap Circle;
		static const InputMap Cross;
		static const InputMap L;
		static const InputMap R;
		static const InputMap Start;
		static const InputMap Select;
		
		static long mapToMask[17];
};


class SDLInputUpdateSystem : public InputUpdateSystem
{
	public:
		SDLInputUpdateSystem();
		~SDLInputUpdateSystem();
		virtual bool buttonDown(InputMap map);
		virtual void update();
		
	private:
		SDL_Joystick* joy;
};



#endif

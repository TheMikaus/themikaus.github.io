/*
 * PSP Software Development Kit - http://www.pspdev.org
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * main.c - Basic ELF template
 *
 * Copyright (c) 2005 Marcus R. Brown <mrbrown@ocgnet.org>
 * Copyright (c) 2005 James Forshaw <tyranid@gmail.com>
 * Copyright (c) 2005 John Kelley <ps2dev@kelley.ca>
 *
 * $Id: main.c 1888 2006-05-01 08:47:04Z tyranid $
 * $HeadURL$
 */
 #include <exception>
#include <pspkernel.h>
#include <pspdebug.h>
#include <time.h>
#include <stdlib.h>

#include "input_manager.h"
#include "psp_input_manager.h"

#include "graphics_manager.h"
#include "psp_renderer.h"

#include "game_state_manager.h"

#include "title_screen_gs.h"

#include "test_code.h"


#define printf pspDebugScreenPrintf

/* Define the module info section */
PSP_MODULE_INFO("Retrobot", 0, 1, 1);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
PSP_HEAP_SIZE_KB(-1024);

void dump_threadstatus(void);

int done = 0;

/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
	done = 1;
	return 0;
}

/* Callback thread */
int CallbackThread(SceSize args, void *argp)
{
	int cbid;

	cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
	sceKernelRegisterExitCallback(cbid);
	sceKernelSleepThreadCB();

	return 0;
}

/* Sets up the callback thread and returns its thread id */
int SetupCallbacks(void)
{
	int thid = 0;

	thid = sceKernelCreateThread("update_thread", CallbackThread,
				     0x11, 0xFA0, 0, 0);
	if(thid >= 0)
	{
		sceKernelStartThread(thid, 0, 0);
	}

	return thid;
}


void initInput()
{
	InputManagerSystem* ims = InputManagerSystem::getInstance();
	PSPInputUpdateSystem* pius = new PSPInputUpdateSystem();
	ims->setInputUpdateSystem(pius);
	
	ims->registerButton("StartButton", PSPInputMap::Start);
	ims->registerButton("SelectButton", PSPInputMap::Select);
	ims->registerButton("MoveUp", PSPInputMap::Up);
	ims->registerButton("MoveDown", PSPInputMap::Down);
	ims->registerButton("MoveLeft", PSPInputMap::Left);
	ims->registerButton("MoveRight", PSPInputMap::Right);
	ims->registerButton("Fire", PSPInputMap::Square);
}

void initRenderer()
{
	PSPRenderer* pspr = new PSPRenderer();
	GraphicsManager* gm = GraphicsManager::getInstance();
	gm->setRenderer(pspr);
}

void initGameStates()
{
	// Note that all GameState autoregister themselves
	// The Title screen GameState sets the new state automatically
}

int main(void)
{
	pspDebugScreenInit();
	SetupCallbacks();

	//test_input();
	//test_renderer();
	//test_graphics();
	//test_entity();
	initInput();
	initRenderer();
	//initSound
	initGameStates();
	
	srand(clock());
	
	GameStateManager* gsm = GameStateManager::getInstance();
	unsigned int start = 0;
	unsigned int delta = 1;
	while(!done)
	{
		start = clock();
		gsm->update(delta);
		delta = clock() - start;
	}

	sceKernelExitGame();
	return 0;
}

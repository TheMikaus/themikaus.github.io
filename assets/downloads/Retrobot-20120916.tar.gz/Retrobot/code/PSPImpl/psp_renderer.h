#ifndef PSP_RENDERER_H
#define PSP_RENDERER_H

#include "graphics_manager.h"

struct Vertex 
{
   unsigned int color; 
   float nx, ny, nz;
   float x, y, z; 
}; 


struct Voxel
{
	Vertex* verticies;
  int vertCount;
};

struct VoxelizedGraphicData
{
	Voxel* voxels;
	int voxelCount;
  int vertexCount;
};

class PSPRenderer : public Renderer
{
	public:
		PSPRenderer();
		~PSPRenderer();
		virtual void setSpriteData(SpriteData* sprites, int spriteMax);
		virtual void setGraphicData(GraphicData* graphics, int graphicMax);
		virtual void setBackgroundData(BackgroundData* backgrounds, int backgroundMax);
		virtual void setLightData(LightData* lights, int lightMax);
		virtual void render(CameraData cameraData);
		
	protected:
		void drawVoxelizedGraphic(CameraData& cameraData, int graphicIndex, float pos[3], float rot[3]);
		void drawSprite(CameraData& cameraData, SpriteData& sprite);
		void drawBackground(CameraData& cameraData, BackgroundData& background);
		void drawTiledBackground(CameraData& cameraData, BackgroundData& background);
		void drawPixeledBackground(CameraData& cameraData, BackgroundData& background);
		void createVoxelizedGraphicData(GraphicData& data, int index);
		void createVoxel(Voxel& voxel, float x, float y, float depth, unsigned int color);
		void setupLights();
			
	private:
		void* fbp0;
		void* fbp1;
		void* zbp;
		SpriteData* spriteData;
		int spriteMax;
		GraphicData* graphicData;
		VoxelizedGraphicData* voxelGraphicData;
		int graphicMax;
		BackgroundData* backgroundData;
		int backgroundMax;
		LightData* lightData;
		int lightMax;
};


#endif

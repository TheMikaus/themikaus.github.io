#include "psp_renderer.h"

#include "psp_vram.h" /* Taken from the sdk */

#include <pspdisplay.h>
#include <pspgu.h>
#include <pspgum.h>

#include <stdlib.h>
#include <string.h>

#include <pspdebug.h>
#define printf pspDebugScreenPrintf

// Needed for the graphics list
static unsigned int __attribute__((aligned(16))) list[262144];


/* NOTE: a lot of the folowing code is just snippets of samples from the sdk */
#define PSP_BUF_WIDTH (512)
#define PSP_SCR_WIDTH (480)
#define PSP_SCR_HEIGHT (272)

void moveWorld(CameraData cameraData, float position[3], float rotation[3])
{
	sceGumMatrixMode(GU_PROJECTION);
	sceGumLoadIdentity();
	sceGumPerspective(75.0f,16.0f/9.0f,0.5f,1000.0f);

	sceGumMatrixMode(GU_VIEW);
	{
		ScePspFVector3 pos =
			{ cameraData.pos[0], cameraData.pos[1], cameraData.pos[2]};
		ScePspFVector3 rot =
			{ cameraData.rot[0], cameraData.rot[1], cameraData.rot[2]};
		
		sceGumLoadIdentity();
		sceGumRotateXYZ(&rot);
		sceGumTranslate(&pos);
	}	
	
	sceGumMatrixMode(GU_MODEL);
	{
		ScePspFVector3 pos =
			{ position[0], position[1], position[2]};
		ScePspFVector3 rot =
			{rotation[0], rotation[1], rotation[2]};

		sceGumLoadIdentity();
		sceGumTranslate(&pos);
		sceGumRotateXYZ(&rot);
	}
}

PSPRenderer::PSPRenderer()
{
	fbp0 = getStaticVramBuffer(PSP_BUF_WIDTH, PSP_SCR_HEIGHT, GU_PSM_8888);
	fbp1 = getStaticVramBuffer(PSP_BUF_WIDTH, PSP_SCR_HEIGHT, GU_PSM_8888);
	zbp = getStaticVramBuffer(PSP_BUF_WIDTH, PSP_SCR_HEIGHT, GU_PSM_4444);
	sceGuInit();
	
	// Set up the display
	sceGuStart(GU_DIRECT, list);
	sceGuDrawBuffer(GU_PSM_8888, fbp0, PSP_BUF_WIDTH);
	sceGuDispBuffer(PSP_SCR_WIDTH, PSP_SCR_HEIGHT, fbp1, PSP_BUF_WIDTH);
	sceGuDepthBuffer(zbp, PSP_BUF_WIDTH);
	sceGuOffset(2048 - (PSP_SCR_WIDTH/2), 2048 - (PSP_SCR_HEIGHT/2));
	sceGuViewport(2048, 2048, PSP_SCR_WIDTH, PSP_SCR_HEIGHT);
	sceGuDepthRange(65535, 0);
	sceGuScissor(0, 0, PSP_SCR_WIDTH, PSP_SCR_HEIGHT);
	sceGuEnable(GU_SCISSOR_TEST);
	sceGuDepthFunc(GU_GEQUAL);
	sceGuEnable(GU_DEPTH_TEST);
	sceGuFrontFace(GU_CCW);
	sceGuShadeModel(GU_SMOOTH);
	sceGuEnable(GU_CULL_FACE);
	sceGuEnable(GU_CLIP_PLANES);
//	sceGuEnable(GU_BLEND);	
	sceGuFinish();
	sceGuSync(0,0);

	sceDisplayWaitVblankStart();
	sceGuDisplay(GU_TRUE);
	
	voxelGraphicData = NULL;
	lightData = NULL;
	spriteData = NULL;
	backgroundData = NULL;
}


PSPRenderer::~PSPRenderer()
{
	sceGuTerm();
	free(voxelGraphicData);
}


void PSPRenderer::setSpriteData(SpriteData* sprites, int spriteMax)
{
	this->spriteData = sprites;
	this->spriteMax = spriteMax;
}

void PSPRenderer::setBackgroundData(BackgroundData* backgrounds, int backgroundMax)
{
	this->backgroundData = backgrounds;
	this->backgroundMax = backgroundMax;
}


void PSPRenderer::setLightData(LightData* lights, int lightMax)
{
	this->lightData = lights;
	this->lightMax = lightMax;
}


/* Six sides, two triangles each, 3 verts per triangle */
#define VERT_PER_VOXEL (36)
void PSPRenderer::setGraphicData(GraphicData* graphics, int graphicMax)
{
	if (voxelGraphicData != NULL)
	{
		for (int vgdIdx = 0; vgdIdx < this->graphicMax; vgdIdx++)
		{
			for (int vIdx = 0; vIdx < voxelGraphicData[vgdIdx].voxelCount; vIdx++)
			{
				free(voxelGraphicData[vgdIdx].voxels[vIdx].verticies);
			}
			if (voxelGraphicData[vgdIdx].voxels != NULL) free(voxelGraphicData[vgdIdx].voxels);
		}
		free(voxelGraphicData);
	}

	this->graphicData = graphics;
	this->graphicMax = graphicMax;
		
	voxelGraphicData = (VoxelizedGraphicData*)malloc(sizeof(VoxelizedGraphicData) * graphicMax);
	for (int vIdx = 0; vIdx < graphicMax; vIdx++)
	{
		if (graphics[vIdx].pixelData != NULL)
		{
			createVoxelizedGraphicData(graphics[vIdx], vIdx);
		}
		else
		{
			voxelGraphicData[vIdx].voxels = NULL;
			voxelGraphicData[vIdx].voxelCount = 0;
		}
	}
}


inline void setVoxelVerticiesFront(Vertex* verticies, float x, float y, float w, float h, unsigned int color)
{
	// Front Face
	verticies[0] = {color, 0, 0, 1, x, y, 0};
	verticies[1] = {color, 0, 0, 1, x+w, y, 0};
	verticies[2] = {color, 0, 0, 1, x+w, y+h, 0};
	verticies[3] = {color, 0, 0, 1, x+w, y+h, 0};
	verticies[4] = {color, 0, 0, 1, x, y+h, 0};
	verticies[5] = {color, 0, 0, 1, x, y, 0};
}

inline void setVoxelVerticiesLeft(Vertex* verticies, float x, float y, float w, float h, float depth, unsigned int color)
{
	// LEFT
	verticies[0] = {color, -1, 0, 0, x, y, 0};
	verticies[1] = {color, -1, 0, 0, x, y+h, 0};
	verticies[2] = {color, -1, 0, 0, x, y+h, -depth};
	verticies[3] = {color, -1, 0, 0, x, y+h, -depth};
	verticies[4] = {color, -1, 0, 0, x, y, -depth};
	verticies[5] = {color, -1, 0, 0, x, y, 0};
}

inline void setVoxelVerticiesRight(Vertex* verticies, float x, float y, float w, float h, float depth, unsigned int color)
{
	// RIGHT
	verticies[0] = {color, 1, 0, 0, x+w, y+h, 0};
	verticies[1] = {color, 1, 0, 0, x+w, y, 0};
	verticies[2] = {color, 1, 0, 0, x+w, y, -depth};
	verticies[3] = {color, 1, 0, 0, x+w, y, -depth};
	verticies[4] = {color, 1, 0, 0, x+w, y+h, -depth};
	verticies[5] = {color, 1, 0, 0, x+w, y+h, 0};
}

inline void setVoxelVerticiesTop(Vertex* verticies, float x, float y, float w, float h, float depth, unsigned int color)
{
	// TOP
	verticies[0] = {color, 0, 1, 0, x, y+h, 0};
	verticies[1] = {color, 0, 1, 0, x+w, y+h, 0};
	verticies[2] = {color, 0, 1, 0, x+w, y+h, -depth};
	verticies[3] = {color, 0, 1, 0, x+w, y+h, -depth};
	verticies[4] = {color, 0, 1, 0, x, y+h, -depth};
	verticies[5] = {color, 0, 1, 0, x, y+h, 0};
}

inline void setVoxelVerticiesBottom(Vertex* verticies, float x, float y, float w, float h, float depth, unsigned int color)
{
	// BOTTOM
	verticies[0] = {color, 0, -1, 0, x, y, 0};
	verticies[1] = {color, 0, -1, 0, x, y, -depth};
	verticies[2] = {color, 0, -1, 0, x+w, y, -depth};
	verticies[3] = {color, 0, -1, 0, x+w, y, -depth};
	verticies[4] = {color, 0, -1, 0, x+w, y, 0};
	verticies[5] = {color, 0, -1, 0, x, y, 0};
}

inline void setVoxelVerticiesBack(Vertex* verticies, float x, float y, float w, float h, float depth, unsigned int color)
{
	// BACK
	verticies[0] = {color, 0, 0, -1, x, y, -depth};
	verticies[1] = {color, 0, 0, -1, x, y+h, -depth};
	verticies[2] = {color, 0, 0, -1, x+w, y+h, -depth};
	verticies[3] = {color, 0, 0, -1, x+w, y+h, -depth};
	verticies[4] = {color, 0, 0, -1, x+w, y, -depth};
	verticies[5] = {color, 0, 0, -1, x, y, -depth};
}

void setVoxelVerticies(Vertex* verticies, float x, float y, float w, float h, float depth, unsigned int color)
{
	setVoxelVerticiesFront(verticies, x, y, w, h, color);
	setVoxelVerticiesLeft(&verticies[6], x, y, w, h, depth, color);
	setVoxelVerticiesRight(&verticies[12], x, y, w, h, depth, color);
	setVoxelVerticiesTop(&verticies[18], x, y, w, h, depth, color);
	setVoxelVerticiesBottom(&verticies[24], x, y, w, h, depth, color);
	setVoxelVerticiesBack(&verticies[30], x, y, w, h, depth, color);
}

void PSPRenderer::createVoxel(Voxel& voxel, float x, float y, float depth, unsigned int color)
{
	voxel.verticies = (Vertex*) malloc(sizeof(Vertex)*VERT_PER_VOXEL);
	setVoxelVerticies(voxel.verticies, x, y, 1, 1, depth, color);
}

void PSPRenderer::createVoxelizedGraphicData(GraphicData& data, int index)
{
	int voxelCount = 0;
	VoxelizedGraphicData* vgd = &voxelGraphicData[index];
	vgd->voxelCount = voxelCount;
	
	// Count visible pixels
	for (int hIdx = 0; hIdx < data.height; hIdx++)
	{
		for (int wIdx = 0; wIdx < data.width; wIdx++)
		{
			if ( (data.pixelData[(hIdx*data.width)+wIdx] && 0xff000000))
			{
				voxelCount++;
			}
		}
	}
	vgd->voxelCount = voxelCount;
	vgd->vertexCount = voxelCount * VERT_PER_VOXEL;
	vgd->voxels = (Voxel*)malloc(sizeof(VoxelizedGraphicData)*voxelCount);

	voxelCount = 0;
	
	for (int hIdx = 0; hIdx < data.height; hIdx++)
	{
		for (int wIdx = 0; wIdx < data.width; wIdx++)
		{
			if ( (data.pixelData[(hIdx*data.width)+wIdx] && 0xff000000))
			{
				createVoxel(vgd->voxels[voxelCount],
					wIdx, data.height - hIdx - 1, data.depth, data.pixelData[(hIdx * data.width) + wIdx]);
				voxelCount++;
			}
		}
	}
}


void PSPRenderer::drawVoxelizedGraphic(CameraData& cameraData, int graphicIndex, float pos[3], float rot[3])
{
	VoxelizedGraphicData* vgd = &voxelGraphicData[graphicIndex];
	Vertex* verticies = (struct Vertex*)sceGuGetMemory(vgd->vertexCount * sizeof(struct Vertex)); 
	
	for (int vIdx = 0; vIdx < vgd->voxelCount; vIdx++)
	{
		memcpy(&(verticies[vIdx * VERT_PER_VOXEL]),
			vgd->voxels[vIdx].verticies,
			sizeof(struct Vertex) * VERT_PER_VOXEL);
	}
	
	moveWorld(cameraData, pos, rot);
	sceGumDrawArray(GU_TRIANGLES,GU_NORMAL_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,vgd->vertexCount,0,verticies);
}


void PSPRenderer::drawSprite(CameraData& cameraData, SpriteData& sprite)
{
	drawVoxelizedGraphic(cameraData, sprite.graphicIndex, sprite.pos, sprite.rot);
}


void PSPRenderer::drawTiledBackground(CameraData& cameraData, BackgroundData& background)
{
	int startX = background.info.tiledInfo.srcXInTiles;
	int startY = background.info.tiledInfo.srcYInTiles;
	int endX = startX + background.info.tiledInfo.displayWidthInTiles;
	int endY = startY + background.info.tiledInfo.displayHeightInTiles;
	int tIdx;
	if (endX > background.width) endX = background.width;
	if (endY > background.height) endY = background.height;
	float dummyRot[3] = { 0, 0, 0};
	float tileOffsetPos[3];
	int offsetX = 0;
	int offsetY = 0;
	
	for (int yIdx = startY; yIdx < endY; yIdx++)
	{
		for (int xIdx = startX; xIdx < endX; xIdx++)
		{
			tIdx = yIdx * background.width + xIdx;
			if (background.info.tiledInfo.tileData[tIdx] != -1)
			{
				tileOffsetPos[0] = background.display[0] + (offsetX * background.info.tiledInfo.tileWidth);
				tileOffsetPos[1] = background.display[1] + (offsetY * background.info.tiledInfo.tileHeight);
				tileOffsetPos[2] = background.display[2];
				drawVoxelizedGraphic(cameraData, background.info.tiledInfo.tileData[tIdx], tileOffsetPos, dummyRot);
			}
			offsetX++;
		}
		offsetY++;
		offsetX=0;
	}

}

void PSPRenderer::drawPixeledBackground(CameraData& cameraData, BackgroundData& background)
{
	int endX = background.info.pixeledInfo.srcX + background.info.pixeledInfo.displayWidthInPixels;
	int endY = background.info.pixeledInfo.srcY + background.info.pixeledInfo.displayHeightInPixels;
	if (endX > background.width) endX = background.width;
	if (endY > background.height) endY = background.height;
	float pos[3];
	float rot[3] = { 0, 0, 0};
	unsigned int color;
	int pIdx;
	Vertex* verticies;
	pos[0] = background.display[0];
	pos[1] = background.display[1];
	pos[2] = background.display[2];

	int vertCount = 0;
	int srcX = background.info.pixeledInfo.srcX;
	int srcY = background.info.pixeledInfo.srcY;
	float x = 0;
	float y = (endY - srcY) * background.info.pixeledInfo.pixelHeight;
	int lc, rc, uc, dc;
	int w = background.info.pixeledInfo.pixelWidth;
	int h = background.info.pixeledInfo.pixelHeight;
	int depth = background.info.pixeledInfo.pixelDepth;
	int npIdx;
	#define IS_COLORED(index) (background.info.pixeledInfo.colorData[index] & 0xff000000)
	for (int yIdx = srcY; yIdx < endY; yIdx++)
	{
		for (int xIdx = srcX; xIdx < endX; xIdx++)
		{
			pIdx = yIdx * background.width + xIdx;
			color = background.info.pixeledInfo.colorData[pIdx];
			if ( (color & 0xff000000) )
			{
				vertCount += 12;
				
				// Check above, below, left and right
				lc = ((xIdx - 1 >= srcX && !IS_COLORED(pIdx - 1)) || xIdx - 1 < srcX);
				rc = ((xIdx + 1 < endX && !IS_COLORED(pIdx + 1)) || xIdx + 1 == endX);
				npIdx = pIdx - background.width;
				uc = ((yIdx - 1 >= srcY && !IS_COLORED(npIdx)) || yIdx - 1 < srcY);
				npIdx = pIdx + background.width;
				dc = ((yIdx + 1 < endY && !IS_COLORED(npIdx)) || yIdx + 1 == endY);
				if (lc) vertCount += 6;
				if (rc) vertCount += 6;
				if (uc) vertCount += 6;
				if (dc) vertCount += 6;
			}
		}
	}

  verticies = (struct Vertex*)sceGuGetMemory(vertCount*sizeof(struct Vertex));
  vertCount = 0;
	for (int yIdx = srcY; yIdx < endY; yIdx++)
	{
		for (int xIdx = srcX; xIdx < endX; xIdx++)
		{
			pIdx = yIdx * background.width + xIdx;
			color = background.info.pixeledInfo.colorData[pIdx];
			if ( (color & 0xff000000) )
			{
				// Check above, below, left and right
				lc = ((xIdx - 1 >= srcX && !IS_COLORED(pIdx - 1)) || xIdx - 1 < srcX);
				rc = ((xIdx + 1 < endX && !IS_COLORED(pIdx + 1)) || xIdx + 1 == endX);
				npIdx = pIdx - background.width;
				uc = ((yIdx - 1 >= srcY && !IS_COLORED(npIdx)) || yIdx - 1 < srcY);
				npIdx = pIdx + background.width;
				dc = ((yIdx + 1 < endY && !IS_COLORED(npIdx)) || yIdx + 1 == endY);
				
				setVoxelVerticiesFront(&verticies[vertCount], x, y, w, h, color);
        vertCount += 6;
				setVoxelVerticiesBack(&verticies[vertCount], x, y, w, h, depth, color);
				vertCount += 6;
				
				if (lc)
				{
					setVoxelVerticiesLeft(&verticies[vertCount], x, y, w, h, depth, color);
					vertCount += 6;
				}
				
				if (rc)
				{
					setVoxelVerticiesRight(&verticies[vertCount], x, y, w, h, depth, color);
					vertCount += 6;
				}
				
				if (uc)
				{
					setVoxelVerticiesTop(&verticies[vertCount], x, y, w, h, depth, color);
					vertCount += 6;
				}
				
				if (dc)
				{
					setVoxelVerticiesBottom(&verticies[vertCount], x, y, w, h, depth, color);
					vertCount += 6;
				}
			}
			x += background.info.pixeledInfo.pixelWidth;
		}
		x = 0;
		y -= background.info.pixeledInfo.pixelHeight;
	}

  moveWorld(cameraData, pos, rot);
  sceGumDrawArray(GU_TRIANGLES,GU_NORMAL_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,vertCount,0,verticies);

}

void PSPRenderer::drawBackground(CameraData& cameraData, BackgroundData& background)
{
	if (background.type == BACKGROUND_TYPE_TILED)
	{
		drawTiledBackground(cameraData, background);
	}
	else if(background.type == BACKGROUND_TYPE_PIXELED)
	{
		drawPixeledBackground(cameraData, background);
	}
}



void setupPointLight(LightData& lightData, int& i)
{
	ScePspFVector3 pos = { lightData.pos[0], lightData.pos[1], lightData.pos[2] };
	sceGuLight(i,GU_POINTLIGHT,GU_DIFFUSE_AND_SPECULAR,&pos);
	sceGuLightColor(i,GU_DIFFUSE,lightData.color);
	sceGuLightColor(i,GU_SPECULAR,lightData.color);
	sceGuLightAtt(i,0.0f,lightData.strength,0.0f);
}

void setupSpotLight(LightData& lightData, int& i)
{
	ScePspFVector3 pos = { lightData.pos[0], lightData.pos[1], lightData.pos[2] };
	ScePspFVector3 rot = { lightData.rot[0], lightData.rot[1], lightData.rot[2] };
	sceGuLight(i,GU_SPOTLIGHT,GU_DIFFUSE_AND_SPECULAR,&pos);
	sceGuLightSpot(i, &rot, lightData.strength, 30.0f * (GU_PI/180.0));
	sceGuLightColor(i,GU_DIFFUSE,lightData.color);
	sceGuLightColor(i,GU_SPECULAR,lightData.color);
	//sceGuLightAtt(i,0.0f,lightData.strength,0.0f);
}

void setupDirectionalLight(LightData& lightData, int& i)
{
	ScePspFVector3 pos = { lightData.pos[0], lightData.pos[1], lightData.pos[2] };
	ScePspFVector3 rot = { lightData.rot[0], lightData.rot[1], lightData.rot[2] };
	sceGuLight(i,GU_DIRECTIONAL,GU_DIFFUSE_AND_SPECULAR,&pos);
	sceGuLightColor(i,GU_DIFFUSE,lightData.color);
	sceGuLightColor(i,GU_SPECULAR,lightData.color);
	sceGuLightAtt(i,0.0f,lightData.strength,0.0f);
}

void setupLight(LightData& lightData, int& i)
{
	if (lightData.type == LIGHT_DATA_POINT) setupPointLight(lightData, i);
	else if (lightData.type == LIGHT_DATA_SPOT) setupSpotLight(lightData, i);
	else if (lightData.type == LIGHT_DATA_DIRECTION) setupDirectionalLight(lightData, i);
}


void PSPRenderer::setupLights()
{
	bool lightOn = false;
	bool lightsOn[4];
	
	if (lightData == NULL) return;
	
	// There are four lights max in the PSP renderer, assume that is the minimum sent in
	for (int lIdx = 0; lIdx < 4; lIdx++)
	{
		lightsOn[lIdx] = lightData[lIdx].type != LIGHT_DATA_NONE;
		lightOn = lightOn || lightsOn[lIdx];
	}
	
	int mask[4] = { GU_LIGHT0, GU_LIGHT1, GU_LIGHT2, GU_LIGHT3 };
	
	if (lightOn)
	{
		sceGuEnable(GU_LIGHTING);
		for (int lIdx = 0; lIdx < 4; lIdx++)
		{
			if (lightsOn[lIdx])
			{
				sceGuEnable(mask[lIdx]);
				setupLight(lightData[lIdx], lIdx);
			}
			else
			{
				sceGuDisable(mask[lIdx]);
			}
		}
	}
	else
	{
		sceGuDisable(GU_LIGHTING);
	}

}

void PSPRenderer::render(CameraData cameraData)
{
	int val = 0;
  int cleared = 0;
	
	// Start Clean up here
	// Clear the screen
	
	for (int bIdx = 0; bIdx < backgroundMax; bIdx++)
	{
    sceGuStart(GU_DIRECT, list);
    if (cleared == 0)
    {
      sceGuClearColor(0xff000000); 
      sceGuClearDepth(0);
      sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);
      cleared = 1;
    }

    setupLights();

    sceGuSpecular(12.0f); // TODO: why twelve?
    sceGuAmbient(0x00888888);
    sceGuAmbientColor(0xffffffff); 
    sceGuColor(0xffffff);


		for (int sIdx = 0; sIdx < spriteMax; sIdx++)
		{
			if (spriteData[sIdx].visible && spriteData[sIdx].layerId == bIdx)
			{
				drawSprite(cameraData, spriteData[sIdx]);
			}
		}
		drawBackground(cameraData, backgroundData[bIdx]);
    sceGuFinish();
    sceGuSync(0, 0);
	}

	// Finish up the frame
	sceDisplayWaitVblankStart();
	sceGuSwapBuffers();
}

#include "psp_input_manager.h"


const InputMap PSPInputMap::AnalogLeft  =  1;
const InputMap PSPInputMap::AnalogRight =  2;
const InputMap PSPInputMap::AnalogUp    =  3;
const InputMap PSPInputMap::AnalogDown  =  4;
const InputMap PSPInputMap::Up          =  5;
const InputMap PSPInputMap::Down        =  6;
const InputMap PSPInputMap::Left        =  7;
const InputMap PSPInputMap::Right       =  8;
const InputMap PSPInputMap::Square      =  9;
const InputMap PSPInputMap::Triangle    = 10;
const InputMap PSPInputMap::Circle      = 11;
const InputMap PSPInputMap::Cross       = 12;
const InputMap PSPInputMap::L           = 13;
const InputMap PSPInputMap::R           = 14;
const InputMap PSPInputMap::Start       = 15;
const InputMap PSPInputMap::Select      = 16;

long PSPInputMap::mapToMask[17] =
	{	0,
		0, 0, 0, 0,
		PSP_CTRL_UP, PSP_CTRL_DOWN,
		PSP_CTRL_LEFT, PSP_CTRL_RIGHT,
		PSP_CTRL_SQUARE, PSP_CTRL_TRIANGLE,
		PSP_CTRL_CIRCLE, PSP_CTRL_CROSS,
		PSP_CTRL_LTRIGGER, PSP_CTRL_RTRIGGER,
		PSP_CTRL_START, PSP_CTRL_SELECT
	};


PSPInputUpdateSystem::PSPInputUpdateSystem()
{
	sceCtrlSetSamplingCycle(0);
	sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

}

bool PSPInputUpdateSystem::buttonDown(InputMap map)
{
	bool down = false;
	
	if (map < 0 || map >= 17)
	{
		throw new InputMapInvalidException(map);
	}
	
	int mask = PSPInputMap::mapToMask[map];
	
	if (PSPInputMap::AnalogLeft == map)
	{
		down = pad.Lx < 55;
	}
	else if (PSPInputMap::AnalogRight == map)
	{
		down = pad.Lx > 200;
	}
	else if (PSPInputMap::AnalogUp == map)
	{
		down = pad.Ly < 55;
	}
	else if (PSPInputMap::AnalogDown == map)
	{
		down = pad.Ly > 200;
	}
	else
	{
		down = pad.Buttons & mask;
	}
	
	return down;
}

void PSPInputUpdateSystem::update()
{
	sceCtrlReadBufferPositive(&pad, 1); 
}
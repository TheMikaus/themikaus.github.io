#ifndef BULLET_ENT_H
#define BULLET_ENT_H

#include <input_manager.h>
#include <entity_manager.h>

#include <string>

class UpgradeEntityCreator : public EntityCreator
{
	public:
		UpgradeEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class UpgradeEntity : public Entity
{
	public:
		UpgradeEntity();
		virtual ~UpgradeEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual const char* getName();
		virtual void message(const char* messageName, int data);
		virtual void setStartingGraphicIndex(int index);

	private:
		float cycleTime;
		int display;
		float vel[2];
};


#endif
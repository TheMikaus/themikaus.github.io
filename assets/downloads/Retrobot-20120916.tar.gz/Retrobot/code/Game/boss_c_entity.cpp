#include <boss_c_entity.h>
#include <bullet_entity.h>

#include <string.h>
#include <math.h>

bool BossCEntityCreator::registered = false;
BossCEntityCreator theBossCEntityCreator;

BossCEntityCreator::BossCEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "boss_c");
	}
}

Entity* BossCEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	BossCEntity* bossEntity = new BossCEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	bossEntity->setSpriteIndex(spriteIndex);
	bossEntity->setGraphicIndex(graphicIndex);
	bossEntity->setPosition(pos);
	bossEntity->setRotation(rot);
	bossEntity->getSpriteData()->layerId = 0;
	bossEntity->setStartingPosition(pos);
	return bossEntity;
}


#define BOSS_MOVEMENT_SPEED (0.5f)
BossCEntity::BossCEntity()
{
	setHealthMax(10);
	setHealth(getHealthMax());
	player = NULL;
	canShoot = true;
	ims = InputManagerSystem::getInstance();
	em = EntityManager::getInstance();
	setIsPhysical(true);
	speed = BOSS_MOVEMENT_SPEED;
	shootDelay = 0;
	type = 0;
	target = 0;
	waitInPlace = 60.0;
}

void BossCEntity::setType(int type)
{
	this->type = type;
}

BossCEntity::~BossCEntity()
{
}


void BossCEntity::setCanShoot(bool shoot)
{
	canShoot = shoot;
}

void BossCEntity::setSpeed(float speed)
{
	this->speed = speed;
}


void BossCEntity::setStartingPosition(float* pos)
{
	startingPosition[0] = pos[0];
	startingPosition[1] = pos[1];
	
	targetPositions[0] = pos[1];
	targetPositions[1] = targetPositions[0] - 24.0;
	targetPositions[2] = targetPositions[1] - 24.0;
	targetPositions[3] = targetPositions[2] - 24.0;
}

void BossCEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;

	if (isDead())
	{
		justDied();
	}
	else if (spriteData != NULL)
	{
		spriteData->visible = true;
		if (player == NULL)
		{
			int max;
			Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(-1, max);
			for (int eIdx = 0; eIdx < max; eIdx++)
			{
				if (strcmp(entities[eIdx]->getName(), "player") == 0)
				{
					player = (DamageableEntity*)entities[eIdx];
					break;
				}
			}
		}
		
		SpriteData* spriteData = getSpriteData();
		float pBottom = player->getSpriteData()->pos[1];
		float pTop = player->getGraphicData()->height + pBottom;
		float bGun = spriteData->pos[1] + 4.0;
		
		if (waitInPlace > 0)
		{
			waitInPlace -= dT;
			target = closestTarget(pBottom);
		}
		else if (shootDelay <= 0)
		{
			shootDelay = 30.0;
			int bulletCount;
			Entity** bullets = em->getEntitiesInGroup(3, bulletCount);
			for (int bIdx = 0; bIdx < bulletCount; bIdx++)
			{
				if (bullets[bIdx] == NULL)
				{
				
					float rot[3] = {0.0, 0.0, 0.0};
					float pos[3];
					pos[0] = spriteData->pos[0];
					pos[0] -= getGraphicData()->width;
					pos[1] = spriteData->pos[1] + 4.0;
					pos[2] = spriteData->pos[2];
					
					int bTag = em->createEntity(3, "bullet", pos, rot, 3);
					if (bTag != -1)
					{
						BulletEntity* bullet = (BulletEntity*)em->getEntity(bTag);
						float bSpeed = -5.0;
						bullet->setSpeed(bSpeed);
						bullet->setOwner(this);
						bullet->setSpecialData(getSpecialData());
						bullet->setDamage(2);
					}
					break;
				}
			}
		}
		else 
		{
			float distance = spriteData->pos[1] - targetPositions[target];
			if (distance > 0.5f)
			{
				spriteData->pos[1] -= speed * dT;
			}
			else if (distance < -0.5f)
			{
				spriteData->pos[1] += speed * dT;
			}
			else
			{
				waitInPlace = 60.0f;
			}
		}
		
		if (shootDelay > 0)
		{
			shootDelay -= dT;
		}
	}
}

int BossCEntity::closestTarget(float pos)
{
	int closest = 0;
	float minDistance = fabs(targetPositions[0] - pos);

	for (int tIdx = 0; tIdx < 4; tIdx++)
	{
		if (fabs(targetPositions[tIdx] - pos) < minDistance)
		{
			minDistance = fabs(targetPositions[tIdx] - pos);
			closest = tIdx;
		}
	}
	
	return closest;
}

void BossCEntity::message(char const* messageName, int data)
{
	if (strcmp(messageName, "damage") == 0)
	{
		addHealth(-data);
	}
}


void BossCEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	restorePosRotData();

	if (collidingObj != NULL)
	{
        if (strcmp(collidingObj->getName(), "player") == 0)
        {
            collidingObj->message("damage", 10);
        }
	}
}


void BossCEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
	int max;
	player->message("increment_boss_count", 0);
	
	Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(1, max);
	for (int eIdx = 0; eIdx < max; eIdx++)
	{
		if (entities[eIdx] != NULL && strcmp(entities[eIdx]->getName(), "door") == 0)
		{
			entities[eIdx]->message("open", type);
		}
	}
	
	// TODO: FIX THIS.
	//       Currently using a hard coded graphic index.
	//       These indexes should be inherent to the entity (register with the GM?)
	float rot[3] = {0.0, 0.0, 0.0};
	em->createEntity(3, "upgrade", getSpriteData()->pos, rot, 5);
	EntityManager::getInstance()->deleteEntity(getTagId());
}


void BossCEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* BossCEntity::getName()
{
	return "boss_c";
}

#include <title_screen_gs.h>
#include <tiles.h>
#include <player_entity.h>


TitleScreenGameState onlyOneTSGS;


TitleScreenGameState::TitleScreenGameState()
{
	GameStateManager* gsm = GameStateManager::getInstance();
	gsm->registerState("TitleScreen", this);
	gsm->setNewState("TitleScreen");
}


void TitleScreenGameState::init()
{
	int max;
	GraphicData* graphicData = gm->getGraphicData(&max);
	graphicData[0].width = PLAYER_WIDTH;
	graphicData[0].height = PLAYER_HEIGHT;
	graphicData[0].depth = 0.5f;
	graphicData[0].pixelData = player_data;


	BackgroundData* bData = gm->getBackgroundData(&max);
	bData[0].type = BACKGROUND_TYPE_PIXELED;
	bData[0].width = TITLESCREEN_WIDTH;
	bData[0].height = TITLESCREEN_HEIGHT;
	bData[0].info.pixeledInfo.colorData = titlescreen_data;
	bData[0].display[0] = -40;
	bData[0].display[1] = 0;
	bData[0].display[2] = 0;
	bData[0].info.pixeledInfo.srcX = 0;
	bData[0].info.pixeledInfo.srcY = 0;
	bData[0].info.pixeledInfo.pixelWidth = 1;
	bData[0].info.pixeledInfo.pixelHeight = 1;
	bData[0].info.pixeledInfo.pixelDepth = 5;
	bData[0].info.pixeledInfo.displayWidthInPixels = bData[0].width;
	bData[0].info.pixeledInfo.displayHeightInPixels = bData[0].height;
	
	bData[1].type = BACKGROUND_TYPE_PIXELED;
	bData[1].width = TS_PRESSSTART_WIDTH;
	bData[1].height = TS_PRESSSTART_HEIGHT;
	bData[1].info.pixeledInfo.colorData = ts_pressstart_data;
	bData[1].display[0] = -40;
	bData[1].display[1] = -20;
	bData[1].display[2] = 0;
	bData[1].info.pixeledInfo.srcX = 0;
	bData[1].info.pixeledInfo.srcY = 0;
	bData[1].info.pixeledInfo.pixelWidth = 1;
	bData[1].info.pixeledInfo.pixelHeight = 1;
	bData[1].info.pixeledInfo.pixelDepth = 5;
	bData[1].info.pixeledInfo.displayWidthInPixels = bData[0].width;
	bData[1].info.pixeledInfo.displayHeightInPixels = bData[0].height;
	
	
	
	CameraData cameraData;
	cameraData.pos[0] = cameraData.pos[1] = 0;
	cameraData.pos[2] = -40;
	cameraData.rot[0] = cameraData.rot[1] = cameraData.rot[2] = 0;
	gm->setCameraData(cameraData);
	
	LightData* lightData = gm->getLightData(&max);
	lightData[0].type = LIGHT_DATA_DIRECTION;
	lightData[0].color = 0xffffffff;
	lightData[0].strength = 1.0f;
	lightData[0].pos[0] = 0;
	lightData[0].pos[1] = 0.25;
	lightData[0].pos[2] = 0.25;
	
	startButton = im->findButton("StartButton");
        selectButton = im->findButton("SelectButton");
	
	
	float pos[3] = {0.0, -10.0, -10};
	float rot[3] = {0.0, 0.0, 0.0};
	playerId = em->createEntity(-1, "player", pos, rot, 0);
	PlayerEntity* player = (PlayerEntity*)em->getEntity(playerId);
	player->setIsPhysical(false);
	player->setSpeed(1.0f);
	gm->updateAllGraphicBoxedData();
	gm->updateAllBackgroundBoxedData();
        gm->setGraphicDataOutOfDate();
}


void TitleScreenGameState::update(long deltaTime)
{
	im->updateButtons(deltaTime);
	if (im->buttonWasPressed(startButton))
	{
		GameStateManager::getInstance()->setNewState("MainGame");
	}
        if (im->buttonWasPressed(selectButton))
        {
                GameStateManager::getInstance()->exit();       
        }
	em->update(deltaTime);
	gm->render(deltaTime);
}


void TitleScreenGameState::destroy()
{
	int max;
	// TODO: clean up all the resources
	em->deleteEntity(playerId);
	em->update(0);
	BackgroundData* bData = gm->getBackgroundData(&max);
	bData[0].type = BACKGROUND_TYPE_NONE;
	bData[1].type = BACKGROUND_TYPE_NONE;
}

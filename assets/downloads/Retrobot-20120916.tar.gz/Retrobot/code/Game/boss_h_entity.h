#ifndef BOSS_H_ENT_H
#define BOSS_H_ENT_H

#include <input_manager.h>
#include <entity_manager.h>
#include <damageable_entity.h>

#include <string>

class BossHEntityCreator : public EntityCreator
{
	public:
		BossHEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class BossHEntity : public DamageableEntity
{
	public:
		BossHEntity();
		virtual ~BossHEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual void setType(int type);
		virtual const char* getName();
		virtual void message(const char* messageName, int data);
		void setSpeed(float speed);
		void setCanShoot(bool shoot);
		void setStartingPosition(float* pos);

	private:
		InputManagerSystem* ims;
		EntityManager* em;
		DamageableEntity* player;
		
		int type;
		
		float speed;
		float waitInPlace;
		int target;
		bool canShoot;
		float shootDelay;
		float bombDelay;
		int shotCount;
		
		float startingPosition[2];
		float targetPositions[40][2];
};


#endif
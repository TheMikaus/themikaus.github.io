#include <bullet_entity.h>

#include <stdio.h>
#include <string.h>
#include <math.h>

bool BulletEntityCreator::registered = false;
BulletEntityCreator theBulletEntityCreator;

BulletEntityCreator::BulletEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "bullet");
	}
}

Entity* BulletEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	BulletEntity* bulletEntity = new BulletEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	bulletEntity->setSpriteIndex(spriteIndex);
	bulletEntity->setGraphicIndex(graphicIndex);
	bulletEntity->setPosition(pos);
	bulletEntity->setRotation(rot);
	bulletEntity->getSpriteData()->layerId = 0;
	bulletEntity->setIsPhysical(true);
	bulletEntity->setSpeed(8.0f);
	
	return bulletEntity;
}


BulletEntity::~BulletEntity()
{
}

BulletEntity::BulletEntity()
{
	timeToLive = 60.0;
	speed = 0;
	damage = 1;
	owner = NULL;
}

void BulletEntity::setSpeed(float speed)
{
	this->speed = speed;
}

void BulletEntity::setOwner(Entity* owner)
{
	this->owner = owner;
}


void BulletEntity::setDamage(int damage)
{
	this->damage = damage;
}

void BulletEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;
	float xSpeed;
	float ySpeed;
	
	timeToLive -= dT;
	if (timeToLive < 0)
	{
		getSpriteData()->visible = false;
		EntityManager::getInstance()->deleteEntity(getTagId());
	}
	else
	{
		float rotation = getSpriteData()->rot[2];
		
		xSpeed = cos(rotation) * speed;
		ySpeed = sin(rotation) * speed;
		getSpriteData()->pos[0] += dT * xSpeed;
		getSpriteData()->pos[1] += dT * ySpeed;
	}
}


void BulletEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	if (collidingObj != owner)
	{
		if (collidingObj == NULL)
		{
			EntityManager::getInstance()->deleteEntity(getTagId());
		}
		else if(strcmp(collidingObj->getName(), "bullet") != 0)
		{
			EntityManager::getInstance()->deleteEntity(getTagId());
			collidingObj->message("damage", damage);
		}
	}
	
}



void BulletEntity::message(const char* messageName, int data)
{
	// TODO: DO NOTHING!
}

void BulletEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
}


void BulletEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* BulletEntity::getName()
{
	return "bullet";
}

#include <game_map.h>

#include <stdlib.h>

unsigned int* createBackgroundData(int w, int h, unsigned int* mapData)
{
	unsigned int* data = (unsigned int*)malloc(sizeof(unsigned int) * w * h);
	
	for (int y = 0; y < h; y++)
	{
		for (int x = 0; x < w; x++)
		{
			int dIdx = x + y * w;
			if (mapData[dIdx] == 0xffffffff)
			{
				data[dIdx] = 0xffffffff;
			}
			else
			{
				data[dIdx] = 0x00;
			}
		}
	}
	
	
	return data;
}


void updateScreenData( GameMapData* gameMapData, int sx, int sy, int w, int h, unsigned int* mapData)
{
	int sIdx = sx + sy * gameMapData->screenDataWidth;
	ScreenData* screenData = &(gameMapData->screenData[sIdx]);

	int mSx = (sx * SCREEN_DATA_WIDTH);
	int mSy = (sy * SCREEN_DATA_HEIGHT);
	int mEx = mSx + SCREEN_DATA_WIDTH;
	int mEy = mSy + SCREEN_DATA_HEIGHT;
	
	if (mEx > w) mEx = w;
	if (mEy > h) mEy = h;
	
	screenData->x = mSx;
	screenData->y = mSy;
	screenData->xE = mEx;
	screenData->yE = mEy;
	
	int entityCount = 0;
	int lightCount = 0;
	int r,g,b;
	int mIdx;
	unsigned int color;

	for (int y = mSy; y < mEy; y++)
	{
		for (int x = mSx; x < mEx; x++)
		{
			mIdx = y * w + x;
			color = mapData[mIdx];
			
			if (color != 0 && color != 0xffffffff)
			{
				r = color & 0xff;
				g = (color & 0xff00) >> 8;
				b = (color & 0xff0000) >> 16; 
				
				if (r > 0 && b > 0)
				{
					// PLAYER ENTITY
					entityCount++;
				}
				else if (r > 0 && g > 0)
				{
					// Light 
					lightCount++;
				}
				else if (g > 0)
				{
					// DOOR ENTITY
					entityCount++;
				}
				else if (b > 0)
				{
					// DOOR ENTITY
					entityCount++;
				}
				else if (r > 0)
				{
					// Monster
					entityCount++;
				}
			}
		}
	}
	
	
	screenData->entityCount = entityCount;
	screenData->lightCount = lightCount;
	screenData->entityPlacementData = (EntityPlacementData*)malloc(sizeof(EntityPlacementData) * entityCount);
	screenData->lightPlacementData = (LightPlacementData*)malloc(sizeof(LightPlacementData) * lightCount);
	screenData->nonZero = 0;
	entityCount = lightCount = 0;
	for (int y = mSy; y < mEy; y++)
	{
		for (int x = mSx; x < mEx; x++)
		{
			mIdx = y * w + x;
			color = mapData[mIdx];
			
			if (color != 0 && color != 0xffffffff)
			{
				screenData->nonZero++;
				r = color & 0xff;
				g = (color & 0xff00) >> 8;
				b = (color & 0xff0000) >> 16; 
				
				if (r > 0 && b > 0)
				{
					// PLAYER ENTITY
					screenData->entityPlacementData[entityCount].x = x;
					screenData->entityPlacementData[entityCount].y = y;
					screenData->entityPlacementData[entityCount].entityType = ENTITY_TYPE_PLAYER;
					gameMapData->playerPlacement = &screenData->entityPlacementData[entityCount];
					gameMapData->startScreen[0] = sx;
					gameMapData->startScreen[1] = sy;
					entityCount++;
				}
				else if (r > 0 && g > 0)
				{
					// Light 
					screenData->lightPlacementData[lightCount].x = x;
					screenData->lightPlacementData[lightCount].y = y;
					lightCount++;
				}
				else if (g > 0)
				{
					// Special Door entity
					screenData->entityPlacementData[entityCount].x = x;
					screenData->entityPlacementData[entityCount].y = y;
					screenData->entityPlacementData[entityCount].entityType = ENTITY_TYPE_DOOR_B;
					screenData->entityPlacementData[entityCount].extraInfo = g / 16;
					entityCount++;
				}
				else if (b > 0)
				{
					// DOOR ENTITY
					screenData->entityPlacementData[entityCount].x = x;
					screenData->entityPlacementData[entityCount].y = y;
					screenData->entityPlacementData[entityCount].entityType = ENTITY_TYPE_DOOR;
					screenData->entityPlacementData[entityCount].extraInfo = b / 16 + ENTITY_BOSS_START;
					entityCount++;
				}
				else if (r > 0)
				{
					// Monster
					screenData->entityPlacementData[entityCount].x = x;
					screenData->entityPlacementData[entityCount].y = y;
					screenData->entityPlacementData[entityCount].entityType = r / 16 + ENTITY_BOSS_START;
					screenData->entityPlacementData[entityCount].extraInfo = r / 16 + ENTITY_BOSS_START;
					entityCount++;
				}
			}
		}
	}
}


void createScreenObjects(GameMapData* gameMapData, int w, int h, unsigned int* mapData)
{
	int sw = w / SCREEN_DATA_WIDTH;
	if (w % SCREEN_DATA_WIDTH > 0) sw++;
	int sh = h /SCREEN_DATA_HEIGHT;
	if (h % SCREEN_DATA_HEIGHT > 0) sh++;
	gameMapData->screenDataWidth = sw;
	gameMapData->screenDataHeight = sh;
	gameMapData->screenData = (ScreenData*)malloc(sizeof(ScreenData)*sw*sh);
	
	// Go through each screen set up the coordinates
	for (int sy = 0; sy < sh; sy++)
	{
		for (int sx = 0; sx < sw; sx++)
		{
			updateScreenData( gameMapData, sx, sy, w, h, mapData);
		}
	}
}


GameMapData* loadGameMapData(int w, int h, unsigned int* mapData)
{
	GameMapData* gameMapData = (GameMapData*)malloc(sizeof(GameMapData));
	
	gameMapData->levelBackgroundData.width = w;
	gameMapData->levelBackgroundData.height = h;
	gameMapData->levelBackgroundData.backgroundData = createBackgroundData(w, h, mapData);
	
	createScreenObjects(gameMapData, w, h, mapData);
	
	return gameMapData;
}

void freeGameMapData(GameMapData* gameMapData)
{
	// Free entity and lights per screen
	int sIdxEnd = gameMapData->screenDataWidth * gameMapData->screenDataHeight;
	for (int sIdx = 0; sIdx < sIdxEnd; sIdx++)
	{
		free(gameMapData->screenData[sIdx].entityPlacementData);
		free(gameMapData->screenData[sIdx].lightPlacementData);
	}
	free(gameMapData->screenData);
	// TODO: THIS NEEDS TO BE DELETED, but it causes a crash
	free(gameMapData->levelBackgroundData.backgroundData);
	gameMapData->levelBackgroundData.backgroundData = NULL;
	free(gameMapData);
}
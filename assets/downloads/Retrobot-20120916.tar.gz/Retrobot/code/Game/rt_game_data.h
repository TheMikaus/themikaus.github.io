#ifndef RT_GAME_DATA_H
#define RT_GAME_DATA_H

#include <player_entity.h>

typedef struct RTGameData
{
	PlayerEntity* playerEntity;
	int currentScreen[2];
	int* visitedScreen;
} RTGameData;


#endif
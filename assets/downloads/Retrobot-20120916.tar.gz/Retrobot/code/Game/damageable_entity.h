#ifndef DAMAGEABLE_ENTITY_H
#define DAMAGEABLE_ENTITY_H

#include <entity_manager.h>

// This by itself is not a class that should be instantiated.
// It has several constant elements that are used by other types of entities.

class DamageableEntity : public Entity
{
	public:
		virtual void update(long deltaTime) = 0;
		virtual void collision(Entity* collidingObj) = 0;
		virtual void justDied() = 0;
		virtual void destroy() = 0;
		virtual const char* getName() = 0;
		virtual void message(const char* messageName, int data) = 0;
		virtual ~DamageableEntity();
		
		virtual void setHealthMax(int healthMax);
		virtual void setHealth(int health);
		virtual void addHealth(int healthToAdd);
		virtual int getHealthMax();
		virtual int getHealth();
		virtual bool isDead();
		
	private:
		int healthMax;
		int health;

};

#endif
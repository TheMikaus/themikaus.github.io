#ifndef BOMB_ENT_H
#define BOMB_ENT_H

#include <input_manager.h>
#include <entity_manager.h>

#include <string>

class BombEntityCreator : public EntityCreator
{
	public:
		BombEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class BombEntity : public Entity
{
	public:
		BombEntity();
		virtual ~BombEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual const char* getName();
		virtual void message(const char* messageName, int data);
		void setOwner(Entity* entity);
		void setDamage(int damage);
		void shootBullet(float rotation);

	private:
		int damage;
		float timeToLive;
		Entity* owner;
};


#endif
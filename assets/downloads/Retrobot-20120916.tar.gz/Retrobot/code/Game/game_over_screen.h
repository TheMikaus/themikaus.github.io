#ifndef GAME_OVER_SCREEN_GS_H
#define GAME_OVER_SCREEN_GS_H

#include <game_state_manager.h>


class GameOverScreenGameState : public GameState
{
	public:
		GameOverScreenGameState();
		void init();
		void update(long deltaTime);
		void destroy();
		
	private:
		ButtonId startButton;
		float delay;
};


#endif
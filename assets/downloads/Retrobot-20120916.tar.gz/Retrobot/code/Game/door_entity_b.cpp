#include <door_entity_b.h>

#include <string.h>
#include <player_entity.h>

#define DOOR_ENTITY_STATE_IN_WALL 0
#define DOOR_ENTITY_STATE_MOVE_UP 1
#define DOOR_ENTITY_STATE_IN_PLACE 2
#define DOOR_ENTITY_STATE_MOVE_DOWN 3

bool DoorEntityBCreator::registered = false;
DoorEntityBCreator theDoorEntityBCreator;

DoorEntityBCreator::DoorEntityBCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "door_b");
	}
}

Entity* DoorEntityBCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	DoorEntityB* doorEntity = new DoorEntityB();
	
	/* NOTE: These may all get moved into the Entity Manager */
	doorEntity->setSpriteIndex(spriteIndex);
	doorEntity->setGraphicIndex(graphicIndex);
	doorEntity->setPosition(pos);
	doorEntity->setRotation(rot);
	doorEntity->getSpriteData()->layerId = 0;
	doorEntity->setIsPhysical(true);
	doorEntity->setSpeed(2.0f);
	
	return doorEntity;
}


void DoorEntityB::setType(int type)
{
	this->type = type;
}


void DoorEntityB::rightSideDoor(bool rightSide)
{
	this->rightSide = rightSide;
}


DoorEntityB::DoorEntityB()
{
	speed = 0;
	localState = DOOR_ENTITY_STATE_IN_PLACE;
	player = NULL;
	extra = 0;
}

DoorEntityB::~DoorEntityB()
{
}

void DoorEntityB::setSpeed(float speed)
{
	this->speed = speed;
}


void DoorEntityB::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;
	
	if (localState == DOOR_ENTITY_STATE_IN_PLACE)
	{
		if (player == NULL)
		{
			int max;
			Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(-1, max);
			for (int eIdx = 0; eIdx < max; eIdx++)
			{
				if (strcmp(entities[eIdx]->getName(), "player") == 0)
				{
					player = entities[eIdx];
					break;
				}
			}
		}
		
		// Check if player is to the right of us and if so then trigger the move up
		PlayerEntity* pe = (PlayerEntity*)player;
		if (pe->getDeadBossCount() >= type)
		{
			localState = DOOR_ENTITY_STATE_MOVE_DOWN;
			distanceMoved = 0.0;
		}
	}
	else if (localState == DOOR_ENTITY_STATE_MOVE_DOWN)
	{
		if (distanceMoved < getGraphicData()->height)
		{
			distanceMoved += speed * dT;
			getSpriteData()->pos[1] += speed * dT;
		}
		else
		{
			localState == DOOR_ENTITY_STATE_IN_WALL;
			setIsPhysical(false);
		}
	}
}


void DoorEntityB::message(const char* messageName, int data)
{
}

void DoorEntityB::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	
	
}


void DoorEntityB::justDied()
{
	// TODO: this will spawn a sparks entity I think
}


void DoorEntityB::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* DoorEntityB::getName()
{
	return "door_b";
}

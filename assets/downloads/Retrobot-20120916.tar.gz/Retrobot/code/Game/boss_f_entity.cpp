#include <boss_f_entity.h>
#include <bullet_entity.h>

#include <stdlib.h>
#include <string.h>
#include <math.h>

bool BossFEntityCreator::registered = false;
BossFEntityCreator theBossFEntityCreator;


BossFEntityCreator::BossFEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "boss_f");
	}
}


Entity* BossFEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	BossFEntity* bossEntity = new BossFEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	bossEntity->setSpriteIndex(spriteIndex);
	bossEntity->setGraphicIndex(graphicIndex);
	bossEntity->setPosition(pos);
	bossEntity->setRotation(rot);
	bossEntity->getSpriteData()->layerId = 0;
	bossEntity->setStartingPosition(pos);
	
	return bossEntity;
}


void BossFEntity::setStartingPosition(float* pos)
{
	startingPosition[0] = pos[0];
	startingPosition[1] = pos[1];
	startingPosition[2] = pos[2];
	
	targetPositions[0] = pos[1];
  for (int idx = 1; idx < 10; idx++)
  {
    targetPositions[idx] = targetPositions[idx - 1] - 8.0f;
  }
}

#define BOSS_MOVEMENT_SPEED (1.0f)
BossFEntity::BossFEntity()
{
	setHealthMax(20);
	setHealth(getHealthMax());
	player = NULL;
	ims = InputManagerSystem::getInstance();
	em = EntityManager::getInstance();
	setIsPhysical(true);
	speed = BOSS_MOVEMENT_SPEED;
	shotDelay = 2.5f;
	shotCount = 0;
	type = 0;
	target = 1;
	waitInPlace = 15.0f;
}

void BossFEntity::setType(int type)
{
	this->type = type;
}

BossFEntity::~BossFEntity()
{
}


void BossFEntity::setCanShoot(bool shoot)
{
	canShoot = shoot;
}

void BossFEntity::setSpeed(float speed)
{
	this->speed = speed;
}


void BossFEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;

	if (isDead())
	{
		justDied();
	}
	else if (spriteData != NULL)
	{
		spriteData->visible = true;
		if (player == NULL)
		{
			int max;
			Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(-1, max);
			for (int eIdx = 0; eIdx < max; eIdx++)
			{
				if (strcmp(entities[eIdx]->getName(), "player") == 0)
				{
					player = (DamageableEntity*)entities[eIdx];
					break;
				}
			}
		}
		
		float distance = spriteData->pos[1] - targetPositions[target];
		if (fabs(distance) > 0.25f)
		{
			if (fabs(distance) < 0.5f)
			{
				spriteData->pos[1] = targetPositions[target];
			}
			else
			{
				if (distance > 0) spriteData->pos[1] -= speed * dT;
				else spriteData->pos[1] += speed * dT;
			}
		}
		else if (shotCount < 4)
		{
			if (shotDelay < 0)
			{
				int bulletCount;
				Entity** bullets = em->getEntitiesInGroup(3, bulletCount);
				for (int bIdx = 0; bIdx < bulletCount; bIdx++)
				{
					if (bullets[bIdx] == NULL)
					{
						float rot[3] = {0.0, 0.0, 0.0};
						float pos[3];
						pos[0] = spriteData->pos[0];
						pos[0] += getGraphicData()->width;
						pos[1] = spriteData->pos[1] + (4.0 * (rand()%3));
						pos[2] = spriteData->pos[2];
						
						int bTag = em->createEntity(3, "bullet", pos, rot, 2);
						if (bTag != -1)
						{
							BulletEntity* bullet = (BulletEntity*)em->getEntity(bTag);
							float bSpeed = 6.0;
							bullet->setSpeed(bSpeed);
							bullet->setOwner(this);
							bullet->setSpecialData(getSpecialData());
							bullet->setDamage(1);
						}
						break;
					}
				}
				shotCount++;
				shotDelay = 2.5f;
			}
			else
			{
				shotDelay -= dT;
			}
		}
		else if (waitInPlace > 0)
		{
			waitInPlace -= dT;
		}
		else
		{
			shotCount = 0;
			waitInPlace = 15.0;
      target = rand() % 10;
		}
	}
}


void BossFEntity::message(char const* messageName, int data)
{
	if (strcmp(messageName, "damage") == 0)
	{
		addHealth(-data);
	}
}


void BossFEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	restorePosRotData();
	if (collidingObj != NULL)
	{
        if (strcmp(collidingObj->getName(), "player") == 0)
        {
            collidingObj->message("damage", 10);
        }
	}
}


void BossFEntity::justDied()
{
	int max;
	player->message("increment_boss_count", 0);
	
	Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(1, max);
	for (int eIdx = 0; eIdx < max; eIdx++)
	{
		if (entities[eIdx] != NULL && strcmp(entities[eIdx]->getName(), "door") == 0)
		{
			entities[eIdx]->message("open", type);
		}
	}
	
	// TODO: FIX THIS.
	//       Currently using a hard coded graphic index.
	//       These indexes should be inherent to the entity (register with the GM?)
	float rot[3] = {0.0, 0.0, 0.0};
	em->createEntity(3, "upgrade", getSpriteData()->pos, rot, 5);
	EntityManager::getInstance()->deleteEntity(getTagId());
}


void BossFEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* BossFEntity::getName()
{
	return "boss_f";
}

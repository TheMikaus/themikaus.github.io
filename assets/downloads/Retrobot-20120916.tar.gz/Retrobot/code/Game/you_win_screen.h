#ifndef YOU_WIN_SCREEN_GS_H
#define YOU_WIN_SCREEN_GS_H

#include <game_state_manager.h>


class YouWinScreenGameState : public GameState
{
	public:
		YouWinScreenGameState();
		void init();
		void update(long deltaTime);
		void destroy();
		
	private:
		float delay;
};


#endif
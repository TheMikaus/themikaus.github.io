#include <boss_h_entity.h>
#include <bullet_entity.h>
#include <bomb_entity.h>

#include <string.h>
#include <math.h>

bool BossHEntityCreator::registered = false;
BossHEntityCreator theBossHEntityCreator;


BossHEntityCreator::BossHEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "boss_h");
	}
}


Entity* BossHEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	BossHEntity* bossEntity = new BossHEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	bossEntity->setSpriteIndex(spriteIndex);
	bossEntity->setGraphicIndex(graphicIndex);
	bossEntity->setPosition(pos);
	bossEntity->setRotation(rot);
	bossEntity->getSpriteData()->layerId = 0;
	bossEntity->setStartingPosition(pos);
	
	return bossEntity;
}


void BossHEntity::setStartingPosition(float* pos)
{
	startingPosition[0] = pos[0];
	startingPosition[1] = pos[1];
	startingPosition[2] = pos[2];
	
	// Set up all forty target positions
	for (int x = 0; x < 7; x++)
	{
		for (int y = 0; y < 5; y++)
		{
			int tIdx = x*5 + y;
			targetPositions[tIdx][0] = pos[0] + x * 21.0;
			targetPositions[tIdx][1] = pos[1] - y * 21.0;
		}
	}
}

#define BOSS_MOVEMENT_SPEED (1.0f)
BossHEntity::BossHEntity()
{
	setHealthMax(40);
	setHealth(getHealthMax());
	player = NULL;
	ims = InputManagerSystem::getInstance();
	em = EntityManager::getInstance();
	setIsPhysical(true);
	speed = BOSS_MOVEMENT_SPEED;
	bombDelay = 5.0f;
	shootDelay = 2.5f;
	shotCount = 0;
	target = 0;
	type = 0;
	waitInPlace = 15.0f;
}

void BossHEntity::setType(int type)
{
	this->type = type;
}

BossHEntity::~BossHEntity()
{
}


void BossHEntity::setCanShoot(bool shoot)
{
	canShoot = shoot;
}

void BossHEntity::setSpeed(float speed)
{
	this->speed = speed;
}


void BossHEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;

	if (isDead())
	{
		justDied();
	}
	else if (spriteData != NULL)
	{
		spriteData->visible = true;
		if (player == NULL)
		{
			int max;
			Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(-1, max);
			for (int eIdx = 0; eIdx < max; eIdx++)
			{
				if (strcmp(entities[eIdx]->getName(), "player") == 0)
				{
					player = (DamageableEntity*)entities[eIdx];
					break;
				}
			}
		}
		
		float distY = spriteData->pos[1] - targetPositions[target][1];
		float distX = spriteData->pos[0] - targetPositions[target][0];
		
		if (fabs(distY) > 0.25f)
		{
			if (fabs(distY) < 0.5f)
			{
				spriteData->pos[1] = targetPositions[target][1];
			}
			else
			{
				if (distY < 0) spriteData->pos[1] += speed * dT;
				else spriteData->pos[1] -= speed * dT;
			}
		}
		else if (fabs(distX) > 0.25f)
		{
			if (fabs(distX) < 0.5f)
			{
				spriteData->pos[0] = targetPositions[target][0];
			}
			else
			{
				spriteData->pos[1] = targetPositions[target][1];
				if (distX < 0) spriteData->pos[0] += speed * dT;
				else spriteData->pos[0] -= speed * dT;
			}
		}
		else
		{
			spriteData->pos[0] = targetPositions[target][0];
			target++;
			if (target == 30) target = 0;
		}
		
		// Shoot whenever possible at the player along the udlr only
		float pXDiff = player->getSpriteData()->pos[0] - spriteData->pos[0];
		float pYDiff = player->getSpriteData()->pos[1] - spriteData->pos[1];
		float rotValue = 3.14159 + atan2(pYDiff, pXDiff);;
		
		if (shootDelay > 0)
		{
			shootDelay -= dT;
		}
		else
		{
			// Shoot
			shootDelay = 30.0f;
			// Fire a bullet at the given rotation
			int bulletCount;
			Entity** bullets = em->getEntitiesInGroup(3, bulletCount);
			for (int bIdx = 0; bIdx < bulletCount; bIdx++)
			{
				if (bullets[bIdx] == NULL)
				{
				
					float rot[3] = {0.0, 0.0, rotValue};
					float pos[3];
					int max;
					pos[0] = spriteData->pos[0] + getGraphicData()->width / 2.0;
					pos[1] = spriteData->pos[1] + getGraphicData()->height / 2.0;
					pos[2] = spriteData->pos[2];
					
					int bTag = em->createEntity(3, "bullet", pos, rot, 2);
					if (bTag != -1)
					{
						BulletEntity* bullet = (BulletEntity*)em->getEntity(bTag);
						float bSpeed = -5.0;
						bullet->setSpeed(bSpeed);
						bullet->setOwner(this);
						bullet->setSpecialData(getSpecialData());
						bullet->setDamage(3);
					}
					break;
				}
			}
		}
		
		if (bombDelay > 0 )
		{
			bombDelay -= dT;
		}
		else
		{
			bombDelay = 120.0f;
			
			int bulletCount;
			Entity** bullets = em->getEntitiesInGroup(3, bulletCount);
			for (int bIdx = 0; bIdx < bulletCount; bIdx++)
			{
				if (bullets[bIdx] == NULL)
				{
				
					float rot[3] = {0.0, 0.0, rotValue};
					float pos[3];
					int max;
					pos[0] = spriteData->pos[0] + getGraphicData()->width / 2.0;
					pos[1] = spriteData->pos[1] + getGraphicData()->height / 2.0;
					pos[2] = spriteData->pos[2];
					
					int bTag = em->createEntity(3, "bomb", pos, rot, 16);
					if (bTag != -1)
					{
						BombEntity* bomb = (BombEntity*)em->getEntity(bTag);
						bomb->setOwner(this);
						bomb->setSpecialData(getSpecialData());
						bomb->setDamage(5);
					}
					break;
				}
			}
		}
	}
}


void BossHEntity::message(char const* messageName, int data)
{
	if (strcmp(messageName, "damage") == 0)
	{
		addHealth(-data);
	}
}


void BossHEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	restorePosRotData();
	if (collidingObj != NULL)
	{
        if (strcmp(collidingObj->getName(), "player") == 0)
        {
            collidingObj->message("damage", 10);
        }
	}
}


void BossHEntity::justDied()
{
	int max;
	player->message("increment_boss_count", 0);
	
	Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(1, max);
	for (int eIdx = 0; eIdx < max; eIdx++)
	{
		if (entities[eIdx] != NULL && strcmp(entities[eIdx]->getName(), "door") == 0)
		{
			entities[eIdx]->message("open", type);
		}
	}
	
	// TODO: FIX THIS.
	//       Currently using a hard coded graphic index.
	//       These indexes should be inherent to the entity (register with the GM?)
	float rot[3] = {0.0, 0.0, 0.0};
	em->createEntity(3, "upgrade", getSpriteData()->pos, rot, 5);
	EntityManager::getInstance()->deleteEntity(getTagId());
}


void BossHEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* BossHEntity::getName()
{
	return "boss_h";
}

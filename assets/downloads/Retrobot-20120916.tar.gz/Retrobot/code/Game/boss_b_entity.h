#ifndef BOSS_B_ENT_H
#define BOSS_B_ENT_H

#include <input_manager.h>
#include <entity_manager.h>
#include <damageable_entity.h>

#include <string>

class BossBEntityCreator : public EntityCreator
{
	public:
		BossBEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class BossBEntity : public DamageableEntity
{
	public:
		BossBEntity();
		virtual ~BossBEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual void setType(int type);
		virtual const char* getName();
		virtual void message(const char* messageName, int data);
		void setSpeed(float speed);
		void setCanShoot(bool shoot);
		void setStartingPosition(float* pos);
		void setDamage(int dmg);

	private:
		InputManagerSystem* ims;
		EntityManager* em;
		DamageableEntity* player;
		
		int type;
		
		float speed;
		float rotatingSpeed;
		float posAdjust;
		bool canShoot;
		int dmg;
		float shootDelay;
		float startPos[3];
		float selfRotation;
};


#endif
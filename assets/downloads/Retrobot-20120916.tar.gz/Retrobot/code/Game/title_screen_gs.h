#ifndef TITLE_SCREEN_GS_H
#define TITLE_SCREEN_GS_H

#include <game_state_manager.h>


class TitleScreenGameState : public GameState
{
	public:
		TitleScreenGameState();
		void init();
		void update(long deltaTime);
		void destroy();
		
	private:
		ButtonId startButton;
                ButtonId selectButton;
		int playerId;
};


#endif

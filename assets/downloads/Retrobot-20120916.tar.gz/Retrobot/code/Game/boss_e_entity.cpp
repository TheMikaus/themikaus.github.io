#include <boss_b_entity.h>
#include <boss_e_entity.h>

#include <string.h>
#include <math.h>

bool BossEEntityCreator::registered = false;
BossEEntityCreator theBossEEntityCreator;


BossEEntityCreator::BossEEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "boss_e");
	}
}


Entity* BossEEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	BossBEntity* bossEntity = new BossBEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	bossEntity->setSpriteIndex(spriteIndex);
	bossEntity->setGraphicIndex(graphicIndex);
	bossEntity->setPosition(pos);
	bossEntity->setRotation(rot);
	bossEntity->getSpriteData()->layerId = 0;
	bossEntity->setStartingPosition(pos);
	bossEntity->setDamage(3);
	bossEntity->setHealthMax(20);
	bossEntity->setHealth(20);
	
	return bossEntity;
}

#ifndef MAIN_GAME_STATE_H
#define MAIN_GAME_STATE_H

#include <game_state_manager.h>
#include <game_map.h>
#include <rt_game_data.h>

class MainGameState : public GameState
{
	public:
		MainGameState();
		void init();
		void update(long deltaTime);
		void destroy();
		
	private:
		GameMapData* gameMapData;
		RTGameData rtGameData;
		CameraData cameraData;
		int bossGIdxByIdx[19];
		
		void setupMainGraphicsData();
		void displayScreen(int x, int y);
		
		void updateHUD();
		
		
		int playerGIdx;
		int doorGIdx;
		int bulletGIdx;
		int beamGIdx;
		int bigBeamGIdx;
		int upgradeBGIdx;
		int upgradeHGIdx;
		int hudBGIdx;
		int hudHGIdx;
		int hudBCGIdx;
		int bossAGIdx;
		int bossBGIdx;
		int bossCGIdx;
		int bossDGIdx;
		int bossGGIdx;
		int bombGIdx;
		int doorBGIdx;
		float hudUpperLeft[2];
};


#endif
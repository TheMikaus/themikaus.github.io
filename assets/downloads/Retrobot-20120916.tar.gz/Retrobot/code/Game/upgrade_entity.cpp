#include <upgrade_entity.h>

#include <string.h>
#include <stdlib.h>

bool UpgradeEntityCreator::registered = false;
UpgradeEntityCreator theUpgradeEntityCreator;

UpgradeEntityCreator::UpgradeEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "upgrade");
	}
}

Entity* UpgradeEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	UpgradeEntity* upgradeEntity = new UpgradeEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	upgradeEntity->setSpriteIndex(spriteIndex);
	upgradeEntity->setGraphicIndex(graphicIndex);
	upgradeEntity->setPosition(pos);
	upgradeEntity->setRotation(rot);
	upgradeEntity->getSpriteData()->layerId = 0;
	upgradeEntity->setIsPhysical(true);
	upgradeEntity->setStartingGraphicIndex(graphicIndex);
	
	return upgradeEntity;
}


UpgradeEntity::~UpgradeEntity()
{
}


float getRandomFloat()
{
	return (float)rand()/((float)RAND_MAX/2.0) - 1.0;
}


UpgradeEntity::UpgradeEntity()
{
	cycleTime = 60.0;
	display = 0;
	vel[0] = getRandomFloat();
	vel[1] = getRandomFloat();
}

void UpgradeEntity::setStartingGraphicIndex(int index)
{
	display = index;
}


void UpgradeEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;
	cycleTime -= dT;
	if (cycleTime < 0)
	{
		if (getGraphicIndex() != display)
		{
			setGraphicIndex(display);
		}
		else
		{
			setGraphicIndex(display+1);
		}
		cycleTime = 60;
	}
	
	getSpriteData()->pos[0] += vel[0] * dT;
	getSpriteData()->pos[1] += vel[1] * dT;
}


void UpgradeEntity::collision(Entity* collidingObj)
{
	if (collidingObj == NULL)
	{
		// Hit the environment Reverse random directions
		restorePosRotData();
		vel[0] = getRandomFloat();
		vel[1] = getRandomFloat();
	}
	else if(strcmp(collidingObj->getName(), "player") == 0)
	{
		EntityManager::getInstance()->deleteEntity(getTagId());
		if (getGraphicIndex() == display)
		{
			collidingObj->message("increment_bullet_count", 0);
		}
		else
		{
			collidingObj->message("increment_health", 0);
		}
	}
}


void UpgradeEntity::message(const char* messageName, int data)
{
	// TODO: DO NOTHING!
}

void UpgradeEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
}


void UpgradeEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* UpgradeEntity::getName()
{
	return "upgrade";
}

#include <dummy_entity.h>


bool DummyEntityCreator::registered = false;
DummyEntityCreator theDummyEntityCreator;

DummyEntityCreator::DummyEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "dummy");
	}
}

Entity* DummyEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	DummyEntity* dummyEntity = new DummyEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	dummyEntity->setSpriteIndex(spriteIndex);
	dummyEntity->setGraphicIndex(graphicIndex);
	dummyEntity->setPosition(pos);
	dummyEntity->setRotation(rot);
	dummyEntity->getSpriteData()->layerId = 0;
	
	return dummyEntity;
}


DummyEntity::DummyEntity()
{
	setHealthMax(10);
	setHealth(getHealthMax());
	setIsPhysical(true);
}

DummyEntity::~DummyEntity()
{
}

#define Dummy_MOVEMENT_SPEED (0.25f)
void DummyEntity::update(long deltaTime)
{
	spriteData->visible = true;
}


void DummyEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
}

void DummyEntity::message(const char* messageName, int data)
{
}


void DummyEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
}


void DummyEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* DummyEntity::getName()
{
	return "Dummy";
}

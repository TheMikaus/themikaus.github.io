#ifndef PLAYER_ENT_H
#define PLAYER_ENT_H

#include <input_manager.h>
#include <entity_manager.h>
#include <damageable_entity.h>

#include <string>

#define MAX_BULLET_COUNT 5

class PlayerEntityCreator : public EntityCreator
{
	public:
		PlayerEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class PlayerEntity : public DamageableEntity
{
	public:
		PlayerEntity();
		virtual ~PlayerEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual const char* getName();
		virtual void message(const char* messageName, int data);
		void setSpeed(float speed);
		void setCanShoot(bool shoot);
		
		void incrementDeadBosses();
		int getDeadBossCount();
		int getMaxBulletCount();

	private:
		ButtonId moveUp;
		ButtonId moveDown;
		ButtonId moveLeft;
		ButtonId moveRight;
		ButtonId fire;
		InputManagerSystem* ims;
		EntityManager* em;
		
		float speed;
		float rotatingSpeed;
		float posAdjust;
		bool canShoot;
		int deadBosses;
		
		int maxBulletCount;
};


#endif
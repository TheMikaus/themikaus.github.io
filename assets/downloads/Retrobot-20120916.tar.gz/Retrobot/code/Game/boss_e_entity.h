#ifndef BOSS_E_ENT_H
#define BOSS_E_ENT_H

#include <input_manager.h>
#include <entity_manager.h>
#include <damageable_entity.h>

#include <string>

class BossEEntityCreator : public EntityCreator
{
	public:
		BossEEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};


#endif
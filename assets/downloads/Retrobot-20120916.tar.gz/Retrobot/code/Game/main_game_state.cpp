#include <main_game_state.h>
#include <tiles.h>

#include <Log.h>

#include <stdlib.h>
#include <string.h>

#include <door_entity.h>
#include <boss_entity.h>
#include <door_entity_b.h>

#define POS_SCALER (4.0f)

MainGameState onlyOneMGS;

char* bossNamesByIdx[] =
{
	"",
	"",
	"",
	"",
	"boss",
	"boss_b",
	"boss_c",
	"boss_g",
	"",
	"",
	"",
	"boss_d",
	"boss_e",
	"boss_f",
	"boss_h"
};


MainGameState::MainGameState()
{
	GameStateManager* gsm = GameStateManager::getInstance();
	gsm->registerState("MainGame", this);
}


void MainGameState::init()
{
	// Load the map
	// Init states and such
	gameMapData = loadGameMapData(GAME_MAP_WIDTH, GAME_MAP_HEIGHT, game_map_data);
	setupMainGraphicsData();
	
	em->setupGroups(4, 1, 48, 40, 48);
	
	// Set up the player
	float pos[3];
	pos[0] = (gameMapData->playerPlacement->x+1) * POS_SCALER;
	pos[1] = (gameMapData->playerPlacement->y) * POS_SCALER * -1.0f;
	pos[2] = -5.0f;
	
	float rot[3] = { 0.0, 0.0, 0.0 };
	int tagId = em->createEntity(0, "player", pos, rot, playerGIdx);
	PlayerEntity* player = (PlayerEntity*)em->getEntity(tagId);
	player->setIsPhysical(true);
	player->setSpeed(2.0f);
	player->setCanShoot(true);
	
	rtGameData.playerEntity = player;
	rtGameData.currentScreen[0] = pos[0] / SCREEN_DATA_WIDTH / 4;
	rtGameData.currentScreen[1] = -1.0 * (pos[1] / SCREEN_DATA_HEIGHT) / 4.0;
	
	int screenCount = gameMapData->screenDataWidth * gameMapData->screenDataHeight;
	rtGameData.visitedScreen = (int*)malloc(sizeof(int) * screenCount);
	memset(rtGameData.visitedScreen, 0, sizeof(int) * screenCount);
	
	// Set up the background
	int max;
	BackgroundData* backgroundData = gm->getBackgroundData(&max);
	backgroundData[0].type = BACKGROUND_TYPE_PIXELED;
	backgroundData[0].width = gameMapData->levelBackgroundData.width;
	backgroundData[0].height = gameMapData->levelBackgroundData.height;
	backgroundData[0].info.pixeledInfo.colorData = gameMapData->levelBackgroundData.backgroundData;
	backgroundData[0].display[2] = 0;
	backgroundData[0].info.pixeledInfo.pixelWidth = 4;
	backgroundData[0].info.pixeledInfo.pixelHeight = 4;
	backgroundData[0].info.pixeledInfo.pixelDepth = 10;
	backgroundData[0].info.pixeledInfo.displayWidthInPixels = SCREEN_DATA_WIDTH;
	backgroundData[0].info.pixeledInfo.displayHeightInPixels = SCREEN_DATA_HEIGHT;
	
	displayScreen(rtGameData.currentScreen[0], rtGameData.currentScreen[1]);
	//displayScreen(0, 0);

	gm->updateAllGraphicBoxedData();
	gm->updateAllBackgroundBoxedData();
  gm->setGraphicDataOutOfDate();
}


void MainGameState::displayScreen(int x, int y)
{
	int max;
	BackgroundData* backgroundData = gm->getBackgroundData(&max);
	
	backgroundData[0].display[0] = x * SCREEN_DATA_WIDTH * 4.0;
	backgroundData[0].display[1] = (y+1) * SCREEN_DATA_HEIGHT * -4.0;

	backgroundData[0].info.pixeledInfo.srcX = x * SCREEN_DATA_WIDTH;;
	backgroundData[0].info.pixeledInfo.srcY = y * SCREEN_DATA_HEIGHT;
	
	hudUpperLeft[0] = x * SCREEN_DATA_WIDTH * 4.0;;
	hudUpperLeft[1] = (y+1) * SCREEN_DATA_HEIGHT * -4.0;
	
	//CameraData cameraData;
	cameraData.pos[0] = -4.0 * x * SCREEN_DATA_WIDTH + (-SCREEN_DATA_WIDTH * 2);
	cameraData.pos[1] = 4.0 * (y+1) * SCREEN_DATA_HEIGHT + (-SCREEN_DATA_HEIGHT * 2);
	cameraData.pos[2] = -SCREEN_DATA_HEIGHT * 2 - 10.0;
	cameraData.rot[0] = cameraData.rot[1] = cameraData.rot[2] = 0;
	gm->setCameraData(cameraData);
	
	LightData* lightData = gm->getLightData(&max);
	int sIdx = y * gameMapData->screenDataWidth + x;
	ScreenData* sd = &gameMapData->screenData[sIdx];

	for (int lIdx = 0; lIdx < sd->lightCount; lIdx++)
	{
		lightData[lIdx].type = LIGHT_DATA_POINT;
		lightData[lIdx].color = 0xff0000ff;
		lightData[lIdx].strength = 0.25f;
		lightData[lIdx].pos[0] = sd->lightPlacementData[lIdx].x * POS_SCALER;
		lightData[lIdx].pos[1] = (sd->lightPlacementData[lIdx].y+1) * POS_SCALER * -1.0f;
		lightData[lIdx].pos[2] = -2.5f;
	}
	
	int eMax;
	Entity** entities = em->getEntitiesInGroup(-1, eMax);
	for (int eIdx = 0; eIdx < eMax; eIdx++)
	{
		if (entities[eIdx] != NULL)
		{
			if (strcmp(entities[eIdx]->getName(), "bullet") == 0)
			{
				em->deleteEntity(entities[eIdx]->getTagId());
			}
			else
			{
				entities[eIdx]->setEnabled(false);
			}
		}
	}
	rtGameData.playerEntity->setSpecialData(sIdx);
	rtGameData.playerEntity->setEnabled(true);
	
	if (rtGameData.visitedScreen[sIdx] == 0)
	{
		rtGameData.visitedScreen[sIdx] = 1;
		
		// Create the entities
		for (int eIdx = 0; eIdx < sd->entityCount; eIdx++)
		{
			if (sd->entityPlacementData[eIdx].entityType != ENTITY_TYPE_PLAYER)
			{
				if (sd->entityPlacementData[eIdx].entityType == ENTITY_TYPE_DOOR)
				{
					// generate the door!
					float pos[3];
					pos[0] = (sd->entityPlacementData[eIdx].x+1) * POS_SCALER;
					pos[1] = (sd->entityPlacementData[eIdx].y) * POS_SCALER * -1.0f;
					pos[2] = -5.0f;

					float rot[3] = { 0.0, 0.0, 0.0 };
					int id = em->createEntity(1, "door", pos, rot, doorGIdx);
					int type = sd->entityPlacementData[eIdx].extraInfo;
					DoorEntity* de = (DoorEntity*)em->getEntity(id);
					de->setType(type);
					de->rightSideDoor(type < 8);
					de->setSpecialData(sIdx);
				}
				else if (sd->entityPlacementData[eIdx].entityType == ENTITY_TYPE_DOOR_B)
				{
					// generate the door!
					float pos[3];
					pos[0] = (sd->entityPlacementData[eIdx].x+1) * POS_SCALER;
					pos[1] = (sd->entityPlacementData[eIdx].y) * POS_SCALER * -1.0f;
					pos[2] = -5.0f;

					float rot[3] = { 0.0, 0.0, 0.0 };
					int id = em->createEntity(1, "door_b", pos, rot, doorBGIdx);
					int type = sd->entityPlacementData[eIdx].extraInfo;
					DoorEntityB* de = (DoorEntityB*)em->getEntity(id);
					de->setType(type);
					de->setSpecialData(sIdx);
				}
				else
				{
					// Generate entity based off of entity map
					float pos[3];
					pos[0] = (sd->entityPlacementData[eIdx].x+1) * POS_SCALER;
					pos[1] = (sd->entityPlacementData[eIdx].y) * POS_SCALER * -1.0f;
					pos[2] = -5.0f;

					float rot[3] = { 0.0, 0.0, 0.0 };
					char* bType = bossNamesByIdx[sd->entityPlacementData[eIdx].extraInfo];
					int gIndex = bossGIdxByIdx[sd->entityPlacementData[eIdx].extraInfo];
					int id = em->createEntity(1, bType, pos, rot, gIndex);
					BossEntity* be = (BossEntity*)em->getEntity(id);
					be->setType(sd->entityPlacementData[eIdx].extraInfo);
					be->setSpecialData(sIdx);
				}
				
			}
		}
	}
	else
	{
		// Update every entity in this room
		for (int eIdx = 0; eIdx < eMax; eIdx++)
		{
			if (entities[eIdx] != NULL && entities[eIdx]->getSpecialData() == sIdx)
			{
				entities[eIdx]->setEnabled(true);
			}
		}
	}
}


void MainGameState::updateHUD()
{
	// The Last 32 sprites are reserved for the hud.
	int sIdx = 0;
	int maxSprites;
	int max;
	SpriteData* sd = gm->getSpriteData(&maxSprites);
	sIdx = maxSprites - 32;
	GraphicData* gd = gm->getGraphicData(&max);
	
	// Draw Hearts
	for (int hIdx = 0; hIdx < rtGameData.playerEntity->getHealth(); hIdx++)
	{
		sd[sIdx].visible = true;
		sd[sIdx].graphicIndex = hudHGIdx;
		sd[sIdx].layerId = 1;
		sd[sIdx].rot[0] = sd[sIdx].rot[1] = sd[sIdx].rot[2] = 0.0;
		sd[sIdx].pos[0] = hudUpperLeft[0] + (hIdx * gd[hudHGIdx].width) + SCREEN_DATA_WIDTH/2;
		sd[sIdx].pos[1] = hudUpperLeft[1] + SCREEN_DATA_HEIGHT*3.25;
		sd[sIdx].pos[2] = 10.0;
		sIdx++;
	}
	
	// Draw bullets
	for (int bIdx = 0; bIdx < rtGameData.playerEntity->getMaxBulletCount(); bIdx++)
	{
		sd[sIdx].visible = true;
		sd[sIdx].graphicIndex = hudBGIdx;
		sd[sIdx].layerId = 1;
		sd[sIdx].rot[0] = sd[sIdx].rot[1] = sd[sIdx].rot[2] = 0.0;
		sd[sIdx].pos[0] = hudUpperLeft[0] + (bIdx * gd[hudHGIdx].width) + SCREEN_DATA_WIDTH/2.0;
		sd[sIdx].pos[1] = hudUpperLeft[1] + SCREEN_DATA_HEIGHT*3.25 - gd[hudHGIdx].height - 1.0;
		sd[sIdx].pos[2] = 10.0;
		sIdx++;
	}
	
	// Draw Dead boss count
	for (int bIdx = 0; bIdx < rtGameData.playerEntity->getDeadBossCount(); bIdx++)
	{
		sd[sIdx].visible = true;
		sd[sIdx].graphicIndex = hudBCGIdx;
		sd[sIdx].layerId = 1;
		sd[sIdx].rot[0] = sd[sIdx].rot[1] = sd[sIdx].rot[2] = 0.0;
		sd[sIdx].pos[0] = hudUpperLeft[0] + (bIdx * gd[hudHGIdx].width) + SCREEN_DATA_WIDTH*2.5;
		sd[sIdx].pos[1] = hudUpperLeft[1] + SCREEN_DATA_HEIGHT*3.25;
		sd[sIdx].pos[2] = 10.0;
		sIdx++;
	}
	
	for (; sIdx < maxSprites;sIdx++)
	{
		sd[sIdx].visible = false;
	}
}


void MainGameState::setupMainGraphicsData()
{
	int max;
	GraphicData* graphicData = gm->getGraphicData(&max);
	
	int gIdx = 0;
	memset(bossGIdxByIdx, 0, sizeof(int) * 19);
	
	// Set up the player graphic data
	playerGIdx = gIdx;
	graphicData[gIdx].width = PLAYER_WIDTH;
	graphicData[gIdx].height = PLAYER_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = player_data;
	gIdx++;
	
	// Set up the door
	doorGIdx = gIdx;
	graphicData[gIdx].width = DOOR_ENTITY_WIDTH;
	graphicData[gIdx].height = DOOR_ENTITY_HEIGHT;
	graphicData[gIdx].depth = 3.0f;
	graphicData[gIdx].pixelData = door_entity_data;
	gIdx++;
	
	// Set up bullets
	bulletGIdx = gIdx;
	graphicData[gIdx].width = BULLET_WIDTH;
	graphicData[gIdx].height = BULLET_HEIGHT;
	graphicData[gIdx].depth = 1.0f;
	graphicData[gIdx].pixelData = bullet_data;
	gIdx++;
	
	beamGIdx = gIdx;
	graphicData[gIdx].width = BEAM_WIDTH;
	graphicData[gIdx].height = BEAM_HEIGHT;
	graphicData[gIdx].depth = 1.0f;
	graphicData[gIdx].pixelData = beam_data;
	gIdx++;
	
	bigBeamGIdx = gIdx;
	graphicData[gIdx].width = BIG_BEAM_WIDTH;
	graphicData[gIdx].height = BIG_BEAM_HEIGHT;
	graphicData[gIdx].depth = 1.0f;
	graphicData[gIdx].pixelData = big_beam_data;
	gIdx++;
	
	// Set up the Upgrades
	upgradeBGIdx = gIdx;
	graphicData[gIdx].width = UPGRADE_BULLET_WIDTH;
	graphicData[gIdx].height = UPGRADE_BULLET_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = upgrade_bullet_data;
	gIdx++;
	
	upgradeHGIdx = gIdx;
	graphicData[gIdx].width = UPGRADE_HEALTH_WIDTH;
	graphicData[gIdx].height = UPGRADE_HEALTH_HEIGHT;
	graphicData[gIdx].depth = 3.0f;
	graphicData[gIdx].pixelData = upgrade_health_data;
	gIdx++;
	
	// Set up the HUD elements
	hudBGIdx = gIdx;
	graphicData[gIdx].width = HUD_BULLET_WIDTH;
	graphicData[gIdx].height = HUD_BULLET_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = hud_bullet_data;
	gIdx++;
	
	hudHGIdx = gIdx;
	graphicData[gIdx].width = HUD_HEART_WIDTH;
	graphicData[gIdx].height = HUD_HEART_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = hud_heart_data;
	gIdx++;
	
	hudBCGIdx = gIdx;
	graphicData[gIdx].width = HUD_BOSS_WIDTH;
	graphicData[gIdx].height = HUD_BOSS_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = hud_boss_data;
	gIdx++;
	
	// Set up the bosses
	bossAGIdx = gIdx;
	graphicData[gIdx].width = BOSS_WIDTH;
	graphicData[gIdx].height = BOSS_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = boss_data;
	bossGIdxByIdx[4] = gIdx;
	gIdx++;
	
	bossBGIdx = gIdx;
	graphicData[gIdx].width = BOSS_B_WIDTH;
	graphicData[gIdx].height = BOSS_B_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = boss_b_data;
	bossGIdxByIdx[5] = gIdx;
	bossGIdxByIdx[12] = gIdx;
	gIdx++;
	
	bossCGIdx = gIdx;
	graphicData[gIdx].width = BOSS_C_WIDTH;
	graphicData[gIdx].height = BOSS_C_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = boss_c_data;
	bossGIdxByIdx[6] = gIdx;
	gIdx++;
	
	bossDGIdx = gIdx;
	graphicData[gIdx].width = BOSS_D_WIDTH;
	graphicData[gIdx].height = BOSS_D_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = boss_d_data;
	bossGIdxByIdx[11] = gIdx;
	gIdx++;
	
	bossDGIdx = gIdx;
	graphicData[gIdx].width = BOSS_F_WIDTH;
	graphicData[gIdx].height = BOSS_F_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = boss_f_data;
	bossGIdxByIdx[13] = gIdx;
	gIdx++;
	
	bossGGIdx = gIdx;
	graphicData[gIdx].width = BOSS_G_WIDTH;
	graphicData[gIdx].height = BOSS_G_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = boss_g_data;
	bossGIdxByIdx[7] = gIdx;
	gIdx++;
	
	bossGIdxByIdx[14] = bossGGIdx;
	
	bombGIdx = gIdx;
	graphicData[gIdx].width = BOMB_WIDTH;
	graphicData[gIdx].height = BOMB_HEIGHT;
	graphicData[gIdx].depth = 0.25f;
	graphicData[gIdx].pixelData = bomb_data;
	gIdx++;
	
	doorBGIdx = gIdx;
	graphicData[gIdx].width = DOOR_ENTITY_B_WIDTH;
	graphicData[gIdx].height = DOOR_ENTITY_B_HEIGHT;
	graphicData[gIdx].depth = 3.0f;
	graphicData[gIdx].pixelData = door_entity_b_data;
	gIdx++;

}

void MainGameState::update(long deltaTime)
{
	float bottom = (rtGameData.currentScreen[1]+1) * SCREEN_DATA_HEIGHT * -4.0;
	float top = bottom + SCREEN_DATA_HEIGHT * 4.0;
	float left = rtGameData.currentScreen[0] * SCREEN_DATA_WIDTH * 4.0;
	float right = left + SCREEN_DATA_WIDTH * 4.0;

	SpriteData* psd = rtGameData.playerEntity->getSpriteData();
	
	if (psd->pos[0] < left)
	{
		rtGameData.currentScreen[0]--;
		displayScreen(rtGameData.currentScreen[0], rtGameData.currentScreen[1]);
	}
	else if (psd->pos[0] > right)
	{
		rtGameData.currentScreen[0]++;
		displayScreen(rtGameData.currentScreen[0], rtGameData.currentScreen[1]);
	}
	else if (psd->pos[1] > top)
	{
		rtGameData.currentScreen[1]--;
		displayScreen(rtGameData.currentScreen[0], rtGameData.currentScreen[1]);
	}
	else if (psd->pos[1] < bottom)
	{
		rtGameData.currentScreen[1]++;
		displayScreen(rtGameData.currentScreen[0], rtGameData.currentScreen[1]);
	}

	im->updateButtons(deltaTime);
	em->update(deltaTime);
	updateHUD();
	gm->render(deltaTime);
	
	ButtonId selectButton = InputManagerSystem::getInstance()->findButton("SelectButton");
	if (rtGameData.playerEntity->isDead())
	{
		GameStateManager* gsm = GameStateManager::getInstance();
		gsm->setNewState("GameOverScreen");
	}
	else if (rtGameData.playerEntity->getDeadBossCount() == 8)
	{
		GameStateManager* gsm = GameStateManager::getInstance();
		gsm->setNewState("YouWinScreen");
	}
  else if (im->buttonWasPressed(selectButton))
	{
		GameStateManager* gsm = GameStateManager::getInstance();
		gsm->setNewState("TitleScreen");
	}
}

void MainGameState::destroy()
{
	freeGameMapData(gameMapData);
	gameMapData = NULL;

	int max;
	BackgroundData* backgroundData = gm->getBackgroundData(&max);
	backgroundData[0].type = BACKGROUND_TYPE_NONE;
	backgroundData[0].width = 0;
	backgroundData[0].height = 0;
	backgroundData[0].info.pixeledInfo.colorData = NULL;
	
	em->clearEntitiesInGroup(-1);
	em->update(0);
}

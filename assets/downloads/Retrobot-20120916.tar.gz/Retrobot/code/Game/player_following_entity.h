#ifndef PLAYER_ENT_H
#define PLAYER_ENT_H

#include <input_manager.h>
#include <entity_manager.h>
#include <damageable_entity.h>


class PlayerFollowingEntityCreator : public EntityCreator
{
	public:
		PlayerFollowingEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class PlayerFollowingEntity : public DamageableEntity
{
	public:
		PlayerFollowingEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual const char* getName();
		virtual void message(const char* messageName, int data);

	private:
		EntityManager* em;
};


#endif
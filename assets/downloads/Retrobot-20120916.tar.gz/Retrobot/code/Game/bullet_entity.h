#ifndef BULLET_ENT_H
#define BULLET_ENT_H

#include <input_manager.h>
#include <entity_manager.h>

#include <string>

class BulletEntityCreator : public EntityCreator
{
	public:
		BulletEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class BulletEntity : public Entity
{
	public:
		BulletEntity();
		virtual ~BulletEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual const char* getName();
		virtual void message(const char* messageName, int data);
		void setSpeed(float speed);
		void setOwner(Entity* entity);
		void setDamage(int damage);

	private:
		int damage;
		float speed;
		int localState;
		Entity* owner;
		float timeToLive;
};


#endif
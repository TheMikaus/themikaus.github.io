#include <you_win_screen.h>
#include <tiles.h>


YouWinScreenGameState onlyOneYWSGS;


YouWinScreenGameState::YouWinScreenGameState()
{
	GameStateManager* gsm = GameStateManager::getInstance();
	gsm->registerState("YouWinScreen", this);
}


void YouWinScreenGameState::init()
{
	int max;
    GraphicData* graphicData = gm->getGraphicData(&max);

	BackgroundData* bData = gm->getBackgroundData(&max);
	bData[0].type = BACKGROUND_TYPE_PIXELED;
	bData[0].width = YOUWINSCREEN_WIDTH;
	bData[0].height = YOUWINSCREEN_HEIGHT;
	bData[0].info.pixeledInfo.colorData = youwinscreen_data;
	bData[0].display[0] = -40;
	bData[0].display[1] = 0;
	bData[0].display[2] = 0;
	bData[0].info.pixeledInfo.srcX = 0;
	bData[0].info.pixeledInfo.srcY = 0;
	bData[0].info.pixeledInfo.pixelWidth = 1;
	bData[0].info.pixeledInfo.pixelHeight = 1;
	bData[0].info.pixeledInfo.pixelDepth = 5;
	bData[0].info.pixeledInfo.displayWidthInPixels = bData[0].width;
	bData[0].info.pixeledInfo.displayHeightInPixels = bData[0].height;
	
	CameraData cameraData;
	cameraData.pos[0] = cameraData.pos[1] = 0;
	cameraData.pos[2] = -40;
	cameraData.rot[0] = cameraData.rot[1] = cameraData.rot[2] = 0;
	gm->setCameraData(cameraData);
	
	LightData* lightData = gm->getLightData(&max);
	lightData[0].type = LIGHT_DATA_DIRECTION;
	lightData[0].color = 0xffffffff;
	lightData[0].strength = 1.0f;
	lightData[0].pos[0] = 0;
	lightData[0].pos[1] = 0.25;
	lightData[0].pos[2] = 0.25;

	gm->updateAllGraphicBoxedData();
	gm->updateAllBackgroundBoxedData();
        gm->setGraphicDataOutOfDate();
	
	delay = 120.0f;
}


void YouWinScreenGameState::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;
	im->updateButtons(deltaTime);
	
	delay -= dT;
	if (delay < 0)
	{
		GameStateManager::getInstance()->setNewState("TitleScreen");
	}
	em->update(deltaTime);
	gm->render(deltaTime);
}


void YouWinScreenGameState::destroy()
{
	int max;
	// TODO: clean up all the resources
	BackgroundData* bData = gm->getBackgroundData(&max);
	bData[0].type = BACKGROUND_TYPE_NONE;
	bData[1].type = BACKGROUND_TYPE_NONE;
}

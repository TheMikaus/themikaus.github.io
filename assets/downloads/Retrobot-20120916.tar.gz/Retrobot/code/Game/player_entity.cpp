#include <player_entity.h>
#include <bullet_entity.h>

#include <string.h>

bool PlayerEntityCreator::registered = false;
PlayerEntityCreator thePlayerEntityCreator;

PlayerEntityCreator::PlayerEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "player");
	}
}

Entity* PlayerEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	PlayerEntity* playerEntity = new PlayerEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	playerEntity->setSpriteIndex(spriteIndex);
	playerEntity->setGraphicIndex(graphicIndex);
	playerEntity->setPosition(pos);
	playerEntity->setRotation(rot);
	playerEntity->getSpriteData()->layerId = 0;
	
	return playerEntity;
}


#define PLAYER_MOVEMENT_SPEED (0.1f)
PlayerEntity::PlayerEntity()
{
	setHealthMax(3);
	setHealth(getHealthMax());
	
	canShoot = false;
	ims = InputManagerSystem::getInstance();
	em = EntityManager::getInstance();
	moveUp = ims->findButton("MoveUp");
	moveDown = ims->findButton("MoveDown");
	moveLeft = ims->findButton("MoveLeft");
	moveRight = ims->findButton("MoveRight");
	fire = ims->findButton("Fire");
	setIsPhysical(true);
	speed = PLAYER_MOVEMENT_SPEED;
	rotatingSpeed = 0;
	deadBosses = 0;
	maxBulletCount = 3;
        posAdjust = 0;
}

PlayerEntity::~PlayerEntity()
{
}

void PlayerEntity::incrementDeadBosses()
{
	deadBosses++;
}

int PlayerEntity::getDeadBossCount()
{
	return deadBosses;
}


void PlayerEntity::setCanShoot(bool shoot)
{
	canShoot = shoot;
}

int PlayerEntity::getMaxBulletCount()
{
	return maxBulletCount;
}


void PlayerEntity::setSpeed(float speed)
{
	this->speed = speed;
}


#define BASE_ROT_SPEED (0.3f)
#define FRAMES_TO_TURN (3.14159f/BASE_ROT_SPEED)
//#define POS_ADJUST_PER_FRAME ((((float)getGraphicData()->width)/FRAMES_TO_TURN)/3.0f)
#define POS_ADJUST_PER_FRAME (0.0f)
void PlayerEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;
	
	deltaTime = 1;
	if (isDead())
	{
		justDied();
	}
	else if (spriteData != NULL)
	{
		if (ims->buttonDown(moveUp))
		{
			spriteData->pos[1] += speed * dT;
		}
		else if (ims->buttonDown(moveDown))
		{
			spriteData->pos[1] -= speed * dT;
		}
		else if (ims->buttonDown(moveLeft) && rotatingSpeed >= 0)
		{
			if (spriteData->rot[1] > -3.14159)
			{
				rotatingSpeed = -0.3;
				posAdjust = POS_ADJUST_PER_FRAME;
			}
			else
			{
				spriteData->pos[0] -= speed * dT;
			}
		}
		else if (ims->buttonDown(moveRight) && rotatingSpeed <= 0)
		{
			if (spriteData->rot[1] < 0.0)
			{
				rotatingSpeed = 0.3;
				posAdjust = -POS_ADJUST_PER_FRAME;
			}
			else
			{
				spriteData->pos[0] += speed * dT;
			}
		}
		
		if (ims->buttonWasPressed(fire) && canShoot)
		{
			int bulletCount;
			Entity** bullets = em->getEntitiesInGroup(2, bulletCount);
			for (int bIdx = 0; bIdx < bulletCount && bIdx < maxBulletCount; bIdx++)
			{
				if (bullets[bIdx] == NULL)
				{
				
					float rot[3] = {0.0, 0.0, 0.0};
					float pos[3];
					pos[0] = spriteData->pos[0];
					if (spriteData->rot[1] < 0) pos[0] -= getGraphicData()->width;
					pos[1] = spriteData->pos[1] + 6.0;
					pos[2] = spriteData->pos[2];
					
					int bTag = em->createEntity(2, "bullet", pos, rot, 2);
					if (bTag != -1)
					{
						BulletEntity* bullet = (BulletEntity*)em->getEntity(bTag);
						float bSpeed = 3.0;
						if (spriteData->rot[1] < 0) bSpeed *= -1.0f;
						bullet->setSpeed(bSpeed);
						bullet->setOwner(this);
					}
					break;
				}
			}
		}
		
		spriteData->rot[1] += rotatingSpeed * dT;
		spriteData->pos[0] += posAdjust;
		if (spriteData->rot[1] < -3.14159)
		{
			spriteData->rot[1] = -3.14159;
			spriteData->pos[0] -= posAdjust;
			rotatingSpeed = 0;
			posAdjust = 0;
		}
		else if (spriteData->rot[1] > 0)
		{
			spriteData->rot[1] = 0;
			spriteData->pos[0] -= posAdjust;
			rotatingSpeed = 0;
			posAdjust = 0;
		}
		spriteData->visible = true;
	}
}


void PlayerEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	restorePosRotData();
}


void PlayerEntity::message(const char* messageName, int data)
{
	if (strcmp(messageName, "damage") == 0)
	{
		addHealth(-data);
	}
	else if (strcmp(messageName, "increment_boss_count") == 0)
	{
		incrementDeadBosses();
	}
	else if (strcmp(messageName, "increment_bullet_count") == 0)
	{
		maxBulletCount++;
	}
	else if (strcmp(messageName, "increment_health") == 0)
	{
		setHealthMax(getHealthMax() + 1);
		addHealth(1);
	}
}


void PlayerEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
	spriteData->visible = false;
}


void PlayerEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* PlayerEntity::getName()
{
	return "player";
}

#ifndef DUMMY_ENT_H
#define DUMMY_ENT_H

#include <entity_manager.h>
#include <damageable_entity.h>


class DummyEntityCreator : public EntityCreator
{
	public:
		DummyEntityCreator();
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex);
		
		static bool registered;
};

class DummyEntity : public DamageableEntity
{
	public:
		DummyEntity();
		virtual ~DummyEntity();
		virtual void update(long deltaTime);
		virtual void collision(Entity* collidingObj);
		virtual void justDied();
		virtual void destroy();
		virtual const char* getName();
		virtual void message(const char* messageName, int data);

	private:
};


#endif
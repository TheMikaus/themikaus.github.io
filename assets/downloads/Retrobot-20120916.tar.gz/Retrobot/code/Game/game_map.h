#ifndef GAME_MAP_H
#define GAME_MAP_H


#define ENTITY_TYPE_PLAYER 0
#define ENTITY_TYPE_DOOR 1
#define ENTITY_TYPE_DOOR_B 2
#define ENTITY_BOSS_START (ENTITY_TYPE_DOOR_B + 1)


typedef struct LevelBackgroundData
{
	int width;
	int height;
	unsigned int* backgroundData;
} LevelBackgroundData;


typedef struct EntityPlacementData
{
	int x;
	int y;
	int entityType;
	int extraInfo;
} EntityPlacementData;


typedef struct LightPlacementData
{
	int x;
	int y;
} LightPlacementData;


#define SCREEN_DATA_WIDTH 50
#define SCREEN_DATA_HEIGHT 30
typedef struct ScreenData
{
	EntityPlacementData* entityPlacementData;
	int entityCount;
	LightPlacementData* lightPlacementData;
	int lightCount;
	int x;
	int y;
	int xE;
	int yE;
	int nonZero;
} ScreenData;


typedef struct GameMapData
{
	EntityPlacementData* playerPlacement;
	int startScreen[2];
	LevelBackgroundData levelBackgroundData;
	ScreenData* screenData;
	int screenDataWidth;
	int screenDataHeight;
} GameMapData;



GameMapData* loadGameMapData(int w, int h, unsigned int* mapData);
void freeGameMapData(GameMapData* gameMapData);

#endif
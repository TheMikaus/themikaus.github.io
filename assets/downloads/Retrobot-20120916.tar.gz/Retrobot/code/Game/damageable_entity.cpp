#include <damageable_entity.h>

void DamageableEntity::setHealthMax(int healthMax)
{
	this->healthMax = healthMax;
}

void DamageableEntity::setHealth(int health)
{
	this->health = health;
}


int DamageableEntity::getHealthMax()
{
	return healthMax;
}


int DamageableEntity::getHealth()
{
	return health;
}


void DamageableEntity::addHealth(int healthToAdd)
{
	health += healthToAdd;
	if (health > healthMax) health = healthMax;
}


bool DamageableEntity::isDead()
{
	return health <= 0;
}


DamageableEntity::~DamageableEntity()
{
}
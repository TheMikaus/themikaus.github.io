#include <boss_d_entity.h>
#include <bullet_entity.h>

#include <stdio.h>

#include <string.h>
#include <math.h>

bool BossDEntityCreator::registered = false;
BossDEntityCreator theBossDEntityCreator;

BossDEntityCreator::BossDEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "boss_d");
	}
}

Entity* BossDEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	BossDEntity* bossEntity = new BossDEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	bossEntity->setSpriteIndex(spriteIndex);
	bossEntity->setGraphicIndex(graphicIndex);
	bossEntity->setPosition(pos);
	bossEntity->setRotation(rot);
	bossEntity->getSpriteData()->layerId = 0;
	bossEntity->setStartingPosition(pos);
	return bossEntity;
}


#define BOSS_MOVEMENT_SPEED (0.5f)
BossDEntity::BossDEntity()
{
	setHealthMax(20);
	setHealth(getHealthMax());
	player = NULL;
	canShoot = true;
	ims = InputManagerSystem::getInstance();
	em = EntityManager::getInstance();
	setIsPhysical(true);
	speed = BOSS_MOVEMENT_SPEED;
	shootDelay = 0;
	type = 0;
	target = 0;
	lastTarget = -1;
	waitInPlace = 15.0;
}

void BossDEntity::setType(int type)
{
	this->type = type;
}

BossDEntity::~BossDEntity()
{
}


void BossDEntity::setCanShoot(bool shoot)
{
	canShoot = shoot;
}

void BossDEntity::setSpeed(float speed)
{
	this->speed = speed;
}


void BossDEntity::setStartingPosition(float* pos)
{
	startingPosition[0] = pos[0];
	startingPosition[1] = pos[1];
	
	targetPositions[0] = pos[1] + 16.0;
	targetPositions[1] = pos[1];
	targetPositions[2] = pos[1] - 16.0;
}

void BossDEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;

	if (isDead())
	{
		justDied();
	}
	else if (spriteData != NULL)
	{
		spriteData->visible = true;
		if (player == NULL)
		{
			int max;
			Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(-1, max);
			for (int eIdx = 0; eIdx < max; eIdx++)
			{
				if (strcmp(entities[eIdx]->getName(), "player") == 0)
				{
					player = (DamageableEntity*)entities[eIdx];
					break;
				}
			}
		}
		
		SpriteData* spriteData = getSpriteData();
		// If not in the targe position, move to it
		// else If wait time > 0 do nothing
		// if in a target position move to the start position
		// else if can shoot, shoot
		float distance = spriteData->pos[1] - targetPositions[target + 1];
		if (fabs(distance) > 0.5f)
		{
			if (distance > 0.5f)
			{
				spriteData->pos[1] -= speed * dT;
			}
			else if (distance < 0.5f)
			{
				spriteData->pos[1] += speed * dT;
			}
		}
		else if (waitInPlace > 0)
		{
			waitInPlace -= dT;
		}
		else
		{
			waitInPlace = 5.0;
			int tmp = target;
			if (lastTarget == 0) target = 0;
			if (lastTarget == -1) target = 1;
			if (lastTarget == 1) target = -1;
			lastTarget = tmp;
			
			if (lastTarget == 0)
			{
				int bulletCount;
				Entity** bullets = em->getEntitiesInGroup(3, bulletCount);
				for (int bIdx = 0; bIdx < bulletCount; bIdx++)
				{
					if (bullets[bIdx] == NULL)
					{
						float rot[3] = {0.0, 0.0, 0.0};
						float pos[3];
						pos[0] = spriteData->pos[0];
						pos[1] = spriteData->pos[1] + 4.0;
						pos[2] = spriteData->pos[2];
						int bTag = em->createEntity(3, "bullet", pos, rot, 4);
						if (bTag != -1)
						{
							BulletEntity* bullet = (BulletEntity*)em->getEntity(bTag);
							float bSpeed = 5.0;
							bullet->setSpeed(bSpeed);
							bullet->setOwner(this);
							bullet->setSpecialData(getSpecialData());
							bullet->setDamage(3);
						}
						break;
					}
				}
			}
		}
	}
}


void BossDEntity::message(char const* messageName, int data)
{
	if (strcmp(messageName, "damage") == 0)
	{
		addHealth(-data);
	}
}


void BossDEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	restorePosRotData();
 	if (collidingObj != NULL)
	{
        if (strcmp(collidingObj->getName(), "player") == 0)
        {
            collidingObj->message("damage", 10);
        }
	}
}


void BossDEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
	int max;
	player->message("increment_boss_count", 0);
	
	Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(1, max);
	for (int eIdx = 0; eIdx < max; eIdx++)
	{
		if (entities[eIdx] != NULL && strcmp(entities[eIdx]->getName(), "door") == 0)
		{
			entities[eIdx]->message("open", type);
		}
	}
	
	// TODO: FIX THIS.
	//       Currently using a hard coded graphic index.
	//       These indexes should be inherent to the entity (register with the GM?)
	float rot[3] = {0.0, 0.0, 0.0};
	em->createEntity(3, "upgrade", getSpriteData()->pos, rot, 5);
	EntityManager::getInstance()->deleteEntity(getTagId());
}


void BossDEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* BossDEntity::getName()
{
	return "boss_d";
}

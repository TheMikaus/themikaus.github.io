#include <door_entity.h>

#include <string.h>

#define DOOR_ENTITY_STATE_IN_WALL 0
#define DOOR_ENTITY_STATE_MOVE_UP 1
#define DOOR_ENTITY_STATE_IN_PLACE 2
#define DOOR_ENTITY_STATE_MOVE_DOWN 3

bool DoorEntityCreator::registered = false;
DoorEntityCreator theDoorEntityCreator;

DoorEntityCreator::DoorEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "door");
	}
}

Entity* DoorEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	DoorEntity* doorEntity = new DoorEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	doorEntity->setSpriteIndex(spriteIndex);
	doorEntity->setGraphicIndex(graphicIndex);
	pos[1] -= doorEntity->getGraphicData()->height;
	doorEntity->setPosition(pos);
	doorEntity->setRotation(rot);
	doorEntity->getSpriteData()->layerId = 0;
	doorEntity->setIsPhysical(false);
	doorEntity->setSpeed(2.0f);
	
	return doorEntity;
}


void DoorEntity::setType(int type)
{
	this->type = type;
}


void DoorEntity::rightSideDoor(bool rightSide)
{
	this->rightSide = rightSide;
}


DoorEntity::DoorEntity()
{
	speed = 0;
	localState = DOOR_ENTITY_STATE_IN_WALL;
	player = NULL;
	extra = 0;
}

DoorEntity::~DoorEntity()
{
}

void DoorEntity::setSpeed(float speed)
{
	this->speed = speed;
}


void DoorEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;
	
	if (localState == DOOR_ENTITY_STATE_IN_WALL)
	{
		if (player == NULL)
		{
			int max;
			Entity** entities = EntityManager::getInstance()->getEntitiesInGroup(-1, max);
			for (int eIdx = 0; eIdx < max; eIdx++)
			{
				if (strcmp(entities[eIdx]->getName(), "player") == 0)
				{
					player = entities[eIdx];
					break;
				}
			}
		}
		
		// Check if player is to the right of us and if so then trigger the move up
		float px = player->getSpriteData()->pos[0];
		float dx = getSpriteData()->pos[0];
		bool playerPassed = rightSide && px > (dx + getGraphicData()->width);
		playerPassed = playerPassed || (!rightSide && px < dx);
		if (playerPassed)
		{
			localState = DOOR_ENTITY_STATE_MOVE_UP;
			setIsPhysical(true);
			distanceMoved = getGraphicData()->height;
		}
	}
	else if (localState == DOOR_ENTITY_STATE_MOVE_UP)
	{
		if (distanceMoved > 0)
		{
			distanceMoved -= speed * dT;
			getSpriteData()->pos[1] += speed * dT;
		}
		else
		{
			localState == DOOR_ENTITY_STATE_IN_PLACE;
		}
	}
	else if (localState == DOOR_ENTITY_STATE_MOVE_DOWN)
	{
		if (distanceMoved < getGraphicData()->height)
		{
			distanceMoved += speed * dT;
			getSpriteData()->pos[1] -= speed * dT;
		}
		else
		{
			localState == DOOR_ENTITY_STATE_IN_PLACE;
		}
	}
}


void DoorEntity::message(const char* messageName, int data)
{
	// Open command will be issued
	if (strcmp(messageName, "open") == 0)
	{
		if (type == data)
		{
			localState = DOOR_ENTITY_STATE_MOVE_DOWN;
		}
	}
}

void DoorEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	
	
}


void DoorEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
}


void DoorEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* DoorEntity::getName()
{
	return "door";
}

#include <player_following_entity.h>


bool PlayerFollowingEntityCreator::registered = false;
PlayerFollowingEntityCreator thePlayerFollowingEntityCreator;

PlayerFollowingEntityCreator::PlayerFollowingEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "player_following");
	}
}

Entity* PlayerFollowingEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	PlayerFollowingEntity* playerEntity = new PlayerFollowingEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	playerEntity->setSpriteIndex(spriteIndex);
	playerEntity->setGraphicIndex(graphicIndex);
	playerEntity->setPosition(pos);
	playerEntity->setRotation(rot);
	
	return playerEntity;
}


void PlayerFollowingEntity::message(const char* messageName, int data)
{
}

PlayerFollowingEntity::PlayerFollowingEntity()
{
	setHealthMax(10);
	setHealth(getHealthMax());
	em = EntityManager::getInstance();
	setIsPhysical(false);
}

#define PLAYER_FOLLOWING_MOVEMENT_SPEED (0.05f)
void PlayerFollowingEntity::update(long deltaTime)
{
	if (isDead())
	{
		justDied();
	}
	else if (spriteData != NULL)
	{
		int max;
		// I know the player is currently in group 0
		// it will be convention, but I could just pass in -1
		// I also know that there will only be one entity in this group
		Entity** entities = em->getEntitiesInGroup(0, max);
		if (entities[0] != NULL)
		{
			SpriteData* esd = entities[0]->getSpriteData();
			
			if (esd != NULL)
			{
				float xDir = (esd->pos[0] < spriteData->pos[0] ? -1 : 1);
				float yDir = (esd->pos[1] < spriteData->pos[1] ? -1 : 1);
				spriteData->pos[0] += xDir * PLAYER_FOLLOWING_MOVEMENT_SPEED * deltaTime;
				spriteData->pos[1] += yDir * PLAYER_FOLLOWING_MOVEMENT_SPEED * deltaTime;
			}
		}
	}
}


void PlayerFollowingEntity::collision(Entity* collidingObj)
{
	// The collision is called on both objects
	// be careful what you put in here.
	// In general the other objects will do something to this one
	restorePosRotData();
}


void PlayerFollowingEntity::justDied()
{
	// TODO: this will spawn a sparks entity I think
}


void PlayerFollowingEntity::destroy()
{
	// TODO: This is called when the object is removed  from the em
}


const char* PlayerFollowingEntity::getName()
{
	return "player_following";
}

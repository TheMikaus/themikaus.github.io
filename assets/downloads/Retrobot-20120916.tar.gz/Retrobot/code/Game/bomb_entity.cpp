#include <bomb_entity.h>
#include <bullet_entity.h>

bool BombEntityCreator::registered = false;
BombEntityCreator theBombEntityCreator;

BombEntityCreator::BombEntityCreator()
{
	if (registered == false)
	{
		registered = true;
		EntityManager::getInstance()->registerEntityCreator(this, "bomb");
	}
}


Entity* BombEntityCreator::createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex)
{
	BombEntity* bombEntity = new BombEntity();
	
	/* NOTE: These may all get moved into the Entity Manager */
	bombEntity->setSpriteIndex(spriteIndex);
	bombEntity->setGraphicIndex(graphicIndex);
	bombEntity->setPosition(pos);
	bombEntity->setRotation(rot);
	bombEntity->getSpriteData()->layerId = 0;
	
	return bombEntity;
}


BombEntity::BombEntity()
{
	timeToLive = 60.0f;
}

BombEntity::~BombEntity()
{
	
}

void BombEntity::update(long deltaTime)
{
	float dT = (float)deltaTime/60000.0000;
	timeToLive -= dT;
	if (timeToLive < 0)
	{
		justDied();
	}
}

void BombEntity::collision(Entity* collidingObj)
{
}


void BombEntity::shootBullet(float rotation)
{
	int bulletCount;
	EntityManager* em = EntityManager::getInstance();
	Entity** bullets = em->getEntitiesInGroup(3, bulletCount);
	for (int bIdx = 0; bIdx < bulletCount; bIdx++)
	{
		if (bullets[bIdx] == NULL)
		{
		
			float rot[3] = {0.0, 0.0, rotation};
			float pos[3];
			int max;
			pos[0] = spriteData->pos[0] + getGraphicData()->width / 2.0;
			pos[1] = spriteData->pos[1] + getGraphicData()->height / 2.0;
			pos[2] = spriteData->pos[2];
			
			int bTag = em->createEntity(3, "bullet", pos, rot, 2);
			if (bTag != -1)
			{
				BulletEntity* bullet = (BulletEntity*)em->getEntity(bTag);
				float bSpeed = -5.0;
				bullet->setSpeed(bSpeed);
				bullet->setOwner(owner);
				bullet->setSpecialData(getSpecialData());
				bullet->setDamage(3);
			}
			break;
		}
	}
}

void BombEntity::justDied()
{
	// TODO: Spawn four bullets that go off in the cardinal directions
	// Fire a bullet at the given rotation
	shootBullet(0);
	shootBullet(3.14159/2.0);
	shootBullet(3.14159);
	shootBullet(3.14159 + 3.14159/2.0);
	EntityManager::getInstance()->deleteEntity(getTagId());
}


void BombEntity::destroy()
{
}

const char* BombEntity::getName()
{
	return "bomb";
}

void BombEntity::message(const char* messageName, int data)
{
}

void BombEntity::setOwner(Entity* entity)
{
	this->owner = entity;
}


void BombEntity::setDamage(int damage)
{
	this->damage = damage;
}
#ifndef ENTITY_MANAGER_H
#define ENTITY_MANAGER_H

#include <graphics_manager.h>



class Entity
{
	public:
		Entity();
		
		virtual void update(long deltaTime) = 0;
		virtual void collision(Entity* collidingObj) = 0;
		virtual void justDied() = 0;
		virtual void destroy() = 0;
		virtual void message(const char* messageName, int data) = 0;
		virtual const char* getName() = 0;
		virtual ~Entity();
		
		void setTagId(int id);
		int getTagId();
		void setSpriteIndex(int index);
		int getSpriteIndex();
		void setGraphicIndex(int index);
		GraphicData* getGraphicData();
		int getGraphicIndex();
		SpriteData* getSpriteData();
		
		void setRotation(float* rot);
		void setPosition(float* pos);
		void getRotation(float* rot);
		void getPosition(float* pos);
		void storePosRotData();
		void restorePosRotData();
		void setEnabled(bool isEnabled);
		bool isEnabled();
		
		bool isPhysical();
		void setIsPhysical(bool isIt);
		
		void setSpecialData(int data);
		int getSpecialData();

		
	protected:
		SpriteData* spriteData;
		
		
	private:
		float lastPos[3];
		float lastRot[3];
		int tagId;
		int spriteIndex;
		int graphicIndex;
		bool physical;
		bool enabled;
		int specialData;
};

class EntityCreator
{
	public:
		virtual Entity* createEntity(float pos[3], float rot[3], int spriteIndex, int graphicIndex) = 0;
};


#define MAX_ENTITIES 160
#define MAX_ENTITY_CREATORS 40
#define ENTITY_TYPE_NAME_MAX 20
class EntityManager
{
	public:
		static EntityManager* getInstance();
		void setupGroups(int numberOfGroups, ...);
		Entity** getEntitiesInGroup(int groupNumber, int& max);
		void clearEntitiesInGroup(int groupNumber);
		void registerEntityCreator(EntityCreator* creator, const char type[ENTITY_TYPE_NAME_MAX]);
		int createEntity(int groupNumber, const char type[ENTITY_TYPE_NAME_MAX], float pos[3], float rot[3], int graphicIndex);
		void deleteEntity(int tagId);
		void update(long deltaTime);
		Entity* getEntity(int tagId);
		
	protected:
		EntityManager();
		
		int findEmptyEntityTagId(int startIndex, int endIndex);
		void processDeleteQueue();
		
	private:
		static EntityManager* instance;
		Entity* listOfEntities[MAX_ENTITIES];
		int deleteQueue[MAX_ENTITIES];
		int entitiesToDelete;
		int* groupIndexes;
		int* groupSizes;
		int numberOfGroups;

		EntityCreator* entityCreators[MAX_ENTITY_CREATORS];
		
		char entityTypes[MAX_ENTITY_CREATORS][ENTITY_TYPE_NAME_MAX];
};


#endif
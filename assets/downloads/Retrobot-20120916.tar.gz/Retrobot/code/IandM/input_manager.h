#ifndef INPUT_MANAGER_H
#define INPUT_MANAGER_H

#include <exception>


/****************************************************************/
/****************************************************************/
/* DEFINES AND SUPPORTING INPUT CLASSES/STRUCTS                 */
/****************************************************************/
/****************************************************************/

#define MAX_BUTTON_COUNT 32


/**
 * Button Id returned from the input manager that should be used as
 * the input reference when checking if a button is down.
 */
typedef unsigned char ButtonId;


/**
 * This is the system specific button name
 * Should be an enum or a pound define in an implementing class
 */
typedef int InputMap;


/**
 * This type is the general name used for that input button
 * i.e. "Attack"
 */
 #define INPUT_NAME_MAX 32


/**
 * Data structure used to internally store button information
 * Clients shouldn't really get this, but it needs to be exposed here
 * for the implementations to work properly.
 * downTime     : how long this button has been pressed
 * buttonId     : where this input button is stored in the array
 * wasChecked   : has this been checked since it was pressed?
 * inputToCheck : The buttons that map to the given input name
 * inputName    : the visible name i.e. "attack button"
 */
 #define INPUT_BUTTON_MAX 8
typedef struct InputButton
{
		long downTime;
		ButtonId buttonId;
		bool wasChecked;
		int inputToCheck[INPUT_BUTTON_MAX];
		int inputCount;
		char inputName[INPUT_NAME_MAX];
} InputButton;



/****************************************************************/
/****************************************************************/
/* MAIN INPUT MANAGER INTERFACE                                 */
/****************************************************************/
/****************************************************************/


/**
 * This is the abstract class that the input systems need to implement
 * for system specific input updates.
 */
class InputUpdateSystem
{
	public:
		/**
		 * Return true if the mapped button is down
		 * map : the name of the button
		 * throws : InputMapInvalidException
		 */
		virtual bool buttonDown(InputMap map) = 0;
		
		/**
		 * this function is called once prior to checking all the buttons
		 * and is used to update local state information
		 */
		virtual void update() = 0;

		/**
		 * destructor!
		 */
		virtual ~InputUpdateSystem();
};


/**
 * TODO: Update comment
 */
class InputManagerSystem
{
	public:
		/**
		 * This function should loop through all of the
		 * registered buttons and update them accordingly
		 * with the deltaTime if they are currently down.
		 * deltaTime : the units don't matter here as long as
		 *             they are consistent
		 * throws : NoInputUpdateSystemException
		 */
		virtual void updateButtons(long deltaTime);
		
		/**
		 * Returns the id of the button with the given name
		 * name : the action name for the input being looked for
		 *        i.e. "action"
		 */
		ButtonId findButton(const char name[INPUT_NAME_MAX]);
		
		/**
		 * registers the inputMap with the inputName.  If there is
		 * no current association to InputName, then a new link is
		 * added.
		 * name   : the action name for the input being registered
		 * input  : the key name for the input being registered
		 * throws : InputButtonMapFullException
		 */
		ButtonId registerButton(const char name[INPUT_NAME_MAX], InputMap input);
		
		/**
		 * returns how long the given button has been pressed
		 * buttonId : the buttonId of the button to check
		 * throws   : InputButtonNotFoundException
		 */
		long buttonDown(ButtonId buttonId);
		
		/**
		 * returns whether or not the button was pressed.
		 * buttonId : the buttonId of the button to check
		 * throws   : InputButtonNotFoundException
		 */
		bool buttonWasPressed(ButtonId buttonId);

		/**
		 * Sets the input update system for this instance
		 */
		 void setInputUpdateSystem(InputUpdateSystem* sys);


		void clearInputs();

		/**
		 * returns the instance of InputManagerSystem
		 */
		static InputManagerSystem* getInstance();

	protected:
		InputManagerSystem();

	private:
		static InputManagerSystem* instance;
		
		InputUpdateSystem* inputUpdateSystem;
		unsigned char buttonCount;
		InputButton inputButtons[MAX_BUTTON_COUNT];
};



/****************************************************************/
/****************************************************************/
/* EXCEPTIONS                                                   */
/****************************************************************/
/****************************************************************/


/**
 * This exception is thrown if the number of input buttons
 * registered exceeds MAX_BUTTON_COUNT
 */
class InputButtonMapFullException : public std::exception
{
	virtual const char* what() const throw();
};


/**
 * This exception is thrown if no input system is set
 */
class NoInputUpdateSystemException : public std::exception
{
	virtual const char* what() const throw();
};


/**
 * This exception is thrown if the request button Id is
 * outside the range of registered buttons
 */
class InputButtonIdNotFoundException : public std::exception
{
	virtual const char* what() const throw();
	public:
		InputButtonIdNotFoundException(ButtonId buttonId);

	private:
		ButtonId buttonId;
		char myMessage[256];
};


/**
 * This exception is thrown if the request map is
 * not supported by the current input update system
 */
class InputMapInvalidException : public std::exception
{
	virtual const char* what() const throw();
	public:
		InputMapInvalidException(InputMap map);
		~InputMapInvalidException() throw();

	private:
		InputMap map;
		char myMessage[256];
};

#endif

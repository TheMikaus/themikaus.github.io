#ifndef GRAPHICS_MANAGER_H
#define GRAPHICS_MANAGER_H

#include <string>

#define MAX_SPRITE_DATA 256
typedef struct SpriteData
{
	float pos[3];       /* position in 3d space     */
	float rot[3];       /* rotation in 3d space     */
	int graphicIndex; /* what graphic data to use */
	int effectIndex;  /* effect data to apply     */
	int layerId;      /* render order             */
	bool visible;     /* whether or not to render */
} SpriteData;



typedef struct CameraData
{
	float pos[3];
	float rot[3];
} CameraData;


typedef struct DimensionData
{
	float x;
	float y;
	float width;
	float height;
} DimensionData;

typedef struct BoxData
{
	DimensionData* dimensionData;
	int numberOfBoxes;
} BoxData;

#define MAX_GRAPHIC_DATA 256
typedef struct GraphicData
{
	int width;       /* width in pixels      */
	int height;      /* height in pixels     */
	float depth;       /* number of units to extrude the voxel */
	unsigned int* pixelData;  /* RGBA for each pixel  */
	BoxData boxedData;
} GraphicData;


#define MAX_LIGHT_DATA 4
#define LIGHT_DATA_NONE 0
#define LIGHT_DATA_POINT 1
#define LIGHT_DATA_SPOT 2
#define LIGHT_DATA_DIRECTION 3
typedef struct LightData
{
	int type; // POINT, SPOT, DIRECTION
	
	unsigned int color;
	float strength;
	float pos[3];
	float rot[3];
	
} LightData;

#define MAX_EFFECT_DATA 256
class EffectData
{
	public:
		virtual void applyEffectToSprite(SpriteData& spriteData, long deltaTime);
};


#define MAX_BACKGROUND_DATA 4
#define BACKGROUND_TYPE_NONE 0
#define BACKGROUND_TYPE_TILED 1
#define BACKGROUND_TYPE_PIXELED 2
typedef struct BackgroundData
{
	int width;
	int height;
	float display[3];
	int type;
	
	union info
	{
		struct tiledInfo
		{
			int* tileData;
			int srcXInTiles;
			int srcYInTiles;
			float tileWidth;
			float tileHeight;
			int displayWidthInTiles;
			int displayHeightInTiles;	
		} tiledInfo;
		
		struct pixeledInfo
		{
			unsigned int* colorData;
			int srcX;
			int srcY;
			float pixelWidth;
			float pixelHeight;
			float pixelDepth;
			int displayWidthInPixels;
			int displayHeightInPixels;
			BoxData boxedData;
		} pixeledInfo;
	} info;
} BackgroundData;




class Renderer
{
	public:
		virtual void setSpriteData(SpriteData* sprites, int spriteMax) = 0;
		virtual void setGraphicData(GraphicData* graphics, int graphicMax) = 0;
		virtual void setBackgroundData(BackgroundData* backgrounds, int backgroundMax) = 0;
		virtual void setLightData(LightData* lights, int lightMax) = 0;
		virtual void render(CameraData cameraData) = 0;
};


class GraphicsManager
{
	public:
		static GraphicsManager* getInstance();
		LightData* getLightData(int* maxLights);
		SpriteData* getSpriteData(int* maxSprites);
		GraphicData* getGraphicData(int* maxGraphics);
		EffectData** getEffectData(int* maxEffects);
		BackgroundData* getBackgroundData(int* maxBackgrounds);
		void setRenderer(Renderer* renderer);
		void render(long deltaTime);
		void setGraphicDataOutOfDate();
		void setCameraData(CameraData cameraData);
		void updateAllGraphicBoxedData();
		void updateGraphicBoxedData(int gIdx);
		void updateAllBackgroundBoxedData();
		void updateBackgroundBoxedData(int bIdx);

	protected:
		GraphicsManager();
		
	private:
		static GraphicsManager* instance;

		CameraData cameraData;
		LightData lightData[MAX_LIGHT_DATA];
		SpriteData spriteData[MAX_SPRITE_DATA];
		GraphicData graphicData[MAX_GRAPHIC_DATA];
		BackgroundData backgroundData[MAX_BACKGROUND_DATA];
		EffectData* effectData[MAX_EFFECT_DATA];
		Renderer* renderer;
		bool graphicDataOutOfDate;
};



#endif

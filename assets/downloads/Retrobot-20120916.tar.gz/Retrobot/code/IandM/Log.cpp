#include <Log.h>

FILE* LOG::instance = NULL;

FILE* LOG::getInstance()
{
  if (instance == NULL)
  {
    instance = fopen("ms0:/DUMP.TXT","a");
  }
  return instance;
}

void LOG::closeInstance()
{
  if (instance != NULL)
  {
    fclose(instance);
    instance = NULL;
  }
}

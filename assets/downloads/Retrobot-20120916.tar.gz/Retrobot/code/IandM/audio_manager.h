#ifndef AUDIO_MANAGER_H
#define AUDIO_MANAGER_H

#include <stdio.h>

class AudioPlayerInterface
{
};


class MP3ConverterInterface
{
};


#define SR_TYPE_WAVE 0
#define SR_TYPE_MP3 1
struct SoundReference
{
  char soundName[40];
  char soundFileName[100];
  int type; // 0 = WAVE, 1 = MP3
};

struct AudioReference
{
  FILE* fileReference;
  bool looping;
  unsigned long offset;
  SoundReference* soundReference;
  bool active;
};

#define MAX_RT_SOUNDS 30
#define MAX_SOUNDS 30
typedef int SoundReferenceId;
typedef int AudioReferenceId;
class AudioManager
{
  public:
    static AudioManager* getInstance();
    static AudioManager* createInitialInstance(MP3ConverterInterface* mci, AudioPlayerInterface* api);

    SoundReferenceId registerSound(char* name, char* filename, int srType);
    SoundReferenceId getIdByName(char* name);

    AudioReferenceId playSound(SoundReferenceId soundId);
    AudioReferenceId playSoundByName(char* name);

    AudioReferenceId loopSound(SoundReferenceId soundId);
    AudioReferenceId loopSoundByName(char* name);

    void stopSound(AudioReferenceId id);
    void stopAllSound();

    void setVolume(int channel, int volume);

    void update(unsigned long deltaTime);

  private:
    AudioManager(MP3ConverterInterface* mci, AudioPlayerInterface* api);
    static AudioManager* instance;

    MP3ConverterInterface* mci;
    AudioPlayerInterface* api;

    SoundReference sounds[MAX_SOUNDS];
    AudioReference rtSounds[MAX_RT_SOUNDS];
    int soundCount;
};

#endif

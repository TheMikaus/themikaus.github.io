#ifndef LOG_H
#define LOG_H

#include <stdio.h>

class LOG
{
  public:
    static FILE* getInstance();
    static void closeInstance();

  private:
    static FILE* instance;
};

#endif

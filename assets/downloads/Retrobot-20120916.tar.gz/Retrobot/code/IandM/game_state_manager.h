#ifndef GAME_STATE_MANAGER_H
#define GAME_STATE_MANAGER_H


#include <input_manager.h>
#include <graphics_manager.h>
#include <entity_manager.h>


class GameState
{
	public:
		virtual void init() = 0;
		virtual void update(long deltaTime) = 0;
		virtual void destroy() = 0;
		GameState();
		
	protected:
		InputManagerSystem* im;
		GraphicsManager* gm;
		EntityManager* em;
};



#define MAX_STATE_NAME_LENGTH 40
#define MAX_STATES 20

class GameStateManager
{
	public:
		void update(long deltaTime);
		void registerState(char stateName[MAX_STATE_NAME_LENGTH], GameState* state);
		void setNewState(char state[MAX_STATE_NAME_LENGTH]);
                void exit();
                bool isDone();
		GameStateManager();
		static GameStateManager* getInstance();
		
	private:
	
		static GameStateManager* instance;
		char stateNames[MAX_STATES][MAX_STATE_NAME_LENGTH];
		GameState* states[MAX_STATES];
		
		GameState* lastState;
		GameState* currentState;
                bool exitGame;	
};



#endif

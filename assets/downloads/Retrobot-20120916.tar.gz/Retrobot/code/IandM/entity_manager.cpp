#include <entity_manager.h>

#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

Entity::Entity()
{
	enabled = true;
	specialData = 0;
  spriteData = NULL;
}

Entity::~Entity()
{
	spriteData = NULL;
}


void Entity::setSpecialData(int data)
{
	specialData = data;
}


int Entity::getSpecialData()
{
	return specialData;
}


void Entity::setIsPhysical(bool isIt)
{
	physical = isIt;
}

bool Entity::isPhysical()
{
	return physical;
}

void Entity::setTagId(int id)
{
	tagId = id;
}

int Entity::getTagId()
{
	return tagId;
}

void Entity::setEnabled(bool isEnabled)
{
	enabled = isEnabled;
}

bool Entity::isEnabled()
{
	return enabled;
}

void Entity::setSpriteIndex(int index)
{
	int max;
	GraphicsManager* gm = GraphicsManager::getInstance();
	SpriteData* lsd = gm->getSpriteData(&max);
	
	if (max > index)
	{
		spriteIndex = index;
		spriteData = &(lsd[index]);
	}
}

GraphicData* Entity::getGraphicData()
{
	GraphicsManager* gm = GraphicsManager::getInstance();
	int max;
	GraphicData* gd = gm->getGraphicData(&max);

  if (spriteData->graphicIndex == -1) return NULL;
	
	return &gd[spriteData->graphicIndex];
}


SpriteData* Entity::getSpriteData()
{
	return spriteData;
}

int Entity::getSpriteIndex()
{
	return spriteIndex;
}


void Entity::setGraphicIndex(int index)
{
	graphicIndex = index;
	if (spriteData != NULL)
	{
		spriteData->graphicIndex = index;
	}
}

int Entity::getGraphicIndex()
{
	return graphicIndex;
}


void Entity::setRotation(float* rot)
{
	if (spriteData != NULL)
	{
		spriteData->rot[0] = rot[0];
		spriteData->rot[1] = rot[1];
		spriteData->rot[2] = rot[2];
	}
}

void Entity::setPosition(float* pos)
{
	if (spriteData != NULL)
	{
		spriteData->pos[0] = pos[0];
		spriteData->pos[1] = pos[1];
		spriteData->pos[2] = pos[2];
	}
}

void Entity::getRotation(float* rot)
{
	if (spriteData != NULL)
	{
		rot[0] = spriteData->rot[0];
		rot[1] = spriteData->rot[1];
		rot[2] = spriteData->rot[2];
	}
}


void Entity::getPosition(float* pos)
{
	if (spriteData != NULL)
	{
		pos[0] = spriteData->pos[0];
		pos[1] = spriteData->pos[1];
		pos[2] = spriteData->pos[2];
	}
}


void Entity::storePosRotData()
{
	memcpy(lastPos, spriteData->pos, 3 * sizeof(float));
	memcpy(lastRot, spriteData->rot, 3 * sizeof(float));
}

void Entity::restorePosRotData()
{
	memcpy(spriteData->pos, lastPos, 3*sizeof(float));
	memcpy(spriteData->rot, lastRot, 3*sizeof(float));
}



/**************************************************************************/
EntityManager* EntityManager::instance = NULL;


EntityManager* EntityManager::getInstance()
{
	if (instance == NULL)
	{
		instance = new EntityManager();
	}
	return instance;
}


EntityManager::EntityManager()
{
	groupIndexes = NULL;
	memset(listOfEntities, 0, sizeof(Entity*)*MAX_ENTITIES);
	memset(deleteQueue, 0, sizeof(int)*MAX_ENTITIES);
	memset(entityCreators, 0, sizeof(EntityCreator*)*MAX_ENTITY_CREATORS);
	numberOfGroups = 0;
	entitiesToDelete = 0;
}


void EntityManager::setupGroups(int numberOfGroups, ...)
{
	va_list groupSizesArgs;
	int currentIndex = 0;
	
	if (groupIndexes != NULL)
	{
		free(groupIndexes);
		free(groupSizes);
	}
	
	groupIndexes = (int*)malloc(sizeof(int)*numberOfGroups);
	groupSizes = (int*)malloc(sizeof(int)*numberOfGroups);
	this->numberOfGroups = numberOfGroups;
	
	va_start(groupSizesArgs, numberOfGroups);
	for (int gIdx = 0; gIdx < numberOfGroups; gIdx++)
	{
		groupIndexes[gIdx] = currentIndex;
		groupSizes[gIdx] = va_arg(groupSizesArgs, int);
		currentIndex += groupSizes[gIdx];
	}
	
	va_end(groupSizesArgs);
}


Entity** EntityManager::getEntitiesInGroup(int groupNumber, int& max)
{
	if (groupNumber == -1 || numberOfGroups == 0 || groupNumber >= numberOfGroups)
	{
		max = MAX_ENTITIES;
		return listOfEntities;
	}
	
	max = groupSizes[groupNumber];
	return &listOfEntities[groupIndexes[groupNumber]];
}


void EntityManager::clearEntitiesInGroup(int groupNumber)
{
	if (groupNumber == -1 || numberOfGroups == 0 || groupNumber >= numberOfGroups)
	{
		// Go through each entity and delete it
		for (int eIdx = 0; eIdx < MAX_ENTITIES; eIdx++)
		{
			if (listOfEntities[eIdx] != NULL)
			{
				listOfEntities[eIdx]->getSpriteData()->visible = false;
				listOfEntities[eIdx]->destroy();
				delete listOfEntities[eIdx];
				listOfEntities[eIdx] = NULL;
			}
		}
	}
	else
	{
		int eStart = groupIndexes[groupNumber];
		int eEnd = eStart + groupSizes[groupNumber];
		for (int eIdx = eStart; eIdx < eEnd; eIdx++)
		{
			if (listOfEntities[eIdx] != NULL)
			{
				listOfEntities[eIdx]->getSpriteData()->visible = false;
				listOfEntities[eIdx]->destroy();
				delete listOfEntities[eIdx];
				listOfEntities[eIdx] = NULL;
			}
		}
	}
}

void EntityManager::registerEntityCreator(EntityCreator* creator, const char type[ENTITY_TYPE_NAME_MAX])
{
	for (int ecIdx = 0; ecIdx < MAX_ENTITY_CREATORS; ecIdx++)
	{
		if (entityCreators[ecIdx] == NULL)
		{
			strcpy(entityTypes[ecIdx], type);
			entityCreators[ecIdx] = creator;
			break;
		}
	}
}


int EntityManager::createEntity(int groupNumber, const char type[ENTITY_TYPE_NAME_MAX], float pos[3], float rot[3], int graphicIndex)
{
	// Find the creator
	EntityCreator* ec = NULL;
	for (int ecIdx = 0; ecIdx < MAX_ENTITY_CREATORS; ecIdx++)
	{
		if (entityCreators[ecIdx] == NULL) break;
		if (strcmp(entityTypes[ecIdx], type) == 0)
		{
			ec = entityCreators[ecIdx];
			break;
		}
	}
	
	// Find the next empty entity
	int sIdx;
	int eIdx;
	if (groupNumber == -1 || numberOfGroups == 0 || groupNumber >= numberOfGroups)
	{
		sIdx = 0;
		eIdx = MAX_ENTITIES;
	}
	else
	{
		sIdx = groupIndexes[groupNumber];
		eIdx = sIdx + groupSizes[groupNumber];
	}
	
	int tagId = findEmptyEntityTagId(sIdx, eIdx);
	
	if (tagId != -1 && ec != NULL)
	{
		int spriteIndex = tagId;

		listOfEntities[tagId] = ec->createEntity(pos, rot, spriteIndex, graphicIndex);
		listOfEntities[tagId]->setTagId(tagId);
		listOfEntities[tagId]->getSpriteData()->visible = true;
		return tagId;
	}
	return -1;
}


int EntityManager::findEmptyEntityTagId(int startIndex, int endIndex)
{
	for (int eIdx = startIndex; eIdx < endIndex; eIdx++)
	{
		if (listOfEntities[eIdx] == NULL)
		{
			return eIdx;
		}
	}
	return -1;
}


Entity* EntityManager::getEntity(int tagId)
{
	return listOfEntities[tagId];
}


void EntityManager::deleteEntity(int tagId)
{
	if (listOfEntities[tagId] != NULL)
	{
		deleteQueue[entitiesToDelete] = tagId;
		entitiesToDelete++;
	}
}


void EntityManager::processDeleteQueue()
{
	for (int dIdx = 0; dIdx < entitiesToDelete; dIdx++)
	{
		volatile int tagId = deleteQueue[dIdx];
		deleteQueue[dIdx] = -1;
		
		if (tagId != -1 && listOfEntities[tagId] != NULL)
		{
			if (listOfEntities[tagId]->getSpriteData() != NULL)
			{
				listOfEntities[tagId]->getSpriteData()->visible = false;
			}
			listOfEntities[tagId]->destroy();
			listOfEntities[tagId] = NULL;
			delete listOfEntities[tagId];
		}
	}
	entitiesToDelete = 0;
}


bool graphicAABBCollide(float apos[3], float adim[2], float bpos[3], float bdim[2])
{
	float aTop, aBottom, aLeft, aRight;
	float bTop, bBottom, bLeft, bRight;
	
	aTop = apos[1] + adim[1];
	aBottom = apos[1];
	aLeft = apos[0];
	aRight = apos[0] + adim[0];
	
	bTop = bpos[1] + bdim[1];
	bBottom = bpos[1];
	bLeft = bpos[0];
	bRight = bpos[0] + bdim[0];
	
	bool xAxis = (bLeft <= aLeft && aLeft <= bRight)
			  || (bLeft <= aRight && aRight <= bRight)
			  || (aLeft <= bLeft && bLeft <= aRight)
			  || (aLeft <= bRight && bRight <= aRight);
	bool yAxis = (bTop >= aTop && aTop >= bBottom)
			  || (bTop >= aBottom && aBottom >= bBottom)
			  || (aTop >= bTop && bTop >= aBottom)
			  || (aTop >= bBottom && bBottom >= aBottom);
	
	return xAxis && yAxis;
}

bool graphicBoxedDataCollide(float apos[3], BoxData* abox, float bpos[3], BoxData* bbox)
{
	float adim[2];
	float bdim[2];
	float aapos[3];
	float bbpos[3];
	DimensionData* tmp;
	
	//pspDebugScreenSetXY(0, 2);
	//printf("%d %d\n", abox->numberOfBoxes, bbox->numberOfBoxes);
	for (int aIdx = 0; aIdx < abox->numberOfBoxes; aIdx++)
	{
		tmp = &abox->dimensionData[aIdx];
		adim[0] = tmp->width;
		adim[1] = tmp->height;
		aapos[0] = apos[0] + tmp->x;
		aapos[1] = apos[1] + tmp->y;
		//printf("a%d) %f %f %f %f\n", aIdx, aapos[0], aapos[1], adim[0], adim[1]);
		for (int bIdx = 0; bIdx < bbox->numberOfBoxes; bIdx++)
		{
			tmp = &bbox->dimensionData[bIdx];
			bdim[0] = tmp->width;
			bdim[1] = tmp->height;
			bbpos[0] = bpos[0] + tmp->x;
			bbpos[1] = bpos[1] + tmp->y;
			//printf("b%d) %f %f %f %f\n", bIdx, bbpos[0], bbpos[1], bdim[0], bdim[1]);
			if (graphicAABBCollide(aapos, adim, bbpos, bdim))
			{
			//printf("a%d) %f %f %f %f\n", aIdx, aapos[0], aapos[1], adim[0], adim[1]);
			//printf("b%d) %f %f %f %f\n", bIdx, bbpos[0], bbpos[1], bdim[0], bdim[1]);
				return true;
			}
		}
	}
	
	return false;
}


bool pointInBox(float point[2], float pos[3], float dim[2])
{
	return ( pos[0] < point[0] && point[0] < pos[0] + dim[0]
	      && pos[1] < point[1] && point[1] < pos[1] + dim[1]);
}


bool entitiesAABBCollide(GraphicData* gData, Entity* ea, Entity* eb)
{
	if (ea == NULL || eb == NULL) return false;
	if (!ea->isPhysical() || !eb->isPhysical()) return false;
	
	SpriteData* sa = ea->getSpriteData();
	SpriteData* sb = eb->getSpriteData();
	if (sa == NULL || sb == NULL) return false;
	if (sa->layerId != sb->layerId) return false;
	
	int gaIdx = sa->graphicIndex;
	int gbIdx = sb->graphicIndex;
	
	if (gaIdx == -1 || gbIdx == -1) return false;
	
	
	GraphicData* ga = &gData[gaIdx];
	GraphicData* gb = &gData[gbIdx];
	float apos[3];
	apos[0] = sa->pos[0];
	apos[1] = sa->pos[1];
	apos[2] = sa->pos[2];
	if (sa->rot[1] <= -3.14159) apos[0] -= ga->width;
	float bpos[3];
	bpos[0] = sb->pos[0];
	bpos[1] = sb->pos[1];
	bpos[2] = sb->pos[2];
	if (sb->rot[1] <= -3.14159) bpos[0] -= gb->width;
	float adim[2] = { ga->width, ga->height };
	float bdim[2] = { gb->width, gb->height };
	return graphicAABBCollide(apos, adim, bpos, bdim);
	/*
	if (graphicAABBCollide(apos, adim, bpos, bdim))
	{
		// Check per box data now
		//return graphicBoxedDataCollide(apos, &ga->boxedData, bpos, &gb->boxedData);
	}
	
	return false;
	*/

}


bool entityTiledEnvironmentAABBCollide(BackgroundData* bData, Entity* entity)
{
	// Should be very similar to how the psp renders tiled backgrounds
	// NOT NEEDED FOR THIS GAME ... OMITTING
	return false;
}


int computeVisibleBoxes(BackgroundData* bData, DimensionData* dData, int max)
{
  int numberOfBoxes = 0;
	float dpos[3];
	float ddim[2];
	float bbpos[3];
	float bdim[2];
	float point[2];
	
	DimensionData* currentBox;
	float dw = bData->info.pixeledInfo.pixelWidth;
	float dh = bData->info.pixeledInfo.pixelHeight;
	dpos[0] = bData->info.pixeledInfo.srcX * dw;
	dpos[1] = (bData->height - bData->info.pixeledInfo.displayHeightInPixels - bData->info.pixeledInfo.srcY) * dh;
	dpos[2] = 0;
	ddim[0] = bData->info.pixeledInfo.displayWidthInPixels * dw;
	ddim[1] = bData->info.pixeledInfo.displayHeightInPixels * dh;
	for (int bIdx = 0; bIdx < bData->info.pixeledInfo.boxedData.numberOfBoxes; bIdx++)
	{
		// if the box is in the visible space add it to the temp and move on
		currentBox = &bData->info.pixeledInfo.boxedData.dimensionData[bIdx];
		bbpos[0] = currentBox->x;
		bbpos[1] = currentBox->y;
		bbpos[2] = 0;
		bdim[0] = currentBox->width;
		bdim[1] = currentBox->height;
		point[0] = currentBox->x;
		point[1] = currentBox->y;
		if (graphicAABBCollide(dpos, ddim, bbpos, bdim))
		//if (pointInBox(point, dpos, ddim))
		{
			dData[numberOfBoxes].x = currentBox->x - dpos[0];
			dData[numberOfBoxes].y = currentBox->y - dpos[1];
			dData[numberOfBoxes].width = currentBox->width;
			dData[numberOfBoxes].height = currentBox->height;

			numberOfBoxes++;
			if (numberOfBoxes == max)
			{
				break;
			}
		}
	}
	
  return numberOfBoxes;
}

bool entityPixeledEnvironmentAABBCollide(float* envShift, BoxData* boxData, GraphicData* gData, Entity* entity)
{
	SpriteData* sd = entity->getSpriteData();
	GraphicData* ga = &gData[sd->graphicIndex];
	
	float spos[3];
	spos[0] = sd->pos[0];
	spos[1] = sd->pos[1];
	spos[2] = sd->pos[2];
	if (sd->rot[1] <= -3.14159) spos[0] -= ga->width;
	return graphicBoxedDataCollide(spos, &ga->boxedData, envShift, boxData);
}


bool entityEnvironmentAABBCollide(float* envShift, BoxData* boxData, GraphicData* gData, Entity* entity)
{
	if (entity->getSpriteData() == NULL) return false;
  /*
	if (bData->type == BACKGROUND_TYPE_TILED)
	{
		//return entityTiledEnvironmentAABBCollide(boxData, entity);
	}
	else if (bData->type == BACKGROUND_TYPE_PIXELED)
	{
  */
		return entityPixeledEnvironmentAABBCollide(envShift, boxData, gData, entity);
  /*
	}
	return false;
  */
}


void EntityManager::update(long deltaTime)
{

	// Step all of the entities forward in time
	for (int eIdx = 0; eIdx < MAX_ENTITIES; eIdx++)
	{
		if (listOfEntities[eIdx] != NULL && listOfEntities[eIdx]->isEnabled())
		{
			listOfEntities[eIdx]->storePosRotData();
			listOfEntities[eIdx]->update(deltaTime);
		}
	}

	GraphicsManager* gm = GraphicsManager::getInstance();
	int max;
	GraphicData* gData = gm->getGraphicData(&max);
	BackgroundData* bData = gm->getBackgroundData(&max);

  DimensionData tempBD[300];
  for (int bIdx = 0; bIdx < max; bIdx++)
  {
    BoxData tempData;
    tempData.dimensionData = (DimensionData*)(&tempBD);
    tempData.numberOfBoxes = computeVisibleBoxes(&bData[bIdx], tempBD, 300);
    for (int eIdx = 0; eIdx < MAX_ENTITIES; eIdx++)
    {
      if (listOfEntities[eIdx] == NULL || !listOfEntities[eIdx]->isEnabled()) continue;
	    if (listOfEntities[eIdx]->getSpriteData()->layerId != bIdx) continue;
			if (listOfEntities[eIdx]->isPhysical() && entityEnvironmentAABBCollide(bData[bIdx].display, &tempData, gData, listOfEntities[eIdx]))
			{
				listOfEntities[eIdx]->collision(NULL);
			}
    }
  }

	for (int eIdx = 0; eIdx < MAX_ENTITIES; eIdx++)
	{
		if (listOfEntities[eIdx] == NULL || !listOfEntities[eIdx]->isEnabled()) continue;
		for (int cIdx = eIdx+1; cIdx < MAX_ENTITIES; cIdx++)
		{
			if (listOfEntities[cIdx] != NULL
			    && listOfEntities[cIdx]->isEnabled()
				&& entitiesAABBCollide(gData, listOfEntities[eIdx], listOfEntities[cIdx]))
			{
				listOfEntities[eIdx]->collision(listOfEntities[cIdx]);
				listOfEntities[cIdx]->collision(listOfEntities[eIdx]);
			}
		}
	}

	processDeleteQueue();

}

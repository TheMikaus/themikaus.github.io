#include <graphics_manager.h>

#include <string.h>
#include <stdlib.h>

/****************************************************************/
/****************************************************************/
/* GRPHICS MANAGER IMPLEMENTATION                               */
/****************************************************************/
/****************************************************************/
GraphicsManager* GraphicsManager::instance = NULL;
GraphicsManager* GraphicsManager::getInstance()
{
	if (NULL == instance)
	{
		instance = new GraphicsManager();
	}
	return instance;
}

GraphicsManager::GraphicsManager()
{
	renderer = NULL;
	graphicDataOutOfDate = true;
	memset(&cameraData, 0, sizeof(CameraData));
	memset(lightData, 0, sizeof(LightData) * MAX_LIGHT_DATA);
	memset(spriteData, 0, sizeof(SpriteData) * MAX_SPRITE_DATA);
	memset(graphicData, 0, sizeof(GraphicData) * MAX_GRAPHIC_DATA);
	memset(backgroundData, 0, sizeof(BackgroundData*) * MAX_BACKGROUND_DATA);
}

SpriteData* GraphicsManager::getSpriteData(int* maxSprites)
{
	*maxSprites = MAX_SPRITE_DATA;
	return spriteData;
}

GraphicData* GraphicsManager::getGraphicData(int* maxGraphics)
{
	*maxGraphics = MAX_GRAPHIC_DATA;
	return graphicData;
}

EffectData** GraphicsManager::getEffectData(int* maxEffects)
{
	*maxEffects = MAX_EFFECT_DATA;
	return effectData;
}

LightData* GraphicsManager::getLightData(int* maxLights)
{
	*maxLights = MAX_LIGHT_DATA;
	return lightData;
}

BackgroundData* GraphicsManager::getBackgroundData(int* maxBackgrounds)
{
	*maxBackgrounds = MAX_BACKGROUND_DATA;
	return backgroundData;
}

void GraphicsManager::setRenderer(Renderer* renderer)
{
	this->renderer = renderer;
}

void GraphicsManager::render(long deltaTime)
{
	int effectIndex = 0;
	
	for (int sIdx = 0; sIdx < MAX_SPRITE_DATA; sIdx++)
	{
		effectIndex = spriteData[sIdx].effectIndex;
		if (spriteData[sIdx].visible && effectIndex != 0)
		{
			effectData[effectIndex]->applyEffectToSprite(spriteData[sIdx], deltaTime);
		}
	}
	
	renderer->setSpriteData(spriteData, MAX_SPRITE_DATA);
	renderer->setBackgroundData(backgroundData, MAX_BACKGROUND_DATA);
	if (graphicDataOutOfDate)
	{
		graphicDataOutOfDate = false;
		renderer->setGraphicData(graphicData, MAX_GRAPHIC_DATA);
	}
	renderer->setLightData(lightData, MAX_LIGHT_DATA);
	renderer->render(cameraData);
}

void GraphicsManager::setCameraData(CameraData cameraData)
{
	this->cameraData = cameraData;
}


void GraphicsManager::updateAllGraphicBoxedData()
{
	for (int gIdx = 0; gIdx < MAX_GRAPHIC_DATA; gIdx++)
	{
		if (graphicData[gIdx].pixelData != NULL)
		{
			updateGraphicBoxedData(gIdx);
		}
	}
}

void GraphicsManager::setGraphicDataOutOfDate()
{
        graphicDataOutOfDate = true;
}

void GraphicsManager::updateGraphicBoxedData(int gIdx)
{
	GraphicData* gd = &graphicData[gIdx];
	int boxCount = 0;
	int inBox = 0;
	int pIdx;
	
	for (int y = 0; y < gd->height; y++)
	{
		inBox = 0;
		for (int x = 0; x < gd->width; x++)
		{
			pIdx = y * gd->width + x;
			if (!(gd->pixelData[pIdx] & 0xff000000))
			{
				inBox = 0;
			}
			else if(inBox == 0 && (gd->pixelData[pIdx] & 0xff000000))
			{
				inBox = 1;
				boxCount++;
			}
		}
	}
	
	gd->boxedData.numberOfBoxes = boxCount;
	gd->boxedData.dimensionData = (DimensionData*)malloc(sizeof(DimensionData)*boxCount);
	boxCount = 0;
	int sx = 0;
	
	for (int y = 0; y < gd->height; y++)
	{
		inBox = 0;
		sx = 0;
		for (int x = 0; x < gd->width; x++)
		{
			pIdx = y * gd->width + x;
			if (!(gd->pixelData[pIdx] & 0xff000000))
			{
				if (inBox)
				{
					gd->boxedData.dimensionData[boxCount-1].x = sx;
					gd->boxedData.dimensionData[boxCount-1].y = gd->height - y - 1;
					gd->boxedData.dimensionData[boxCount-1].width = x - sx;
					gd->boxedData.dimensionData[boxCount-1].height = 1;
					inBox = 0;
				}
			}
			else if(inBox == 0 && (gd->pixelData[pIdx] & 0xff000000))
			{
				inBox = 1;
				sx = x;
				boxCount++;
			}
		}
		
		if (inBox)
		{
			gd->boxedData.dimensionData[boxCount-1].x = sx;
			gd->boxedData.dimensionData[boxCount-1].y = gd->height - y - 1;
			gd->boxedData.dimensionData[boxCount-1].width = gd->width - sx;
			gd->boxedData.dimensionData[boxCount-1].height = 1;
		}
	}
}


void GraphicsManager::updateAllBackgroundBoxedData()
{
	for (int bIdx = 0; bIdx < MAX_BACKGROUND_DATA; bIdx++)
	{
		if (backgroundData[bIdx].type == BACKGROUND_TYPE_PIXELED)
		{
			updateBackgroundBoxedData(bIdx);
		}
	}
}


void GraphicsManager::updateBackgroundBoxedData(int bIdx)
{
	BackgroundData* bd = &backgroundData[bIdx];
	int boxCount = 0;
	int inBox = 0;
	int pIdx;
	
	for (int y = 0; y < bd->height; y++)
	{
		inBox = 0;
		for (int x = 0; x < bd->width; x++)
		{
			pIdx = y * bd->width + x;
			if (!(bd->info.pixeledInfo.colorData[pIdx] & 0xff000000))
			{
				inBox = 0;
			}
			else if(inBox == 0 && (bd->info.pixeledInfo.colorData[pIdx] & 0xff000000))
			{
				inBox = 1;
				boxCount++;
			}
		}
	}
	
	bd->info.pixeledInfo.boxedData.numberOfBoxes = boxCount;
	bd->info.pixeledInfo.boxedData.dimensionData = (DimensionData*)malloc(sizeof(DimensionData)*boxCount);
	boxCount = 0;
	int sx = 0;
	float dw = bd->info.pixeledInfo.pixelWidth;
	float dh = bd->info.pixeledInfo.pixelHeight;
	
	for (int y = 0; y < bd->height; y++)
	{
		inBox = 0;
		sx = 0;
		for (int x = 0; x < bd->width; x++)
		{
			pIdx = y * bd->width + x;
			if (!(bd->info.pixeledInfo.colorData[pIdx] & 0xff000000))
			{
				if (inBox)
				{
					bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].x = sx * dw;
					bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].y = (bd->height - y) *dh;
					bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].width = (x - sx) * dw;
					bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].height = 1 * dh;
					inBox = 0;
				}
			}
			else if(inBox == 0 && (bd->info.pixeledInfo.colorData[pIdx] & 0xff000000))
			{
				inBox = 1;
				sx = x;
				boxCount++;
			}
		}
		
		if (inBox)
		{
			bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].x = sx * dw;
			bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].y = (bd->height - y) * dh;
			bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].width = (bd->width - sx) * dw;
			bd->info.pixeledInfo.boxedData.dimensionData[boxCount-1].height = 1 * dh;
		}
	}
}


/****************************************************************/
/****************************************************************/
/* EFFECT DATA DEFAULTS HAVE NO BEHAvIOR DEFINED                */
/****************************************************************/
/****************************************************************/

void EffectData::applyEffectToSprite(SpriteData& spriteData, long deltaTime)
{
}

#include <input_manager.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>


InputUpdateSystem::~InputUpdateSystem()
{
}


InputManagerSystem* InputManagerSystem::instance = NULL;
InputManagerSystem* InputManagerSystem::getInstance()
{
	if (NULL == instance)
	{
		instance = new InputManagerSystem();
	}
	return instance;
}

InputManagerSystem::InputManagerSystem()
{
	buttonCount = 0;
	inputUpdateSystem = NULL;
	memset(inputButtons, 0, sizeof(InputButton) * MAX_BUTTON_COUNT);
}


ButtonId InputManagerSystem::findButton(const char name[INPUT_NAME_MAX])
{
	int buttonIdx = 0;
	for (; buttonIdx < buttonCount && buttonIdx < MAX_BUTTON_COUNT; buttonIdx++)
	{
		if (strcmp(inputButtons[buttonIdx].inputName, name) == 0)
		{
			break;
		}
	}
	
	return buttonIdx;
}


ButtonId InputManagerSystem::registerButton(const char name[INPUT_NAME_MAX], InputMap map)
{
	ButtonId retValue = findButton(name);

	if (buttonCount >= MAX_BUTTON_COUNT)
	{
		throw new InputButtonMapFullException();
	}

	buttonCount++;
	strcpy(inputButtons[retValue].inputName, name);
	
	if (inputButtons[retValue].inputCount < INPUT_BUTTON_MAX)
	{
		for (int i = 0; i < INPUT_BUTTON_MAX; i++)
		{
			if (inputButtons[retValue].inputToCheck[i] == 0)
			{
				inputButtons[retValue].inputToCheck[i] = map;
			}
		}
		
	}
	
	inputButtons[retValue].buttonId = retValue;

	return retValue;
}

long InputManagerSystem::buttonDown(ButtonId buttonId)
{
	if (buttonId >= buttonCount)
	{
		throw new InputButtonIdNotFoundException(buttonId);
	}
	
	if (inputButtons[buttonId].downTime == 0)
	{
		inputButtons[buttonId].wasChecked = false;
	}

	return inputButtons[buttonId].downTime;
}

bool InputManagerSystem::buttonWasPressed(ButtonId buttonId)
{
	if (buttonId >= buttonCount)
	{
		throw new InputButtonIdNotFoundException(buttonId);
	}
	
	if (inputButtons[buttonId].downTime > 0 && !inputButtons[buttonId].wasChecked)
	{
		inputButtons[buttonId].wasChecked = true;
		return true;
	}

	return false;
}

void InputManagerSystem::setInputUpdateSystem(InputUpdateSystem* sys)
{
	inputUpdateSystem = sys;
}

void InputManagerSystem::updateButtons(long deltaTime)
{
	bool buttonDown;
	InputMap map;
	
	if (NULL == inputUpdateSystem) throw new NoInputUpdateSystemException();

	inputUpdateSystem->update();

	for (int btnIdx = 0; btnIdx < buttonCount; btnIdx++)
	{
		buttonDown = false;
		for (int inputIdx = 0; inputIdx < INPUT_BUTTON_MAX; inputIdx++)
		{
			map = inputButtons[btnIdx].inputToCheck[inputIdx];
			if (map == 0) break;
			if (inputUpdateSystem->buttonDown(map))
			{
				buttonDown = true;
				break;
			}
		}
		
		if (buttonDown)
		{
			inputButtons[btnIdx].downTime += deltaTime;
		}
		else
		{
			inputButtons[btnIdx].downTime = 0;
			inputButtons[btnIdx].wasChecked = false;
		}
		
	}
}


void InputManagerSystem::clearInputs()
{
	memset(inputButtons, 0, sizeof(InputButton) * MAX_BUTTON_COUNT);
}






/****************************************************************/
/****************************************************************/
/* EXCEPTIONS                                                   */
/****************************************************************/
/****************************************************************/

const char* InputButtonMapFullException::what() const throw()
{
	return "Out of input button slots.";
}


const char* NoInputUpdateSystemException::what() const throw()
{
	return "No Input Update System set!";
}


const char* InputButtonIdNotFoundException::what() const throw()
{
	/* This cast (char*) is here intentionally.  We are pretty certain that
	 * there won't be a problem with this sprintf so we are ignoring the
	 * error/warning this generates.
	 */
	sprintf((char*)myMessage, "Button Id %d out of range.",  this->buttonId);
	return myMessage;
}

InputButtonIdNotFoundException::InputButtonIdNotFoundException(ButtonId buttonId)
{
	this->buttonId = buttonId;
}


const char* InputMapInvalidException::what() const throw()
{
	/* This cast (char*) is here intentionally.  See above comment */
	sprintf((char*)myMessage, "Map %d is not supported.", this->map);
	return myMessage;
}

InputMapInvalidException::InputMapInvalidException(InputMap map)
{
	this->map = map;
}

InputMapInvalidException::~InputMapInvalidException() throw()
{
}

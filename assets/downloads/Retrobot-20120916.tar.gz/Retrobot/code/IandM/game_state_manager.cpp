#include <game_state_manager.h>

#include <string.h>
#include <stdio.h>

GameState::GameState()
{
	im = InputManagerSystem::getInstance();
	em = EntityManager::getInstance();
	gm = GraphicsManager::getInstance();
}


GameStateManager* GameStateManager::instance = NULL;
GameStateManager* GameStateManager::getInstance()
{
	if (instance == NULL)
	{
		instance = new GameStateManager();
	}
	return instance;
}

GameStateManager::GameStateManager()
{
	memset(stateNames, 0, sizeof(char)*MAX_STATES*MAX_STATE_NAME_LENGTH);
	memset(states, 0, sizeof(GameState*)*MAX_STATES);
	lastState = currentState = NULL;
        exitGame = false;
}


void GameStateManager::registerState(char stateName[MAX_STATE_NAME_LENGTH], GameState* state)
{
	for (int sIdx = 0; sIdx < MAX_STATES; sIdx++)
	{
		if (states[sIdx] == NULL)
		{
			states[sIdx] = state;
			strcpy(stateNames[sIdx], stateName);
			break;
		}
	}
}


void GameStateManager::setNewState(char state[MAX_STATE_NAME_LENGTH])
{
	for (int sIdx = 0; sIdx < MAX_STATES; sIdx++)
	{
		if (states[sIdx] != NULL && strcmp(stateNames[sIdx], state) == 0)
		{
			currentState = states[sIdx];
			break;
		}
	}
}


void GameStateManager::exit()
{
        exitGame = true;
}

bool GameStateManager::isDone()
{
        return exitGame;
}

void GameStateManager::update(long deltaTime)
{
	if (currentState != lastState)
	{
		if (lastState != NULL)
		{
			lastState->destroy();
		}
		lastState = currentState;
		currentState->init();
	}
	else if (currentState != NULL)
	{
		currentState->update(deltaTime);
	}
}

#include <audio_manager.h>
#include <string.h>

// ----------------------------------------
// Audio Manager
// ----------------------------------------
AudioManager* AudioManager::instance = NULL;

AudioManager* AudioManager::getInstance()
{
  return instance;
}

AudioManager* AudioManager::createInitialInstance(MP3ConverterInterface* mci, AudioPlayerInterface* api)
{
  instance = new AudioManager(mci, api);
}

AudioManager::AudioManager(MP3ConverterInterface* mci, AudioPlayerInterface* api)
{
  this->mci = mci;
  this->api = api;
  soundCount = 0;
  for (int idx = 0; idx < MAX_RT_SOUNDS; idx++)
  {
    rtSounds[idx].active = false;
  }
}


SoundReferenceId AudioManager::registerSound(char* name, char* filename, int srType)
{
  if (soundCount < MAX_SOUNDS)
  {
    strcpy(sounds[soundCount].soundName, name);
    strcpy(sounds[soundCount].soundFileName, filename);
    sounds[soundCount].type = srType;
    soundCount++;
    return soundCount - 1;
  }

  return -1;
}


SoundReferenceId AudioManager::getIdByName(char* name)
{
  for (int sIdx = 0; sIdx < soundCount; sIdx++)
  {
    if (strcmp(sounds[soundCount].soundName, name) == 0)
    {
      return sIdx;
    }
  }

  return -1;
}


AudioReferenceId AudioManager::playSound(SoundReferenceId soundId)
{
  AudioReferenceId retId = -1;
  for (int idx = 0; idx < MAX_RT_SOUNDS; idx++)
  {
    if (rtSounds[idx].active == false)
    {
      rtSounds[idx].active = true;
      rtSounds[idx].looping = false;
      rtSounds[idx].offset = 0;
      rtSounds[idx].soundReference = &sounds[soundId];
      rtSounds[idx].fileReference = NULL; // TODO: Open the file!
      if (sounds[soundId].type == SR_TYPE_WAVE)
      {
        // TODO: Init Audio Interface to receive sound
      }
      else if (sounds[soundId].type == SR_TYPE_MP3)
      {
        // TODO: Init MP3 Player Interface
      }

      retId = idx;
      break;
    }
  }
  return retId;
}


AudioReferenceId AudioManager::playSoundByName(char* name)
{
  SoundReferenceId idx = getIdByName(name);
  AudioReferenceId retId = -1;
  if (idx != -1)
  {
    retId = playSound(idx);
  }
  return retId;
}


AudioReferenceId AudioManager::loopSound(SoundReferenceId soundId)
{
  AudioReferenceId retId = playSound(soundId);
  if (retId != -1) rtSounds[retId].looping = true;
  return retId;
}


AudioReferenceId AudioManager::loopSoundByName(char* name)
{
  SoundReferenceId soundId = getIdByName(name);
  AudioReferenceId retId = -1;
  if (soundId != -1)
  {
    retId = loopSound(soundId);
  }
  return retId;
}


void AudioManager::stopSound(AudioReferenceId id)
{
  // STOP IT!
}

void AudioManager::stopAllSound()
{
  for (int sIdx = 0; sIdx < MAX_RT_SOUNDS; sIdx++)
  {
    stopSound(sIdx);
  }
}


void AudioManager::setVolume(int channel, int volume)
{
  // TODO DO IT!
}

void AudioManager::update(unsigned long deltaTime)
{
  for (int sIdx = 0; sIdx < MAX_RT_SOUNDS; sIdx++)
  {
    if (rtSounds[sIdx].active)
    {
      if (rtSounds[sIdx].soundReference->type == SR_TYPE_MP3)
      {
        // TODO: Call mci to get the next chunk of the buffer
      }
      else if (rtSounds[sIdx].soundReference->type == SR_TYPE_WAVE)
      {
        // TODO: read the next chunk of the buffer
      }

      // TODO: Play the next chunk of the buffer through the api;
      // TODO: update offset
      // TODO: if at end of sound and not looping set active to false
      // TODO: else reset offset to 0
    }
  }
}



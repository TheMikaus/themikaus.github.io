#define BEAM_WIDTH 6
#define BEAM_HEIGHT 3
extern unsigned int beam_data[18];


#define BIG_BEAM_WIDTH 12
#define BIG_BEAM_HEIGHT 3
extern unsigned int big_beam_data[36];


#define BOMB_WIDTH 5
#define BOMB_HEIGHT 5
extern unsigned int bomb_data[25];


#define BOSS_WIDTH 8
#define BOSS_HEIGHT 8
extern unsigned int boss_data[64];


#define BOSS_B_WIDTH 8
#define BOSS_B_HEIGHT 8
extern unsigned int boss_b_data[64];


#define BOSS_C_WIDTH 8
#define BOSS_C_HEIGHT 8
extern unsigned int boss_c_data[64];


#define BOSS_D_WIDTH 8
#define BOSS_D_HEIGHT 8
extern unsigned int boss_d_data[64];


#define BOSS_F_WIDTH 8
#define BOSS_F_HEIGHT 8
extern unsigned int boss_f_data[64];


#define BOSS_G_WIDTH 8
#define BOSS_G_HEIGHT 8
extern unsigned int boss_g_data[64];


#define BULLET_WIDTH 2
#define BULLET_HEIGHT 1
extern unsigned int bullet_data[2];


#define DEMO_BACKGROUND_WIDTH 40
#define DEMO_BACKGROUND_HEIGHT 10
extern unsigned int demo_background_data[400];


#define DOOR_ENTITY_WIDTH 4
#define DOOR_ENTITY_HEIGHT 20
extern unsigned int door_entity_data[80];


#define DOOR_ENTITY_B_WIDTH 4
#define DOOR_ENTITY_B_HEIGHT 20
extern unsigned int door_entity_b_data[80];


#define GAME_MAP_WIDTH 150
#define GAME_MAP_HEIGHT 150
extern unsigned int game_map_data[22500];


#define GAMEOVERSCREEN_WIDTH 81
#define GAMEOVERSCREEN_HEIGHT 17
extern unsigned int gameoverscreen_data[1377];


#define HUD_BOSS_WIDTH 5
#define HUD_BOSS_HEIGHT 5
extern unsigned int hud_boss_data[25];


#define HUD_BULLET_WIDTH 5
#define HUD_BULLET_HEIGHT 5
extern unsigned int hud_bullet_data[25];


#define HUD_HEART_WIDTH 6
#define HUD_HEART_HEIGHT 5
extern unsigned int hud_heart_data[30];


#define MAP_BACKGROUND_WIDTH 200
#define MAP_BACKGROUND_HEIGHT 75
extern unsigned int map_background_data[15000];


#define PLAYER_WIDTH 5
#define PLAYER_HEIGHT 10
extern unsigned int player_data[50];


#define TEST_LEVEL_WIDTH 150
#define TEST_LEVEL_HEIGHT 120
extern unsigned int test_level_data[18000];


#define TEST_LEVEL_ORIG_WIDTH 100
#define TEST_LEVEL_ORIG_HEIGHT 60
extern unsigned int test_level_orig_data[6000];


#define TITLESCREEN_WIDTH 81
#define TITLESCREEN_HEIGHT 17
extern unsigned int titlescreen_data[1377];


#define TS_PRESSSTART_WIDTH 81
#define TS_PRESSSTART_HEIGHT 17
extern unsigned int ts_pressstart_data[1377];


#define UPGRADE_BULLET_WIDTH 12
#define UPGRADE_BULLET_HEIGHT 5
extern unsigned int upgrade_bullet_data[60];


#define UPGRADE_HEALTH_WIDTH 12
#define UPGRADE_HEALTH_HEIGHT 5
extern unsigned int upgrade_health_data[60];


#define YOUWINSCREEN_WIDTH 81
#define YOUWINSCREEN_HEIGHT 17
extern unsigned int youwinscreen_data[1377];



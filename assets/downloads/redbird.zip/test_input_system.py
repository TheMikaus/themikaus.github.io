import pygame, sys, os
from pygame.locals import *

import systems.input_system
from systems.input_system import InputUpdateSystem, InputManagerSystem, ButtonNames

pygame.init()
ims = InputManagerSystem(InputUpdateSystem(0.5))
leftButtonId = ims.registerButton( 'Left', ButtonNames.LEFT )
attackButtonId = ims.registerButton( 'Attack', ButtonNames.B )
jumpButtonId = ims.registerButton( 'Jump', ButtonNames.A )
exitButtonId = ims.registerButton( 'Exit', ButtonNames.START)

while True:
	ims.updateButtons( 1 )
	if( ims.buttonWasPressed( attackButtonId ) ):
		print "ATTACK"
	elif( ims.buttonWasPressed( jumpButtonId ) ):
		print "JUMP"
	elif( ims.buttonWasPressed( leftButtonId ) ):
		pygame.quit()
		sys.exit()
	elif( ims.buttonWasPressed( exitButtonId ) ):
		pygame.quit()
		sys.exit()

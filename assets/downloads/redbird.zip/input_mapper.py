import pygame, sys
from pygame.locals import *

def waitForButtonOrAxis():
	while True:
		for event in pygame.event.get():
			if event.type == JOYBUTTONDOWN:
				print "Button " + str(event)
				return ('Button', event.button)
			elif event.type == JOYAXISMOTION:
				print "Axis " + str(event)
				if( event.value < 0 ):
					return ('Axis', event.axis, -1)
				elif( event.value > 0 ):
					return ('Axis', event.axis, 1)
				


pygame.init()
pygame.joystick.init()

joypad = pygame.joystick.Joystick(0)
joypad.init()

buttonMap = dict()

print "Button Mapping application!"
print "Detected joystick " + joypad.get_name()
for buttonName in ("UP", "DOWN", "LEFT", "RIGHT", "START", "SELECT", "A", "B"):
	print "Press the button for " + buttonName
	buttonMap[buttonName] = waitForButtonOrAxis()

mapFile = open('im/' + joypad.get_name() + '.im', 'w')

for buttonName in buttonMap.keys():
	if( buttonMap[buttonName][0] == 'Button' ):
		mapFile.write(buttonName + ' ' + buttonMap[buttonName][0] + ' ' + str(buttonMap[buttonName][1]) + '\n')
	elif( buttonMap[buttonName][0] == 'Axis' ):
		mapFile.write(buttonName + ' ' + buttonMap[buttonName][0] + ' ' + str(buttonMap[buttonName][1]) + ' ' + str(buttonMap[buttonName][2]) + '\n')

mapFile.close()

# This is sample code to try and get myself to understand the way data in the tile loader is parsed
# This should eventually lead to a set of systems to be used by the game.

import sys, os, pygame

import tiledtmxloader

# ----------
print( "Loading map" )
demoMap = tiledtmxloader.tmxreader.TileMapParser().parse_decode("maps/testMap.tmx")


pygame.init()
screen_width = min(1024, demoMap.pixel_width)
screen_height = min(768, demoMap.pixel_height)
screen = pygame.display.set_mode((screen_width, screen_height))

resources = tiledtmxloader.helperspygame.ResourceLoaderPygame()
resources.load(demoMap)

renderer = tiledtmxloader.helperspygame.RendererPygame()
# cam_offset is for scrolling
cam_world_pos_x = 0
cam_world_pos_y = 0
renderer.set_camera_position_and_size(cam_world_pos_x, cam_world_pos_y, \
				screen_width, screen_height, "topleft")

totalLayers = tiledtmxloader.helperspygame.get_layers_from_map(resources)

screen.fill((0, 0, 0))

for layer in totalLayers:
	if layer.is_object_group:
		print layer.name
		print str(len(layer.objects)) + str(layer.objects)
		for object in layer.objects:
			print object.name + " " + object.type + " " + str(object.x) + " " + str(object.y)
			print object.properties["Type"]
			print object.properties["Health"]
	else:
		renderer.render_layer(screen, layer)

pygame.display.flip()

running = True
while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

import pygame, sys, os
from pygame.locals import *

import systems
from systems.input_system import InputUpdateSystem, InputManagerSystem, ButtonNames
from systems.game_state_system import GameStateManagerSystem
from systems.graphic_system import GraphicManagerSystem
from systems.entity_system import EntityManagerSystem
from systems.animation_system import AnimationSystem

import game
from game.level_game_state import LevelGameState
from game.game_over_state import GameOverGameState
from game.player_game_data import PlayerGameData 

def initInputSystem():
    ims = InputManagerSystem(InputUpdateSystem(0.5))
    ims.registerButton( 'Attack', ButtonNames.B )
    ims.registerButton( 'Jump', ButtonNames.A )
    ims.registerButton( 'Menu', ButtonNames.START)
    ims.registerButton( 'CycleWeapon', ButtonNames.SELECT )
    ims.registerButton( 'Up', ButtonNames.UP )
    ims.registerButton( 'Down', ButtonNames.DOWN )
    ims.registerButton( 'Left', ButtonNames.LEFT )
    ims.registerButton( 'Right', ButtonNames.RIGHT )
    return ims
    
    
def initAnimationSystem():
    afs = AnimationSystem()
    afs.loadAnimations( "./animations" )
    AnimationSystem.instance = afs
    return afs
    

# The main game setup and loop logic
def main():
    pygame.init()

    ims = initInputSystem()
    InputManagerSystem.instance = ims
    
    gms = GraphicManagerSystem()
    GraphicManagerSystem.instance = gms
    
    # TODO: init sound system
    
    afs = initAnimationSystem()
    
    ems = EntityManagerSystem( )
    EntityManagerSystem.instance = ems

    gsms = GameStateManagerSystem()
    GameStateManagerSystem.instance = gsms
    
    pgd = PlayerGameData()
    
    # TODO: This is a multistep process at the moment.
    #       1) Use a LevelGameState object and get the basic level state logic set up
    #       2) Move out all variables from the LevelGameState to a Game object
    #       3) Create that game object here
    #       4) Pass it into the LevelGameState
    #       5) Create a BossSelectGameState and use that here instead
    #       6) Create a TitleScreenGameState and use that here instead
    gsms.appendState( LevelGameState( ims, gms, ems, pgd ) )

    leftOverTimeSlice = 0
    exitGame = False
    MinimumTimeSliceInMilliseconds = (1.0/60.0) * (1000) # Attempting 60 frames a second
    GameTick = (1.0/60.0)
    gameClock = pygame.time.Clock()
    while( exitGame == False ):
        leftOverTimeSlice += gameClock.tick()

        while( leftOverTimeSlice >= MinimumTimeSliceInMilliseconds ):
            leftOverTimeSlice -= MinimumTimeSliceInMilliseconds
            if( gsms.update( GameTick ) == False ):
                exitGame = True
                break
            else:
                ims.updateButtons( GameTick )
                ems.update( GameTick )

        gms.update()

    pygame.quit()
    sys.exit()



# START THE MAIN PROGRAM
if __name__ == "__main__":
    try:
        main()
    finally:
        pygame.quit()

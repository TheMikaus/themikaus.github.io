import compileall

compileall.compile_dir('./', force=True)

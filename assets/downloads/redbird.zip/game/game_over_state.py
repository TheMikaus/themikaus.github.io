# This python file will deal with the game over state
# It should present the user with the following options:
# 1 - Restart level
# 2 - Return to Title Screen
# 3 - Exit Game

import sys

import pygame

import systems
from systems.input_system import ButtonNames
from systems.game_state_system import GameState, GameStateManagerSystem, StateTransitions

class GameOverGameState(GameState):
    def __init__( self, inputManagerSystem, graphicManagerSystem, entityManagerSystem ):
        GameState.__init__( self )
        self.mInputManagerSystem = inputManagerSystem
        self.mGraphicManagerSystem = graphicManagerSystem
        self.mEntityManagerSystem = entityManagerSystem
        self.mMenuItem = 0
        self.mMenuItemMax = 2

    def initialize( self ):
        print "GameOverState.initialize"
        self.initializeInput()
        self.initializeGraphicsResources()

    def initializeInput( self ):
        print "PauseGameState.initialize.Input"
        # Bleh
        self.mAcceptButtonId = self.mInputManagerSystem.findButtonId( 'Jump' )
        self.mMenuButtonId = self.mInputManagerSystem.findButtonId( 'Menu' )
        self.mUpButtonId = self.mInputManagerSystem.findButtonId( 'Up' )
        self.mDownButtonId = self.mInputManagerSystem.findButtonId( 'Down' )
        self.mLeftButtonId = self.mInputManagerSystem.findButtonId( 'Left' )
        self.mRightButtonId = self.mInputManagerSystem.findButtonId( 'Right' )

    def initializeGraphicsResources( self ):
        print "PauseGame.initialize.GraphicsResources"
        self.mSurface, self.mSurfaceId = self.mGraphicManagerSystem.addLayer( 320, 240 )
        self.mGameOverMenu = pygame.image.load( "tiles/GameOverMenu.png" )
        self.mMenuSelector = pygame.image.load( "tiles/MenuSelector.png" )

    def exit( self ):
        print "GameOverState.exit"
        self.mGraphicManagerSystem.removeLayer( self.mSurfaceId )
        self.mGameOverMenu = None
        self.mMenuSelector = None
        self.mSurface = None

    def update( self, deltaTime ):
        menuPos = (160 - self.mGameOverMenu.get_width() / 2, 120 - self.mGameOverMenu.get_height() / 2 )
        self.mSurface.blit( self.mGameOverMenu, menuPos )
        
        quarterHeight = self.mMenuSelector.get_height() / 4
        selectorPosY = self.mMenuItem * self.mMenuSelector.get_height()
        selPos = (menuPos[0] + self.mMenuSelector.get_width() / 2, menuPos[1] + quarterHeight + selectorPosY)
        self.mSurface.blit( self.mMenuSelector, selPos )
        if( self.mInputManagerSystem.buttonWasPressed( self.mUpButtonId ) ):
            self.mMenuItem = self.mMenuItem - 1
            if( self.mMenuItem < 0 ):
                self.mMenuItem = self.mMenuItemMax
        if( self.mInputManagerSystem.buttonWasPressed( self.mDownButtonId ) ):
            self.mMenuItem = self.mMenuItem + 1
            if( self.mMenuItem > self.mMenuItemMax ):
                self.mMenuItem = 0

        if( self.mInputManagerSystem.buttonWasPressed( self.mAcceptButtonId ) ):
            if( self.mMenuItem == 0 ):
                return None, StateTransitions.POP
            if( self.mMenuItem == 1 ):
                # TODO: Back to the title screen
                pass
            if( self.mMenuItem == 2 ):
                return None, StateTransitions.EXIT
        return self, StateTransitions.NOOP

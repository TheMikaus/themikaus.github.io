# This python file should contain the the player game state that is saved.

class PlayerGameData:
    def __init__( self ):
        # Should be an array of strings.
        # Each string is the level name that was beat.
        self.mStagesBeat = []
        
        # This is a string array of the special items a player has
        # picked up.
        self.mSpecialItems = []
        
        # This is a string array of the special weapons in the player's
        # inventory.
        self.mSpecialWeapons = []

    # TODO: Save/Load
        
        
class PlayerLevelGameStateData:
    def __init__( self, playerGameData ):
        self.mPlayerGameData = playerGameData
        self.mLives = 3
        self.mWeaponEnergy = self.initWeaponEnergy( playerGameData )
        self.mStartingPosition = None
        self.mContinuePosition = None
        self.mBossContinuePosition = None
        self.mLastSeenSpawningPoint = 'Start'
        
    def setSpawningPoint( self, type ):
        self.mLastSeenSpawningPoint = type
        
    def getCurrentStartingPosition( self ):
        if( self.mLastSeenSpawningPoint == 'Start' ):
            return self.mStartingPosition
        elif( self.mLastSeenSpawningPoint == 'Continue' ):
            return self.mContinuePosition
        elif( self.mLastSeenSpawningPoint == 'Boss' ):
            return self.mBossContinuePosition

    
    def initWeaponEnergy( self, playerGameData ):
        for weapons in playerGameData.mSpecialWeapons:
            self.mWeaponEnergy.append( 100 )

    def getPlayerPositions( self, levelObjectLayers ):
        self.mStartingPosition = self.getPlayerPosition( levelObjectLayers, 'Start' )
        self.mContinuePosition = self.getPlayerPosition( levelObjectLayers, 'Continue' )
        self.mBossContinuePosition = self.getPlayerPosition( levelObjectLayers, 'Boss' )
            
    def getPlayerPosition( self, levelObjectLayers, type ):
        for layer in levelObjectLayers:
            for object in layer.objects:
                if( object.type == 'PlayerSpawn' and object.properties['Type'] == type ):
                    return [ object.x, object.y + object.height]


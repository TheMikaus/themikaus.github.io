# This python file should deal with the player entities

import copy
import sys
import uuid

import tiledtmxloader

import pygame
import systems
from systems.entity_system import Entity, EntityCreator, EntityWithHealth, EntityManagerSystem
from bullet_entities import PlainBullet

# EntityCreator is not necessary for this particular set of entities

class CameraEntity(Entity):
    def __init__( self, manager, renderer ):
        Entity.__init__( self, manager )
        self.mEntityId = uuid.uuid4()
        self.mEntitySpecialName = "Camera"
        self.mPlayerEntity = manager.getEntity( "Player" )
        self.mRenderer = renderer
        self.mPhysical = False
        self.mScreenWidth = 320
        self.mScreenHeight = 240
        self.mScreenRect = pygame.Rect( 0, 0, self.mScreenWidth, self.mScreenHeight )
        self.mNewX = 0
        self.mNewY = 0
        self.mFollowMode = "Center"
        self.mTracked = False
        self.mAcquired = False
        self.mNextMode = None
        
    def acquire( self ):
        self.mAcquired = True
        
    def free( self ):
        self.mAcquired = False

    def loadImages( self ):
        #self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        print "No image for camera required"

    def leftTrackTo( self, posX, speedX ):
        self.mFollowMode = "LeftTrack"
        self.mTracked = False
        self.mTrackPos = posX
        self.mTrackPosSpeed = speedX
    
    def rightTrackTo( self, posX, speedX ):
        self.mFollowMode = "RightTrack"
        self.mTracked = False
        self.mTrackPos = posX
        self.mTrackPosSpeed = speedX

    def moveToCentered( self, speed ):
        self.mFollowMode = "MoveToCentered"
        self.mTrackPosSpeed = speed
        self.mTracked = False

    def update( self, deltaTime ):
        if( self.mFollowMode == "Center" ):
            self.mNewX = self.mPlayerEntity.mPos[0] + self.mPlayerEntity.mRect.width/2 - (self.mScreenWidth / 2)
            self.mNewY = self.mPlayerEntity.mPos[1] - self.mPlayerEntity.mRect.height/2 - (self.mScreenHeight / 2)
        elif( self.mFollowMode == "LeftTrack" ):
            if( self.mScreenRect.left < self.mTrackPos ):
                self.mNewX = self.mScreenRect.left + self.mTrackPosSpeed
                self.mNewY = self.mScreenRect.top
            elif( self.mTracked == False ):
                self.mTracked = True
            else:
                self.breakTrackCheck()
        elif( self.mFollowMode == "RightTrack" ):
            if( self.mScreenRect.right < self.mTrackPos ):
                self.mNewX = self.mScreenRect.left + self.mTrackPosSpeed
                self.mNewY = self.mScreenRect.top
            elif( self.mTracked == False ):
                self.mTracked = True
            else:
                self.breakTrackCheck()
        elif( self.mFollowMode == "MoveToCentered" ):
            leftX = self.mPlayerEntity.mPos[0] - self.mScreenRect.width / 2
            rightX = self.mPlayerEntity.mPos[0] + self.mPlayerEntity.mRect.width/2 + self.mScreenRect.width / 2
            self.mTracked = (self.mTrackPosSpeed > 0 and self.mScreenRect.left > leftX) or (self.mTrackPosSpeed < 0 and self.mScreenRect.right < rightX)
            if( self.mTracked == False ):
                self.mNewX = self.mScreenRect.left + self.mTrackPosSpeed
                self.mNewY = self.mScreenRect.top
            elif( self.mNextMode != None ):
                self.mFollowMode = self.mNextMode
                self.mNextMode = None

        self.mScreenRect.topleft = ( self.mNewX, self.mNewY )    
        self.mRenderer.set_camera_position_and_size( self.mNewX, self.mNewY, self.mScreenWidth, self.mScreenHeight, "topleft" )

    def breakTrackCheck( self ):
        if( self.mPlayerEntity.mPos[0] < self.mScreenRect.left - self.mPlayerEntity.mRect.width / 16 ):
            self.moveToCentered( -1 * self.mPlayerEntity.mRect.width / 16 )
            self.mNextMode = "Center"
        elif( self.mPlayerEntity.mPos[0] > self.mScreenRect.right + self.mPlayerEntity.mRect.width / 16 ):
            self.moveToCentered( self.mPlayerEntity.mRect.width / 16 )
            self.mNextMode = "Center"
            

    def message( self, entitySendingMessage, message, data ):
        raise Exception( "Camera should never receive a message." )

    def getScreenRect( self ):
        return self.mScreenRect


class PlayerEntity(EntityWithHealth):
    def __init__( self, inputManagerSystem, manager, renderableLayer, playerGameData ):
        EntityWithHealth.__init__( self, manager )
        self.mPlayerGameData = playerGameData
        self.mParent = None
        self.mInputManagerSystem = inputManagerSystem
        self.mRenderableLayer = renderableLayer
        self.mAttackButtonId = self.mInputManagerSystem.findButtonId( 'Attack' )
        self.mJumpButtonId = self.mInputManagerSystem.findButtonId( 'Jump' )
        self.mCycleWeaponId = self.mInputManagerSystem.findButtonId( 'CycleWeapon' )
        self.mUpButtonId = self.mInputManagerSystem.findButtonId( 'Up' )
        self.mDownButtonId = self.mInputManagerSystem.findButtonId( 'Down' )
        self.mLeftButtonId = self.mInputManagerSystem.findButtonId( 'Left' )
        self.mRightButtonId = self.mInputManagerSystem.findButtonId( 'Right' )
        self.mPlayerGroundSpeedX = 1.375 * 60
        self.mPlayerAirSpeedX = 1.3125 * 60
        self.mEntityId = uuid.uuid4()
        self.mEntitySpecialName = "Player"
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mJumpTime = 0
        self.mOnGround = True
        self.mTimeTillNextShot = 0
        self.mBulletList = []
        self.mBulletSpriteList = []
        self.mXDir = 1
        self.setHealth( 10 )
        self.setMaxHealth( 10 )
        self.setInvincibleTime( 0.5 )

    def hasItem( self, item ):
        return item in self.mPlayerGameData.mPlayerGameData.mSpecialItems
  
    def addItem( self, item ):
        self.mPlayerGameData.mPlayerGameData.mSpecialItems.append( item )
        
    def loadImages( self ):
        print "Loading images"
        # The Animation system has fully loaded everything already
        self.mImage = pygame.image.load( "tiles/entities/Player.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)

        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)
        self.mAnimationFamily = self.mAnimationSystem.getFamily( "player" )
        self.setCurrentAnimation( "Standing", self.loop, False, 0 )

    def setToWalking( self ):
        self.setCurrentAnimation( "Walking", self.loop, (self.mXDir == -1), 0)
    
    def setToStanding( self ):
        self.setCurrentAnimation( "Standing", self.loop, (self.mXDir == -1), 0)
        
    def update( self, deltaTime ):
        # Adjust speed due to in air or not
        if( self.mJumpVelocity != 0 ):
            speedX = self.mPlayerAirSpeedX
        else:
            speedX = self.mPlayerGroundSpeedX

        # Adjust position based off of direction and speed
        if( self.mInputManagerSystem.buttonDown( self.mLeftButtonId ) > 0 ):
            self.mProposedSteps[0] -= speedX * deltaTime
            self.mXDir = -1
            if( self.getCurrentAnimationName() == "Shooting" ):
                self.setCurrentAnimation( "ShootingAndWalking", self.setToWalking, True, self.mCurrentAnimation.mCurrentFrame )
            elif( self.getCurrentAnimationName() != "ShootingAndWalking" ):
                self.setCurrentAnimation( "Walking", self.loop, True, 0 )
        elif( self.mInputManagerSystem.buttonDown( self.mRightButtonId ) > 0 ):
            self.mProposedSteps[0] += speedX * deltaTime
            self.mXDir = 1
            if( self.getCurrentAnimationName() == "Shooting" ):
                self.setCurrentAnimation( "ShootingAndWalking", self.setToWalking, False, self.mCurrentAnimation.mCurrentFrame )
            elif( self.getCurrentAnimationName() != "ShootingAndWalking" ):
                self.setCurrentAnimation( "Walking", self.loop, False, 0 )
        else:
            if( self.getCurrentAnimationName() == "ShootingAndWalking" ):
                self.setCurrentAnimation( "Shooting", self.setToStanding, (self.mXDir == -1), 0 )
            else:
                self.setCurrentAnimation( "Standing", self.loop, (self.mXDir == -1), 0 )

        # Process shooting
        self.mTimeTillNextShot -= deltaTime
        if( self.mInputManagerSystem.buttonWasPressed( self.mAttackButtonId ) > 0 ):
            if( self.mTimeTillNextShot <= 0 and len(self.mBulletList) < 3 ):
                self.mTimeTillNextShot = .10
                bPos = [ self.mPos[0] + self.mXDir * 32, self.mPos[1] ]
                bullet = self.mManager.createEntity( "PlayerGroup", "PlainBullet", bPos, "Bullet")
                bullet.setParent( self )
                bullet.setXDir( self.mXDir )
                bullet.loadImages()
                self.mBulletList.append(bullet)
                self.mBulletSpriteList.append(bullet.mBulletSprite)
                self.mRenderableLayer.add_sprite(bullet.mBulletSprite)
                if( self.getCurrentAnimationName() == "Walking" ):
                    self.setCurrentAnimation( "ShootingAndWalking", self.setToWalking, (self.mXDir == -1), self.mCurrentAnimation.mCurrentFrame )
                # TODO: Else if Jumping
                elif( self.getCurrentAnimationName() != "ShootingAndWalking" ):
                    self.setCurrentAnimation( "Shooting", self.setToStanding, (self.mXDir == -1), 0 )
                
        # Process jumps
        if( self.mInputManagerSystem.buttonDown( self.mJumpButtonId ) > 0 ):
            if( self.mInputManagerSystem.buttonWasPressed( self.mJumpButtonId ) ):
                if( self.mOnGround and self.mJumpTime == 0 ):
                    #self.mJumpVelocity = -4.875 * 60 # this is from a web page
                    self.mJumpVelocity = -7.875 * 60 # adjusted to look right
            self.mJumpTime += deltaTime
        else:
            if( self.mJumpVelocity < 0 ):
                self.mJumpVelocity = 0

        # Call the update function
        EntityWithHealth.update( self, deltaTime )
        self.mOnGround = False # assuming that collision with the ground will happen after every update call

    def collision( self, object, isGround ):
        #self.restorePosData()
        if( isGround[1] ):
            self.mOnGround = isGround
            self.mJumpVelocity = 0
            self.mJumpTime = 0

    def message( self, entitySendingMessage, message, data ):
        EntityWithHealth.message( self, entitySendingMessage, message, data )
        if( isinstance(entitySendingMessage, PlainBullet) and entitySendingMessage.mParent == self ):
            if( entitySendingMessage.mBulletSprite in self.mBulletSpriteList ):
                self.mBulletSpriteList.remove( entitySendingMessage.mBulletSprite )
                self.mRenderableLayer.remove_sprite( entitySendingMessage.mBulletSprite )
                self.mBulletList.remove( entitySendingMessage )
                self.mManager.removeEntityFromGroup( entitySendingMessage, "PlayerGroup" )
                self.mManager.deleteEntity( entitySendingMessage )

    def died( self ):
        pass

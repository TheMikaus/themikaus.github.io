# This python file should contain all of the enemies on the all levels.

import copy
import sys
import uuid

import pygame
import systems
import tiledtmxloader

from systems.entity_system import Entity, EntityCreator, EntityManagerSystem
from game.entities.player_entities import PlayerEntity

# ---------------------
# TeaLeafBag
# ---------------------
class TeaLeafBagEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return TeaLeafBag( manager, pos )

class TeaLeafBag(Entity):
    def __init__( self, manager, pos ):
        Entity.__init__( self, manager )
        self.mEntityId = uuid.uuid4()
        self.mPhysical = True
        self.mPos = copy.copy( pos );
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True


    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        # TODO: Move in the proper direction till it hits a wall
        pass

    def collision( self, object, isGround ):
        if( isinstance(object, PlayerEntity) ):
            object.addItem( self.mEntitySpecialName )
            self.mParent.message( self, "Remove", None )

    def message( self, entitySendingMessage, message, data ):
        return "Pass"

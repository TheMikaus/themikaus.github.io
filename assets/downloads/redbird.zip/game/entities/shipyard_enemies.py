# This python file should contain all of the enemies on the shipyard level.

import copy
import math
import sys

import tiledtmxloader

import pygame
import systems
from systems.entity_system import Entity, EntityWithHealth, EntityCreator, EntityManagerSystem
from player_entities import PlayerEntity
from bullet_entities import PlainBullet


# ---------------------
# RAT : Walk left and right
# ---------------------
class ShipyardRatEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return ShipyardRat( manager, pos )

class ShipyardRat(EntityWithHealth):
    def __init__( self, manager, pos ):
        EntityWithHealth.__init__( self, manager )
        self.mPhysical = True
        self.mPos = copy.copy( pos );
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True
        self.mProposedSteps[0] = 0
        self.mProposedSteps[1] = 0
        self.setHealth( 3 )
        self.setMaxHealth( 3 )
        self.mDamage = 1
        self.mSpeed = 60

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        self.mProposedSteps[0] = self.mDirections[0] * self.mSpeed * deltaTime;

    def collision( self, object, isGround ):
        if( isinstance( object, PlayerEntity ) ):
            object.message( self, "Damage", -1 * self.mDamage )

        if( isGround[0] ):
            # TODO: Figure out how to make the rat turn around if they hit a wall
            if( object[0] != None ):
                self.mDirections[0] = self.mDirections[0] * -1.0

    def died( self ):
        pass

    def message( self, entitySendingMessage, message, data ):
        EntityWithHealth.message( self, entitySendingMessage, message, data)



# ---------------------
# Seagulls : Swoop once
# ---------------------
class ShipyardSeagullEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return ShipyardSeagull( manager, pos )

class ShipyardSeagull(EntityWithHealth):
    def __init__( self, manager, pos ):
        EntityWithHealth.__init__( self, manager )
        self.mPos = copy.copy( pos )
        self.mPhysical = True
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = False
        self.setHealth( 3 )
        self.setMaxHealth( 3 )
        self.mDamage = 2
        self.mSpeed = 60
        self.mSwooped = False
        playerEntity = manager.getEntity( "Player" )
        self.mYSwoopTarget = playerEntity.mPos[1]
        self.mApplyGravity = False
        self.mState = "coast"
        self.mStateTime = 0
        
    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        self.mProposedSteps[0] = self.mDirections[0] * self.mSpeed * deltaTime
        if( self.mState == "coast" ):
            self.mStateTime += deltaTime
            if( self.mStateTime > 0.5 ):
                self.mState = "attack"
                self.mSpeed *= 3
                self.mYSwoopTarget = self.mManager.getEntity( "Player" ).mPos[1]
        elif( self.mState == "attack" ):
            self.mSwooped = (self.mPos[1] > self.mYSwoopTarget)
            if( self.mSwooped == False ):
                self.mProposedSteps[1] = self.mSpeed * deltaTime
            else:
                self.mSpeed /= 1.5
                self.mState = "None"

    def collision( self, object, isGround ):
        if( isinstance( object, PlayerEntity ) ):
            object.message( self, "Damage", -1 * self.mDamage )

        #if( isGround[1] ):
        #    pass

    def died( self ):
        pass

    def message( self, entitySendingMessage, message, data ):
        EntityWithHealth.message( self, entitySendingMessage, message, data)



# ---------------------
# Trashcans : hard hat guys
# ---------------------
class ShipyardTrashcanEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return ShipyardTrashcan( manager, pos )

class ShipyardTrashcan(EntityWithHealth):
    def __init__( self, manager, pos ):
        EntityWithHealth.__init__( self, manager )
        self.mPos = copy.copy( pos );
        self.mPhysical = True
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True
        self.setHealth( 10 )
        self.setMaxHealth( 10 )
        self.mState = "hidden"
        self.mHiddenTimeMax = 2
        self.mPeekTimeMax = 1.5
        self.mShootTimeMax = 1
        self.mStateTime = 0
        self.mShotBullet = False
        self.mDamage = 3

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(0, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        # TODO: Move in the proper direction till it hits a wall
        self.mStateTime += deltaTime
        if( self.mState == "hidden"):
            if( self.mStateTime > self.mHiddenTimeMax ):
                self.mSourceRect.left = 32
                self.mState = "peek"
                self.mStateTime = 0
        elif( self.mState == "peek" ):
            # TODO: PLAY PEEK ANIMATION
            if( self.mStateTime > self.mPeekTimeMax ):
                self.mStateTime = 0
                self.mSourceRect.left = 64
                self.mState = "shooting"
        elif( self.mState == "shooting" ):
            if( self.mShotBullet == False ):
                bPos = [ self.mPos[0] + self.mDirections[0] * 32, self.mPos[1] ]
                bullet = self.mManager.createEntity( "Spawned", "PlainBullet", bPos, "Bullet")
                bullet.setParent( self )
                bullet.setXDir( self.mDirections[0] )
                bullet.loadImages()
                self.mParent.mRenderLayer.add_sprite(bullet.mBulletSprite)
                self.mShotBullet = True
            elif( self.mStateTime > self.mShootTimeMax ):
                self.mStateTime = 0
                self.mSourceRect.left = 0
                self.mState = "hidden"
                self.mShotBullet = False

    def collision( self, object, isGround ):
        if( isinstance( object, PlayerEntity ) ):
            object.message( self, "Damage", -1 * self.mDamage )

        #if( isGround ):
        #    pass

    def died( self ):
        pass

    def message( self, entitySendingMessage, message, data ):
        if( entitySendingMessage.mParent == self ):
            if( isinstance(entitySendingMessage, PlainBullet) ):
                self.mParent.mRenderLayer.remove_sprite( entitySendingMessage.mBulletSprite )
                self.mManager.removeEntityFromGroup( entitySendingMessage, "Spawned" )
                self.mManager.deleteEntity( entitySendingMessage )
                
        if( message == "Damage" ):
            if( self.mState != "shooting" ):
                entitySendingMessage.mSpeedX *= -2.0;
                entitySendingMessage.mSpeedY = -2.0 * 32 * 8.0
                self.mStateTime = 0
                self.mState = "hidden"
                self.mSourceRect.left = 0
                return "BOUNCE!"
            else:
                EntityWithHealth.message( self, entitySendingMessage, message, data)




# ---------------------
# Turrets : shoot from roof
# ---------------------
class ShipyardTurretEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return ShipyardTurret( manager, pos )

class ShipyardTurret(EntityWithHealth):
    def __init__( self, manager, pos ):
        EntityWithHealth.__init__( self, manager )
        self.mPos = copy.copy( pos );
        self.mPhysical = True
        self.mRect = pygame.Rect(0, 0, 32, 16)
        self.mPos[1] -= 16
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = False
        self.mApplyGravity = False
        self.setHealth( 4 )
        self.setMaxHealth( 4 )
        self.mState = "waiting"
        self.mStateTime = 0
        self.mWaitTimeMax = 2
        self.mBulletWaitMax = 0.5
        self.mBulletsShot = 0
        self.mDamage = 2

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 16)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        self.mStateTime += deltaTime
        if( self.mState == "waiting" ):
            if( self.mStateTime > self.mWaitTimeMax ):
                self.mStateTime = 0
                self.mState = "shooting"
                self.mRect.height = 32
                self.mSourceRect.height = 32
                self.mPos[1] += 16
        elif( self.mState == "shooting" ):
            if( self.mStateTime > self.mBulletWaitMax ):
                if( self.mBulletsShot == 3 ):
                    self.mState = "waiting"
                    self.mStateTime = 0
                    self.mBulletsShot = 0
                    self.mRect.height = 16
                    self.mSourceRect.height = 16
                    self.mPos[1] -= 16
                else:
                    self.mStateTime = 0
                    self.fireBullet( 1, 0 )
                    self.fireBullet( -1, 0 )
                    self.fireBullet( 1, 1 )
                    self.fireBullet( -1, 1 )
                    self.fireBullet( 0, 1)
                    self.mBulletsShot += 1

    def fireBullet( self, xDir, yDir ):
        bPos = [ self.mPos[0], self.mPos[1] ]
        bullet = self.mManager.createEntity( "Spawned", "PlainBullet", bPos, "Bullet")
        bullet.setParent( self )
        bullet.setXDir( xDir )
        bullet.setYDir( yDir )
        bullet.loadImages()
        self.mParent.mRenderLayer.add_sprite(bullet.mBulletSprite)

    def collision( self, object, isGround ):
        if( isinstance( object, PlayerEntity ) ):
            object.message( self, "Damage", -1 * self.mDamage )

        #if( isGround ):
        #    pass

    def died( self ):
        pass

    def message( self, entitySendingMessage, message, data ):
        EntityWithHealth.message( self, entitySendingMessage, message, data)
        if( entitySendingMessage.mParent == self ):
            if( isinstance(entitySendingMessage, PlainBullet) ):
                self.mParent.mRenderLayer.remove_sprite( entitySendingMessage.mBulletSprite )
                self.mManager.removeEntityFromGroup( entitySendingMessage, "Spawned" )
                self.mManager.deleteEntity( entitySendingMessage )


class TargetEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return TargetEntity( manager, pos )
        
class TargetEntity(Entity):
    def __init__( self, manager, pos ):
        Entity.__init__( self, manager )
        self.mPos = copy.copy( pos );
        self.mPhysical = False
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mEnabled = False

# ---------------------
# Boss
# ---------------------
class ShipyardBossEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return ShipyardBoss( manager, pos )

class ShipyardBoss(EntityWithHealth):
    def __init__( self, manager, pos ):
        EntityWithHealth.__init__( self, manager )
        self.mPos = copy.copy( pos );
        self.mPhysical = True
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True
        self.setHealth( 25 )
        self.setMaxHealth( 25 )
        self.mState = "decide"
        self.mPlayerEntity = manager.getEntity( "Player" )
        self.mTargets = []
        self.mTargets.append( manager.getEntity( "ShipyardBossLeftTarget" ) )
        self.mTargets.append( manager.getEntity( "ShipyardBossRightTarget" ) )
        self.mStateTime = 0
        self.mDamage = 2
        self.mSpeed = 0
        self.mPaused = True
        

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def otherSide( self ):
        pos = 0
        retTarg = self.mTargets[0]
        for Target in self.mTargets:
            if( math.fabs(self.mPos[0] - Target.mPos[0]) > pos ):
                pos = math.fabs(self.mPos[0] - Target.mPos[0])
                retTarg = Target
                
        return retTarg
        
        
    def atTarget( self ):
        return ( math.fabs(self.mPos[0] - self.mTargetSpot.mPos[0]) < 4 )
        
    def nearPlayer( self ):
        return ( math.fabs(self.mPos[0] - (self.mPlayerEntity.mPos[0] + self.mPlayerEntity.mRect.width)) < 16 ) or ( math.fabs( (self.mPos[0] + self.mRect.width) - self.mPlayerEntity.mPos[0]) < 16)

    def update( self, deltaTime ):
        # states = decide, walk away, shoot or smack
           if( self.mPaused == False ):
            if( self.mState == "decide" ):
                self.mTargetSpot = self.otherSide()
                self.mSpeed = (self.mTargetSpot.mPos[0] - self.mPos[0]) / 1.5
                self.mState = "walk"
            elif( self.mState == "walk" ):
                if( self.atTarget() ):
                    self.mStateTime = 0
                    self.mState = "decideToSmackOrShoot"
                else:
                    self.mProposedSteps[0] = self.mSpeed * deltaTime

            elif( self.mState == "decideToSmackOrShoot" ):
                self.mStateTime += deltaTime
                if( self.mStateTime > 0.5 ):
                    if( self.nearPlayer() ):
                        self.mState = "smack"
                        self.mStateTime = 0
                    else:
                        self.mState = "shoot"
                        self.mBulletCount = 0
                        self.mStateTime = 0
                    
            elif( self.mState == "shoot" ):
                self.mStateTime += deltaTime
                if( self.mStateTime > 0.5 ):
                    if( self.mBulletCount < 3 ):
                        self.mStateTime = 0
                        # IF we are at the left target shoot right
                        if( self.mTargetSpot == self.mTargets[0] ):
                          pxDir = 1
                        else:
                          pxDir = -1
                        
                        if( self.mBulletCount == 0 ):
                            self.fireBullet( pxDir * 3, 0 )
                        elif( self.mBulletCount == 1 ):
                            self.fireBullet( pxDir * 2, -1 )
                        else:
                            self.fireBullet( pxDir * 1, -2 )
                            
                        self.mBulletCount += 1
                    else:
                        self.mState = "decide"
            elif( self.mState == "smack" ):
                if( self.mStateTime == 0 ):
                    self.mRect.width = 64
                    self.mSourceRect.width= 64
                    if( self.mTargetSpot == self.mTargets[1] ):
                        self.mPos[0] -= 32
                self.mStateTime += deltaTime
                    
                if( self.mStateTime > 2 ):
                    self.mState = "decide"
                    self.mRect.width = 32
                    self.mSourceRect.width= 32
                    if( self.mTargetSpot == self.mTargets[1] ):
                        self.mPos[0] += 32

    def fireBullet( self, xDir, yDir ):
        bPos = [ self.mPos[0], self.mPos[1] ]
        bullet = self.mManager.createEntity( "Spawned", "PlainBullet", bPos, "Bullet")
        bullet.setParent( self )
        bullet.setXDir( xDir )
        bullet.setYDir( yDir )
        bullet.loadImages()
        self.mParent.mRenderLayer.add_sprite(bullet.mBulletSprite)

    def collision( self, object, isGround ):
        if( isinstance( object, PlayerEntity ) ):
            object.message( self, "Damage", -1 * self.mDamage )

    def died( self ):
        # TODO: Message somebody to start the boss died animiation
        pass

    def message( self, entitySendingMessage, message, data ):
        EntityWithHealth.message( self, entitySendingMessage, message, data)
        if( entitySendingMessage.mParent == self ):
            if( isinstance(entitySendingMessage, PlainBullet) ):
                self.mParent.mRenderLayer.remove_sprite( entitySendingMessage.mBulletSprite )
                self.mManager.removeEntityFromGroup( entitySendingMessage, "Spawned" )
                self.mManager.deleteEntity( entitySendingMessage )





# This python file should contain all of the enemies on the all levels.

import copy
import sys
import uuid

import tiledtmxloader

import pygame
import systems
from systems.entity_system import Entity, EntityCreator, EntityManagerSystem
from systems.game_state_system import GameStateManagerSystem
from game.entities.player_entities import PlayerEntity, CameraEntity

# ---------------------
# Triggers
# ---------------------
class CameraTriggerEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return CameraTrigger( manager, pos )

class CameraTrigger(Entity):
    def __init__( self, manager, pos ):
        Entity.__init__( self, manager )
        self.mEntityId = uuid.uuid4()
        self.mPhysical = False
        self.mPos = copy.copy( pos );
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True
        self.mActedOn = False
        self.mCameraEntity = manager.getEntity( "Camera" )

    def loadImages( self ):
        self.mSprite = None

    def update( self, deltaTime ):
        if( self.mActedOn == False ):
            if( self.mEntitySpecialName == "TrackRight" ):
                self.mCameraEntity.rightTrackTo( self.mPos[0] + self.mRect.width, self.mRect.width / 16 )
                self.mActedOn = True

    def collision( self, object, isGround ):
        pass

    def message( self, entitySendingMessage, message, data ):
        pass


# This python file should contain all of the enemies on the all levels.

import copy
import sys
import uuid

import tiledtmxloader

import pygame
import systems
from systems.entity_system import Entity, EntityCreator, EntityManagerSystem
from systems.game_state_system import GameStateManagerSystem
from game.entities.player_entities import PlayerEntity

# ---------------------
# HealthSmall
# ---------------------
class HealthSmallEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return HealthSmall( manager, pos )

class HealthSmall(Entity):
    def __init__( self, manager, pos ):
        Entity.__init__( self, manager )
        self.mEntityId = uuid.uuid4()
        self.mPhysical = True
        self.mPos = copy.copy( pos );
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        pass

    def collision( self, object, isGround ):
        if( isinstance(object, PlayerEntity) ):
            object.applyHealthAdjustment( 2 )
            self.mParent.message( self, "Remove", None )

    def message( self, entitySendingMessage, message, data ):
        return "Pass"



# ---------------------
# HealthLarge
# ---------------------
class HealthLargeEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return HealthLarge( manager, pos )

class HealthLarge(Entity):
    def __init__( self, manager, pos ):
        Entity.__init__( self, manager )
        self.mEntityId = uuid.uuid4()
        self.mPhysical = True
        self.mPos = copy.copy( pos );
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        pass

    def collision( self, object, isGround ):
        if( isinstance(object, PlayerEntity) ):
            object.applyHealthAdjustment( 5 )
            self.mParent.message( self, "Remove", None )

    def message( self, entitySendingMessage, message, data ):
        return "Pass"


# ---------------------
# BossDoor
# ---------------------
class BossDoorEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return BossDoor( manager, pos )

class BossDoor(Entity):
    def __init__( self, manager, pos ):
        Entity.__init__( self, manager )
        self.mEntityId = uuid.uuid4()
        self.mPhysical = True
        self.mPos = copy.copy( pos );
        self.mRect = pygame.Rect(0, 0, 32, 32)
        self.mRect.bottomleft = copy.copy( pos )
        self.mOnGround = True
        self.mStateList = GameStateManagerSystem.instance.findState( "LevelGameState" )
        self.mCameraEntity = manager.getEntity( "Camera" )
        self.mWasOnScreen = False
        self.mState = "spawn"

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/MetaDataTiles.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        onScreen = self.mCameraEntity.getScreenRect().colliderect( self.mRect )
        if( onScreen == False ):
            self.mWasOnScreen = False
            
        if( onScreen and self.mWasOnScreen == False and self.mCameraEntity.mAcquired == False):
            self.mCameraEntity.rightTrackTo( self.mPos[0] + self.mRect.width, self.mRect.width / 16 )
            self.mState = None
            self.mWasOnScreen = True
        elif( self.mState == "open" ):
            self.mPos[1] -= self.mRect.height / 16
            self.mRect.bottomleft = copy.copy( self.mPos )
            if( self.mPos[1] < self.mStatePos[1] - self.mRect.height ):
                self.mStateList[0].bossDoorOpened( self )
        elif( self.mState == "close" ):
            self.mPos[1] += self.mRect.height / 16
            self.mRect.bottomleft = copy.copy( self.mPos )
            if( self.mPos[1] > self.mStatePos[1] + self.mRect.height ):
                self.mStateList[0].bossDoorClosed( self )

    def collision( self, object, isGround ):
        if( isinstance(object, PlayerEntity) ):
            self.mPhysical = False
            self.mStateList[0].bossDoorTouch( self )

    def message( self, entitySendingMessage, message, data ):
        self.mState = message
        self.mStatePos = copy.copy( self.mPos )



# This python file should deal with the bullet entities

import copy
import sys
import uuid

import tiledtmxloader

import pygame
import systems
from systems.entity_system import Entity, EntityCreator, EntityWithHealth, EntityManagerSystem



class PlainBulletEntityCreator(EntityCreator):
    def createEntity( self, manager, pos ):
        return PlainBullet( manager, pos )


class PlainBullet(Entity):
    # TODO: This whole bullet entity probably needs to go in it's own file
    #       of projectiles with some sort of base projectile?
    def __init__( self, manager, pos ):
        Entity.__init__( self, manager )
        self.mPhysical = True
        self.mRect = pygame.Rect(pos[0], pos[1], 32, 32)
        self.mPos = copy.copy( pos )
        self.mRect.bottomleft = copy.copy( pos )
        self.mProposedSteps[0] = 0
        self.mProposedSteps[1] = 0
        self.mSpeedX = 0
        self.mSpeedY = 0
        self.mCameraEntity = manager.getEntity( "Camera" )

    def applyGravity( self, movementDueToGravity, deltaTime ):
        self.mRect.bottomleft = copy.copy( self.mPos )

    def loadImages( self ):
        # TODO: Load the bullet sprite sheet
        self.mImage = pygame.image.load( "tiles/entities/Bullets.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)
        self.mBulletSprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mImage, self.mRect, self.mSourceRect)

    def update( self, deltaTime ):
        self.mProposedSteps[0] = self.mSpeedX * deltaTime
        self.mProposedSteps[1] = self.mSpeedY * deltaTime
        onScreen = self.mCameraEntity.getScreenRect().colliderect( self.mRect )
        if( onScreen == False ):
            self.mParent.message( self, "Remove", False )

    def collision( self, object, isGround ):
        if( object != self.mParent ):
            if( isinstance( object, Entity ) ):
                if( object.message( self, "Damage", -1 ) == None ):
                    self.mParent.message( self, "Remove", isGround )
            else:
                self.mParent.message( self, "Remove", isGround )

    def message( self, entitySendingMessage, message, data ):
        if( isinstance( entitySendingMessage, PlainBullet ) ):
            return "PASS_THROUGH_PROJECTILE"
        

    def setXDir( self, xDir ):
        self.mSpeedX = xDir * 32 * 8
        
    def setYDir( self, yDir ):
        self.mSpeedY = yDir * 32 * 8


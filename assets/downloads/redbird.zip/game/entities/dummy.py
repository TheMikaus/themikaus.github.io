# This python file is for testing entity information

import sys
import uuid

import pygame
import systems
from systems.entity_system import Entity, EntityCreator, EntityManagerSystem

class Dummy(Entity):
    def __init__( self, manager, renderer ):
        Entity.__init__( self, manager )
        self.mEntityId = uuid.uuid4()
        self.mEntitySpecialName = "Dummy"
        self.mPlayerEntity = manager.getEntity( "Player" )
        self.mRenderer = renderer;
        self.mPhysical = True
        self.mRect = pygame.Rect(0, 0, 32, 32)

    def loadImages( self ):
        self.mImage = pygame.image.load( "tiles/entities/Player.png" )
        self.mSourceRect = pygame.Rect(32, 0, 32, 32)

    def update( self, deltaTime ):
        self.mRect.bottomleft = self.mPos

    def message( self, entitySendingMessage, message, data ):
        pass

    def collision( self, object, isGround ):
        if( isGround[1] ):
            self.mJumpVelocity = 0

# This python file is to house the spawner class

import pygame
import systems
from systems.entity_system import Entity, EntityCreator, EntityManagerSystem

# xDirection -1, 1 (left or right)
# yDirection -1, 1 (face up, face down)
# spawnType = OnScreen, OnceALevel, IfNotOwnedByPlayer

class EntitySpawner(Entity):
    def __init__( self, manager, posX, posY, properties, renderLayer ):
        Entity.__init__( self, manager )
        self.mPosX = posX
        self.mPosY = posY
        self.mPlayerEntity = manager.getEntity( "Player" )
        self.mCameraEntity = manager.getEntity( "Camera" )
        self.mEntityType = properties['EntityType']
        self.mXDir = properties['xDirection']
        self.mYDir = properties['yDirection']
        self.mSpawnType = properties['spawnType']
        self.mEntitySpecialName = properties['specialName']
        self.mWasOnScreen = False
        self.mAttachedEntity = None
        self.mAlreadySpawned = False
        self.mPhysical = False
        self.mRect = pygame.Rect( self.mPosX, self.mPosY, 32, 32 )
        self.mRenderLayer = renderLayer
        self.mPickedUp = False
        print "Spawner for " + self.mEntityType + "(" + self.mSpawnType + ") created."

    def applyGravity( self, movementDuetoGravity, deltaTime ):
        pass

    def storePosData( self ):
        pass

    def restorePosData( self ):
        pass

    def applySteps( self ):
        pass

    def collision( self, object, isGround ):
        pass

    def loadImages( self ):
        pass

    def update( self, deltaTime ):
        onScreen = self.mCameraEntity.getScreenRect().colliderect( self.mRect )
        spawnEntity = False 
        if( onScreen and self.mWasOnScreen == False and self.mAttachedEntity == None):
            if( self.mSpawnType == 'OnScreen' and self.mPickedUp == False):
               spawnEntity = True 
            elif( self.mSpawnType == 'OnceALevel' and self.mAlreadySpawned == False):
                spawnEntity = True
            elif( self.mSpawnType == 'IfNotOwnedByPlayer' and self.mPlayerEntity.hasItem(self.mEntitySpecialName) == False ):
                spawnEntity = True

        self.mWasOnScreen = onScreen

        if( spawnEntity ):
            self.mAttachedEntity = self.mManager.createEntity( "Spawned", self.mEntityType, [self.mPosX, self.mPosY], self.mEntitySpecialName )
            self.mAttachedEntity.setDirections( self.mXDir, self.mYDir )
            print "Spawner for " + self.mEntityType + " created entity " + self.mEntitySpecialName
            # TODO: set the initial facing attributes and all that fun stuff
            self.mAttachedEntity.loadImages()
            self.mAttachedEntity.setParent( self )
            self.mAlreadySpawned = True
            if( self.mAttachedEntity.mSprite != None ):
                self.mRenderLayer.add_sprite(self.mAttachedEntity.mSprite);

        if( self.mAttachedEntity != None ):
            self.checkOffscreenOfEntity()
        elif( self.mSpawnType == "OnScreen" ):
            if( self.mCameraEntity.getScreenRect().colliderect(self.mRect) == False):
                self.mPickedUp = False
        

    def message( self, entitySendingMessage, message, data ):
        if( entitySendingMessage == self.mAttachedEntity ):
            if( message == "Remove" ):
                self.removeEntity()
                self.mPickedUp = True


    def checkOffscreenOfEntity( self ):
        onScreen = self.mCameraEntity.getScreenRect().colliderect( self.mAttachedEntity.mRect )
        if( onScreen == False and self.mSpawnType == "OnScreen"):
            self.removeEntity()
            self.mAlreadySpawned = False

    def removeEntity( self ):
        if( self.mAttachedEntity != None ):
            if( self.mAttachedEntity.mSprite != None ):
                self.mRenderLayer.remove_sprite(self.mAttachedEntity.mSprite)
            self.mManager.removeEntityFromGroup( self.mAttachedEntity, "Spawned" )
            self.mManager.deleteEntity( self.mAttachedEntity )
            self.mAttachedEntity = None

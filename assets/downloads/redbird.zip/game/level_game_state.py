# This python file should deal with most of the Stage level logic (the game itself I guess)
# Entities will be in separate packages, still haven't worked all of that out.

import copy
import sys
import pygame

import tiledtmxloader

import systems
from systems.input_system import ButtonNames
from systems.game_state_system import GameState, GameStateManagerSystem, StateTransitions

import game
from game.pause_game_state import PauseGameState
from game.game_over_state import GameOverGameState

import game.entities
from game.entities.player_entities import PlayerEntity, CameraEntity
from game.entities.shipyard_enemies import ShipyardRatEntityCreator, ShipyardSeagullEntityCreator, ShipyardTrashcanEntityCreator, ShipyardTurretEntityCreator, ShipyardBossEntityCreator, TargetEntityCreator
from game.entities.item_entities import HealthSmallEntityCreator, HealthLargeEntityCreator, BossDoorEntityCreator
from game.entities.camera_entities import CameraTriggerEntityCreator
from game.entities.special_item_entities import TeaLeafBagEntityCreator
from game.entities.spawners import EntitySpawner
from game.entities.dummy import Dummy
from game.entities.bullet_entities import PlainBulletEntityCreator
from game.player_game_data import PlayerGameData, PlayerLevelGameStateData

class LevelGameState(GameState):
    def __init__( self, inputManagerSystem, graphicsManagerSystem, entityManagerSystem, playerGameData ):
        GameState.__init__( self )
        self.mInputManagerSystem = inputManagerSystem
        self.mGraphicsManagerSystem = graphicsManagerSystem
        self.mEntityManagerSystem = entityManagerSystem
        self.mPlayerDied = False
        self.mLevelGameStateData = PlayerLevelGameStateData( playerGameData )
        self.mGameState = "Normal"
        self.mStateName = "LevelGameState"

    def initialize( self ):
        print "LevelGameState.initialize"
        self.initializeInput()
        self.initializeResources()

    def initializeInput( self ):
        print "LevelGameState.initialize.Input"
        self.mAttackButtonId = self.mInputManagerSystem.findButtonId( 'Attack' )
        self.mMenuButtonId = self.mInputManagerSystem.findButtonId( 'Menu' )
        self.mCycleWeaponId = self.mInputManagerSystem.findButtonId( 'CycleWeapon' )
        self.mUpButtonId = self.mInputManagerSystem.findButtonId( 'Up' )
        self.mDownButtonId = self.mInputManagerSystem.findButtonId( 'Down' )
        self.mLeftButtonId = self.mInputManagerSystem.findButtonId( 'Left' )
        self.mRightButtonId = self.mInputManagerSystem.findButtonId( 'Right' )

    def initializeResources( self ):
        print "LevelGameState.initialize.LoadMap"
        self.mTmxMap = tiledtmxloader.tmxreader.TileMapParser().parse_decode( "maps/testMap.tmx" )
        #self.mTmxMap = tiledtmxloader.tmxreader.TileMapParser().parse_decode( "maps/00-shipyard.tmx" )

        print "LevelGameState.initialize.LoadTiles"
        self.mTmxResources = tiledtmxloader.helperspygame.ResourceLoaderPygame()
        self.mTmxResources.load( self.mTmxMap )

        print "LevelGameState.initialize.Layer"
        self.mAllLayers = tiledtmxloader.helperspygame.get_layers_from_map( self.mTmxResources )
        self.mRenderableLayers = []
        self.mObjectLayers = []

        for layer in self.mAllLayers:
            if layer.is_object_group:
                self.mObjectLayers.append( layer )
            else:
                self.mRenderableLayers.append( layer )

        self.mRenderer = tiledtmxloader.helperspygame.RendererPygame()
        self.mRenderer.set_camera_position_and_size( 0, 0, 320, 240, "topleft" )
        self.mSurface, self.mSurfaceId = self.mGraphicsManagerSystem.addLayer( 320, 240 )

        self.mPlayerEntity = PlayerEntity( self.mInputManagerSystem, self.mEntityManagerSystem, self.mRenderableLayers[1], self.mLevelGameStateData )
        self.mLevelGameStateData.getPlayerPositions( self.mObjectLayers )
        self.setPlayerStartingPosition()
        self.mEntityManagerSystem.addEntityToGroup( self.mPlayerEntity, "PlayerGroup" )
        self.mEntityManagerSystem.mListOfEntities.append( self.mPlayerEntity )

        self.mCameraEntity = CameraEntity( self.mEntityManagerSystem, self.mRenderer )
        self.mEntityManagerSystem.addEntityToGroup( self.mCameraEntity, "PlayerGroup" )
        self.mEntityManagerSystem.mListOfEntities.append( self.mCameraEntity )

        self.mDummyEntity = Dummy( self.mEntityManagerSystem, self.mRenderer )
        self.mEntityManagerSystem.addEntityToGroup( self.mDummyEntity, "PlayerGroup" )
        self.mEntityManagerSystem.mListOfEntities.append( self.mDummyEntity )
        self.mDummyEntity.mPos = [ self.mPlayerEntity.mPos[0] + 64, self.mPlayerEntity.mPos[1] ]

        self.mEntityManagerSystem.setCollisionLayer( self.mRenderableLayers[3] )
        self.mEntityManagerSystem.setGravity( 15 ) # This is mega man's gravity .25 pixels a frame at 60 frames

        # TODO: Create the entities
        self.configureEntityManager()
        self.loadEntitySpawners()
        self.loadTargets()

        # TODO: Load up the sprites using the entities
        self.mPlayerEntity.loadImages()
        self.mDummyEntity.loadImages()

        print "LevelGameState.initialize.LoadSprites"
        # TODO: Load the Sprites
        self.mPlayerSprite = self.mPlayerEntity.mSprite
        self.mDummySprite = tiledtmxloader.helperspygame.SpriteLayer.Sprite(self.mDummyEntity.mImage, self.mDummyEntity.mRect, self.mDummyEntity.mSourceRect)
        # TODO: Figure out the correct layer to add sprites.
        self.mRenderableLayers[1].add_sprite(self.mPlayerSprite)
        self.mRenderableLayers[1].add_sprite(self.mDummySprite)
        
        # TODO: Load the pieces of the health display
        self.mPlayerStatusLayer, self.mPlayerStatusLayerId = self.mGraphicsManagerSystem.addLayer( 60, 100 )
        self.mPlayerStatusLayer.set_colorkey( (255, 0, 255) )
        self.mPlayerStatusLayer.fill( (255, 0, 255) )
        self.mPlayerStatusLayer.set_alpha( 255 )
        self.mHealthFont = pygame.font.SysFont("monospace", 8)
        
    def interrupted( self ):
        print "LevelGameState.interrupted"
        self.mGraySurface, self.mGraySurfaceId = self.mGraphicsManagerSystem.addLayer( 320, 240 )
        self.mGraySurface.fill( ( 0, 0, 0 ) )
        self.mGraySurface.set_alpha( 128 )
        self.mEntityManagerSystem.pauseSystem()

    def resumed( self ):
        print "LevelGameState.resumed"
        self.mGraphicsManagerSystem.removeLayer( self.mGraySurfaceId )
        self.mGraySurface = None
        self.mEntityManagerSystem.resumeSystem()
        if( self.mPlayerDied == True ):
            self.mPlayerDied = False
            self.exit()
            self.initializeResources()

    # This should probably be in the LevelGameStateData
    def setPlayerStartingPosition( self ):
        self.mPlayerEntity.mPos = self.mLevelGameStateData.getCurrentStartingPosition()

    def exit( self ):
        print "LevelGameState.exit"
        self.mGraphicsManagerSystem.removeLayer( self.mPlayerStatusLayerId )
        self.mGraphicsManagerSystem.removeLayer( self.mSurfaceId )
        self.mSurface = None
        self.mEntityManagerSystem.removeEntities()

    def update( self, deltaTime ):
        if( self.mGameState == "Normal" ):
            State, Trans = self.updateInNormalState( deltaTime )
        elif( self.mGameState == "PauseEntitiesAndOpenDoor" ):
            State, Trans = self.updateInPauseEntitiesAndOpenDoorState( deltaTime )
        elif( self.mGameState == "OpenDoor" ):
            State, Trans = self.updateInOpenDoorState( deltaTime )
        elif( self.mGameState == "MovePlayer" ):
            State, Trans = self.updateInMovePlayerState( deltaTime )
        elif( self.mGameState == "CloseDoor" ):
            State, Trans = self.updateInCloseDoorState( deltaTime )

        # TODO: REMOVE THIS IT'S TEMPORARY
        if( self.mInputManagerSystem.buttonWasPressed( self.mCycleWeaponId ) ):
            return None, StateTransitions.POP

        self.mSurface.fill( (0, 0, 0) )
        for layer in self.mRenderableLayers:
            self.mRenderer.render_layer( self.mSurface, layer )
            
        return State, Trans
    
    def updateInNormalState( self, deltaTime ):
        self.updatePlayerStatusSurface()
        # TODO: Remove this once the main exit/entrance is set up for this game state
        # TODO: The logic here should update the camera based on where the player is
        #     : This might be doable from the entity class
        # TODO: Should check ending conditions for state transitions
        if( self.mInputManagerSystem.buttonWasPressed( self.mCycleWeaponId ) ):
            return None, StateTransitions.POP
        elif( self.mInputManagerSystem.buttonWasPressed( self.mMenuButtonId ) ):
            return PauseGameState( self.mInputManagerSystem, self.mGraphicsManagerSystem ), StateTransitions.PUSH

        # If player died, then push on the GameOverGameState
        if( self.mPlayerEntity.isDead() ):
            self.mLevelGameStateData.mLives = self.mLevelGameStateData.mLives - 1
            if( self.mLevelGameStateData.mLives == 0 ):
                self.mPlayerDied = True
                return GameOverGameState( self.mInputManagerSystem, self.mGraphicsManagerSystem, self.mEntityManagerSystem ), StateTransitions.PUSH
            else:
                # TODO: Put the state into a death animation state
                #       Wait for the animation to finish and then start the level over
                #       from the starting position
                self.exit()
                self.initializeResources()

        return self, StateTransitions.NOOP
    
    def updateInPauseEntitiesAndOpenDoorState( self, deltaTime ):
        self.mEntityManagerSystem.pauseEntities()
        for entity in self.mEntitySpawners:
            entity.unpause()
            
        self.mDoor.unpause()
        self.mCameraEntity.unpause()
        self.mCameraEntity.acquire()
        self.mDoor.message( self, "open", 0 )
        self.mGameState = "OpenDoor"
        return self, StateTransitions.NOOP
    
    def bossDoorOpened( self, door ):
        self.mGameState = "MovePlayer"
        self.mDoor.message( self, "hold", 0 )
        self.mPlayerPos = copy.copy( self.mPlayerEntity.mPos )
        
    def updateInOpenDoorState( self, deltaTime ):
        # The door is being opened by itself
        # the previous state messaged the door and the door is now messaging the state
        return self, StateTransitions.NOOP
        
    def updateInMovePlayerState( self, deltaTime ):
        if( self.mCameraEntity.mFollowMode == "RightTrack" ):
            self.mCameraEntity.moveToCentered( self.mPlayerEntity.mRect.width / 16 )
        elif( self.mPlayerEntity.mPos[0] < (self.mPlayerPos[0] + self.mPlayerEntity.mRect.width * 2) ):
            self.mPlayerEntity.mPos[0] += self.mPlayerEntity.mRect.width / 16
            self.mPlayerEntity.mRect.bottomleft = self.mPlayerEntity.mPos
        elif( self.mCameraEntity.mFollowMode == "MoveToCentered" and self.mCameraEntity.mTracked == True):
            self.mCameraEntity.leftTrackTo( self.mPlayerEntity.mPos[0] - self.mPlayerEntity.mRect.width, self.mPlayerEntity.mRect.width / 16 )
        elif( self.mCameraEntity.mTracked == True ):
            self.mDoor.message( self, "close", 0 )
            self.mGameState = "CloseDoor"
        return self, StateTransitions.NOOP
        
    def updateInCloseDoorState( self, deltaTime ):
        # The door is being opened by itself
        # the previous state messaged the door and the door is now messaging the state
        return self, StateTransitions.NOOP
    
    def bossDoorClosed( self, door ):
        self.mDoor.message( self, "dormant", 0 )
        self.mDoor.setPassability( False )
        self.mGameState = "Normal"
        self.mCameraEntity.free()
        self.mEntityManagerSystem.unpauseEntities()
    
    def updatePlayerStatusSurface( self ):
        # TODO: Replace with graphic representation
        label = self.mHealthFont.render( str(self.mPlayerEntity.mHealth), 1, (255,255,255) )
        self.mPlayerStatusLayer.fill( (255, 0, 255) )
        self.mPlayerStatusLayer.blit(label, (10, 10))

    def loadEntitySpawners( self ):
        self.mEntitySpawners = []
        for layer in self.mObjectLayers:
            for object in layer.objects:
                if( object.type == 'Spawner' ):
                    posX = object.x
                    posY = object.y + object.height
                    spawner = EntitySpawner( self.mEntityManagerSystem, posX, posY, object.properties, self.mRenderableLayers[1] )
                    self.mEntitySpawners.append( spawner )
                    self.mEntityManagerSystem.addEntityToGroup( spawner, "Spawners" )
                    self.mEntityManagerSystem.mListOfEntities.append( spawner )
                    
    def loadTargets( self ):
        self.mTargets = []
        for layer in self.mObjectLayers:
            for object in layer.objects:
                if( object.type == 'Target' ):
                    posX = object.x
                    posY = object.y + object.height
                    pos = [ object.x, object.y ]
                    entitySpecialName = object.properties["specialName"]
                    self.mTargets.append( self.mEntityManagerSystem.createEntity( "Targets", "Target", pos, entitySpecialName ) )
                    

    def bossDoorTouch( self, door ):
        self.mGameState = "PauseEntitiesAndOpenDoor"
        self.mDoor = door

    def configureEntityManager( self ):
        self.mEntityManagerSystem.registerEntityCreator( 'HealthSmall', HealthSmallEntityCreator() )
        self.mEntityManagerSystem.registerEntityCreator( 'HealthLarge', HealthLargeEntityCreator() )

        self.mEntityManagerSystem.registerEntityCreator( 'BossDoor', BossDoorEntityCreator() )

        self.mEntityManagerSystem.registerEntityCreator( 'ShipyardRat', ShipyardRatEntityCreator() )
        self.mEntityManagerSystem.registerEntityCreator( 'ShipyardSeagull', ShipyardSeagullEntityCreator() )
        self.mEntityManagerSystem.registerEntityCreator( 'ShipyardTrashcan', ShipyardTrashcanEntityCreator() )
        self.mEntityManagerSystem.registerEntityCreator( 'ShipyardTurret', ShipyardTurretEntityCreator() )
        self.mEntityManagerSystem.registerEntityCreator( 'ShipyardBoss', ShipyardBossEntityCreator() )
        
        self.mEntityManagerSystem.registerEntityCreator( 'TeaLeafBag', TeaLeafBagEntityCreator() )
        
        self.mEntityManagerSystem.registerEntityCreator( 'CameraTrigger', CameraTriggerEntityCreator() )
        
        self.mEntityManagerSystem.registerEntityCreator( 'PlainBullet', PlainBulletEntityCreator() )
        self.mEntityManagerSystem.registerEntityCreator( 'Target', TargetEntityCreator() )

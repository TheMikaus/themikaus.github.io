# This python file should deal with most of the Stage level logic (the game itself I guess)
# Entities will be in separate packages, still haven't worked all of that out.

import sys

import tiledtmxloader

import systems
from systems.input_system import ButtonNames
from systems.game_state_system import GameState, GameStateManagerSystem, StateTransitions

class PauseGameState(GameState):
    def __init__( self, inputManagerSystem, graphicManagerSystem ):
        GameState.__init__( self )
        self.mInputManagerSystem = inputManagerSystem
        self.mGraphicManagerSystem = graphicManagerSystem

    def initialize( self ):
        print "PauseGameState.initialize"
        self.initializeInput()
        self.initializeGraphicsResources()

    def initializeInput( self ):
        print "PauseGameState.initialize.Input"
        # Bleh
        self.mAcceptButtonId = self.mInputManagerSystem.findButtonId( 'Jump' )
        self.mMenuButtonId = self.mInputManagerSystem.findButtonId( 'Menu' )
        self.mUpButtonId = self.mInputManagerSystem.findButtonId( 'Up' )
        self.mDownButtonId = self.mInputManagerSystem.findButtonId( 'Down' )
        self.mLeftButtonId = self.mInputManagerSystem.findButtonId( 'Left' )
        self.mRightButtonId = self.mInputManagerSystem.findButtonId( 'Right' )

    def initializeGraphicsResources( self ):
        print "PauseGame.initialize.GraphicsResources"
        #self.mSurface, self.mSurfaceId = self.mGraphicManagerSystem.addLayer( 320, 240 )

    def exit( self ):
        print "PauseGameState.exit"
        #self.mGraphicManagerSystem.removeLayer( self.mSurfaceId )
        #self.mSurface = None

    def update( self, deltaTime ):
        # TODO: Remove this once the main exit/entrance is set up for this game state
        if( self.mInputManagerSystem.buttonWasPressed( self.mAcceptButtonId ) ):
            return None, StateTransitions.POP
        elif( self.mInputManagerSystem.buttonWasPressed( self.mMenuButtonId ) ):
            return None, StateTransitions.POP
        return self, StateTransitions.NOOP

pytmxloader

A python map loader for the map format used by Tiled (see www.mapeditor.org)

Project homepage and download:
    https://code.google.com/p/pytmxloader/
    https://code.google.com/p/pytmxloader/downloads/list

Dependencies:
    python 2.6+ or python 3.1+          http://www.python.org
    pygame 9.1+                         http://www.pygame.org


==== changelog ====

2011-12-15
    - 2to3 conversion completed

2011-12-14  [beta release 3.0.1]
    - added examples
    - fixed scaling
    - fixed hero size of minig game examples
    - reogranized module imports
    - fixed marging position


2011-11-23  [alpha release 3.0.0.82]
    - using 'New BSD license' now
    - improved loading speed of maps
    - improved pygame loader and renderer
    - pyglet part is pretty broken








<?xml version="1.0" encoding="UTF-8"?>
<tileset name="mini4x" firstgid="1" tilewidth="24" tileheight="28">
 <image source="graphics/mini4x.png"/>
</tileset>

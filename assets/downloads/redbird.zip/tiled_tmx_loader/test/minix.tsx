<?xml version="1.0" encoding="UTF-8"?>
<tileset name="minix" firstgid="1" tilewidth="24" tileheight="28">
 <image source="minix.png"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset name="mini3x" firstgid="1" tilewidth="24" tileheight="28">
 <image source="mini3x.png"/>
</tileset>

# This is the python file that should deal with the input system.
# Do not split this over multiple files.  Keep everything compact!
# The input system should be very similar to the one that was used for Retrobot

#################################################################################################
# USAGE NOTES
#################################################################################################
# This is an "interesting" system.  Basic work flow described below:
# - Load up the input update system (this is pygame specific)
#   ius = InputUpdateSystem()
#   - Load up the ControllerButtonMapping with (this is done by the input update system)
#     mapping = ControllerButtonMapping()
#     mapping.loadMapping( "im/JOYSTICKNAME.im" )
# - Create an instance of the InputManagerSystem (dumb name I know)
#   ims = InputManagerSystem( ius )
# - Register buttons you are interested in using with the constants provided in the ButtonNames enum
#   attackButtonId = ims.registerButton( "Attack", ButtonNames.B )
#   jumpButtonId = ims.registerButton( "Jump", ButtonNames.A )
# - Update the system!
#   ims.updateButtons( deltaTime )
# - Check if the buttons are down
#   if( ims.buttonDown( jumpButtonId ) ): DO SOMETHING
#   if( ims.buttonWasPressed( attackButtonId ) ): DO SOMETHING ELSE
#
# That's pretty much it.  The goal of this was to try and separate the game code from the
# actual input layer.  So the game itself doesn't know about joystick button 0, it knows about
# joystick button "A" and joystick button "UP" in the init stage.  Then in the core logic of the
# game it can just see if the attackButtonId is down/pressed, etc...
#
# In the games that are planned for this engine that works out fairly well.
# It will probably suck for games that need to expand past this.
#################################################################################################

import pygame, sys
from pygame.locals import *

class AxisInputRecord:  
    def __init__( self ):
        self.mInputType = 'Axis'
        self.mAxis = 0
        self.mDirection = 0

class ButtonInputRecord:
    def __init__( self ):
        self.mInputType = 'Button'
        self.mValue = 0

class ButtonNames:
    UP     = "UP"
    DOWN   = "DOWN"
    LEFT   = "LEFT"
    RIGHT  = "RIGHT"
    SELECT = "SELECT"
    START  = "START"
    A      = "A"
    B      = "B"

class ControllerButtonMapping:
    def __init__( self ):
        self.mButtonMap = dict()

    def loadMapping( self, fileName ):
        with open( fileName ) as f:
            for mapping in f:
                lineItems = mapping.split()
                key = lineItems[0]
                inputType = lineItems[1]
                if( inputType == 'Axis' ):
                    inputRecord = AxisInputRecord()
                    inputRecord.mAxis = int(lineItems[2])
                    inputRecord.mDirection = int(lineItems[3])
                    self.mButtonMap[key] = inputRecord;
                elif( inputType == 'Button' ):
                    inputRecord = ButtonInputRecord()
                    inputRecord.mValue = int(lineItems[2])
                    self.mButtonMap[key] = inputRecord

    def getButtonToCheck( self, key ):
        return self.mButtonMap[key]


class InputButton:
    def __init__( self ):
        self.mDownTime = 0
        self.mButtonId = 0
        self.mWasChecked = False
        self.mInputToCheck = []
        self.mInputName = ""


class KeyboardJoystick:
    def __init__( self ):
        pass

    def init( self ):
        pass
    
    def get_button( self, buttonValue ):
        return pygame.key.get_pressed()[buttonValue]

    def get_name( self ):
        return "Keyboard"

class InputUpdateSystem:
    def __init__( self, deadZone ):
        pygame.joystick.init()
        if( pygame.joystick.get_count() > 0 ):
            self.mJoypad = pygame.joystick.Joystick(0)
        else:
            self.mJoypad = KeyboardJoystick()

        self.mJoypad.init()
        self.mControllerButtonMapping = ControllerButtonMapping()
        try:
            self.mControllerButtonMapping.loadMapping( 'controllerMappings/' + self.mJoypad.get_name() + '.im' )
        except IOError:
            self.mJoypad = KeyboardJoystick()
            self.mControllerButtonMapping.loadMapping( 'controllerMappings/' + self.mJoypad.get_name() + '.im' )
        self.mDeadZone = deadZone

    def __del__( self ):
        pygame.joystick.quit()

    def buttonDown( self, buttonToCheck ):
        button = self.mControllerButtonMapping.getButtonToCheck( buttonToCheck )
        if( button.mInputType == 'Axis' ):
            if( button.mDirection < 0 ):
                return (self.mJoypad.get_axis(button.mAxis) < -1.0 * self.mDeadZone)
            else:
                return (self.mJoypad.get_axis(button.mAxis) > self.mDeadZone)
        elif( button.mInputType == 'Button' ):
            return (self.mJoypad.get_button(button.mValue) != 0)

    def update( self ):
        pygame.event.pump()


class InputManagerSystem:
    def __init__( self, inputUpdateSystem ):
        self.mInputButtons = []
        self.mInputUpdateSystem = inputUpdateSystem

    def updateButtons( self, deltaTime ):
        self.mInputUpdateSystem.update()
        for button in self.mInputButtons:
            buttonDown = False
            for inputToCheck in button.mInputToCheck:
                if( self.mInputUpdateSystem.buttonDown( inputToCheck ) ):
                    buttonDown = True
                    break
            if( buttonDown ):
                button.mDownTime += deltaTime
            else:
                button.mDownTime = 0
                button.mWasChecked = False  

    def findButton( self, buttonName ):
        for button in self.mInputButtons:
            if( button.mInputName == buttonName ):
                return button
        newButton = InputButton()
        self.mInputButtons.append(newButton)
        return newButton

    def findButtonId( self, buttonName ):
        for index, button in enumerate(self.mInputButtons):
            if( button.mInputName == buttonName ):
                return index
        return -1

    def registerButton( self, buttonName, buttonToCheck ):
        button = self.findButton( buttonName )
        button.mInputName = buttonName
        button.mInputToCheck.append( buttonToCheck )
        self.mInputButtons.append( button )
        return len( self.mInputButtons ) - 1

    def deregisterButton( self, buttonName ):
        for index, button in enumerate(self.mInputButtons):
            if( button.mInputName == buttonName ):
                self.mInputButtons.pop( index )
                return

    def buttonDown( self, buttonId ):
        if( self.mInputButtons[buttonId].mDownTime == 0 ):
            self.mInputButtons[buttonId].mWasChecked = False
        return self.mInputButtons[buttonId].mDownTime;

    def buttonWasPressed( self, buttonId ):
        if( self.mInputButtons[buttonId].mDownTime > 0 and self.mInputButtons[buttonId].mWasChecked == False ):
            self.mInputButtons[buttonId].mWasChecked = True
            return True
        return False 

    def clearInputs( self ):
        self.mInputButtons = []

    def getState( self ):
        return self.mInputButtons

    def setState( self, state ):
        self.mInputButtons = state

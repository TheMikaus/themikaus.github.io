# This python file is for the animation system
# Animation File formates
# The animation system will load animations from the main animation directory passed in
# animations/
#          ./animation_family_name/
#                                ./frame_001.png or jpg (I don't know which yet)
#                                ./leftcorner.xy <--- list of framenumber x y (This is supposed to be where the left "foot" is in each frame)
#                                ./animations.list <-- See animation list format below
#
# Animation list format
# Start ANIMATION_NAME
#   FrameNumber TimeDelay
#   FrameNumber TimeDelay
#   etc...
# End
#

import pygame
import os

from os import walk


class AnimationImageFrame:
    def __init__( self, fileName, x, y ):
        self.mX = x
        self.mY = y
        self.mImage = pygame.image.load( fileName )
        self.mFileName = fileName
        
    def flip( self ):
        aif = AnimationImageFrame(self.mFileName, self.mImage.get_rect().width - self.mX, self.mY)
        aif.mImage = pygame.transform.flip( self.mImage, True, False )
        return aif


class AnimationSequence:
    def __init__( self, name ):
        self.mAnimationName = name
        self.mAnimationFrames = []
        self.mAnimationFramesFlipped = []
        self.mAnimationDurations = []
        
    def addFrame( self, imageFrame, duration ):
        self.mAnimationFrames.append( imageFrame )
        self.mAnimationFramesFlipped.append( imageFrame.flip() )
        self.mAnimationDurations.append( duration )


class AnimationInstance:
    def __init__( self, sequence ):
        self.mSequence = sequence
        self.mFrameTime = 0
        self.mCurrentFrame = 0
    
    def animationOver( self ):
        return self.mCurrentFrame == len( self.mSequence.mAnimationFrames )
    
    def currentFrame( self ):
        return self.mSequence.mAnimationFrames[self.mCurrentFrame]
        
    def currentFrameFlipped( self ):
        return self.mSequence.mAnimationFramesFlipped[self.mCurrentFrame]
    
    def update( self, deltaTime ):
        self.mFrameTime += deltaTime
        frameTime = self.mSequence.mAnimationDurations[self.mCurrentFrame]
        if( self.mFrameTime >= frameTime ):
            self.mFrameTime -= frameTime
            self.mCurrentFrame += 1


class AnimationFamily:
    def __init__( self, familyName ):
        self.mFamilyName = familyName
        self.mAnimationImageFrames = dict() # Using a dictionary so we don't have to worry about the order in which the os returns the frames when asked
        self.mAnimationSequences = dict()

    def load( self, animationDirectory ):
        for( dirpath, dirnames, filenames ) in walk( animationDirectory ):
            for file in filenames:
                if( "frame" in file ):
                   aif = AnimationImageFrame( animationDirectory + "/" + file, 0, 0 )
                   index = int( file[6:-4] )
                   self.mAnimationImageFrames[index] = aif
                
        leftFile = open( animationDirectory + "/leftcorner.xy", "r" )
        for line in leftFile:
            if(  "#" in line ):
                continue
            else:
                parts = line.split()
                index = int( parts[0] )
                x = int( parts[1] )
                y = int( parts[2] )
                self.mAnimationImageFrames[index].mX = x
                self.mAnimationImageFrames[index].mY = y
        leftFile.close()

        animationListFile = open( animationDirectory + "/animations.list", "r" )
        for line in animationListFile:
            if( "Start" in line ):
                currentSequence = AnimationSequence( line.split()[1] )
            elif( "End" in line ):
                self.mAnimationSequences[currentSequence.mAnimationName] = currentSequence
            elif( "#" in line or (not line.strip()) ):
                continue
            else:
                parts = line.split()
                index = int( parts[0] )
                duration = float( parts[1] )
                currentSequence.addFrame( self.mAnimationImageFrames[index], duration )
        animationListFile.close()

    def newAnimationInstance( self, sequence ):
        return AnimationInstance( self.mAnimationSequences[sequence] )


class AnimationSystem:
    def __init__( self ):
        self.mAnimationFamilies = dict()
        
    def loadAnimations( self, animationDirectory ):
        for( dirpath, dirnames, filenames ) in walk( animationDirectory ):
            for dir in dirnames:
                animationFamily = AnimationFamily( dir )
                animationFamily.load( animationDirectory + "/" + dir )
                self.mAnimationFamilies[dir] = animationFamily
        
    def getFamily( self, animationFamily ):
        return self.mAnimationFamilies[animationFamily]
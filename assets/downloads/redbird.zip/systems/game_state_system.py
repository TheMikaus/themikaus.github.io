# This python file should deal with the basic game state stack.
# Should not split this over multiple files.  Keep everything compact!

#################################################################################################
# USAGE NOTES
#################################################################################################
# Basic workflow:
# - Create GameStateManagerSystem
#   gsms = GameStateManagerSystem()
# - Append the initial state
#   gsms.appendState(StartingGameStateThatICreatedBySubclassingGameState())
# - in your mainloop
#   gsms.update( deltaTime )
# So for the most part the states update underlying mechanisms and apply game logic.  States
# themselves may contain localized data required for it to do what it needs to do.
#
# Basic game loop logic should probably follow the next portion.
# "Main Loop"
#  gsms.append(IntroScreenState())
#  while gameIsRunning:
#    update time
#    determine number of time slices this interval
#    foreach time slice
#      update input
#      gameIsRunning = gsms.update( timeSliceTime )
#      if( gameIsRunning ):
#        render
#      else:
#        break
#
# Or something like that
#################################################################################################

import sys


# State transition returned with the update call
class StateTransitions:
    POP = "POP"
    PUSH = "PUSH"
    NOOP = "NOOP"
    JUMP = "JUMP"
    EXIT = "EXIT"


# Base class to be used for any states coming into the system
class GameState:
    def __init__( self ):
        self.mStateName = "ABSTRACT"

    def initialize( self ):
        # Code that should be called when the state is first being entered.
        # May need to take some game world object, but I don't know yet.
        raise Exception("Initialize not overridden.")

    def interrupted( self ):
        # Code that should be called when the state switches from it's state to another
        # but is not exited (so pausing a game for example)
        raise Exception("Interrupted not overridden.")

    def resumed( self ):
        # Code that should be called when the state switches back from being interrupted
        # so any special logic that was done on interrupt can be undone here and things
        # needed for the next update call will be set up here.
        raise Exception("Resumed not overridden.")

    def exit( self ):
        # Code that is called if the state is being removed from the state stack.
        raise Exception("Exit not overridden.")

    def update( self, deltaTime ):
        # Code that is called every update frame if this game state is the current game state.
        return self, StateTransitions.NOOP


# Class used in running the state's basic logic
# Repeating horrible naming convention of the Input System :)
class GameStateManagerSystem:
    def __init__( self ):
        self.mStateList = []
        self.mStarted = False

    def findState( self, stateName ):
        return [state for state in self.mStateList if( state.mStateName == stateName )]

    def appendState( self, state ):
        if( self.mStarted == False ):
            state.initialize()
            self.mStarted = True
        self.mStateList.append(state)

    def update( self, deltaTime ):
        currentState = self.mStateList[-1]
        nextState, action = currentState.update( deltaTime )
        if( action == StateTransitions.PUSH ):
            currentState.interrupted()
            nextState.initialize()
            self.mStateList.append(nextState)
        elif( action == StateTransitions.POP ):
            currentState.exit()
            self.mStateList.pop()
            if( nextState != None):
                self.mStateList.append(nextState)
                nextState.initialize()
            elif( len(self.mStateList) > 0 ):
                self.mStateList[-1].resumed()
        elif( action == StateTransitions.JUMP ):
            # TODO: Jump to the appropriate state
            pass
        elif( action == StateTransitions.EXIT ):
            self.mStateList = []
        return len(self.mStateList) > 0

# This python file should deal with the graphic management system.
# Should not split this over multiple files. Keep everything compact!

import sys
import pygame, sys, os
from pygame.locals import *

class GraphicManagerSystem:
    def __init__( self ):
        self.mScreenWidth = 320
        self.mScreenHeight = 240
        self.mRenderingSurfaces = []
        #self.mScreen = pygame.display.set_mode( (self.mScreenWidth, self.mScreenHeight), pygame.FULLSCREEN, 32 )
        self.mScreen = pygame.display.set_mode( (self.mScreenWidth, self.mScreenHeight) )

    def addLayer( self, width, height ):
        #newSurface = pygame.Surface( (width, height), pygame.SRCALPHA, 32 )
        newSurface = pygame.Surface( (width, height) )
        #newSurface = newSurface.convert_alpha()
        self.mRenderingSurfaces.append( newSurface )
        return newSurface, len( self.mRenderingSurfaces ) - 1

    def removeLayer( self, index ):
        self.mRenderingSurfaces.pop( index )

    def update( self ):
        self.mScreen.fill( ( 255, 255, 255 ) )
        for surface in self.mRenderingSurfaces:
            self.mScreen.blit( surface, (0, 0) )
        pygame.display.flip()

    def __del__( self ):
        print "DELETE IS CALLED"    

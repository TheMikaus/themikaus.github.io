# This python file should deal with the entity management system.
# Should not split this over multiple files.  Keep everything compact!

import copy
import sys
import math
import uuid

import pygame

from systems.animation_system import AnimationSystem


# Entity base class.  Used to "define" the abstract entity object
class Entity:
    def __init__( self, manager ):
        self.mPos = [0, 0]
        self.mEnabled = True
        self.mPhysical = True
        self.mManager = manager
        self.mRect = None
        self.mJumpVelocity = 0
        self.mProposedSteps = [0, 0]
        self.mParent = None
        self.mPaused = False
        self.mPassable = True
        self.mDirections = [0, 0]
        self.mApplyGravity = True
        self.mAnimationSystem = AnimationSystem.instance
        self.mAnimationFamily = None
        self.mCurrentAnimation = None
        
    def setDirections( self, x, y ):
        self.mDirections = [float(x), float(y)]
    
    def setPassability( self, flag ):
        self.mPassable = flag
    
    def pause( self ):
        self.mPaused = True
        
    def unpause( self ):
        self.mPaused = False

    def setParent( self, parent ):
        self.mParent = parent

    def getParent( self ):
        return self.mParent

    def applyGravity( self, movementDueToGravity, deltaTime ):
        if( self.mPaused == False and self.mApplyGravity):
            self.mJumpVelocity += movementDueToGravity
            self.mProposedSteps[1] = self.mJumpVelocity * deltaTime
            if( self.mJumpVelocity > self.mRect.height * 12 ):
                self.mJumpVelocity = self.mRect.height * 12 

    def storePosData( self ):
        self.mOldPos = copy.copy(self.mPos)

    def restorePosData( self ):
        self.mPos = self.mOldPos
        if( self.mRect != None ):
            self.mRect.bottomleft = self.mPos

    def applySteps( self ):
        if( self.mPaused == False ):
            self.mPos[0] += self.mProposedSteps[0]
            self.mPos[1] += self.mProposedSteps[1]
            self.mProposedSteps[0] = 0
            self.mProposedSteps[1] = 0
            self.mRect.bottomleft = copy.copy( self.mPos )

    def collision( self, object, isGround ):
        raise Exception( "collision not overriden" )
        
    def loadImages( self ):
        raise Exception( "loadImages not overriden" )

    def update( self, deltaTime ):
        raise Exception( "update not overriden" )
        
    def updateAnimation( self, deltaTime ):
        if( self.mCurrentAnimation != None ):
            self.mCurrentAnimation.update( deltaTime )
            if( self.mCurrentAnimation.animationOver() ):
                self.mCallback()
            if( self.mFlipped ):
                self.mImage = self.mCurrentAnimation.currentFrameFlipped().mImage
            else:
                self.mImage = self.mCurrentAnimation.currentFrame().mImage
            self.mSourceRect = self.mImage.get_rect()
            self.mSprite.image = self.mImage
            self.mSprite.source_rect = self.mSourceRect

    def message( self, entitySendingMessage, message, data ):
        raise Exception( "message not overridden" )   
        
    def loop( self ):
        self.mCurrentAnimation.mCurrentFrame = 0
    
    def getCurrentAnimationName( self ):
        return self.mCurrentAnimation.mSequence.mAnimationName
        
    def setCurrentAnimation( self, seq, func, flip, frame ):
        self.mCallback = func
        self.mFlipped = flip
        if( (self.mCurrentAnimation == None) or (self.mCurrentAnimation.mSequence.mAnimationName != seq) ):
            self.mCurrentAnimation = self.mAnimationFamily.newAnimationInstance( seq )
            self.mCurrentAnimation.mCurrentFrame = frame


# Entity With Health
class EntityWithHealth(Entity):
    def __init__( self, manager ):
        Entity.__init__( self, manager )
        self.mInvincibleTime = 0
        self.mTimeTillDamageable = 0

    def setInvincibleTime( self, delay ):
        self.mInvincibleTime = delay

    def setHealth( self, health ):
        self.mHealth = health

    def setMaxHealth( self, max ):
        self.mMaxHealth = max

    def isDead( self ):
        return self.mHealth <= 0

    def getHealth( self ):
        return self.mHealth

    def applyHealthAdjustment( self, health ):
        self.mHealth = self.mHealth + health
        if( self.mHealth > self.mMaxHealth ):
            self.mHealth = self.mMaxHealth

    def died( self ):
        raise Exception( "Entity needs to implement the died function." )

    def message( self, entitySendingMessage, message, data ):
        if( message == "Damage" and self.mTimeTillDamageable <= 0 ):
            self.mTimeTillDamageable = self.mInvincibleTime
            self.applyHealthAdjustment( data )
            if( self.isDead() ):
                self.died()
                if( self.mParent != None ):
                    self.mParent.message( self, "Remove", None )

    def update( self, deltaTime ):
        if( self.mPaused == False ):
            self.mTimeTillDamageable = self.mTimeTillDamageable - deltaTime


# Class that is to act as a function pointer essentially for creating the object
class EntityCreator:
    def createEntity( self, manager, pos ):
        raise Exception( "createEntity not overridden." )


# Handle all of the entities!
class EntityManagerSystem:
    def __init__( self ):
        self.initEntityManagerSystem()

    def initEntityManagerSystem( self ):
        self.mEntityCreators = dict()
        self.mListOfEntities = []
        self.mEntitiesToDelete = []
        self.mGroups = dict()
        self.mPaused = False

    def pauseEntities( self ):
        for entity in self.mListOfEntities:
            entity.pause()
            
    def unpauseEntities( self ):
        for entity in self.mListOfEntities:
            entity.unpause()

    def pauseSystem( self ):
        self.mPaused = True

    def resumeSystem( self ):
        self.mPaused = False

    def setGravity( self, pixelsByGravityPerSecond ):
        self.mPixelsByGravityPerSecond = pixelsByGravityPerSecond

    def addEntityToGroup( self, entity, groupId ):
        if( not ( groupId in self.mGroups ) ):
            self.mGroups[groupId] = []
        self.mGroups[groupId].append(entity)

    def removeEntities( self ):
        self.initEntityManagerSystem()

    def removeEntityFromGroup( self, entityToRemove, groupId ):
        if( groupId in self.mGroups ):
            for index, entity in enumerate(self.mGroups[groupId]):
                if( entity.mEntityId == entityToRemove.mEntityId ):
                    self.mGroups[groupId].pop(index)
                    break;

    def removeGroup( self, groupId ):
        del self.mGroups[groupId]

    def registerEntityCreator( self, EntityCreatorName, EntityCreator ):
        self.mEntityCreators[EntityCreatorName] = EntityCreator

    def createEntity( self, groupId, entityType, pos, entitySpecialName ):
        newEntity = self.mEntityCreators[entityType].createEntity( self, pos )
        newEntity.mEntityId = uuid.uuid4()
        newEntity.mEntitySpecialName = entitySpecialName
        self.addEntityToGroup( newEntity, groupId )
        self.mListOfEntities.append( newEntity )
        return newEntity

    def getEntity( self, entitySpecialName ):
        for entity in self.mListOfEntities:
            if( entity.mEntitySpecialName == entitySpecialName ):
                return entity

    def messageEntity( self, entitySpecialName, entitySendingMessage, message, data ):
        entity = self.getEntity( entitySpecialName )
        entity.message( entitySendingMessage, message, data )

    def deleteEntity( self, entity ):
        self.mEntitiesToDelete.append( entity )

    def setCollisionLayer( self, collisionLayer ):
        self.mCollisionLayer = collisionLayer

    def update( self, deltaTime ):
        if( self.mPaused ):
            return

        entitiesToUpdate = [entity for entity in self.mListOfEntities if( entity.mEnabled and entity.mPaused == False )]
        entitiesToCollide = [entity for entity in self.mListOfEntities if( entity.mPhysical and entity.mPaused == False and entity.mPassable == True)]
        
        # Just time step everyone after storing the last position
        for entity in entitiesToUpdate:
            entity.storePosData()
            entity.updateAnimation( deltaTime )
            entity.update( deltaTime )
            if( entity.mPhysical ):
                collisionType, isGround = self.checkAgainstEnvironment( entity )
                if( collisionType[0] != None or collisionType[1] != None ):
                    entity.collision( collisionType, isGround )
                entity.applySteps()
                entity.storePosData()
                entity.applyGravity( self.mPixelsByGravityPerSecond, deltaTime )
                collisionType, isGround = self.checkAgainstEnvironment( entity )
                if( collisionType[0] != None or collisionType[1] != None ):
                    entity.collision( collisionType, isGround )
                entity.applySteps()

        entitiesLeft = list(entitiesToCollide)
        falseIsGround = [ False, False ]
        for entityA in entitiesToCollide:
            entitiesLeft.pop(0)
            for entityB in entitiesLeft:
                if( entityA.mRect.colliderect(entityB.mRect) ):
                    entityA.collision( entityB, falseIsGround )
                    entityB.collision( entityA, falseIsGround )

        for entityA in self.mEntitiesToDelete:
            if( entityA in self.mListOfEntities ):
                self.mListOfEntities.remove(entityA)

        self.mEntitiesToDelete = []


    def checkAgainstEnvironment( self, entity ):
        # NOTE: Stole this logic from tiled_tmx_loader
        #     : modified it just a little to fit this class and what I wanted the function to return

        # find the tile location of the hero
        tileX = int((entity.mPos[0]) // self.mCollisionLayer.tilewidth)
        tileY = int((entity.mPos[1]) // self.mCollisionLayer.tileheight)

        tilesFound = []
        tilesFoundXY = []
        tileWidth = entity.mRect.width // self.mCollisionLayer.tilewidth
        tileHeight = entity.mRect.height // self.mCollisionLayer.tileheight
        bottomY = -1 * (tileHeight + 1)
        topY = tileHeight + 1
        leftX = -1 * (tileWidth + 1)
        rightX = tileWidth + 1
        for dirY in range( bottomY , topY ):
            for dirX in range( leftX , rightX ):
                if( tileY + dirY < 0 or tileX + dirX < 0 ):
                    continue
                if( tileY + dirY >= self.mCollisionLayer.num_tiles_y or tileX + dirX >= self.mCollisionLayer.num_tiles_x ):
                    continue
                currentTile = self.mCollisionLayer.content2D[tileY + dirY][tileX + dirX]
                if( currentTile != None ):
                    tilesFound.append( currentTile )
                    tilesFoundXY.append( ( tileX + dirX, tileY + dirY ) )

        tileIsGround = [ False, False ]
        
        stepX = self.specialRound( entity.mProposedSteps[0] )
        stepY = self.specialRound( entity.mProposedSteps[1] )
        collisionY = -1

        impassableEntitiesRects = [entityA.mRect for entityA in self.mListOfEntities if( entityA.mPassable == False )]        
        
        tempRect = pygame.Rect( 0, 0, entity.mRect.width, entity.mRect.height )
        tempRect.bottomleft = copy.copy( entity.mPos )
        collisionX = tempRect.move( stepX, 0 ).collidelist( tilesFound )
        collisionXEnt = tempRect.move( stepX, 0 ).collidelist( impassableEntitiesRects )
        tileType = [ None, None ]
        if( collisionX > -1 ):
            entity.mProposedSteps[0] = 0
            tileType[0] = tilesFound[collisionX]
            tileIsGround[0] = True
        elif( collisionXEnt > -1 ):
            entity.mProposedSteps[0] = 0
            tileType[0] = -1 # Sentinel value for entities?  I'm not certain what I want to do here

        collisionY = tempRect.move( 0, stepY ).collidelist( tilesFound )
        collisionYEnt = tempRect.move( 0, stepY ).collidelist( impassableEntitiesRects )
        if( collisionY > -1 ):
            tileIsGround[1] = True
            entity.mProposedSteps[1] = 0
            tileType[1] = tilesFound[collisionY]
        elif( collisionYEnt > -1 ):
            entity.mProposedSteps[1] = 0
            tileType[1] = -1

        # TODO: Do I need to return more information?
        # TODO: FIX THE RETURN 
        return tileType, tileIsGround

    def specialRound( self, value ):
        if value < 0:
            return math.floor(value)
        return math.ceil(value)

bool DSInit(HWND hWnd, DWORD channels, DWORD Freq, DWORD BitRate)
{
	HRESULT hr;
	if(FAILED(hr=dxSound->Initialize(hWnd, DSSCL_PRIORITY,channels,Freq,BitRate))) return false;
	SetTimer(hWnd, 0, 250, NULL);
	return true;
}

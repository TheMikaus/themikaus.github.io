#include <windows.h>
#include <mmsystem.h>
#include "resource.h"

#pragma comment(lib,"winmm.lib")

DWORD LastTimeThrough;

RECT WindowRect;
BOOL appWindowed= TRUE;
BOOL appActive = FALSE;
BOOL blitting = FALSE;

HRESULT WinInit(HINSTANCE hInst, int nCmdShow, HWND* phWnd);
HRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
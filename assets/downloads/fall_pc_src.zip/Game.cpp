#include "game.h"
extern CMusicManager * dxMusic;
extern void fadeOut(int,DWORD);
extern void ClearSurface(LPDIRECTDRAWSURFACE7 &,DWORD);
extern BOOL appActive;
extern BOOL blitting;

extern CDisplay * dxDisplay;
extern DXInput * dxInput;
extern GlobalTime * gt;
extern CSoundManager *dxSound;
extern LPDIRECTDRAWSURFACE7 CreateSurface(DWORD,DWORD);
extern LPDIRECTDRAWSURFACE7 createBitmapSurface(char *);
extern void setColorKey(LPDIRECTDRAWSURFACE7 &, DWORD);


Game* Game::gameInstance=NULL;

void Game::pauseMidi()
{
	if(!music) return;
	if(!ingame) return;
	REFERENCE_TIME temp;
	music->Stop();
	timeStopd=gt->getGlobalTime();
	temp= timeGetTime();
	dxMusic->GetPerformance()->GetTime(&temp,&var);
}

void Game::playMidi()
{
	if(!music) return;
	if(!ingame) return;
	music->GetSegment()->SetStartPoint(var);
	music->Play();
}
void Game::Kill()
{
	quiting=true;	
//    if(boom) { boom->Stop(); delete boom; boom=NULL;}
//	if(boom2) {boom2->Stop(); delete boom2; boom2=NULL;}
//	if(movemenu) {movemenu->Stop(); delete movemenu; movemenu=NULL;}
//	if(strtmenu) {strtmenu->Stop(); delete strtmenu; strtmenu=NULL;}
//	if(land) {land->Stop(); delete land; land=NULL;}
    
	if(F) delete F;
	if(A) delete A;
	if(La) delete La;
	if(Lb) delete Lb;
	if(Ball) delete Ball;
	if(Start) delete Start;
	if(Quit) delete Quit;
	if(backA) delete backA;
	if(backB) delete backB;
	if(tiles) delete tiles;
	if(game) delete game;
	if(Over) delete Over;
	if(HighBmp) delete HighBmp;
	if(ScoreBmp) delete ScoreBmp;
	if(SideA) delete SideA;
	if(SideB) delete SideB;
	if(SideAb) delete SideAb;
	if(SideBb) delete SideBb;
	if(BackGround) delete BackGround;
	if(BackGroundB) delete BackGroundB;
	if(font) delete font;
	if(HighScore) delete HighScore;
	if(PlayerScore) delete PlayerScore;
	if(music) {music->Stop(); music->Unload(); delete music;}
	if(NewBmp) delete NewBmp;
	if(boing) {boing->Stop(); delete boing;}
	if(topLine)
		for(;topLine!=NULL;)
		{
			LevelNode * temp;
			temp = topLine;
			topLine=topLine->getNext();
			delete temp;
		}
	
	F=A=La=Lb=NULL;
	Ball=Start=Quit=NULL;
	backA=backB=NULL;
	tileGrounda=tileGroundb=NULL;
	tiles = NULL;
	game=Over=NULL;
	HighBmp=ScoreBmp=NULL;
	SideA=SideB=SideAb=SideBb=NULL;
	topLine=bottomLine=NULL;
	BackGround=BackGroundB=NULL;
	PlayerScore=HighScore=NULL;

	font=NULL;
	NewBmp=NULL;
	boing=NULL;


}
void Game::loadMidi()
{
	if(music==NULL)	dxMusic->CreateSegmentFromFile(&music,"Sounds/midi.mid",TRUE,TRUE);
	midiLoaded=true;
}

Game* Game::getInstance()
{
	if(gameInstance==NULL) gameInstance=new Game();
	return gameInstance;
}

Game::Game(void)
{
	ingame=false;
	quiting=false;
	music=NULL;
	midiLoaded=false;
	boom=boom2=movemenu=strtmenu=land=NULL;
	F=A=La=Lb=NULL;
	Ball=Start=Quit=NULL;
	backA=backB=NULL;
	tileGrounda=tileGroundb=NULL;
	tiles = NULL;
	game=Over=NULL;
	HighBmp=ScoreBmp=NULL;
	SideA=SideB=SideAb=SideBb=NULL;
	topLine=bottomLine=NULL;
	BackGround=BackGroundB=NULL;
	PlayerScore=HighScore=NULL;

	font=NULL;
	NewBmp=NULL;
	boing=NULL;
}

Game::~Game(void)
{
	quiting=true;
	
	if(boom) { boom->Stop(); delete boom;}
	if(boom2) {boom2->Stop(); delete boom2;}
	if(movemenu) {movemenu->Stop(); delete movemenu;}
	if(strtmenu) {strtmenu->Stop(); delete strtmenu;}
	if(land) {land->Stop(); delete land;}
    
	if(F) delete F;
	if(A) delete A;
	if(La) delete La;
	if(Lb) delete Lb;
	if(Ball) delete Ball;
	if(Start) delete Start;
	if(Quit) delete Quit;
	if(backA) delete backA;
	if(backB) delete backB;
	if(tiles) delete tiles;
	if(game) delete game;
	if(Over) delete Over;
	if(HighBmp) delete HighBmp;
	if(ScoreBmp) delete ScoreBmp;
	if(SideA) delete SideA;
	if(SideB) delete SideB;
	if(SideAb) delete SideAb;
	if(SideBb) delete SideBb;
	if(BackGround) delete BackGround;
	if(BackGroundB) delete BackGroundB;
	if(font) delete font;
	if(HighScore) delete HighScore;
	if(PlayerScore) delete PlayerScore;
	if(music) {music->Stop(); music->Unload(); delete music;}
	if(NewBmp) delete NewBmp;
	if(boing) {boing->Stop(); delete boing;}
	
	if(topLine)
		for(;topLine!=NULL;)
		{
			LevelNode * temp;
			temp = topLine;
			topLine=topLine->getNext();
			delete temp;
		}
		delete gameInstance;
		gameInstance=NULL;
}

void Game::initOtherVariables()
{
	ballFallRate=32;
	ballMoveRate=16;
	screenMoveRate=8;
	updateGameTime=50;
}
void Game::run()
{
	int selection=-1;
	font = new Font("Graphics/Font/ScoreFont",dxDisplay->GetDirectDraw());
	
	while(selection!=1)
	{
		selection = title();
	    if(selection==0)
	    {
			LevelNode * temp=NULL;
			while(topLine!=NULL){
			 temp = topLine;
			 topLine=topLine->getNext();
			 delete temp;
			}
			topLine=NULL;
			bottomLine=NULL;
			timeStop=gt->getGlobalTime();
		 if(startGame()) gameOver();
	    }
	//otherwise they selected exit and it should exit the program
		if(quiting) return;
	}
	fadeOut(100,1);
	dxDisplay->Clear(0);
	dxDisplay->Present();
}

string Game::convertNumString(LONGLONG value)
{

	unsigned int values=(unsigned int)value;
	string temp;
	if(values==0) 
		temp="0";
	while(values>0)
	{
		temp+=('0'+	(values%10));
		values/=10;
	}

	string temps="";
	for(unsigned int i=0;i<temp.size();i++)
	{
		temps+=temp[temp.size()-1-i];
	}

    

	return temps;
}

bool Game::startGame()
{
	//Return true if player dies and false if player presses the escape key
	
	score =0;
	initializeGame();
	
	//Main game loop
	

 	if(music)music->Play(DMUS_SEGF_BEAT,NULL);
    ingame=true;
	
	typedef LONGLONG LL;
	LL updatetime=gt->getGlobalTime();
	LL ctime = gt->getGlobalTime();
	int highscoreX=74;
	highscoreY=0;
	scoreXB=74;
	scoreXA=80+HighBmp->getW();
	scoreY=480-ScoreBmp->getH();
	int key;
	double newx;
	double newy;
	int atY=0;
	int atDispY=48; //The secondary buffer
	double currentyline=48;
	int moved=0;
	blit=-1; //using the Back A sprite 0 both 1 is b 2 is both
	LL ballupdate=gt->getGlobalTime();
	bool passedLine=false;
	int linecount=0;
	bool dline=false;
	int countme=50;


	HighScore->setXY(scoreXA+ScoreBmp->getW()+32,0);
	HighScore->setFromXY(0,0);
	HighScore->setWH(480,64);
	HighScore->setNewWH(480,35);

	PlayerScore->setXY(scoreXB+ScoreBmp->getW()+32,scoreY);
	PlayerScore->setFromXY(0,0);
	PlayerScore->setWH(480,64);
	PlayerScore->setNewWH(480,35);

	string t="0";
	
    LL timediff=0;
	double scale=1;

		newx=Ball->getX();
		   newy=Ball->getY();


	
	while(true)
	{
		while(!appActive)Sleep(100);
		dxInput->updateKeyboard();

		ctime = gt->getGlobalTime();

		 

    	   currentyline-=(int)(screenMoveRate*scale);
		   blitx+=(int)(screenMoveRate*2*scale);
		   blitx%=480;
		   blity+=(int)((screenMoveRate/2)*scale);
		   blity%=480;
		  
		   //updatetime=ctime+15;

		   key=KeyDown();
		   
		   if(key==-1) newx-=(ballMoveRate*scale); //left
		   if(key==1) newx+=(ballMoveRate*scale); //right
		   if(falling) newy+=(ballFallRate*scale); //fall
		   
		   //update screen
		   atY+=(screenMoveRate*scale);
		   moved+=(screenMoveRate*scale);
		   if(atY>=960)
		   {
			atY%=960;
			if(blit==0) { blit=1; ClearSurface(backA->getCurrentSprite(),0);}
			if(blit==2) { blit=-1; ClearSurface(backB->getCurrentSprite(),0);}
		   }
		   if(atY+480>960)
		   {
			   if(blit==1) blit=2;
			   if(blit==-1) blit=0;
		   }

		   if(blit==-1)
		   {
			   if(backA!=NULL){
			   backA->setFromXY(0,atY);
			   backA->setXY(0,0);
			   backA->setNewWH(640,480);
			   backA->setWH(640,480);}
		   }
		   if(blit==1)
		   {
			   backB->setFromXY(0,atY);
			   backB->setXY(0,0);
			   backB->setNewWH(640,480);
			   backB->setWH(640,480);
		   }
		   if(blit==0)
		   {
			   backA->setFromXY(0,atY);
			   backA->setNewWH(640,960-atY);
			   backA->setWH(640,960-atY);
			   backA->setXY(0,0);
			   backB->setXY(0,960-atY);
			   backB->setFromXY(0,0);
			   backB->setNewWH(640,480-(960-atY));
			   backB->setWH(640,480-(960-atY));
		   }
		   if(blit==2)
		   {
			   backB->setFromXY(0,atY);
			   backB->setNewWH(640,960-atY);
			   backB->setWH(640,960-atY);
			   backB->setXY(0,0);
			   backA->setXY(0,960-atY);
			   backA->setFromXY(0,0);
			   backA->setNewWH(640,480-(960-atY));
			   backA->setWH(640,480-(960-atY));
		   }

		   //collision
		   //bound check
		   
		   int tile=(newx+16-64)/32;
			//Do checks before this line

		   if(newy>448)newy=448;
		   if(newx<64) newx=64;
		   if(newx+32>(640-64)) newx=608-64;

		   

		   //update the sprite animation
		   if(ballupdate<ctime)
		   {
			ballupdate=ctime+50;
		    if(Ball->getFrameNumber()==3) Ball->changeFrame(0);
			else Ball->changeFrame(Ball->getFrameNumber()+1);
		   }
		  
			
		   //if player passes his current line remove it from list
		   if(newy>currentyline-32 && topLine->isBlock(tile))
		   {
			   if(falling) 
			   {
				  // land->Stop();//play some sound
				   land->Play(0,0);
			   }
			   falling=false;
			   newy=currentyline-32;
		   }

		   if(newy>currentyline-24 && !topLine->isBlock(tile))
		   {
			   falling=true;
			   
			   LevelNode * temp=topLine;

			   score++;
			   linecount++;

			   t = convertNumString(score);
			   ClearSurface(PlayerScore->getCurrentSprite(),0);
			   font->writeToSurface(PlayerScore->getCurrentSprite(),t.c_str(),0,0);
			   topLine=topLine->getNext();
			   delete temp;
			   
			   currentyline+=48;
		   }
		   Ball->setXY(newx,newy);
			
		  //ctime = engine->getGlobalTime()->getGlobalTime();


		  BackGround->setFromXY(0,blity);
		  BackGround->setWH(512,480-blity);
		  BackGround->setNewWH(512,480-blity);

		  BackGroundB->setFromXY(0,0);
		  BackGroundB->setWH(512,blity);
		  BackGroundB->setNewWH(512,blity);
		  BackGroundB->setXY(64,480-blity);

		  blitting=TRUE;
		  while(!appActive) Sleep(1000);
		  ctime=gt->getGlobalTime();
		  LPDIRECTDRAWSURFACE7 backBuffer = dxDisplay->GetBackBuffer();
	  	
		  BackGround->blt(backBuffer,false);
		  BackGroundB->blt(backBuffer,false);

		  

		   switch(blit)
		   {
		   case -1:
			   backA->blt(backBuffer,true);
			   break;
		   case 1:
			   backB->blt(backBuffer,true);
			   break;
		   case 0:
		   case 2:
			   backA->blt(backBuffer,true);
			   backB->blt(backBuffer,true);
		   }

		    Ball->blt(backBuffer,true);

			
		  SideA->setFromXY(0,blitx);
		  SideA->setWH(64,480-blitx);
		  SideA->setNewWH(64,480-blitx);

		  SideAb->setFromXY(0,0);
		  SideAb->setWH(64,blitx);
		  SideAb->setNewWH(64,blitx);
		  SideAb->setXY(0,480-blitx);

		  SideB->setFromXY(0,blitx);
		  SideB->setWH(64,480-blitx);
		  SideB->setNewWH(64,480-blitx);

		  SideBb->setFromXY(0,0);
		  SideBb->setWH(64,blitx);
		  SideBb->setNewWH(64,blitx);
		  SideBb->setXY(640-64,480-blitx);

			SideA->blt(backBuffer,true);
			SideAb->blt(backBuffer,true);
			SideB->blt(backBuffer,true);
			SideBb->blt(backBuffer,true);

			HighBmp->setXY(highscoreX,highscoreY);
			HighBmp->blt(backBuffer,true);
			
			HighScore->blt(backBuffer,true);

			ScoreBmp->setXY(scoreXA,highscoreY);
			ScoreBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXB,scoreY);
			ScoreBmp->blt(backBuffer,true);

			PlayerScore->blt(backBuffer,true);
			timediff=gt->getGlobalTime()-ctime;
			scale=(double)timediff/(double)50.0;
			

			dxDisplay->Present();
			blitting=FALSE;
			 if(linecount!=0 && (linecount%countme)==0) 
			{
				countme+=50;
			   strtmenu->Play(0,0);
			
			   tiles->changeFrame((tiles->getFrameNumber()+1)%tiles->getFrameCount());

			   screenMoveRate +=3;
			   ballFallRate+=3;
			   ballMoveRate+=2;
			   linecount=0;
			}
	       

 //reblit tiles
		   if(moved>=48)
		   {
			   moved%=48;
			   bottomLine->setNext(RandomLine(bottomLine->getLength()));
			   bottomLine=bottomLine->getNext();
			  			  
			   if(blit==-1 || blit==0)
			   {
				   //blit the tiles to backb
				   for(int i=0;i<bottomLine->getLength();i++)
				   {
					   if(bottomLine->isBlock(i))
					   {
					    tiles->setXY(64+i*32,atDispY);
					    tiles->blt(backB->getCurrentSprite(),true);
					   }
				   }
			   }
			   if(blit==1 || blit==2)
			   {
				   //blit the tiles to back a
				   for(int i=0;i<bottomLine->getLength();i++)
				   {
					   if(bottomLine->isBlock(i))
					   {
					    tiles->setXY(64+i*32,atDispY);
					    tiles->blt(backA->getCurrentSprite(),true);
					   }
				   }
			   }
			   atDispY+=48;
			   if(atDispY>=960) atDispY%=960;
		   }

	   if(dxInput->isKeyDown(DIK_ESCAPE)>-1) 
	   { 
		if(music!=NULL)
		{
			music->Stop();
			ingame=false;
		}
		return false;
	   }
	   if(currentyline<0) break;
	  

	}

	if(music!=NULL)
	{
		music->Stop();
	}

	ingame=false;
	boom2->Play(0,0);
	
	return true;
}

int Game::KeyDown()
{
 	LONGLONG left = dxInput->isKeyDown(DIK_LEFT);
	LONGLONG right = dxInput->isKeyDown(DIK_RIGHT);
	if(right==-1 && left>-1) return -1;
	if(left==-1 && right>-1) return 1;
    if(left>-1 && left<right) return -1;
	if(right>-1 && right<left) return 1;
	
	return 0;
}


void Game::initializeGame()
{
	initFirstSetOfLines();
	initPlayer();
	initTileGround();
	initOtherVariables();

	if(ScoreBmp==NULL) ScoreBmp= new CSprite("Graphics/Score.bmp",dxDisplay->GetDirectDraw());
	if(HighBmp==NULL) HighBmp = new CSprite("Graphics/High.bmp",dxDisplay->GetDirectDraw());
	if(land==NULL) dxSound->Create(&land,"sounds/land.wav",0,GUID_NULL,1);

    string d;
	d=convertNumString(highScore);
    LPDIRECTDRAWSURFACE7 a;
	LPDIRECTDRAWSURFACE7 b;
	if(PlayerScore==NULL)
	{
		a=CreateSurface(480,64);
		setColorKey(a,0);

		b= CreateSurface(480,64);
		setColorKey(b,0);

		HighScore= new CSprite();
		PlayerScore = new CSprite();
		HighScore->setSprite(a);
		PlayerScore->setSprite(b);
	}
	ClearSurface(HighScore->getCurrentSprite(),0);
	font->writeToSurface(HighScore->getCurrentSprite(),d.c_str(),0,0);

}

void Game::initPlayer()
{
	score = 0;
	getScore();
	for(int i=0;i<Ball->getFrameCount();i++)
	{
		Ball->changeFrame(i);
		Ball->setXY(262,0-Ball->getH());
	}

	falling=true;
}

void Game::initTileGround()
{
	if(tileGrounda==NULL) tileGrounda = CreateSurface(640,960); //Tile buffer twice the size of the screen
	if(tileGroundb==NULL) tileGroundb= CreateSurface(640,960);//Tile ground b
	if(tiles==NULL) tiles = new CSprite("Graphics/lines/Tile",dxDisplay->GetDirectDraw(),8);
	LPDIRECTDRAWSURFACE7 ground;
	if(BackGround==NULL) ground= createBitmapSurface("Graphics/BackGround.bmp");
	blity=0;
	if(BackGround==NULL)
	{
		BackGround = new CSprite();
		setColorKey(ground,0);
		BackGround->setSprite(ground);
		BackGround->setXY(64,0);
		BackGroundB = new CSprite();
		BackGroundB->setSprite(ground);
	}

	LPDIRECTDRAWSURFACE7 side;
	if(SideA==NULL) side = createBitmapSurface("Graphics/side.bmp");
	blitx=0;
	if(SideA==NULL) 
	{
		SideA = new CSprite();
		SideA->setSprite(side);
		SideA->setXY(0,0);
		SideAb = new CSprite();
        SideAb->setSprite(side);
		SideAb->setXY(0,0);
	}
	if(SideB==NULL)
	{
		SideB = new CSprite();
		SideB->setSprite(side);
		SideB->setXY(640-64,0);
		SideB->FlipX();
		SideBb = new CSprite();
		SideBb->setSprite(side);
		SideBb->setXY(640-64,0);
		SideBb->FlipX();
	}

	if(backA==NULL)
	{
		backA = new CSprite();
		backA->setSprite(tileGrounda);
		setColorKey(backA->getCurrentSprite(),0);	
	}
	if(backB==NULL)
	{
		backB = new CSprite();
		backB->setSprite(tileGroundb);
		setColorKey(backB->getCurrentSprite(),0);
	
	}
    	backA->setFromXY(0,0);
		backA->setWH(640,480);
		backA->setNewWH(640,480);

		backB->setFromXY(0,0);
		backB->setWH(0,0);
		backB->setNewWH(0,0);

		tiles->changeFrame(0);
		tiles->setFromXY(0,0);
		tiles->setWH(32,16);
		tiles->setNewWH(32,16);
		ClearSurface(tileGrounda,0);
		ClearSurface(tileGroundb,0);
}

void Game::initFirstSetOfLines()
{
 int length=16;//number of tiles
 topLine = blankLevelLine(length);
 LevelNode * temp = blankLevelLine(length);
 topLine->setNext(temp);
 for(int i=0;i<18;i++)
 {
	 temp->setNext(blankLevelLine(length));
	 temp = temp->getNext();
 }
 bottomLine = temp;
}
LevelNode * Game::blankLevelLine(int length)
{
	LevelNode * t= new LevelNode(length);
	for(int i=0;i<length;i++)
		t->setBlock(i,false);
	return t;
}

LevelNode * Game::RandomLine(int length)
{
	LevelNode * t = blankLevelLine(length);
	RandGen d;

	int countme=length/2; //number of bricks  per level
	countme+=d.RandInt((length/2)-4);
	for(int i=0;i<countme;i++)
	{
		int ts = d.RandInt(length);
		while(t->isBlock(ts)) ts=d.RandInt(length);
		t->setBlock(ts,true);
	}
	return t;
}

void Game::DropOver()
{
	int gamex=0;
	int overx=175;
	int gameyend=50;
	int overyend=175;
	game->setXY(gamex,0-game->getW());
	Over->setXY(overx,480);

	typedef LONGLONG LL;
    LL ctime = gt->getGlobalTime();
	LL update = ctime;
	LL add = 25;
	int rate = 10;
	
	while(game->getY()<gameyend)
	{
		
		ctime = gt->getGlobalTime();
		if(update<ctime)
		{
			update=ctime+add;
			if(game->getY()<gameyend) game->setXY(gamex,game->getY()+rate);
			if(game->getY()>gameyend) game->setXY(gamex,gameyend);
		
			
            while(!appActive) Sleep(100);

			blitting=TRUE;
			dxDisplay->Clear(0);
			LPDIRECTDRAWSURFACE7 backBuffer = dxDisplay->GetBackBuffer();
			BackGround->blt(backBuffer,false);
			BackGroundB->blt(backBuffer,false);
			switch(blit)
			{
				case 0:
				case 2:
					backA->blt(backBuffer,true);
					backB->blt(backBuffer,true);
					break;
				case -1:
					backA->blt(backBuffer,true);
					break;
				case 1:
					backB->blt(backBuffer,true);
			}
			SideA->blt(backBuffer,true);
			SideAb->blt(backBuffer,true);
			SideB->blt(backBuffer,true);
			SideBb->blt(backBuffer,true);
			HighBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXA,highscoreY);
			ScoreBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXB,scoreY);
			ScoreBmp->blt(backBuffer,true);
			HighScore->blt(backBuffer,true);
			PlayerScore->blt(backBuffer,true);
			
			
			game->blt(backBuffer,true);
			
			//Display scores

			
			dxDisplay->Present();
			blitting=FALSE;
		}
	}
	boom2->Play(0,0);
	while(Over->getY()>overyend)
	{
		
		ctime = gt->getGlobalTime();
		if(update<ctime)
		{
			update=ctime+add;
			if(Over->getY()>overyend) Over->setXY(overx,Over->getY()-rate);
			if(Over->getY()<overyend) Over->setXY(overx,overyend);

			
			
			while(!appActive) Sleep(100);
			blitting=TRUE;
			dxDisplay->Clear(0);
			LPDIRECTDRAWSURFACE7 backBuffer= dxDisplay->GetBackBuffer();
			BackGround->blt(backBuffer,false);
			BackGroundB->blt(backBuffer,false);
			switch(blit)
			{
				case 0:
				case 2:
					backA->blt(backBuffer,true);
					backB->blt(backBuffer,true);
					break;
				case -1:
					backA->blt(backBuffer,true);
					break;
				case 1:
					backB->blt(backBuffer,true);
			}
			SideA->blt(backBuffer,true);
			SideAb->blt(backBuffer,true);
			SideB->blt(backBuffer,true);
			SideBb->blt(backBuffer,true);
			HighBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXA,highscoreY);
			ScoreBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXB,scoreY);
			ScoreBmp->blt(backBuffer,true);
			HighScore->blt(backBuffer,true);
			PlayerScore->blt(backBuffer,true);
			
			game->blt(backBuffer,true);
			Over->blt(backBuffer,true);

			
			
			
			dxDisplay->Present();
			blitting=FALSE;
		}
	}
	
	boom->Play(0,0);

}

void Game::displayHighScore()
{
	//Cycle "New High Score"
	if(NewBmp==NULL) NewBmp = new CSprite("Graphics/New.bmp",dxDisplay->GetDirectDraw());
	if(boing==NULL) dxSound->Create(&boing,"Sounds/boing.wav",0,GUID_NULL,1);

    NewBmp->setXY(320,400);
	NewBmp->setNewWH(90,30);


	dxInput->updateKeyboard();
	typedef LONGLONG LL;
	LL ctime = gt->getGlobalTime();
	LL update = ctime;

	bool in=true;
	int count=0;
	
	while(dxInput->isKeyDown(DIK_RETURN)==-1)
	{
		
	    dxInput->updateKeyboard();	

		ctime = gt->getGlobalTime();
		
		
		if(update<ctime)
		{
			update=ctime+15;
			
			if(in)
			{
				count++;
				NewBmp->setNewWH(NewBmp->getCurrentWidth()+(NewBmp->getW()/25),NewBmp->getCurrentHeight()+(NewBmp->getH()/25));	
			}
			else
			{
				count++;
				NewBmp->setNewWH(NewBmp->getCurrentWidth()-(NewBmp->getW()/25),NewBmp->getCurrentHeight()-(NewBmp->getH()/25));	
			}
			if(count==25) {count=0; if(!in){boing->Stop();boing->Play(0,0);}in=!in;}
			NewBmp->setXY(320-(NewBmp->getCurrentWidth()/2),400-(NewBmp->getCurrentHeight()/2));
		}	

		while(!appActive) Sleep(100);
		blitting=true;
			LPDIRECTDRAWSURFACE7 backBuffer = dxDisplay->GetBackBuffer();
			BackGround->blt(backBuffer,false);
			BackGroundB->blt(backBuffer,false);
			switch(blit)
			{
				case 0:
				case 2:
					backA->blt(backBuffer,true);
					backB->blt(backBuffer,true);
					break;
				case -1:
					backA->blt(backBuffer,true);
					break;
				case 1:
					backB->blt(backBuffer,true);
			}
			SideA->blt(backBuffer,true);
			SideAb->blt(backBuffer,true);
			SideB->blt(backBuffer,true);
			SideBb->blt(backBuffer,true);
			HighBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXA,highscoreY);
			ScoreBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXB,scoreY);
			ScoreBmp->blt(backBuffer,true);
			HighScore->blt(backBuffer,true);
			PlayerScore->blt(backBuffer,true);
			
			game->blt(backBuffer,true);
			Over->blt(backBuffer,true);
			NewBmp->blt(backBuffer,true);
			
			dxDisplay->Present();
			blitting=FALSE;
	}

}

void Game::gameOver()
{
	//Displays the game over + sound
	//wa wa wa~~~~?
	//Load Bitmaps
    
	  
	if(game==NULL) game = new CSprite("Graphics/GameOver.bmp",dxDisplay->GetDirectDraw());
	if(Over==NULL) Over = new CSprite("Graphics/GameOverB.bmp",dxDisplay->GetDirectDraw());

	DropOver();

	getScore();
	//check current score against old score
	//save if better
	if(highScore<score)
	{
		//Display the you did better sign + sound
		displayHighScore();
		saveScore(score);
	}
	else
	{
		dxInput->updateKeyboard();
		while(dxInput->isKeyDown(DIK_RETURN)==-1)
		{
			
			dxInput->updateKeyboard();	
			while(!appActive) Sleep(100);
		blitting=true;
			LPDIRECTDRAWSURFACE7 backBuffer = dxDisplay->GetBackBuffer();
			BackGround->blt(backBuffer,false);
			BackGroundB->blt(backBuffer,false);
			switch(blit)
			{
				case 0:
				case 2:
					backA->blt(backBuffer,true);
					backB->blt(backBuffer,true);
					break;
				case -1:
					backA->blt(backBuffer,true);
					break;
				case 1:
					backB->blt(backBuffer,true);
			}
			SideA->blt(backBuffer,true);
			SideAb->blt(backBuffer,true);
			SideB->blt(backBuffer,true);
			SideBb->blt(backBuffer,true);
			HighBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXA,highscoreY);
			ScoreBmp->blt(backBuffer,true);
			ScoreBmp->setXY(scoreXB,scoreY);
			ScoreBmp->blt(backBuffer,true);
			HighScore->blt(backBuffer,true);
			PlayerScore->blt(backBuffer,true);
			
			game->blt(backBuffer,true);
			Over->blt(backBuffer,true);
			
			
			dxDisplay->Present();
			blitting=FALSE;
		}
	}

	
}

void Game::saveScore(LONGLONG score)
{
	ofstream out("hscore.txt");
	out << score ;
	out.close();
}

void Game::getScore()
{
	ifstream in("hscore.txt");
	in >> highScore;
	in.close();
}

int Game::title()
{
	//Don't Forget to peek during the input loop
 


	if(F==NULL) F= new CSprite("Graphics/FLetter.bmp",dxDisplay->GetDirectDraw());
	if(A==NULL) A= new CSprite("Graphics/ALetter.bmp",dxDisplay->GetDirectDraw());
    if(La==NULL) La= new CSprite("Graphics/LLetterA.bmp",dxDisplay->GetDirectDraw());
	if(Lb==NULL) Lb= new CSprite("Graphics/LLetterB.bmp",dxDisplay->GetDirectDraw());

		LettersDown(*F,*A,*La,*Lb); //Yes I know I should just remove the parameters now
	StartQuitIn();
	//HighScores
	
	//MenuCode
	int frame=1;
	int at = 0; //Don't forget to change this to zero

	typedef LONGLONG LL;
	LL ctime = gt->getGlobalTime();
	LL updateme = ctime;
	LL updateRate = 75;
    
	int ya = 310;
	int yb = 395; //figure this out
	int x= 262;

	bool update=true;
	
	
	//Load the sounds
	if(movemenu==NULL) dxSound->Create(&movemenu, "Sounds/movemenu.wav",0,GUID_NULL,1);
	if(strtmenu==NULL) dxSound->Create(&strtmenu, "Sounds/strtmenu.wav",0,GUID_NULL,1);

	while(dxInput->isKeyDown(DIK_RETURN)==-1)
	{
		
		{
			update=false;

			dxInput->updateKeyboard();
	        while(!appActive) Sleep(100);
			if((!dxInput->hasKeyCounted(DIK_DOWN) && dxInput->isKeyDown(DIK_DOWN)>-1) || (!dxInput->hasKeyCounted(DIK_UP) && dxInput->isKeyDown(DIK_UP)>-1))
			{
				at = (at==0) ? 1 : 0;
				update=true;
				//Play Sound
				movemenu->Stop();
				movemenu->Reset();
				movemenu->Play(0,0);
			}
			
			ctime = gt->getGlobalTime();

			if(updateme < ctime)
			{
				frame++;
				frame %=4;
			    Ball->changeFrame(frame);
		        update=true;
				updateme = ctime +updateRate;
			}

			if(update)
			{
				if(at==0)
				{
					Ball->setXY(x,ya);
				}
				else
				{
					Ball->setXY(x,yb);
				}

			
			}
				while(!appActive) Sleep(100);
				blitting=TRUE;
				dxDisplay->Clear(0);
				LPDIRECTDRAWSURFACE7 BackBuffer = dxDisplay->GetBackBuffer();
				F->blt(BackBuffer,true);
				A->blt(BackBuffer,true);
				La->blt(BackBuffer,true);
				Lb->blt(BackBuffer,true);
				Ball->blt(BackBuffer,true);
				Start->blt(BackBuffer,true);
				Quit->blt(BackBuffer,true);
				
				dxDisplay->Present();
				blitting=FALSE;
		}
	}

    strtmenu->Play(0,0);
	if(at==0)
	{
		dropBall();
	}
	return at; //This is temporary
}

void Game::dropBall()
{
	int rate = 6;
	typedef LONGLONG LL;
	LL ut= 5;
	LL ctime = gt->getGlobalTime();
	LL updatetime = ctime;
	
	bool done=false;
	

	while(!done)
	{
		
		ctime = gt->getGlobalTime();
		
		if(updatetime<ctime)
		{
			updatetime=ctime+ut;
			done = true;
			if(Ball->getY()<480)
			{
				Ball->setXY(Ball->getX(),Ball->getY()+rate);
				done =false;
			}
		
			while(!appActive) Sleep(100);
			blitting=TRUE;
			LPDIRECTDRAWSURFACE7 BackBuffer = dxDisplay->GetBackBuffer();
				dxDisplay->Clear(0);
				F->blt(BackBuffer,true);
				A->blt(BackBuffer,true);
				La->blt(BackBuffer,true);
				Lb->blt(BackBuffer,true);
				Ball->blt(BackBuffer,true);
				Start->blt(BackBuffer,true);
				Quit->blt(BackBuffer,true);
				
				dxDisplay->Present();
				blitting=FALSE;
		}
	}

}

void Game::StartQuitIn()
{
	//Load up the graphics
	if(Ball==NULL) Ball = new CSprite("Graphics/Ball/Ball",dxDisplay->GetDirectDraw(),4);
    if(Start == NULL) Start = new CSprite("Graphics/Start.bmp",dxDisplay->GetDirectDraw());
	if(Quit == NULL) Quit = new CSprite("Graphics/Quit.bmp",dxDisplay->GetDirectDraw());

    //Load the stopping sound
	//if(boom==NULL)dxSound->Create(&boom, "Sounds/boom.wav",0,GUID_NULL,1);
	if(boom2==NULL)dxSound->Create(&boom2, "Sounds/boom2.wav",0,GUID_NULL,1);

	//Stopping Positions
	
	int BallEndY = 310;
	int StartQuitEndX = 300;
	

	//Starting positions
	
	int BallStartX = StartQuitEndX-38;
	int BallStartY = 0-Ball->getH();
	int StartStartX = 640;
	int StartStartY = BallEndY-25;
	int QuitStartX = 0-Quit->getW();
	int QuitStartY = StartStartY + Start->getH() + 10;
	

	Ball->changeFrame(4); //Set it on the frame of falling
    Ball->setXY(BallStartX,BallStartY);
	Start->setXY(StartStartX,StartStartY);
	Quit->setXY(QuitStartX,QuitStartY);

	//Starting times
	typedef LONGLONG LL;
	LL StartQuitStartTime = gt->getGlobalTime();
	LL BallStartTime = StartQuitStartTime + 75;
	

	bool Done=false;
	LL ctime = gt->getGlobalTime();
    LL updateTime = 5;
	LL updateme = ctime+updateTime;
	int updateRate = 6;
	

	while(!Done)
	{
		
		{
			ctime = gt->getGlobalTime();
			if(updateme < ctime)
			{
				Done=true;
	         updateme=ctime+updateTime;
			
				//Update if needed
				if(ctime>BallStartTime && Ball->getY()<BallEndY)
				{
					Ball->setXY(BallStartX,Ball->getY()+updateRate);
					Done=false;
				}
				if(ctime>StartQuitStartTime)
				{
					if(Start->getX()>StartQuitEndX)
					{
						Start->setXY(Start->getX()-updateRate,StartStartY);
						Done=false;
					}
					if(Quit->getX()<StartQuitEndX)
					{
						Quit->setXY(Quit->getX()+(2*updateRate),QuitStartY);
						Done=false;
					}
				}

				//Don't let it go past it's end
				if(Quit->getX()>StartQuitEndX)
				{
					Done=false;
					Quit->setXY(StartQuitEndX,QuitStartY);
					boom->Stop();
					boom->Reset();
					boom->Play(0,0);
				}
				if(Start->getX()<StartQuitEndX)
				{
					Done=false;
					Start->setXY(StartQuitEndX,StartStartY);
					boom->Stop();
					boom->Reset();
					boom->Play(0,0);
				}
				if(Ball->getY()>BallEndY)
				{
					Done=false;
					Ball->setXY(BallStartX,BallEndY);
					boom2->Play(0,0);
				}

				//Blit
				while(!appActive) Sleep(100);
				blitting=TRUE;
				LPDIRECTDRAWSURFACE7 BackBuffer=dxDisplay->GetBackBuffer();
				dxDisplay->Clear(0);
				F->blt(BackBuffer,true);
				A->blt(BackBuffer,true);
				La->blt(BackBuffer,true);
				Lb->blt(BackBuffer,true);
				Ball->blt(BackBuffer,true);
				Start->blt(BackBuffer,true);
				Quit->blt(BackBuffer,true);
				
				dxDisplay->Present();
				blitting=FALSE;
			}
		}
	}
}

void Game::LettersDown(CSprite & F, CSprite & A,CSprite & La,CSprite & Lb)
{
	typedef LONGLONG LL; //So I don't have to keep typing that damn thing	
	LL counterstart = gt->getGlobalTime(); //This is when the function get's called
	
	//The following are variables that hold the start time for the fall of the letters
	LL FTimeStart = counterstart; 
	LL ATimeStart = FTimeStart + 25; 
	LL LaTimeStart = ATimeStart + 25;
	LL LbTimeStart = LaTimeStart + 25;

	//The next set of variables are y coordinates of when the letter should stop
	//Note that it's initial y will be 0-height
	int FStop = 0;
	int AStop = 10;
	int LaStop = 0;
	int LbStop = 30;
	

	//The next set of variables are the X coordinates for the letters
	
	int Fx = 0;
	int Ax = 155;
	int Lax = 353;
	int Lbx = 500;
	

    //initialize the CSPrite locations
	F.setXY(0,0-F.getH());
	A.setXY(0,0-A.getH());
	La.setXY(0,0-La.getH());
	Lb.setXY(0,0-Lb.getH());

	//Loop
	//Peek
	//UpdateKeyboard input //no I don't know why just do it
	//if it's the letters time to fall make it fall
	//if it's past the stop point set it back to the stop point
	//and stop making it fall
	//when all four letters arent moving exit the function
	bool Done=false;
	
	//This is the how long they wait before the letters fall more
	LL update = 5;
	int fallrate =6; //How many pixels they advance

    //Load Boom Sound
	if(!boom) dxSound->Create(&boom, "Sounds/boom.wav",0,GUID_NULL,1);

	LL NextUpdate = gt->getGlobalTime();
	while(!Done)
	{
		
		{
			dxInput->updateKeyboard();
			if(NextUpdate<gt->getGlobalTime())
			{
				LL ctime = gt->getGlobalTime();

				Done=true;
				NextUpdate=gt->getGlobalTime()+ update;

				//Move what needs to be moved
				if(FTimeStart <ctime && F.getY()<FStop)
				{
					F.setXY(Fx,F.getY()+fallrate);
					Done=false;
				}
				if(ATimeStart< ctime && A.getY()<AStop)
				{
					A.setXY(Ax,A.getY()+fallrate);
					Done=false;
				}
				if(LaTimeStart< ctime && La.getY()<LaStop)
				{
					La.setXY(Lax, La.getY()+fallrate);
					Done = false;
				}
				if(LbTimeStart<ctime && Lb.getY()<LbStop)
				{
					Lb.setXY(Lbx, Lb.getY()+fallrate);
					Done =false;
				}

				//Make sure that they don't go past their stopping positions
				if(F.getY()>FStop) 
				{
				   F.setXY(Fx,FStop);
				   	boom->Stop();
					boom->Reset();
					boom->Play(0,0L);
				}
				if(A.getY()>AStop) 
				{
					A.setXY(Ax,AStop);
					boom->Stop();
					boom->Reset();
					boom->Play(0,0L);
				}
				if(La.getY()>LaStop) 
				{
					La.setXY(Lax,LaStop);
					boom->Stop();
					boom->Reset();
					boom->Play(0,0L);
				}
				if(Lb.getY()>LbStop) 
				{
					Lb.setXY(Lbx,LbStop);
					boom->Stop();
					boom->Reset();
					boom->Play(0,0L);
				}

				//Clear Buffer, blit and flip
				while(!appActive) Sleep(100);
				blitting=TRUE;
				dxDisplay->Clear(0);
				LPDIRECTDRAWSURFACE7 BackBuffer = dxDisplay->GetBackBuffer();
				F.blt(BackBuffer,true);
				A.blt(BackBuffer,true);
				La.blt(BackBuffer,true);
				Lb.blt(BackBuffer,true);
				
				dxDisplay->Present();
				blitting=FALSE;
			}
		}
	}
	
}
#pragma once
#include "stdlib.h"
class LevelNode
{
private:
	bool * data;
	int length;
    LevelNode * next;
public:
    LevelNode(int len);
	void setNext(LevelNode *n) { next=n;}
	void setBlock(int i, bool t);
	LevelNode * getNext() { return next;}
	int getLength() { return length;}
	bool isBlock(int i) { if(i<length) return data[i]; return false;}
    
	LevelNode(void);
	~LevelNode(void);
};

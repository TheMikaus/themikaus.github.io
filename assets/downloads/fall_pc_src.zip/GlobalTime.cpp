#include "globaltime.h"
#pragma comment(lib, "winmm.lib")

/*class GlobalTime
{
private:
	LONGLONG startTime;
	LONGLONG delayTime;
	bool stopped;
public:
    void setTime();
	LONGLONG getGlobalTime();

	void stopTime();
	void startTime();

	GlobalTime(void);
	~GlobalTime(void);
};
*/

void GlobalTime::setTime()
{
	if(!stopped)
	{
	 startTime = timeGetTime();;
	}
}

LONGLONG GlobalTime::getGlobalTime()
{
	return timeGetTime()-startTime;
}

void GlobalTime::stopTime()
{
	if(!stopped)
	{
		stopped=true;
		delayTime = timeGetTime();
	}
}

void GlobalTime::restartTime()
{
	if(stopped)
	{
		stopped=false;
		startTime += (timeGetTime() - delayTime);
	}
}

GlobalTime::GlobalTime(void)
{
	startTime=timeGetTime();
	delayTime=0;
	stopped=false;
}

GlobalTime::~GlobalTime(void)
{
}

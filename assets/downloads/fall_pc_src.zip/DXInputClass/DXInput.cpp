#include "dxinput.h"
extern BOOL appActive;

void DXInput::AddCharToString(string & str)
{
  bool shift = (isKeyDown(DIK_LSHIFT)>=0 || isKeyDown(DIK_RSHIFT)>=0);
  int key=mostRecentKeyPressed();
  if(!keyBuffer[key].triggered)
  {
   keyBuffer[key].triggered=true;
   switch(key)
   {
    case DIK_SPACE: str+=" "; break;
	case DIK_1 -1: //` key
		if(shift) str+="~"; else str+="`"; break;
	case DIK_P + 1: //{ key
		if(shift) str+="{"; else str+="["; break;
	case DIK_P +2 : //} key
		if (shift) str+="}"; else str+="]"; break;
	case DIK_A+9:
		if(shift) str+=":"; else str+=";"; break;
	case 40: //Quote key
		if(shift) str+="\""; else str+="'"; break;
	case 51: //< key
		if(shift) str+="<"; else str+=","; break;
	case 52: //> key
		if(shift) str+=">"; else str+="."; break;
	case 53: //? key
		if(shift) str+="?"; else str+="/"; break;
	case DIK_0 + 1: //the - key
		if (shift) str+="_"; else str+="-"; break;
	case DIK_0+2: //the + key
		if(shift) str+="+"; else str+="="; break;
	case DIK_BACKSLASH:
		if(shift) str+="|"; else str+="\\"; break;
    case DIK_A:
		if(shift) str+="A"; else str+='a'; break;
	case DIK_B:
		if(shift) str+="B"; else str+='b'; break;
	case DIK_C:
		if(shift) str+="C"; else str+='c'; break;
	case DIK_D:
		if(shift) str+="D"; else str+='d'; break;
	case DIK_E:
		if(shift) str+="E"; else str+='e'; break;
	case DIK_F:
		if(shift) str+="F"; else str+='f'; break;
	case DIK_G:
		if(shift) str+="G"; else str+='g'; break;
	case DIK_H:
		if(shift) str+="H"; else str+='h'; break;
	case DIK_I:
		if(shift) str+="I"; else str+='i'; break;
	case DIK_J:
		if(shift) str+="J"; else str+='j'; break;
	case DIK_K:
		if(shift) str+="K"; else str+='k'; break;
	case DIK_L:
		if(shift) str+="L"; else str+='l'; break;
	case DIK_M:
		if(shift) str+="M"; else str+='m'; break;
	case DIK_N:
		if(shift) str+="N"; else str+='n'; break;
	case DIK_O:
		if(shift) str+="O"; else str+='o'; break;
	case DIK_P:
		if(shift) str+="P"; else str+='p'; break;
	case DIK_Q:
		if(shift) str+="Q"; else str+='q'; break;
	case DIK_R:
		if(shift) str+="R"; else str+='r'; break;
	case DIK_S:
		if(shift) str+="S"; else str+='s'; break;
	case DIK_T:
		if(shift) str+="T"; else str+='t'; break;
	case DIK_U:
		if(shift) str+="U"; else str+='u'; break;
	case DIK_V:
		if(shift) str+="V"; else str+='v'; break;
	case DIK_W:
		if(shift) str+="W"; else str+='w'; break;
	case DIK_X:
		if(shift) str+="X"; else str+='x'; break;
	case DIK_Y:
		if(shift) str+="Y"; else str+='y'; break;
	case DIK_Z:
		if(shift) str+="Z"; else str+='z'; break;
	case DIK_1:
		if(shift) str+="!"; else str+='1'; break;
	case DIK_2:
		if(shift) str+="@"; else str+='2'; break;
	case DIK_3:
		if(shift) str+="#"; else str+='3'; break;
	case DIK_4:
		if(shift) str+="$"; else str+='4'; break;
	case DIK_5:
		if(shift) str+="%"; else str+='5'; break;
	case DIK_6:
		if(shift) str+="^"; else str+='6'; break;
	case DIK_7:
		if(shift) str+="&"; else str+='7'; break;
	case DIK_8:
		if(shift) str+="*"; else str+='8'; break;
	case DIK_9:
		if(shift) str+="("; else str+='9'; break;
	case DIK_0:
		if(shift) str+=")"; else str+='0'; break;
	case DIK_BACKSPACE:
		if(str.size()-1>=0)str = str.substr(0,str.size()-1); break;
   }
  }
}


int DXInput::mostRecentKeyPressed()
{
	LONGLONG length=650000;
	int min=-1;
	
	for(int i=0;i<256;i++)
	{
		if(keyBuffer[i].duration!=-1 && keyBuffer[i].duration<length)
		{
			min=i;
			length=keyBuffer[i].duration;
		}
	}
	return min;
	
}

int DXInput::firstKeyDownInList()
{
	for(int i=0;i<256;i++)
	{
		if(keyBuffer[i].duration>-1) return i;
	}

	return -1;
}

int DXInput::leastRecentKeyPressed()
{
	LONGLONG length=keyBuffer[0].duration;
	int max=0;
	
	for(int i=1;i<256;i++)
	{
		if(keyBuffer[i].duration>length)
		{
			max=i;
			length=keyBuffer[i].duration;
		}
	}
	return max;
}

void DXInput::unAcquire()
{
	freeDI();
	//don't forget to add the rest later
}

void DXInput::reAcquire()
{
	DIInit(myhndl,mydevs);
}

bool DXInput::DIInit(HWND hDlg, int whatDev)
{
	bool working=true;
	myhndl=hDlg;
	mydevs=whatDev;

	HINSTANCE hInst = (HINSTANCE)(GetWindowLong(hDlg, GWL_HINSTANCE));

	if(FAILED( DirectInput8Create(hInst, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&directInput, NULL))) return false;


	if(whatDev | 1)
	{
		working =initKeyBoard(hDlg);
	}
	return working;
}

void DXInput::freeDI()
{
	if(keyboard) {keyboard->Unacquire(); keyboard->Release(); keyboard=NULL;}
	if(directInput) {directInput->Release(); directInput=NULL;}
}

bool DXInput::initKeyBoard(HWND hWnd)
{
	DWORD dwCoopFlags;
	
	if(FAILED( directInput->CreateDevice(GUID_SysKeyboard, &keyboard, NULL))) return false;
	if(FAILED(keyboard->SetDataFormat(&c_dfDIKeyboard)))return false; 

	dwCoopFlags = DISCL_FOREGROUND | DISCL_NONEXCLUSIVE;
	//dwCoopFlags = DISCL_EXCLUSIVE | DISCL_FOREGROUND;
	if(FAILED( keyboard->SetCooperativeLevel(hWnd, dwCoopFlags)))return false; 

	keyboard->Acquire(); 

	clearKeyboardBuffer();
	return true;
} 

void DXInput::clearKeyboardBuffer()
{
	for(int i=0;i<256;i++)
	{
		keyBuffer[i].duration=-1;
		keyBuffer[i].triggered=false;
	}
}

bool DXInput::updateKeyboard()
{
	#define KEYDOWN(name, key) (name[key] & 0x80) 
 
    char     buffer[256]; 
 
	while(!appActive) Sleep(100);
    if(FAILED(keyboard->GetDeviceState(sizeof(buffer),(LPVOID)&buffer))) return false;

	for(int i=0;i<256;i++)
	{
		if(KEYDOWN(buffer,i))
		{
		 keyBuffer[i].duration++;
		 if(keyBuffer[i].duration==0)keyBuffer[i].triggered=false;
		}
		else
		{
			keyBuffer[i].duration=-1;
			keyBuffer[i].triggered=false;
		}
	}

	return true;
}

LONGLONG DXInput::isKeyDown(int i)
{
	if(keyBuffer[i].duration>-1) { keyBuffer[i].triggered=true;}
	return keyBuffer[i].duration;
}

DXInput::DXInput(void)
{
	keyboard=NULL;
	directInput=NULL;
}

DXInput::~DXInput(void)
{
	freeDI();
}

#pragma once
#pragma comment(lib,"dinput8.lib")

#include<Dinput.h>
#include<windows.h>
#include<mmsystem.h>

#include<fstream>
#include<string>
using namespace std;

typedef struct keytype
{
	LONGLONG duration;
	bool triggered;
} keytype;

class DXInput
{
private:
	LPDIRECTINPUT8 directInput;
	LPDIRECTINPUTDEVICE8 keyboard;
	keytype keyBuffer[256];	
	HWND myhndl;
	int mydevs;
public:

	bool DIInit(HWND hDlg, int whatDev);

	bool initKeyBoard(HWND hWnd);
	bool updateKeyboard();
	void clearKeyboardBuffer();
	LONGLONG isKeyDown(int i);
	bool hasKeyCounted(int i) { return (keyBuffer[i].duration>-1) && keyBuffer[i].triggered;}
	void AddCharToString(string & str);
	int mostRecentKeyPressed();
	int firstKeyDownInList();
	int leastRecentKeyPressed();


	void unAcquire();
	void reAcquire();

	void freeDI();
	DXInput(void);
	~DXInput(void);
};

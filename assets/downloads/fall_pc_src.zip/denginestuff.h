void setColorKey(LPDIRECTDRAWSURFACE7 & currentSprite, DWORD color)
{
	DDCOLORKEY key;

	key.dwColorSpaceLowValue = color;
	key.dwColorSpaceHighValue = color;
	currentSprite->SetColorKey(DDCKEY_SRCBLT, &key);
}

LPDIRECTDRAWSURFACE7 CreateSurface(DWORD width, DWORD height)
{
	LPDIRECTDRAWSURFACE7 currentSprite;

	DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
	ddsd.dwFlags= DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	ddsd.dwWidth = width;
	ddsd.dwHeight= height;
	dxDisplay->GetDirectDraw()->CreateSurface(&ddsd,&currentSprite,NULL);
	ClearSurface(currentSprite,RGB(0,0,0));
	setColorKey(currentSprite,RGB(0,255,0));
	return currentSprite;
}

LPDIRECTDRAWSURFACE7 createBitmapSurface(char *filename)
{
	LPDIRECTDRAWSURFACE7 currentSprite;

	HDC hdc;
	HBITMAP bit;
	
	bit=(HBITMAP) LoadImage(NULL, filename, IMAGE_BITMAP,0,0,LR_DEFAULTSIZE|LR_LOADFROMFILE);
	if(!bit) return NULL;

	BITMAP bitmapp;
	GetObject(bit, sizeof(BITMAP), &bitmapp);
		
	DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
	ddsd.dwFlags= DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	ddsd.dwWidth = bitmapp.bmWidth;
	ddsd.dwHeight = bitmapp.bmHeight;;

	if(dxDisplay->GetDirectDraw()->CreateSurface(&ddsd,&currentSprite,NULL)!=DD_OK)
	{
		DeleteObject(bit);
		return NULL;
	}
	currentSprite->GetDC(&hdc);
	HDC bit_dc = CreateCompatibleDC(hdc);

	SelectObject(bit_dc,bit);
	BitBlt(hdc,0,0,bitmapp.bmWidth,bitmapp.bmHeight,bit_dc,0,0,SRCCOPY);
	currentSprite->ReleaseDC(hdc);
	DeleteDC(bit_dc);

	setColorKey(currentSprite, RGB(0,255,0));
	return currentSprite;
}

void fadeOut(int rate, DWORD delay)
{
  DDGAMMARAMP ddgr; 
  bool nochange=false;
 
  LPDIRECTDRAWGAMMACONTROL gamma;
  DDGAMMARAMP old;


  dxDisplay->GetFrontBuffer()->QueryInterface(IID_IDirectDrawGammaControl, (LPVOID*) &gamma);
  ZeroMemory(&ddgr, sizeof(ddgr));
  if(FAILED(gamma->GetGammaRamp(0,&ddgr))) return;
  ZeroMemory(&old,sizeof(old));
  if(FAILED(gamma->GetGammaRamp(0,&old))) return;

 MSG msg;
 WORD temp;
 while(!nochange) 
 {
  nochange=true;

  
  for(int i=0;i<256;i++)
  {
	//decrease the values till they are black!!!
    //aka 0 currently having problems with this!
    if(ddgr.red[i]>0)
	{
		temp = ddgr.red[i];
		ddgr.red[i]-=rate;
		if(ddgr.red[i]>temp) ddgr.red[i]=0;
		if(ddgr.red[i]<0) ddgr.red[i]=0;			
		nochange=false;
	}
    
	if(ddgr.blue[i]>0)
	{
		temp = ddgr.blue[i];
		ddgr.blue[i]-=rate;
		if(ddgr.blue[i]>temp) ddgr.blue[i]=0;
		if(ddgr.blue[i]<0) ddgr.blue[i]=0;			
		nochange=false;
	}

	
	if(ddgr.green[i]>0)
	{
		temp = ddgr.green[i];
		ddgr.green[i]-=rate;
		if(ddgr.green[i]>temp) ddgr.green[i]=0;
		if(ddgr.green[i]<0) ddgr.green[i]=0;			
		nochange=false;
	}
  }
	gamma->SetGammaRamp(0,&ddgr);
	Sleep(delay);
  
 }

}

void ClearSurface(LPDIRECTDRAWSURFACE7 &surface, DWORD Color)
{
	DDBLTFX ddbltfx;
	ddbltfx.dwSize=sizeof(ddbltfx);
	ddbltfx.dwFillColor = Color;
	HRESULT rval=surface->Blt(NULL,NULL,NULL,DDBLT_WAIT|DDBLT_COLORFILL,&ddbltfx);
}
#pragma once
#include <windows.h>
#include "dxincludes/dmutil.h"
#include "Font/Font.h"
#include "Dxinputclass/dxinput.h";
#pragma comment (lib,"ddraw.lib")
#include "dxincludes/dsutil.h"
#pragma comment (lib,"dsound.lib")
#include "dxincludes/ddutil.h"

#include "Levelnode.h"
#include "randgen.h"
#include "globaltime.h"

class Game
{
	static Game *gameInstance;
	CMusicSegment * music;
	bool midiLoaded;

	CSound * boom;
	CSound * boom2;
	CSound * movemenu;
	CSound * strtmenu;
	CSound * land;
	CSound * boing;
	//ha ha sound?

	//For the letters
    CSprite *F;
	CSprite *A;
    CSprite *La;
	CSprite *Lb;

	//For the Main Menu and game
	CSprite *Ball;
	CSprite *Start;
	CSprite *Quit;
	
	//For Game Over
	CSprite *game;
	CSprite *Over;

	//Holds the scores
	LONGLONG highScore;
	LONGLONG score;
	CSprite *HighBmp;
	CSprite *ScoreBmp;
	CSprite *NewBmp;
	int highscoreY;
	int scoreXB;
	int scoreXA;
	int scoreY;
	CSprite *HighScore;
	CSprite * PlayerScore;


	//For the Level
	LevelNode * topLine;
	LevelNode * bottomLine;
    //For the bitmap of the level
	LPDIRECTDRAWSURFACE7 tileGrounda;
	LPDIRECTDRAWSURFACE7 tileGroundb;
	CSprite *backA;
	CSprite *backB;
	CSprite *tiles;
	CSprite *SideA;
	CSprite *SideAb;
	CSprite *SideB;
	CSprite *SideBb;
	CSprite *BackGround;
	CSprite *BackGroundB;
    int blitx;
	int blity;

	//To see if player will fall;
	bool falling;
	int ballFallRate;
	int ballMoveRate;
	int screenMoveRate;
	LONGLONG updateGameTime;
	int blit;
	
	bool quiting;
	Font * font; 
	LONGLONG timeStop;
	LONGLONG timeStopd;
	MUSIC_TIME var;
	bool ingame;
public:
	bool isInGame() {return ingame;}
	void Kill();
	void pauseMidi();
	void playMidi();
	void loadMidi();
	bool isMidiLoaded() { return midiLoaded;}
	
	static Game * getInstance();
	Game(void);
	~Game(void);

	void run();

	bool startGame();

	void gameOver();
	void DropOver();
	void displayHighScore();

	void saveScore(LONGLONG score);
	void getScore();

	int title();
	void LettersDown(CSprite & F, CSprite & A,CSprite & La,CSprite & Lb);
	void StartQuitIn();
    void dropBall();

	void initializeGame();
    void initFirstSetOfLines();
	void initPlayer();
	void initTileGround();
	void initOtherVariables();
    LevelNode * blankLevelLine(int length);
	LevelNode * RandomLine(int length);
	

	int KeyDown();
	int closestLeftTile(int x);
	int closestRightTile(int x);
	void redrawTiles();


	string convertNumString(LONGLONG value);
};

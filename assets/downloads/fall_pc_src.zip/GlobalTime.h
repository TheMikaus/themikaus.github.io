#pragma once
#ifndef GlobalTime_h
#define GlobalTime_h

#include <windows.h>
#include <mmsystem.h>
#include <time.h>

class GlobalTime
{
private:
	LONGLONG startTime;
	LONGLONG delayTime;
	bool stopped;
public:
    void setTime();
	LONGLONG getGlobalTime();

	void stopTime();
	void restartTime();

	GlobalTime(void);
	~GlobalTime(void);
};
#endif
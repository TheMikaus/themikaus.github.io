#include "csprite.h"
 
void CSprite::setSprite(LPDIRECTDRAWSURFACE7 & surf)
{
	currentSprite=surf;
	info = new FrameInfo();	

	DDSURFACEDESC2 bob;

	ZeroMemory(&bob,sizeof(bob));
	bob.dwSize=sizeof(DDSURFACEDESC2);
	bob.dwFlags = DDSD_CAPS | DDSD_WIDTH + DDSD_HEIGHT;
	
	surf->GetSurfaceDesc(&bob);
	width =bob.dwWidth;
	height =bob.dwHeight;

	frames=1;
	currentFrame=0;
	info->setFromXY(0,0);
	info->setColorToHold(RGB(0,255,0));
	info->setNewWH(width,height);
	info->setSecXY(width,height);
	info->setTransparancy(1);
}

void CSprite::setColorKey(DWORD color)
{
	DDCOLORKEY key;
	info[currentFrame].setColorToHold(color);
	key.dwColorSpaceLowValue = color;
	key.dwColorSpaceHighValue = color;
	currentSprite->SetColorKey(DDCKEY_SRCBLT, &key);
}

string CSprite::convert(int num)
{
    bool once=false;
	string temp;
	temp="";

	if(num==0) return "0";
	while(num>0)
	{
			temp+='0'+(num%10);
			num/=10;
	}

	return temp;
}

void CSprite::changeFrame(int frame)
{
	if(frame<frames)
	{
    	currentFrame=frame;
		currentSprite = allSprites[frame];

		DDSURFACEDESC2 bob;
		ZeroMemory(&bob,sizeof(DDSURFACEDESC2));
		bob.dwSize=sizeof(DDSURFACEDESC2);
		bob.dwFlags = DDSD_CAPS | DDSD_WIDTH + DDSD_HEIGHT;
	
		currentSprite->GetSurfaceDesc(&bob);
		width =bob.dwWidth;
		height =bob.dwHeight;
	}
}

void CSprite::blt(LPDIRECTDRAWSURFACE7 & surf, bool usekey)
{
	RECT blitfrom;
	RECT blit2;

		int x,y;
		DWORD fromx,secx,newWidth;
		DWORD fromy,secy,newHeight;

		x=info[currentFrame].getX();
		newWidth=info[currentFrame].getNewWidth();
		y=info[currentFrame].getY();
		newHeight=info[currentFrame].getNewHeight();

		secx=info[currentFrame].getSecX();
		secy=info[currentFrame].getSecY();

		fromx=info[currentFrame].getFromX();
		fromy = info[currentFrame].getFromY();


	if(clipme)
	{
		DDSURFACEDESC2 bob;
		ZeroMemory(&bob,sizeof(DDSURFACEDESC2));
		bob.dwSize=sizeof(DDSURFACEDESC2);
		bob.dwFlags = DDSD_CAPS | DDSD_WIDTH + DDSD_HEIGHT;
		surf->GetSurfaceDesc(&bob);

		
		double ratio = (double)info[currentFrame].getSecX() / (double)info[currentFrame].getNewWidth();

		
		
		if(x<0)
		{
			blit2.left=0;
			blitfrom.left=fromx + (DWORD)((double)(x*-1) * ratio);
		}
		else
		{
			blit2.left=x;
			blitfrom.left=fromx;
		}

		if(y<0)
		{
			blit2.top=0;
			blitfrom.top=fromy + (DWORD)((double)(y * -1) * ratio);
		}
        else
		{
			blit2.top=y;
			blitfrom.top=fromy;
		}

		if(x+newWidth>=bob.dwWidth)
		{
			blit2.right=bob.dwWidth;
			blitfrom.right = (LONG)fromx + secx - (LONG)(ratio * ((x+newWidth)-bob.dwWidth));
		}
		else
		{
			blit2.right=x+newWidth;
			blitfrom.right=fromx+secx;
		}

		if(y+newHeight > bob.dwHeight)
		{
			blit2.bottom=bob.dwHeight;
			blitfrom.bottom = (LONG)fromy + secy- (LONG)(ratio * ((y+newHeight)-bob.dwHeight));
		}
		else
		{
			blit2.bottom = y+newHeight;
			blitfrom.bottom = fromy+secy;
		}
	}
	else
	{
		//if no clipping
		blitfrom.top=fromy;
		blitfrom.left=fromx;
		blitfrom.bottom=fromy+secy;
		blitfrom.right=fromx+secx;

		blit2.left=x;
		blit2.top=y;
		blit2.right=x+newWidth;
		blit2.bottom=y+newHeight;
	}

	DDBLTFX dblt;
	dblt.dwSize=sizeof(dblt);
	dblt.dwDDFX = 0;
	if(flipx) dblt.dwDDFX+=DDBLTFX_MIRRORLEFTRIGHT;
	if(flipy) dblt.dwDDFX+=DDBLTFX_MIRRORUPDOWN;

	if(usekey)
		surf->Blt(&blit2,currentSprite,&blitfrom,DDBLT_KEYSRC | DDBLT_DDFX,&dblt);
	else
		surf->Blt(&blit2,currentSprite,&blitfrom,DDBLT_DDFX,&dblt);
}

CSprite::CSprite(char * namepref, LPDIRECTDRAW7 dd, int f)
{
 frames=f;
 currentFrame=0;clipme=true;

 allSprites = new LPDIRECTDRAWSURFACE7[f]; //make the list
 info = new FrameInfo[f];

 

 flipx=flipy=false;

 
 for(int i=0;i<f;i++)
 {
    HDC hdc;
 	HBITMAP bit;
	
	string newname(namepref);
	newname+=convert(i);
	newname+=".bmp";

	
	bit=(HBITMAP) LoadImage(NULL, newname.c_str(), IMAGE_BITMAP,0,0,LR_DEFAULTSIZE|LR_LOADFROMFILE);
	if(!bit) return;

	BITMAP bitmapp;
	GetObject(bit, sizeof(BITMAP), &bitmapp);
	width = bitmapp.bmWidth;
	height = bitmapp.bmHeight;

	info[i].setColorToHold(RGB(0,255,0));
	info[i].setSecXY(width,height);
	info[i].setNewWH(width,height);
	

	DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
	ddsd.dwFlags= DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	ddsd.dwWidth = width;
	ddsd.dwHeight = height;

	if(dd->CreateSurface(&ddsd,&currentSprite,NULL)!=DD_OK)
	{
		DeleteObject(bit);
		return;
	}
	currentSprite->GetDC(&hdc);
	HDC bit_dc = CreateCompatibleDC(hdc);

	SelectObject(bit_dc,bit);
	BitBlt(hdc,0,0,width,height,bit_dc,0,0,SRCCOPY);
	currentSprite->ReleaseDC(hdc);
	DeleteDC(bit_dc);

	setColorKey(RGB(0,255,0));
	allSprites[i] = currentSprite;
 }
 changeFrame(0);
 
}

CSprite::CSprite(char * bitmap, LPDIRECTDRAW7  dd)
{
    currentFrame=0;clipme=true;

	frames =1;

	flipx=flipy=false;

	info = new FrameInfo();

	HDC hdc;
	HBITMAP bit;
	
	bit=(HBITMAP) LoadImage(NULL, bitmap, IMAGE_BITMAP,0,0,LR_DEFAULTSIZE|LR_LOADFROMFILE);
	if(!bit) return;

	BITMAP bitmapp;
	GetObject(bit, sizeof(BITMAP), &bitmapp);
	width = bitmapp.bmWidth;
	height = bitmapp.bmHeight;

	
	info[0].setColorToHold(RGB(0,255,0));
	info[0].setSecXY(width,height);
	info[0].setNewWH(width,height);
	

	DDSURFACEDESC2 ddsd;
	ZeroMemory(&ddsd,sizeof(ddsd));
	ddsd.dwSize = sizeof(DDSURFACEDESC2);
	ddsd.dwFlags= DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	ddsd.dwWidth = width;
	ddsd.dwHeight = height;

	if(dd->CreateSurface(&ddsd,&currentSprite,NULL)!=DD_OK)
	{
		DeleteObject(bit);
		return;
	}
	currentSprite->GetDC(&hdc);
	HDC bit_dc = CreateCompatibleDC(hdc);

	SelectObject(bit_dc,bit);
	BitBlt(hdc,0,0,width,height,bit_dc,0,0,SRCCOPY);
	currentSprite->ReleaseDC(hdc);
	DeleteDC(bit_dc);

	setColorKey(RGB(0,255,0));
}


CSprite::CSprite(void)
{
	flipx=flipy=false;
	clipme=true;
}

CSprite::~CSprite(void)
{
	if(currentSprite) currentSprite->Release();
	for(int i=0;i<frames;i++)
	{
		if(allSprites[i]) allSprites[i]->Release();
	}

	delete currentSprite;
	delete allSprites;
}

#include "frameinfo.h"

FrameInfo::FrameInfo(void)
{
	x=y=0;
	colorToHold=newWidth=newHeight=fromx=fromy=secx=secy=0;
	transparancy=1;
}

FrameInfo::~FrameInfo(void)
{
}

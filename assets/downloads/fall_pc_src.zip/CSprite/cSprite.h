#pragma once

#pragma comment (lib, "ddraw.lib")

#include <ddraw.h>
#include <windows.h>
#include <windowsx.h>
#include "frameinfo.h"

#include <string>
#include<fstream>
using namespace std;


class CSprite
{
private:
	LPDIRECTDRAWSURFACE7 currentSprite;
	LPDIRECTDRAWSURFACE7 * allSprites;
	int currentFrame;
	DWORD width, height;
	FrameInfo * info;
	bool clipme;

	bool flipx;
	bool flipy;

	int frames;
public:
	FrameInfo * getFrameInfo(int i) { return &(info[i]);}
    LPDIRECTDRAWSURFACE7 & getCurrentSprite() { return currentSprite;}
	void changeFrame(int frame);
	int getFrameNumber() { return currentFrame;}
	int getFrameCount() { return frames;}

	string convert(int num);

	void FlipX() {flipx=!flipx;}
	void FlipY() {flipy=!flipy;}
	bool getFlipX() { return flipx;}
	bool getFlipY() { return flipy;}


    void blt(LPDIRECTDRAWSURFACE7  & surf, bool usekey);

	void setWH(int w, int h) { info[currentFrame].setSecXY(w,h);}
	int getW() { return info[currentFrame].getSecX();}
	int getH() {return info[currentFrame].getSecY();}

	void setNewWH(int w, int h) {info[currentFrame].setNewWH(w,h);}
	int getNewW() { return info[currentFrame].getNewWidth();}
	int getNewH() { return info[currentFrame].getNewHeight();}

	void setXY(int x, int y) { info[currentFrame].setXY((DWORD)x,(DWORD)y);}
	int getX() { return info[currentFrame].getX();}
	int getY() { return info[currentFrame].getY();}

	void setFromXY(int x, int y) { info[currentFrame].setFromXY(x,y);}
	int getFromX() { return info[currentFrame].getFromX();}
	int getFromY() { return info[currentFrame].getFromY();}

	void setClip(bool t) { clipme=t;}
	bool getClip() { return clipme;}

	DWORD getOriginalWidth() { return width;}
	DWORD getOriginalHeight() { return height;}
	DWORD getCurrentWidth() { return info[currentFrame].getNewWidth();}
	DWORD getCurrentHeight() {return info[currentFrame].getNewHeight();}


	double getTransparancy() { return info[currentFrame].getTransparancy();}
	void setTransparancy(double t) { info[currentFrame].setTransparancy(t);}

    void setColorKey(DWORD color);

	CSprite(char * bitmap, LPDIRECTDRAW7  dd);
	CSprite(char * namepref, LPDIRECTDRAW7  dd, int f);
	void setSprite(LPDIRECTDRAWSURFACE7 & surf);
	CSprite(void);
	~CSprite(void);
};

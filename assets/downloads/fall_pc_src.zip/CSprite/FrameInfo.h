#pragma once

#include "windows.h"

class FrameInfo
{
private:
	int x,y;
	DWORD colorToHold;
	DWORD newWidth,newHeight;
	DWORD fromx,fromy,secx,secy;
	double transparancy;
public:
	void setNewWidth(DWORD w) { newWidth=w;}
	void setNewHeight(DWORD h) { newHeight=h;}
	void setNewWH(DWORD w, DWORD h) {setNewWidth(w); setNewHeight(h);}

	void setXY(int x, int y) { this->x=x; this->y=y;}
	void setFromXY(DWORD x, DWORD y) { fromx=x;fromy=y;}
	void setSecXY(DWORD x,DWORD y) {secx=x;secy=y;}

	void setTransparancy(double t) { transparancy=t;}
	void setColorToHold(DWORD d) {colorToHold=d;}


	DWORD getNewWidth() { return newWidth;}
	DWORD getNewHeight() { return newHeight;}
	int getX() { return x;}
	int getY() {return y;}
	DWORD getFromX() { return fromx;}
	DWORD getFromY() { return fromy;}
	DWORD getSecX(){return secx;}
	DWORD getSecY(){return secy;}
	DWORD getColorToHold(){return colorToHold;}

	double getTransparancy() { return transparancy;}

	FrameInfo(void);
	~FrameInfo(void);
};

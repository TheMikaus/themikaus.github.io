HRESULT WinInit(HINSTANCE hInst, int nCmdShow, HWND * phWnd)
{
	WNDCLASSEX wc;
	HWND hWnd;
	wc.cbSize = sizeof(wc);
	wc.lpszClassName = TEXT("Game");
	wc.lpfnWndProc = MainWndProc;
	wc.style=CS_VREDRAW | CS_HREDRAW;
	wc.hInstance =hInst;
	wc.hIcon = LoadIcon( hInst,MAKEINTRESOURCE(IDI_ICON1));
	wc.hIconSm = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1));
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground =(HBRUSH) (COLOR_WINDOW +1);
	wc.lpszMenuName = NULL;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;

	if( RegisterClassEx(&wc) == 0 ) return E_FAIL;

	DWORD dwFrameWidth = GetSystemMetrics( SM_CXSIZEFRAME);
	DWORD dwFrameHeight = GetSystemMetrics(SM_CYSIZEFRAME);
	DWORD dwWindowWidth = SCREEN_WIDTH + dwFrameWidth*2;
	DWORD dwWindowHeight = SCREEN_HEIGHT + dwFrameHeight * 2;

	DWORD dwStyle = WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_SYSMENU;
	hWnd = CreateWindowEx(0,TEXT("Game"),TEXT("Fall Release 3"),dwStyle, CW_USEDEFAULT, CW_USEDEFAULT, dwWindowWidth,dwWindowHeight, NULL,NULL,hInst,NULL);

	if(hWnd == NULL) return E_FAIL;

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	GetWindowRect(hWnd, &WindowRect);

	*phWnd = hWnd;
	
	return S_OK;
}
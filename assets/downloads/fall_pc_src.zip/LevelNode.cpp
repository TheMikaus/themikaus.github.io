#include "levelnode.h"

void LevelNode::setBlock(int i, bool t)
{
	if(i<length)
	{
		data[i]=t;
	}
}

LevelNode::LevelNode(int len)
{
	length=len;
	data = new bool[len];
	next=NULL;
}

LevelNode::LevelNode(void)
{
	length=-1;
	next=NULL;
}

LevelNode::~LevelNode(void)
{
	delete [] data;
}

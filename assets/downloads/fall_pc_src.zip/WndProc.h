LRESULT CALLBACK MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	  	case WM_KEYDOWN:
			
			if(wParam==VK_F8) PostMessage(hWnd,WM_CLOSE,0,0);
			if(wParam==VK_TAB)
			{
				if(blitting) return 0L;
				else break;
			}
            if(wParam==VK_F12)
			{
				//stop time
				appActive=false;
				while(blitting) Sleep(100);
				if(gt)gt->stopTime();
				Game::getInstance()->pauseMidi();
				if(appWindowed) GetWindowRect(hWnd,&WindowRect);
				appWindowed=!appWindowed;
				if(FAILED(InitDirectDrawMode(hWnd, appWindowed)))
				{
				//Delete all globals that need deleting
				SAFE_DELETE(dxDisplay);
				MessageBox(hWnd, TEXT("Couldn't switch modes"),TEXT("Crap"),MB_ICONERROR|MB_OK);
				PostMessage(hWnd, WM_CLOSE,0,0);
				}
			   //start time
				if(gt)gt->restartTime();
				appActive=true;
				Game::getInstance()->playMidi();
				return 0L;
			}
			 break;
		
	case WM_GETMINMAXINFO:
		{
			MINMAXINFO* pMinMax =(MINMAXINFO*)lParam;
			DWORD dwFrameWidth = GetSystemMetrics(SM_CXSIZEFRAME);
			DWORD dwFrameHeight = GetSystemMetrics(SM_CYSIZEFRAME);
			pMinMax->ptMaxTrackSize.x=pMinMax->ptMinTrackSize.x = SCREEN_WIDTH +dwFrameWidth *2;
			pMinMax->ptMaxTrackSize.y=pMinMax->ptMinTrackSize.y= SCREEN_HEIGHT+dwFrameHeight*2;
		}
		return 0L;

	case WM_MOVE:
		if(dxDisplay) dxDisplay->UpdateBounds();
		//pause time?
		//freeze input?
		if(gt)gt->stopTime();
		Game::getInstance()->pauseMidi();
		return 0L;

 
  case WM_ACTIVATE:
            if( WA_INACTIVE != wParam && dxInput )
            {
                // Make sure the device is acquired, if we are gaining focus.
                dxInput->reAcquire();
				appActive = TRUE;
				if(gt)gt->restartTime();
				Game::getInstance()->playMidi();
            }
			if( WA_INACTIVE == wParam) {appActive=FALSE; if(gt)gt->stopTime(); dxInput->unAcquire(); Game::getInstance()->pauseMidi();}
            break;

	case WM_SIZE:
		if(SIZE_MAXHIDE==wParam|| SIZE_MINIMIZED==wParam)
			appActive=FALSE;
		else
			appActive=TRUE;

		if(dxDisplay) dxDisplay->UpdateBounds();
		//pause time?
		if(gt)
		if(!appActive)gt->stopTime(); else gt->restartTime();
		if(!appActive)Game::getInstance()->pauseMidi; else Game::getInstance()->playMidi();
		break;

	case WM_SETCURSOR:
		if(!appWindowed)
		{
			SetCursor(NULL);
			return TRUE;
		}
		break;

	case WM_EXITSIZEMOVE:
		//set new time
		if(gt)gt->restartTime();
		Game::getInstance()->playMidi();
		break;

	case WM_SYSCOMMAND:
		switch (wParam)
		{
		case SC_MOVE:
		case SC_SIZE:
		case SC_MAXIMIZE:
		case SC_MONITORPOWER:
			if(!appWindowed) return TRUE;
		}
		break;
	case WM_DESTROY:
		//Clean Everything Up
		appActive=false;
		while(blitting) Sleep(100);
		
		delete dxInput;
		FreeDirectDraw();
		//mental note delete all segments and sounds before this point
		
		if(dxSound) { KillTimer(hWnd,0); delete dxSound;}
		if(dxMusic) { delete dxMusic;}
		PostQuitMessage(0);
		return 0L;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}
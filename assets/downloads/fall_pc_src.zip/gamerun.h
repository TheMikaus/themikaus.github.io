DWORD WINAPI gamerun(LPVOID args)
{
	Game * game = Game::getInstance();
	while(!game->isMidiLoaded()) Sleep(100);
	game->run();
	PostMessage(GHWND,WM_CLOSE,0,0);
	return 0;
}
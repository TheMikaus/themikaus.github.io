#define STRICT


#include "winincludes.h"
#include "dxincludes.h"

#include "game.h"
#include "denginedeclares.h"

GlobalTime * gt=NULL;

DWORD WINAPI gamerun(LPVOID args);
HWND GHWND;

int APIENTRY WinMain( HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR pCmdLine, int nCmdShow)
{
	//Varaibles
	MSG msg;
	HWND hWnd;

	//Make window
	if(FAILED(WinInit(hInst,nCmdShow, &hWnd))) return FALSE;

	GHWND=hWnd;
	//Initialize DirectX stuff
	if(FAILED(InitDirectDraw(hWnd))) return FALSE;
	
	dxInput = new DXInput();
	if(!dxInput->DIInit(hWnd,1)) 
	{
		FreeDirectDraw();
		return FALSE;
	}

	dxSound = new CSoundManager();
	if(!DSInit(hWnd,2,44100,16))
	{
		delete dxInput;
		FreeDirectDraw();
		delete dxSound;
		return FALSE;
	}
	
	
	dxMusic = new CMusicManager();
	if(FAILED(dxMusic->Initialize(hWnd,128,DMUS_APATH_DYNAMIC_STEREO))) 
	{
		delete dxInput;
		FreeDirectDraw();
		delete dxSound;
		delete dxMusic;
		return FALSE;
	}

	gt =new GlobalTime();
	//spawn game thread
	HANDLE gameThread;
	DWORD threadID=3;
	gameThread = CreateThread(0,0,&gamerun,hWnd,0,&threadID);

	Game * game = Game::getInstance();
	game->loadMidi();
	//message loop
	while(true)
	{
		if(PeekMessage(&msg,NULL,0,0,PM_NOREMOVE))
		{
			if(0==GetMessage(&msg,NULL,0,0))
			{
				return (int)msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		WaitMessage();
	}
}

#include "wininit.h"
#include "wndproc.h"
#include "initDDraw.h"
#include "initDSound.h"
#include "gamerun.h"
#include "denginestuff.h"
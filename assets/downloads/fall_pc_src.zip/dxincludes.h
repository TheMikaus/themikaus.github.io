#pragma once
//Screen Information
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480
#define SCREEN_BPP 32

//The following are for Direct Draw
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"ddraw.lib")

#define SAFE_DELETE(P) {if(P) { delete(P); (P)=NULL;}}
#define SAFE_RELEASE(p) {if(p){(p)->Release(); (p)=NULL;}}

#include <ddraw.h>
#include "dxincludes/ddutil.h"

//Globals
CDisplay* dxDisplay=NULL;


//Predifined Functions found elsewhere
HRESULT InitDirectDraw(HWND hWnd);
VOID FreeDirectDraw();
HRESULT InitDirectDrawMode(HWND hWnd, BOOL windowed);

HRESULT drawNext(HWND hWnd);
HRESULT drawSprites();
HRESULT RestoreSurfaces();
//End Direct Draw

//Direct Input
#include "DXinputClass/DXinput.h"
DXInput * dxInput = NULL;

//Direct Sound
#include "DXincludes/dsutil.h"
CSoundManager * dxSound=NULL;
bool DSInit(HWND hWnd, DWORD channels, DWORD Freq, DWORD BitRate);

#include "DXincludes/dmutil.h"
CMusicManager * dxMusic=NULL;


//Test
CMusicSegment * seg;
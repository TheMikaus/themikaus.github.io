HRESULT drawNext(HWND hWnd)
{
	if(FAILED(hr= dxDisplay->getDirectDraw()->TestCooperativeLevel()))
	{
		switch(hr)
		{
		case DDERR_EXCLUSIVEMODEALREADYSET:
		case DDERR_NOEXCLUSIVEMODE:
			Sleep(10);
			return S_OK;
		case DDERR_WRONGMODE:
			return InitDirectDrawMode(hWnd,appWindowed);
		}
		return hr;
	}
	if(FAIlED(hr = drawSprites())
	{
		if(hr!=DDERR_SURFACELOST)
			return hr;
		RestoreSurfaces();
	}
	return S_OK;
}

HRESULT drawSprites()
{
	dxDisplay->Clear(0);
	//Draw all the sprites to buffer
	if(FAILED(hr = dxDisplay->Present())) return hr;
	return S_OK;
}

HRESULT RestoreSurfaces()
{
	HRESULT hr;
	if(FAILED(hr = dxDisplay->GetDirectDraw()->RestoreAllSurfaces())) return hr;
	if(FAILED( hr=drawSprites())) return hr;
	return S_OK;
}
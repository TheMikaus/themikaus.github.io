HRESULT InitDirectDraw(HWND hWnd)
{
	HRESULT hr;
	if(FAILED(hr=InitDirectDrawMode(hWnd, appWindowed))) return hr;
	return S_OK;
}

HRESULT InitDirectDrawMode(HWND hWnd, BOOL windowed)
{
	HRESULT hr;
	//Delete all Surfaces
	SAFE_DELETE(dxDisplay);
	dxDisplay = new CDisplay();
	if(windowed)
	{
		if(FAILED(hr = dxDisplay->CreateWindowedDisplay(hWnd,SCREEN_WIDTH,SCREEN_HEIGHT))) return hr;

		DWORD dwStyle = GetWindowLong(hWnd, GWL_STYLE);
		//dwStyle |= WS_SYSMENU;
		dwStyle &= ~WS_SYSMENU;
		SetWindowLong(hWnd, GWL_STYLE, dwStyle);
	}
	else
	{
		if(FAILED(hr=dxDisplay->CreateFullScreenDisplay(hWnd,SCREEN_WIDTH,SCREEN_HEIGHT,SCREEN_BPP)))	return hr;
		SetMenu(hWnd, NULL);

		DWORD dwStyle = GetWindowLong(hWnd, GWL_STYLE);
		dwStyle &= ~WS_SYSMENU;
		SetWindowLong(hWnd, GWL_STYLE, dwStyle);
	}
	//Restore all Surfaces 
		
	return S_OK;
}

VOID FreeDirectDraw()
{
	//SAFE_DELETE stuff
	SAFE_DELETE(dxDisplay);
}
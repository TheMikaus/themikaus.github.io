#include "gameStructs.h"



SpriteEntry sprites[128];
SpriteEntry sprites_sub[128];

struct spriteStruct * mSprites = (struct spriteStruct *)sprites;
struct spriteStruct * mSprites_sub = (struct spriteStruct *)sprites_sub;

struct playerInfoTag playerInfo;

void resetPlayerInfo()
{
	//Sets all the default values
	playerInfo.maxHp = 30;
	playerInfo.gold = 50;
	
	for(int i = 0; i < 16; i++)
	{
		playerInfo.items[i] = 0;
	}
	
	playerInfo.attackSlots = 1;
	playerInfo.towerLevel = 0;
	
	for(int i = 0; i < 18; i++)
	{
		playerInfo.events[i] = false;
	}
	
	playerInfo.leftHandItem = 12;
	playerInfo.rightHandItem = 12;
	playerInfo.exp = 0;
	playerInfo.level = 1;
	
	for(int i = 0; i < 5; i++)
	{
		playerInfo.basicStats[i] = 3;
	}
	
	playerInfo.statsUp = 5;
	playerInfo.currentTown = 0;
}

//turn off all the sprites
void initSprites(void)
{
	for(int i = 0; i < 128; i++)
	{
	//Move the sprite offscreen
	   sprites[i].attribute[0] = 192;
	   sprites[i].attribute[1] = 0;
	   sprites[i].attribute[2] = 0;
	   sprites[i].attribute[3] = 0;
	   sprites_sub[i].attribute[0] = 192;
	   sprites_sub[i].attribute[1] = 0;
	   sprites_sub[i].attribute[2] = 0;
	   sprites_sub[i].attribute[3] = 0;
    }
}

//copy our sprite to object attribute memory
void updateOAM(void)
{
	for(unsigned int cnt_subs = 0; cnt_subs < 128 * sizeof(SpriteEntry) / 4 ; cnt_subs++)
	{
		((uint32*)OAM_SUB)[cnt_subs] = ((uint32*)sprites_sub)[cnt_subs];
		((uint32*)OAM)[cnt_subs] = ((uint32*)sprites)[cnt_subs];
	}

}

void updateOAMSub(void)
{
	for(unsigned int cnt_subs = 0; cnt_subs < 128 * sizeof(SpriteEntry) / 4 ; cnt_subs++)
	{
		((uint32*)OAM_SUB)[cnt_subs] = ((uint32*)sprites_sub)[cnt_subs];
	}
}

void updateOAMMain(void)
{
	for(unsigned int cnt_subs = 0; cnt_subs < 128 * sizeof(SpriteEntry) / 4 ; cnt_subs++)
	{
		((uint32*)OAM)[cnt_subs] = ((uint32*)sprites)[cnt_subs];
	}

}

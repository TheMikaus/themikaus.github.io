#include <NDS.h>
#include "font.h"
#include "dialog.h"
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
int exitDialog(uint16 * bmap, uint16 * fmap, int DialogStart, int FontStart)
{
	int choice = 0;
	
	//Setup the dialog
	drawDBox(bmap, DialogStart, 0, 0, 31, 23);
	
	//Draw the three messages
	printText16("Do you want to exit?", fmap, 5, 3, FontStart, 20);
	printText16("Yes", fmap, 3, 15, FontStart, 3);
	printText16("No", fmap, 25, 15, FontStart, 2);

	while(true)
	{
		if(TOUCH_SCREEN)
		{
			int tile_x = IPC->touchXpx / 8;
			int tile_y = IPC->touchYpx / 8;
			
			if(tile_y >= 15 && tile_y <= 17)
			{
				if(tile_x >=3 && tile_x <= 8)
				{
					choice = -1;
					break;
				}
				else if(tile_x >= 25 && tile_x <= 28)
				{
					choice = 0;
					break;
				}
			}
		}
	}
	
	//Clear the maps
	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			bmap[cnt_y * 32 + cnt_x] = 0;
			fmap[cnt_y * 32 + cnt_x] = 0;
		}
	}
	return choice;
}

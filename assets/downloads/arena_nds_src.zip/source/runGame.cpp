#include <stdio.h>

#include <NDS.h>
#include <NDS/ARM9/console.h> //basic print funcionality

#include <stdlib.h>

#define abs(x) (((x)<0)?(-(x)):((x)))

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//
//
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
#define TOUCH_X (IPC->touchX / 14)
#define TOUCH_Y (IPC->touchY / 18 - 12)

#define TOUCH_2X (IPC->touchX / 7)
#define TOUCH_2Y (IPC->touchY / 9 - 24)

#define REG_VCOUNT *(vu16*)0x4000006		//Our good old vblank counter 

#include "font.h"
#include "Fade.h"
#include "gamestructs.h"

extern void runTown(int town);
extern int runWorld(int town, bool subFade);
extern void runTower();
extern bool playerDead;
extern void saveLoadDialog(bool load, uint16 * bmap, uint16 * fmap, int DialogStart, int FontStart);


void runGame()
{
	uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * map3 = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);

	volatile int menu = 0;
	bool subOnly = false;
	playerDead = false;
	while(true)
	{
		menu = runWorld(menu, subOnly);
		subOnly = true;
		if(menu == -1)
		{
			return;
		}
		else if(menu == 2)
		{
			if(playerInfo.currentTown == 3)
			{
				runTower();
				subOnly = false;
			}
			else
			{
				
				fade_outSub(125,100);
				runTown(playerInfo.currentTown);
			}
			
			if(playerDead)
			{
				return;
			}
		}
		else if(menu == 3)
		{
			fade_outSub(125,100);
			saveLoadDialog(false, map2, map3, 2, 12);
			subOnly = true;
		}
	}
	
}

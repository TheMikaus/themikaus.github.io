#include <NDS.h>
#define REG_VCOUNT *(vu16*)0x4000006		//Our good old vblank counter 

#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))

#include "splashLogo.tile"

#include "splashsub.h"
#include "subScreen2.h"

#include "touch.tile"
#include "touch2.tile"

#include <stdlib.h>

#define READ_KEYS (~REG_KEYINPUT )

#include "fade.h"
void runNeoSplash()
{
  videoSetMode(MODE_0_2D | DISPLAY_BG0_ACTIVE );
  videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE );
	
  vramSetMainBanks(VRAM_A_MAIN_BG, VRAM_B_MAIN_SPRITE, VRAM_C_SUB_BG, VRAM_D_SUB_SPRITE);

  //Make both the top and the bottom maps 256 color screens
  BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(2);
  SUB_BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(1);

 //get the maps
  uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK(29);
  uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
 
  //Copy the needed palette info
  dmaCopy((uint16*)neosplashPal, (uint16 *)BG_PALETTE, 256 * 2);
  dmaCopy((uint16*)neosplashPal, (uint16 *)BG_PALETTE_SUB, 256 * 2);
  
  //Copy the needed tile info
  dmaCopy((uint16*)neosplashTile,(uint16 *)CHAR_BASE_BLOCK(4), 50176);
  dmaCopy((uint16*)neosplashTile,(uint16 *)CHAR_BASE_BLOCK_SUB(4), 50176);
  
  //Copy the maps I need
  int c= 0;
  
  for(int y = 0; y < 24; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map1[y * 32 + x] = c;
		map0[y*32 + x] = c++;
	}
  }

  
  fade_in(125,100);
  
  while(!TOUCH_SCREEN && READ_KEYS)
  {
	rand();
  }
  
  
  swiWaitForVBlank();
  
  fade_out(125,3500);
}

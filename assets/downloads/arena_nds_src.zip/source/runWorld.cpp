#define CONTROL_QUIT -1
#define CONTROL_ENTERTOWN 1

#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))

#include <NDS.h>
#include "gameStructs.h"
#include "images/worldMap.h"
#include "fade.h"
#include "font.h"
#include "blacktile.tile"
#include "dialog.h"
#include "images/WorldMapSprites.h"
#include "images/WorldMapBottomSprites.h"
#include <stdio.h>
#include "sound.h"

#define READ_KEYS (~REG_KEYINPUT)
bool playerDead = false;

//Define the town locations and constant strings here
const int townLocations[] = { 36,40, 108,28, 184,24, 132, 76,
				200,88, 20, 152, 72,124, 168,140, 224,132 };

const char * townNames[] = { "   Lubdar   ", "Rowinsville ", "Aori Village",
						"Lot's Tower ", "  Durrick   ", "   Gabria   ", 
						"Cedar  Point", "   Scenny   ", "  Akentor   "};

const char * displayItems[] = {   "D - 10 ",
									"D - 25 ",
									"D - 50 ",
									"D - 100",
									"S - 10 ",
									"S - 25 ",
									"S - 50 ",
									"S - 100",
									"H - 10 ",
									"H - 25 ",
									"H - 50 ",
									"H - 100",
									"no item"};

void displayTownName()
{
	printText16(townNames[playerInfo.currentTown], (uint16*)SCREEN_BASE_BLOCK(31), 10, 1, 1,12);
}

void setTownUp(int old, int newt)
{
	mSprites[old].name = 0;
	mSprites[newt].name = 2;
}

int lastKeyDown = 0;

void setUpButtons(uint16 * map)
{
	drawDBox(map, 2, 3, 0, 4, 4);
	drawDBox(map, 2, 13, 0, 5, 4);
	drawDBox(map, 2, 24, 0, 4, 4);
	
	mSprites_sub[0].name = 32;
	mSprites_sub[0].color_256 = 1;
	mSprites_sub[0].x = 28;
	mSprites_sub[0].y = 4;
	mSprites_sub[0].size = 2;
	
	
	mSprites_sub[1].name = 0;
	mSprites_sub[1].color_256 = 1;
	mSprites_sub[1].x = 112;
	mSprites_sub[1].y = 4;
	mSprites_sub[1].size = 2;
	
	
	mSprites_sub[2].name = 64;
	mSprites_sub[2].color_256 = 1;
	mSprites_sub[2].x = 197;
	mSprites_sub[2].y = 4;
	mSprites_sub[2].size = 2;


	mSprites_sub[3].name = 96;
	mSprites_sub[3].color_256 = 1;
	mSprites_sub[3].x = 138;
	mSprites_sub[3].y = 70;
	mSprites_sub[3].size = 1;
	mSprites_sub[3].priority = 1;
	
	mSprites_sub[4].name = 104;
	mSprites_sub[4].color_256 = 1;
	mSprites_sub[4].x = 218;
	mSprites_sub[4].y = 70;
	mSprites_sub[4].size = 1;
	mSprites_sub[4].priority = 1;

	mSprites_sub[5].name = 96;
	mSprites_sub[5].color_256 = 1;
	mSprites_sub[5].x = 138;
	mSprites_sub[5].y = 32 + 70;
	mSprites_sub[5].size = 1;
	mSprites_sub[5].priority = 1;
	
	mSprites_sub[6].name = 104;
	mSprites_sub[6].color_256 = 1;
	mSprites_sub[6].x = 218;
	mSprites_sub[6].y = 32 + 70;
	mSprites_sub[6].size = 1;
	mSprites_sub[6].priority = 1;
	
	updateOAMSub();
}

void hideButtons()
{
	mSprites_sub[2].y = 192;
	mSprites_sub[1].y = 192;
	mSprites_sub[0].y = 192;
	updateOAMSub();
}

int runMapTop()
{
  //Check the keys
  //Move the town spot
  //Update OAM
  int displayName = 0;
  
  if(READ_KEYS & KEY_UP || ~IPC->buttons & IPC_X)
  {

    if(lastKeyDown == 0)
	{
	    playSound(snd_click);
		lastKeyDown = READ_KEYS & KEY_UP || ~IPC->buttons & IPC_X;
		if(playerInfo.currentTown == 0)
		{
			playerInfo.currentTown = 5;
			setTownUp(0,5);
		}
		else if(playerInfo.currentTown == 5)
		{
			playerInfo.currentTown = 0;
			setTownUp(5,0);
		}
		else if(playerInfo.currentTown == 1)
		{
			playerInfo.currentTown = 6;
			setTownUp(1,6);
		}
		else if(playerInfo.currentTown == 6)
		{
			playerInfo.currentTown = 3;
			setTownUp(6,3);
		}
		else if(playerInfo.currentTown == 3)
		{
			playerInfo.currentTown = 1;
			setTownUp(3,1);
		}
		else if(playerInfo.currentTown == 7)
		{
			playerInfo.currentTown = 3;
			setTownUp(7,3);
		}
		else if(playerInfo.currentTown == 2)
		{
			playerInfo.currentTown = 8;
			setTownUp(2,8);
		}
		else if(playerInfo.currentTown == 8)
		{
			playerInfo.currentTown = 4;
			setTownUp(8,4);
		}
		else if(playerInfo.currentTown == 4)
		{
			playerInfo.currentTown = 2;
			setTownUp(4,2);
		}
		displayName = 1;
	}
  }
  else if(READ_KEYS & KEY_DOWN || READ_KEYS & KEY_B)
  {
  
    if(lastKeyDown == 0)
	{
	playSound(snd_click);
		lastKeyDown = READ_KEYS & KEY_DOWN || READ_KEYS & KEY_B;
		if(playerInfo.currentTown == 0)
		{
			playerInfo.currentTown = 5;
			setTownUp(0,5);
		}
		else if(playerInfo.currentTown == 5)
		{
			playerInfo.currentTown = 0;
			setTownUp(5,0);
		}
		else if(playerInfo.currentTown == 1)
		{
			playerInfo.currentTown = 3;
			setTownUp(1,3);
		}
		else if(playerInfo.currentTown == 3)
		{
			playerInfo.currentTown = 6;
			setTownUp(3,6);
		}
		else if(playerInfo.currentTown == 6)
		{
			playerInfo.currentTown = 1;
			setTownUp(6,1);
		}
		else if(playerInfo.currentTown == 2)
		{
			playerInfo.currentTown = 4;
			setTownUp(2,4);
		}
		else if(playerInfo.currentTown == 4)
		{
			playerInfo.currentTown = 8;
			setTownUp(4,8);
		}
		else if(playerInfo.currentTown == 8)
		{
			playerInfo.currentTown = 2;
			setTownUp(8,2);
		}
		displayName = 1;
	}
  }
  else if(READ_KEYS & KEY_LEFT || ~IPC->buttons & IPC_Y)
  {
  
	if(lastKeyDown == 0)
	{
	playSound(snd_click);
		lastKeyDown = READ_KEYS & KEY_LEFT || ~IPC->buttons & IPC_Y; 
		if(playerInfo.currentTown == 0)
		{
			playerInfo.currentTown = 2;
			setTownUp(0,2);
		}
		else if(playerInfo.currentTown == 2)
		{
			playerInfo.currentTown = 1;
			setTownUp(2,1);
		}
		else if(playerInfo.currentTown == 1)
		{
			playerInfo.currentTown = 0;
			setTownUp(1,0);
		}
		else if(playerInfo.currentTown == 3)
		{
			playerInfo.currentTown = 4;
			setTownUp(3,4);
		}
		else if(playerInfo.currentTown == 4)
		{
			playerInfo.currentTown = 3;
			setTownUp(4,3);
		}
		else if(playerInfo.currentTown == 5)
		{
			playerInfo.currentTown = 8;
			setTownUp(5,8);
		}
		else if(playerInfo.currentTown == 8 )
		{
			playerInfo.currentTown = 7;
			setTownUp(8,7);
		}
		else if(playerInfo.currentTown == 7)
		{
			playerInfo.currentTown = 6;
			setTownUp(7,6);
		}
		else if(playerInfo.currentTown == 6)
		{
			playerInfo.currentTown = 5;
			setTownUp(6,5);
		}
		displayName = 1;
	}
  }
  else if(READ_KEYS & KEY_RIGHT || READ_KEYS & KEY_A)
  {
  
    if(lastKeyDown == 0)
	{
	playSound(snd_click);
		lastKeyDown = READ_KEYS & KEY_RIGHT || READ_KEYS & KEY_A;
		if(playerInfo.currentTown == 0)
		{
			playerInfo.currentTown = 1;
			setTownUp(0,1);
		}
		else if(playerInfo.currentTown == 1)
		{
			playerInfo.currentTown = 2;
			setTownUp(1,2);
		}
		else if(playerInfo.currentTown == 2)
		{
			playerInfo.currentTown = 0;
			setTownUp(2,0);
		}
		else if(playerInfo.currentTown == 3)
		{
			playerInfo.currentTown = 4;
			setTownUp(3,4);
		}
		else if(playerInfo.currentTown == 4)
		{
			playerInfo.currentTown = 3;
			setTownUp(4,3);
		}
		else if(playerInfo.currentTown == 5)
		{
			playerInfo.currentTown = 6;
			setTownUp(5,6);
		}
		else if(playerInfo.currentTown == 6)
		{
			playerInfo.currentTown = 7;
			setTownUp(6,7);
		}
		else if(playerInfo.currentTown == 7)
		{
			playerInfo.currentTown = 8;
			setTownUp(7,8);
		}
		else if(playerInfo.currentTown == 8)
		{
			playerInfo.currentTown = 5;
			setTownUp(8,5);
		}
		displayName = 1;
	}
  }
  else
  {
	lastKeyDown = 0;
  }
  
  return displayName;
}

void initMapTop()
{
	//Set the video modes and load the palettes
	videoSetMode(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE);
	
	BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(3);
	BG1_CR = BG_COLOR_256 | BG_32x32 | (30 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(2);
	BG2_CR = BG_COLOR_256 | BG_32x32 | (31 << SCREEN_SHIFT) | (7 << CHAR_SHIFT) | BG_PRIORITY(1);	
	//The last background will have a priority of 0
  
//Setup top
	dmaCopy((uint16 *)worldMapPal, BG_PALETTE, 256 * 2);

//First load the Map ground	
    dmaCopy((uint16 *)blanktile,(uint16*)CHAR_BASE_BLOCK(4), 64);
	dmaCopy((uint16 *)worldMapDialogTiles, (uint16 *)(CHAR_BASE_BLOCK(4) + 64), 640);
	dmaCopy((uint16 *)Map_150, (uint16*) (CHAR_BASE_BLOCK(4) + 704), 40320);
	loadFont16((unsigned short *)CHAR_BASE_BLOCK(7) , worldMapFontSet,blanktile);
  
	uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK(29);
	uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK(30);
	uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK(31);

	int c = 11;
	
	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			map1[cnt_y*32+cnt_x] = 0;
			map2[cnt_y*32+cnt_x] = 0;
			map0[cnt_y*32+cnt_x] = 1;
		}
	}
	
	for(int cnt_y = 2; cnt_y < 23; cnt_y++)
	{
		for(int cnt_x = 1; cnt_x < 31; cnt_x++)
		{
			map0[cnt_y*32+cnt_x] = c++;
		}
	}

	drawDBox(map1, 2, 3, 0, 25, 3);	

	initSprites();
	dmaCopy((uint16 *)citySpritePal,(uint16*)SPRITE_PALETTE,256*2);

	dmaCopy((uint16 *)city1Sprite,(uint16*)SPRITE_GFX, 64);
	
	dmaCopy((uint16 *)city2Sprite,(uint16*)(SPRITE_GFX + 32),64);
	
	for(int cnt_towns = 0; cnt_towns < 9; cnt_towns++)
	{
		mSprites[cnt_towns].x = townLocations[cnt_towns*2] + 4;
		mSprites[cnt_towns].y = townLocations[cnt_towns*2 + 1] + 12;
		mSprites[cnt_towns].color_256 = 1;
		mSprites[cnt_towns].priority = 1;
	}

	mSprites[playerInfo.currentTown].name=2;
	swiWaitForVBlank();
	updateOAM();
	displayTownName();
}




void displaySelectedItems(uint16 * map)
{
	//Display the correct text
	printText16(displayItems[playerInfo.leftHandItem], map,  19, 9, 12, 7);
	
	printText16(displayItems[playerInfo.rightHandItem], map, 19, 13, 12, 7);
}

const char * statnames[] = { "atk", "agi", "def", "spd", "for" };

void displayStats(uint16 * map)
{
	char holder[4];
	int cnt;
	
	for(int cnt_stats = 0; cnt_stats < 5; cnt_stats++)
	{
		printText16(statnames[cnt_stats], map, 4 + cnt_stats * 5, 17, 12, 3);
		
		cnt=sprintf(holder,"%d",playerInfo.basicStats[cnt_stats]);
		if(cnt == 1)
		{
		    printText16("  ",map,4 + cnt_stats*5, 19,12 ,2);
			printText16(holder, map, 5 + cnt_stats * 5, 19, 12, 1);
		}
		else if (cnt == 2)
		{
			printText16(" ",map,4 + cnt_stats*5, 19,12 ,1);
			printText16(holder, map, 5 + cnt_stats * 5, 19, 12, 2);
		}
		else
		{
			printText16(holder, map, 4 + cnt_stats * 5, 19, 12, 3);
		}
	}
	
	
}

void displayPlayerInfo(uint16 * map)
{
	char holder[20];
	int cnt_write = 0;
	
	
	//playerInfo.nameLength = sprintf(playerInfo.name,"Testtest");	
	
	printText16(playerInfo.name, map, 3, 7, 12, playerInfo.nameLength);
	
	cnt_write = sprintf(holder,"Level %d", playerInfo.level);
	printText16(holder,map,3,9,12,cnt_write);
	
	cnt_write = sprintf(holder, "Exp. %d", playerInfo.exp);
	printText16(holder,map,3,11,12,cnt_write);
	
	cnt_write = sprintf(holder, "Gold %d", playerInfo.gold);
	printText16(holder,map,3,13,12,cnt_write);
	
	//Display Stats accross the bottom
	displayStats(map);
	//Display Items that are selected
	displaySelectedItems(map);
}

void initBottomSaveScreen()
{
//Set the video modes and load the palettes
	videoSetModeSub(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE | DISPLAY_BG3_ACTIVE);

//Not sure what the char shifts need to be at yet.	
	SUB_BG0_CR = BG_COLOR_256 | BG_32x32 | (28 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(3);
	SUB_BG1_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(2);
	SUB_BG2_CR = BG_COLOR_256 | BG_32x32 | (30 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(1);	
	SUB_BG3_CR = BG_COLOR_256 | BG_32x32 | (31 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(0);	
  
//Setup top
	dmaCopy((uint16 *)worldMapPal, BG_PALETTE_SUB, 256 * 2);

//First load the Map ground	
    dmaCopy((uint16 *)blanktile,(uint16*)CHAR_BASE_BLOCK_SUB(4), 64);
	dmaCopy((uint16 *)worldMapDialogTiles, (uint16 *)(CHAR_BASE_BLOCK_SUB(4) + 64), 640);
	
	loadFont16((unsigned short *) (CHAR_BASE_BLOCK_SUB(4) + 704), worldMapFontSet, blanktile);

  
	uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK_SUB(28);
	uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
	uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * map3 = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);
	

	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			map0[cnt_y*32+cnt_x] = 1;
			map1[cnt_y*32+cnt_x] = 0;
			map2[cnt_y*32+cnt_x] = 0;
			map3[cnt_y*32+cnt_x] = 0;
		}
	}
	
	
	for(int cnt_sprites = 0; cnt_sprites < 128; cnt_sprites++)
	{
		mSprites_sub[cnt_sprites].y = 196;
	}
	updateOAMSub();
}

void initBottomWorldScreen()
{
//Set the video modes and load the palettes
	videoSetModeSub(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE | DISPLAY_BG3_ACTIVE);

//Not sure what the char shifts need to be at yet.	
	SUB_BG0_CR = BG_COLOR_256 | BG_32x32 | (28 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(3);
	SUB_BG1_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(2);
	SUB_BG2_CR = BG_COLOR_256 | BG_32x32 | (30 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(1);	
	SUB_BG3_CR = BG_COLOR_256 | BG_32x32 | (31 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(0);	
  
//Setup top
	dmaCopy((uint16 *)worldMapPal, BG_PALETTE_SUB, 256 * 2);

//First load the Map ground	
    dmaCopy((uint16 *)blanktile,(uint16*)CHAR_BASE_BLOCK_SUB(4), 64);
	dmaCopy((uint16 *)worldMapDialogTiles, (uint16 *)(CHAR_BASE_BLOCK_SUB(4) + 64), 640);
	
	loadFont16((unsigned short *) (CHAR_BASE_BLOCK_SUB(4) + 704), worldMapFontSet, blanktile);

  
	uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK_SUB(28);
	uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
	uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * map3 = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);
	

	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			if(cnt_x > 2 && cnt_x < 30 && cnt_y > 2 && cnt_y < 21)
			{
				map0[cnt_y*32 + cnt_x] = 6;
			}
			else
			{
				map0[cnt_y*32+cnt_x] = 1;
			}
			
			map1[cnt_y*32+cnt_x] = 0;
			map2[cnt_y*32+cnt_x] = 0;
			map3[cnt_y*32+cnt_x] = 0;
		}
	}
	
	
	
	
	//Load the sprites now.
	//So far I know I have three
	dmaCopy((uint16 *)worldMapBottomSpritesPal, SPRITE_PALETTE_SUB, 256 * 2);
	dmaCopy((uint16 *)worldMapBottomSprites, SPRITE_GFX_SUB, 3584);
	
	drawDBox(map1, 2, 1, 2, 29, 20);
	setUpButtons(map2);
	displayPlayerInfo(map1);
}

extern int exitDialog(uint16 * bmap, uint16 * fmap, int DialogStart, int FontStart);

int noitems()
{
	for(int cnt_items = 0; cnt_items < 12; cnt_items++)
	{
		if(playerInfo.items[cnt_items] > 0)
		{
			return 0;
		}
	}
	
	return 1;
}


int nextDecItem(unsigned short item)
{
	if(noitems())
	{
		return 12;
	}
	
	do
	{
		if(item == 0)
		{
			item = 11;
		}
		else
		{
			item--;
		}
	}
	while(playerInfo.items[item] == 0);
	
	return item;
}

int nextIncItem(unsigned short item)
{
	if(noitems())
	{
		return 12;
	}
	
	do
	{
		if(item >= 11)
		{
			item = 0;
		}
		else
		{
			item++;
		}
	}
	while(playerInfo.items[item] == 0);
	
	return item;
}

extern void saveLoadDialog(bool load, uint16 * bmap, uint16 * fmap, int DialogStart, int FontStart);

int runMapBottom()
{
	int choice = 0;
	int tile_x, tile_y;
	int touch_x, touch_y;
	
	uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
	uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * map3 = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);


	static s8 touched = true;
	if(TOUCH_SCREEN)
	{
		if(touched) 
		{
			if(choice == -1)
			{
				while(TOUCH_SCREEN);
			}
			return choice;
		}
		touched = true;
		//Get the x and y coordinates
		touch_x = IPC->touchXpx;
		touch_y = IPC->touchYpx ;
		tile_x = touch_x / 8;
		tile_y = touch_y / 8;
		
		if(tile_y >= 0 && tile_y <= 4)
		{
			if(tile_x >= 3 && tile_x <= 7)
			{
				//Call the save game routine
				choice = 3; // 3 means load game
				playSound(snd_click);
			}
			else if(tile_x >= 13 && tile_x <=18)
			{
				choice = 2; // 2 means enter the town
				playSound(snd_click);
			}
			else if(tile_x >= 24 && tile_x <= 27)
			{
				//Call the dialog box routine
				//If the return value == 1 then choice = 1
				playSound(snd_click);
				hideButtons();
				for(int cnt_sprites = 3; cnt_sprites < 7; cnt_sprites++)
				{
					mSprites_sub[cnt_sprites].priority=3;
				}
				updateOAMSub();
				choice = exitDialog(map2, map3, 2, 12);
				playSound(snd_click);
				setUpButtons(map2);
				for(int cnt_sprites = 3; cnt_sprites < 7; cnt_sprites++)
				{
					mSprites_sub[cnt_sprites].priority=1;
				}
				updateOAMSub();
			}
		}
		else if(touch_y >= 68 && touch_y <= 104)
		{
			if(touch_x >= 132 && touch_x <= 184)
			{
				playerInfo.leftHandItem = nextDecItem(playerInfo.leftHandItem );
				displayPlayerInfo(map1);
				playSound(snd_back);
			}
			else if(touch_x >= 214 && touch_x <= 254)
			{
				playerInfo.leftHandItem = nextIncItem(playerInfo.leftHandItem );
				displayPlayerInfo(map1);
				playSound(snd_back);
			}
		}
		else if(touch_y >= 98 && touch_y <= 136)
		{
			if(touch_x >= 132 && touch_x <= 184)
			{
				playerInfo.rightHandItem = nextDecItem(playerInfo.rightHandItem);
				displayPlayerInfo(map1);
				playSound(snd_back);
			}
			else if(touch_x >= 214 && touch_x <= 254)
			{
				playerInfo.rightHandItem = nextIncItem(playerInfo.rightHandItem);
				displayPlayerInfo(map1);
				playSound(snd_back);
			}
		}
	}
	else
	{
		touched = false;
	}
	
	
	
	return choice;
}

int runWorld(int town, bool subFade)
{

	lastKeyDown = 0;
	initMapTop();
	initBottomWorldScreen();
	
	int topValue = 0;
	int controlValue = 0;
	
	if(!subFade)
	{
		fade_in(125,100);
	}
	else
	{
		fade_inSub(125,100);
		videoSetMode(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE);
	}
	
	while(true)
	{
		topValue = runMapTop();
		controlValue = runMapBottom();
		if(playerDead)
		{
			return -1;
		}
		
		if(controlValue != 0)
		{
			return controlValue;
		}
		
		swiWaitForVBlank();
		if(runMapTop())
		{
			displayTownName();
			updateOAMMain();
		}
	}
	return 0;
}

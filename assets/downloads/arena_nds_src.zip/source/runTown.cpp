#include <NDS.h>
#include "gameStructs.h"
#include "images/townSprites.h"
#include "fade.h"
#include "font.h"
#include "blacktile.tile"
#include "dialog.h"
#include <stdio.h>
#include <string.h>
#include "sound.h"

#define TOWN_SHOPPING 0
#define TOWN_TAVERN 1
#define TOWN_ARENA 2
#define TOWN_RETURN 4
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
extern bool playerDead;
extern int runDuel();

extern void initBackground(int sel, bool fadein);

typedef void (* townFunc)();
#include "enemyStats.h"

const char * levelUpText = "You leveled Up!";
const char * SlotUpText = "   You gained an\n    extra attack!";

char displayText = 1;

const int giverItems[] = { Item_Damage25, 
							Item_Health25, 
							Item_Shield25, 
							0,
							Item_Damage50,
							Item_Health50,
							Item_Shield50,
							Item_Health25,
							Item_Shield25 };
							

//Should be 9 talker dialogs
const char * talkerDialog[] = 		{ 	"Always meet a charge\n  with a back step",
										"Always charge at one\n  that stands still",
										"Some combinations of\n attacks reduce dmg",
										"",
										"You only get better \n    if you fight",
										"8 warriors await at \n     Lot's Tower",
										"Defeat Lot to gain  \n   control of Alia",
										"Alia is the land you\n      stand on",
										"Collect augmentation\n  items from duelers" };

const char * giverDialog[] =		{	"Please take this item\n   it will aid you",
										"I have given you all \n      that I can."};
										
const char * duelerDialog[] =		{	"You wish to take what\n is mine.  Die!",
										"You took what I have\n\nLeave me."};

const char * itemDescriptions[] = {	"Damage 10-P for 25  ",
										"Damage 25-P for 50  ",
										"Damage 50-P for 75  ",
										"Damage 100-P for 100",
										"Shield 10-P for 25  ",
										"Shield 25-P for 50  ",
										"Shield 50-P for 75  ",
										"Shield 100-P for 100",
										"Health 10-P for 25  ",
										"Health 25-P for 50  ",
										"Health 50-P for 75  ",
										"Health 100-P for 100" };

const char Tavern_welcomeText[] = " Welcome to my Tavern\n\nHope you enjoy yourself\ntry not to start a fight";

bool givePlayerStats(int type)
{
	if(playerInfo.basicStats[PLAYER_ATTACK] < enemyStats[ENEMY_ATTACK] &&
		playerInfo.basicStats[PLAYER_ATTACK] < 255)
		{
			playerInfo.basicStats[PLAYER_ATTACK]++;
		}
	
	if(playerInfo.basicStats[PLAYER_AGILITY] < enemyStats[ENEMY_AGILITY] &&
		playerInfo.basicStats[PLAYER_AGILITY] < 255)
		{
			playerInfo.basicStats[PLAYER_AGILITY]++;
		}
		
	if(playerInfo.basicStats[PLAYER_SPEED] < enemyStats[ENEMY_SPEED] &&
		playerInfo.basicStats[PLAYER_SPEED] < 255)
		{
			playerInfo.basicStats[PLAYER_SPEED]++;
		}
	
	if(playerInfo.basicStats[PLAYER_DEFENSE] < enemyStats[ENEMY_DEFENSE] &&
		playerInfo.basicStats[PLAYER_DEFENSE] < 255)
		{
			playerInfo.basicStats[PLAYER_DEFENSE]++;
		}
		
	if(playerInfo.basicStats[PLAYER_FORESIGHT] < enemyStats[PLAYER_FORESIGHT] &&
		playerInfo.basicStats[PLAYER_FORESIGHT] < 255)
		{
			playerInfo.basicStats[PLAYER_FORESIGHT]++;
		}
		
	if(type == 0)
	{
		playerInfo.exp += 10;
		playerInfo.gold += 15;
	}
	else if(type == 1)
	{
		playerInfo.exp += 20;
		playerInfo.gold += 30;
	}
	else if(type == 2)
	{
		playerInfo.exp += 30;
		playerInfo.gold += 50;
	}
	
	if(playerInfo.exp >= 100)
	{
		playerInfo.exp -= 100;
		return true;
	}
	
	return false;
}

void clearMaps()
{
//swiWaitForVBlank();
    uint16 * smap2 = (uint16*)SCREEN_BASE_BLOCK_SUB(29);
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			smap0[cnt_y*32 + cnt_x] = smap1[cnt_y*32 + cnt_x] = 0;
		}
	}
	
	for(int cnt_y = 4; cnt_y < 18; cnt_y++)
	{
		for(int cnt_x = 5; cnt_x < 28; cnt_x++)
		{
			smap2[cnt_y * 32 + cnt_x ] = 0;
		}
	}
	
	drawDBox(smap0, 2, 3, 0, 4, 4);
	drawDBox(smap0, 2, 13, 0, 5, 4);
	drawDBox(smap0, 2, 24, 0, 4, 4);
}

int runDialog(int selection)
{
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	
	// swiWaitForVBlank();
	
	
	int dialogResult = -1;
	drawDBox(smap0, 2, 4, 6, 23, 10);
	//Draw the text
	//Item for x
	printText16(itemDescriptions[selection], smap1, 5, 7, 12, 20);
	//Do you wish to purchase (one line)
	printText16("Do you want to buy?", smap1, 6, 9, 12 , 19);
	//Yes, No
	printText16("Yes",smap1, 6, 13,12,3);
	printText16("No",smap1, 23, 13, 12, 2);
	
	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			int tile_x = IPC->touchXpx / 8;
			int tile_y = IPC->touchYpx / 8;
			
			if(tile_y >= 11 && tile_y <= 14)
			{
				if(tile_x >= 5 && tile_x <= 10)
				{
					dialogResult = 1;
					break;
				}
				
				if(tile_x >= 22 && tile_x <=26)
				{
					dialogResult = 0;
					break;
				}
			}
		}
		else
		{
			touched = false;
		}
	}
	
	
	swiWaitForVBlank();
	
	for(int cnt_y = 6; cnt_y < 17; cnt_y++)
	{
		for(int cnt_x = 2; cnt_x < 28; cnt_x++)
		{
			smap0[cnt_x + cnt_y*32] = smap1[cnt_x + cnt_y * 32] = 0;
		}
	}
	
	playSound(snd_click);
	return dialogResult;
}

void displayTavern();

int runTalkerDialog()
{
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	// swiWaitForVBlank();
	clearMaps();
	drawDBox(smap0,2, 3,6,25,11);
	
	int dialogResult = -1;
	
	
	//Draw the text
	printText16(talkerDialog[playerInfo.currentTown], smap1, 5, 7, 12, strlen(talkerDialog[playerInfo.currentTown]));

	printText16("Tap to continue",smap1, 7, 14, 12, 15);
	
	drawDBox(smap0, 2, 3, 19, 4, 4);
	drawDBox(smap0, 2, 13, 19, 5, 4);
	drawDBox(smap0, 2, 24, 19, 4, 4);

	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			break;
		}
		else
		{
			touched = false;
		}
	}
	playSound(snd_click);
	
	
	// swiWaitForVBlank();
	displayText = 1;
	displayTavern();
	
	return dialogResult;
}

void runLevelUpDialog()
{
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	// swiWaitForVBlank();
	clearMaps();
	drawDBox(smap0,2, 3,6,25,11);
	playSound(snd_theAttackUp);
	//Draw the text
	printText16(levelUpText, smap1, 8, 7, 12, strlen(levelUpText));

	printText16("Tap to continue",smap1, 7, 14, 12, 15);
	
	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			break;
		}
		else
		{
			touched = false;
		}
	}
	playSound(snd_click);
	
	
	swiWaitForVBlank();
}

void runSlotUpDialog()
{
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	 swiWaitForVBlank();
	clearMaps();
	drawDBox(smap0,2, 3,6,25,11);
	
	//Draw the text
	printText16(SlotUpText, smap1, 5, 7, 12, strlen(SlotUpText));
	playSound(snd_theAttackUp);
	printText16("Tap to continue",smap1, 7, 14, 12, 15);
	
	drawDBox(smap0, 2, 3, 19, 4, 4);
	drawDBox(smap0, 2, 13, 19, 5, 4);
	drawDBox(smap0, 2, 24, 19, 4, 4);

	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			break;
		}
		else
		{
			touched = false;
		}
	}
	playSound(snd_click);
	
	
	swiWaitForVBlank();
		
	displayText = 1;
	displayTavern();
}


int runGiverDialog()
{
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	 swiWaitForVBlank();
	clearMaps();
	drawDBox(smap0,2, 3,6,25,11);
	
	int dialogResult = -1;
	
	if(playerInfo.events[playerInfo.currentTown * 2] == 0)
	{
		playSound(snd_theAttackUp);
	}
	
	//Draw the text
	printText16(giverDialog[playerInfo.events[playerInfo.currentTown*2]], smap1, 5, 7, 12, strlen(giverDialog[playerInfo.events[playerInfo.currentTown*2]]));

	printText16("Tap to continue",smap1, 7, 14, 12, 15);
	
	if(playerInfo.events[playerInfo.currentTown*2] == 0)
	{
		playerInfo.events[playerInfo.currentTown*2] = 1;
		playerInfo.items[giverItems[playerInfo.currentTown]]++;
		if(playerInfo.items[giverItems[playerInfo.currentTown]] > 9)
		{
			playerInfo.items[giverItems[playerInfo.currentTown]] = 9;
		}
	}
	
	drawDBox(smap0, 2, 3, 19, 4, 4);
	drawDBox(smap0, 2, 13, 19, 5, 4);
	drawDBox(smap0, 2, 24, 19, 4, 4);

	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			break;
		}
		else
		{
			touched = false;
		}
	}
	playSound(snd_click);
	
	
	 swiWaitForVBlank();
	
	displayText = 1;
	displayTavern();
	
	return dialogResult;
}

int runDuelerDialog()
{
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	swiWaitForVBlank();
	clearMaps();
	drawDBox(smap0,2, 3,6,25,11);
	
	int dialogResult = -1;
	
	
	//Draw the text
	printText16(duelerDialog[playerInfo.events[playerInfo.currentTown*2 + 1]], smap1, 5, 7, 12, strlen(duelerDialog[playerInfo.events[playerInfo.currentTown*2 + 1]]));
	
	if(playerInfo.events[playerInfo.currentTown*2 + 1] == 0)
	{
		playSound(snd_attack);
	}
	
	printText16("Tap to continue",smap1, 7, 14, 12, 15);

	
	drawDBox(smap0, 2, 3, 19, 4, 4);
	drawDBox(smap0, 2, 13, 19, 5, 4);
	drawDBox(smap0, 2, 24, 19, 4, 4);

	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			break;
		}
		else
		{
			touched = false;
		}
	}
	playSound(snd_click);	
	
	 swiWaitForVBlank();
	//run the duel

	if(playerInfo.events[playerInfo.currentTown*2 + 1] == 0)
	{
		playerInfo.events[playerInfo.currentTown*2 + 1] = 1;
		loadUpEnemyStats(playerInfo.currentTown, 3)	;
		if(runDuel() == -1)
		{
			//Player Died
			playerDead = true;
			return -1;
		}
		else
		{
			displayText = 0;
			initBackground(1, true);
			runSlotUpDialog();
			playerInfo.attackSlots++;
		}
	}
	
	displayText = 1;
	displayTavern();
	
	return dialogResult;
}

char goldText[10];
void displayShop();


void displayGold()
{
	int cnt = sprintf(goldText, "%d gp",playerInfo.gold);
	for(; cnt < 10; cnt++)
	{
	 goldText[cnt] = ' ';
	}
	
	printText16(goldText, (uint16*)SCREEN_BASE_BLOCK_SUB(31), 14, 19,12, 10);
	
}

void runShop()
{
	static s8 justTouched = true;
	if(TOUCH_SCREEN)
	{
		int touch_x = IPC->touchXpx - 28;
		int touch_y = IPC->touchYpx - 40;
		
		if(touch_x <= 0 || touch_y <= 0)
		{
			return;
		}
		
		int selected = -1;
		
		touch_x /= 56;
		touch_y /= 36;
		
		selected = touch_y * 4 + touch_x;
	
		if(selected != -1 && selected < 12 && !justTouched)
		{
			justTouched = true;
			if((touch_x+1) * 25 > playerInfo.gold || playerInfo.items[selected]>9)
			{
				//Play error noise
				playSound(snd_error);
			}
			else
			{
					playSound(snd_click);
				if(runDialog(selected))
				{
					playerInfo.gold -= (touch_x+1) * 25;
					playerInfo.items[selected]++;
					displayShop();
					playSound(snd_attack);
				}
			}
		}
		
	}
	else
	{
		justTouched = false;
	}
	
}

void runTavern()
{
	if(TOUCH_SCREEN)
	{
		int touch_x = IPC->touchXpx;
		int touch_y = IPC->touchYpx;
		
		if(touch_x <= 0 || touch_y <= 0)
		{
			return;
		}
		
		if(touch_y >= 152 && touch_y <= 192)
		{
			if(touch_x >= 24 && touch_x <= 68)
			{
				//talker
				runTalkerDialog();
			}
			else if(touch_x >= 108 && touch_x <= 148)
			{
				//giver
				runGiverDialog();
			}
			else if(touch_x >= 191 && touch_x <= 231)
			{
				//dueler
				runDuelerDialog();
			}
		}
	}
}

void runArena()
{
	if(TOUCH_SCREEN)
	{
		int touch_x = IPC->touchXpx;
		int touch_y = IPC->touchYpx;
		
		if(touch_x <= 0 || touch_y <= 0)
		{
			return;
		}
		
		//Check the three buttons now
		//If the button is pressed ask if they wish to duel
		//If player died then exit to main menu.
		touch_x /= 8;
		touch_y /= 8;
		
		int selected = -1;
		
		if(touch_x >=17 && touch_x <=29)
		{
			if(touch_y >= 6 && touch_y <= 10)
			{
				selected = 0;
			}
			else if(touch_y >= 11 && touch_y <= 15)
			{
				selected = 1;
			}
			else if(touch_y >= 16 && touch_y <= 20)
			{
				selected = 2;
			}
		}
		
		if(selected != -1)
		{
			//Start the duel
			playSound(snd_click);
			loadUpEnemyStats(playerInfo.currentTown, selected);
			if(runDuel() == -1)
			{
				//He died poop
				playerDead = true;
			}
			else
			{
				//Need to draw the bottom background
				initBackground(2,true);
				if(givePlayerStats(selected))
				{
					//They leveled up!
					if(playerInfo.level < 255)
					{
						//Display Level up info!
						runLevelUpDialog();
						playerInfo.level++;
						
						playerInfo.maxHp += playerInfo.basicStats[PLAYER_DEFENSE] + playerInfo.basicStats[PLAYER_ATTACK] + playerInfo.basicStats[PLAYER_FORESIGHT];
						if(playerInfo.maxHp > 999)
						{
							playerInfo.maxHp = 999;
						}
						
						initBackground(2,false);
						while(TOUCH_SCREEN);
					}
				}
				
			}
		}
	}
}


void hideShop()
{
	for(int cnt_sprites = 4; cnt_sprites < 17; cnt_sprites++)
	{
		mSprites_sub[cnt_sprites].x = 256;
		mSprites_sub[cnt_sprites].y = 196;
	}
}

void hideTavern()
{
}

void hideArena()
{
}

void displayShop()
{
	hideArena();
	hideTavern();
	clearMaps();
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(29);
	
	int at;
	char items[2];

	for(int cnt_y = 0; cnt_y < 3; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 4; cnt_x++)
		{
			at = cnt_y*4 + cnt_x ;
			mSprites_sub[at + 4].name = at * 32;
			sprintf(items,"%d",playerInfo.items[at]);
			at += 4;
			mSprites_sub[at].color_256 = 1;
			mSprites_sub[at].x = 14 + cnt_x * 56;
			mSprites_sub[at].y = 40 + cnt_y * 36;
			mSprites_sub[at].size = 2;
			mSprites_sub[at].priority = 2;
			
			printText16(items,smap1, 6 + cnt_x * 7, 6 + cnt_y * 5, 12, 1);
		}
	}
	
	displayGold();
	updateOAMSub();
}

void displayTavern()
{
	hideArena();
	hideShop();
	clearMaps();
	
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	drawDBox(smap0, 2, 3,6,25,11);
	drawDBox(smap0, 2, 3, 19, 4, 4);
	drawDBox(smap0, 2, 13, 19, 5, 4);
	drawDBox(smap0, 2, 24, 19, 4, 4);
	
	if(displayText == 1)
	{
		printText16(Tavern_welcomeText, smap1, 4, 7, 12, strlen(Tavern_welcomeText));
	}
	
	
	mSprites_sub[4].name = Sprite_Talker;
	mSprites_sub[4].color_256 = 1;
	mSprites_sub[4].x = 28;
	mSprites_sub[4].y = 156;
	mSprites_sub[4].size = 2;
    mSprites_sub[4].priority=1;	
	
	mSprites_sub[5].name = Sprite_Giver;
	mSprites_sub[5].color_256 = 1;
	mSprites_sub[5].x = 112;
	mSprites_sub[5].y = 156 ;
	mSprites_sub[5].size = 2;
	mSprites_sub[5].priority=1;
	
	mSprites_sub[6].name = Sprite_Dueler;
	mSprites_sub[6].color_256 = 1;
	mSprites_sub[6].x = 195;
	mSprites_sub[6].y = 156;
	mSprites_sub[6].size = 2;
	mSprites_sub[6].priority=1;
	
	updateOAMSub();
}

const char * arenaText[] = 
{
  "  Pick a\n   dueler\n and fight\n   win to\n gain stats.",
  "  Weak",
  "  Mid",
  " Strong"
};

void displayArena()
{
	hideShop();
	hideTavern();
	clearMaps();

	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	drawDBox(smap0,2, 3, 6, 13, 13);
	drawDBox(smap0, 2, 18, 6, 10, 3);
	drawDBox(smap0, 2, 18, 11, 10, 3);
	drawDBox(smap0, 2, 18, 16, 10, 3);
	
	//Display the text
	//Weak, Mid, Strong
	printText16(arenaText[0], smap1, 4, 7, 12, strlen(arenaText[0]));
	printText16(arenaText[1], smap1, 19, 7, 12, strlen(arenaText[1]));
	printText16(arenaText[2], smap1, 19, 12, 12, strlen(arenaText[2]));
	printText16(arenaText[3], smap1, 19, 17, 12, strlen(arenaText[3]));
	
	updateOAMSub();
}

const townFunc runTownState[3] = { &runShop, &runTavern, &runArena };
const townFunc displayTown[3] = { &displayShop, &displayTavern, &displayArena};

extern void initMapTop();

void initBackground(int state, bool fadein)
{
	//This function will load all the graphics needed into memory
	//And then it'll display the dialog boxes and move the sprites that are
	//common to the display
	//Also covers over the top layer with a mesh
	//And initializes the video mode to have a 4th bg layer on the main view
	initMapTop();
	videoSetMode(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE | DISPLAY_BG3_ACTIVE);
	BG3_CR = BG_COLOR_256 | BG_32x32 | (28 << SCREEN_SHIFT) | (3 << CHAR_SHIFT) | BG_PRIORITY(0);	
	
	
	//Copy the mesh now
	dmaCopy((uint16 *)meshtile,(uint16*)CHAR_BASE_BLOCK(3), 64);
	dmaCopy((uint16 *)townItemSpritePal,(uint16*)SPRITE_PALETTE_SUB,256*2);
		
	//Now I need to cover the bottom
	uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK(28);
	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			map0[cnt_y * 32 + cnt_x] = 0;
		}
	}
	
	
	
	//Copy the needed sprites to memory
	dmaCopy((uint16 *)townItemSprites, (uint16*)SPRITE_GFX_SUB,24576);

	
	initSprites();
	
		//Need the top two backgrounds.
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);
	
	//Clear the map
	swiWaitForVBlank();
	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			smap0[cnt_y * 32 + cnt_x] = 0;
			smap1[cnt_y * 32 + cnt_x] = 0;
		}
	}
	
	uint16 * smap2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
	uint16 * smap3 = (uint16 *)SCREEN_BASE_BLOCK_SUB(28);
	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			if(cnt_x > 2 && cnt_x < 30 && cnt_y > 2 && cnt_y < 21)
			{
				smap3[cnt_y*32 + cnt_x] = 6;
			}
			else
			{
				smap3[cnt_y*32+cnt_x] = 1;
			}
			
		}
	}
	
	drawDBox(smap2, 2, 1, 2, 29, 20);
	
	for(int cnt_y = 3; cnt_y < 20; cnt_y++)
	{
		for(int cnt_x = 3; cnt_x < 27; cnt_x++)
		{
			smap2[cnt_y * 32 + cnt_x] = 0;
		}
	}

	

	drawDBox(smap0, 2, 3, 0, 4, 4);
	drawDBox(smap0, 2, 13, 0, 5, 4);
	drawDBox(smap0, 2, 24, 0, 4, 4);
	
	mSprites_sub[0].name = Sprite_Shop;
	mSprites_sub[0].color_256 = 1;
	mSprites_sub[0].x = 28;
	mSprites_sub[0].y = 4;
	mSprites_sub[0].size = 2;
    mSprites_sub[0].priority=1;	
	
	mSprites_sub[1].name = Sprite_Tavern;
	mSprites_sub[1].color_256 = 1;
	mSprites_sub[1].x = 112;
	mSprites_sub[1].y = 6;
	mSprites_sub[1].size = 2;
	mSprites_sub[1].priority=1;
	
	mSprites_sub[2].name = Sprite_Arena;
	mSprites_sub[2].color_256 = 1;
	mSprites_sub[2].x = 195;
	mSprites_sub[2].y = 4;
	mSprites_sub[2].size = 2;
	mSprites_sub[2].priority=1;
	
	mSprites_sub[3].name = Sprite_World;
	mSprites_sub[3].color_256 = 1;
	mSprites_sub[3].x = 236;
	mSprites_sub[3].y = 172;
	mSprites_sub[3].size = 2;
	mSprites_sub[3].priority=1;
	displayTown[state]();

	if(fadein)
	{
		if(state != 0)
		{
			fade_in(125,100);
		}
		else
		{
			fade_inSub(125,100);
		}
	}
}


int checkTownTouch(int oldState)
{
	int tile_x, tile_y;
	if(TOUCH_SCREEN)
	{
		//Get the x and y coordinates
		tile_x = IPC->touchXpx / 8;
		tile_y = IPC->touchYpx / 8;
		
		if(tile_y >= 0 && tile_y <= 4)
		{
			if(tile_x >= 3 && tile_x <= 7)
			{
				//Play Noise
				while(TOUCH_SCREEN);
				playSound(snd_click);
				
				return TOWN_SHOPPING;
			}
			else if(tile_x >= 13 && tile_x <=18)
			{
				//Play Noise
				while(TOUCH_SCREEN);
				playSound(snd_click);
				
				return TOWN_TAVERN;
			}
			else if(tile_x >= 24 && tile_x <= 27)
			{
				//Play Noise
				while(TOUCH_SCREEN);
				playSound(snd_click);
				return TOWN_ARENA;
			}
		}
		
		if(tile_y >= 20 && tile_y <= 24)
		{
			if (tile_x >= 29 && tile_x <=30)
			{
				playSound(snd_click);
				return TOWN_RETURN;
			}
		}
	}
	return oldState;
}

void runTown(int town)
{
	int state = TOWN_SHOPPING;
	int oldState = state;
	
	initBackground(0,true);
	
	while(true)
	{
		runTownState[state]();
		if(playerDead)
		{
			return;
		}
		
		oldState = state;
		state = checkTownTouch(oldState);
		if(state == 4)
		{
			fade_outSub(125,100);
			break;
		}
		
		if(oldState!=state)
		{
			displayTown[state]();
		}
	}
}

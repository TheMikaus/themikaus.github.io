//Stat organization
//Health, spd, atk, def, agi, for, attackslots

#define ENEMY_HEALTH 0
#define ENEMY_SPEED 1
#define ENEMY_ATTACK 2
#define ENEMY_DEFENSE 3
#define ENEMY_AGILITY 4
#define ENEMY_FORESIGHT 5
#define ENEMY_ATTACKSLOTS 6

extern const int duelerStats[];
extern int enemyStats[7];

extern void loadUpEnemyStats(int town, int type);

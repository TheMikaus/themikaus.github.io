//FADE FUNCTIONS
extern void Fade(unsigned short factor);

extern void fade_in(unsigned short fade, unsigned short delay);

extern void fade_out(unsigned short fadev, unsigned short delay);

extern void FadeMain(unsigned short factor);

extern void FadeSub(unsigned short factor);

extern void fade_inMain(unsigned short fade, unsigned short delay);

extern void fade_outMain(unsigned short fadev, unsigned short delay);

extern void fade_inSub(unsigned short fade, unsigned short delay);

extern void fade_outSub(unsigned short fadev, unsigned short delay);

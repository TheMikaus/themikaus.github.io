/*
	Note that the font data passed in should contain the symbols
	A-Z a-z 0-9 . , ! ? : ' 68 tiles in total.  They should be
	inserted in the above stated order as well.

	Note also that fonts are only 8x8 or 16x16
*/


extern void loadFont16(unsigned short * cbb, const unsigned char * fontdata, const unsigned char * blanktile);
extern void printText16(const char * text, unsigned short * map, int x, int y, int start,int len);
extern void printChar16_inText(char c);
extern void printChar16(char c, unsigned short * map, int x, int y, int start);


#include <NDS.h>
#include <stdio.h>
#include "dialog.h"
#include "sound.h"
#include "images/tiles.tile"
#include "images/arrowLeft.tile"
#include "images/arrowLeft2.tile"
#include "images/arrowRight.tile"
#include "images/arrowRight2.tile"
#include "images/introScreen.h"
#include "images/okbutton.tile"
#include "images/okbutton2.tile"

#include "gameStructs.h"

#include "blacktile.tile"
#include "images/fontset.tile"

#include "font.h"
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
char line1[17] = "Welcome to Arena";

char line2[18] = "Fighting in duels";
char line3[18] = "will raise stats.";

char line4[18] = "Please assign pts";


char attackString[7] = "Attack";
char agilityString[8] = "Agility";
char defenseString[8] = "Defense";
char speedString[6] = "Speed";
char foresightString[10] = "Foresight";

extern void fade_in(unsigned short fade, unsigned short delay);
extern void fade_out(unsigned short fade, unsigned short delay);

extern void displayStatList(uint16*,uint16*);
extern void printPointsLeft(uint16*);



void DrawLeftArrowUp(uint16 * bmap1, int i)
{
	bmap1[64 + i * 128 + 16] = 1;
	bmap1[64 + i * 128 + 17] = 2;
	bmap1[96 + i * 128 + 16] = 3;
	bmap1[96 + i * 128 + 17] = 4;
}

void DrawRightArrowUp(uint16 * bmap1, int i)
{
	bmap1[64 + i * 128 + 27] = 9;
	bmap1[64 + i * 128 + 28] = 10;
	bmap1[96 + i * 128 + 27] = 11;
	bmap1[96 + i * 128 + 28] = 12;
}

void HideOkButton(uint16 * bmap1)
{
	bmap1[ 21 * 32 + 21] = 0;
	bmap1[ 21 * 32 + 22] = 0;
	bmap1[ 21 * 32 + 23] = 0;
	bmap1[ 21 * 32 + 24] = 0;
	
	bmap1[ 22 * 32 + 21] = 0;
	bmap1[ 22 * 32 + 22] = 0;
	bmap1[ 22 * 32 + 23] = 0;
	bmap1[ 22 * 32 + 24] = 0;
}

void DrawOkButtonUp(uint16 * bmap1)
{
	bmap1[ 21 * 32 + 21] = 17;
	bmap1[ 21 * 32 + 22] = 18;
	bmap1[ 21 * 32 + 23] = 19;
	bmap1[ 21 * 32 + 24] = 20;
	
	bmap1[ 22 * 32 + 21] = 21;
	bmap1[ 22 * 32 + 22] = 22;
	bmap1[ 22 * 32 + 23] = 23;
	bmap1[ 22 * 32 + 24] = 24;
}

void DrawLeftArrowDown(uint16 * bmap1, int i)
{
	bmap1[64 + i * 128 + 16] = 5;
	bmap1[64 + i * 128 + 17] = 6;
	bmap1[96 + i * 128 + 16] = 7;
	bmap1[96 + i * 128 + 17] = 8;
}

void DrawRightArrowDown(uint16 * bmap1, int i)
{
	bmap1[64 + i * 128 + 27] = 13;
	bmap1[64 + i * 128 + 28] = 14;
	bmap1[96 + i * 128 + 27] = 15;
	bmap1[96 + i * 128 + 28] = 16;
}


void DrawOkButtonDown(uint16 * bmap1)
{
	bmap1[ 21 * 32 + 21] = 25;
	bmap1[ 21 * 32 + 22] = 26;
	bmap1[ 21 * 32 + 23] = 27;
	bmap1[ 21 * 32 + 24] = 28;
	
	bmap1[ 22 * 32 + 21] = 29;
	bmap1[ 22 * 32 + 22] = 30;
	bmap1[ 22 * 32 + 23] = 31;
	bmap1[ 22 * 32 + 24] = 32;
}

char statMap[] = "% 3d";
char statDisp[4];

void DrawStat(uint16 * bmap2, int which)
{
	sprintf(statDisp,statMap,playerInfo.basicStats[which]);
	printText16(statDisp, bmap2, 21 , 2 + which * 4, 1, 3);
}

void processTouch(int trigger, bool less)
{
	uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK(31);
	uint16 *bmap1 = (uint16 *)SCREEN_BASE_BLOCK_SUB(30);
	uint16 *bmap2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);
	
	if(trigger < 6)
	{
		if(less)
		{
			DrawLeftArrowDown(bmap1,trigger);
			if(playerInfo.basicStats[trigger] > 1)
			{
				playerInfo.basicStats[trigger]--;
				playerInfo.statsUp++;
				playSound(snd_click);
			}
			else
			{
				//Play noise
				playSound(snd_error);
			}
			
			//Hide the button
			HideOkButton(bmap1);
		}
		else
		{
			DrawRightArrowDown(bmap1,trigger);
			if(playerInfo.statsUp > 0)
			{
				playerInfo.basicStats[trigger]++;
				playerInfo.statsUp--;
				
				if(playerInfo.statsUp == 0)
				{
					DrawOkButtonUp(bmap1);
				}
				playSound(snd_click);
			}
			else
			{
				//Play noise
				playSound(snd_error);
			}
		}
		
		DrawStat(bmap2,trigger);
		printPointsLeft(map2);
	}
	else
	{
		DrawOkButtonUp(bmap1);
	}

}

void runIntroScreen()
{
	//Load the tiles for the intro screen
	//let the player adjust the tiles
	//draw this out first.

	for(int i = 0; i < 255; i++)
	{
		BG_PALETTE[i] = RGB15(0,0,0);
		BG_PALETTE_SUB[i] = RGB15(0,0,0);
	}
	
	videoSetMode(MODE_0_2D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE);
	
	
	BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(2);
	BG1_CR = BG_COLOR_256 | BG_32x32 | (30 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(1);
	BG2_CR = BG_COLOR_256 | BG_32x32 | (31 << SCREEN_SHIFT) | (2 << CHAR_SHIFT) | BG_PRIORITY(0);	
  
  
//Setup top
	dmaCopy((uint16 *)introScreenPal, BG_PALETTE, 256 * 2);
	dmaCopy((uint16 *)dialogTiles, (uint16 *)CHAR_BASE_BLOCK(1), 640);
	loadFont16((unsigned short *)CHAR_BASE_BLOCK(2) , fontset,blanktile);
  
	uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK(29);
	uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK(30);
	uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK(31);
	
	//The background needs to be set to just the tile
	for(int y = 0; y < 24; y++)
	{
		for(int x = 0; x < 32; x++)
		{
			map0[y*32 + x] = 0;
		}
	}
	
	//Make the dialog box now on map1
	for(int y = 0; y < 4; y++)
	{
		for(int x = 0; x < 32; x++)
		{
			map1[y*32 + x] = 0;
		}
	}

	drawDBox(map1, 1, 4, 4, 23, 14);	

	for(int y = 19; y < 24; y++)
	{
		for(int x = 0; x < 32; x++)
		{
			map1[y*32 + x] = 0;
		}
	}
	
	//Make intro text on map2
	//For now blank it out
	for(int y = 0; y < 24; y++)
	{
		for(int x = 0; x < 32; x++)
		{
			map2[y*32 + x] = 0;
		}
	}
	
	printText16(line1, map2, 7, 5, 1, 16);
	printText16(line2, map2, 7, 8, 1, 17);
	printText16(line3, map2, 9, 10, 1, 17);
	printText16(line4, map2, 7, 15, 1, 17);
	
	
	//set up the bottom screen
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE);
	
	SUB_BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(2);
	SUB_BG1_CR = BG_COLOR_256 | BG_32x32 | (30 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(1);
	SUB_BG2_CR = BG_COLOR_256 | BG_32x32 | (31 << SCREEN_SHIFT) | (2 << CHAR_SHIFT) | BG_PRIORITY(0);

	dmaCopy((uint16 *)introScreenPal, BG_PALETTE_SUB, 256 * 2);
	dmaCopy((uint16 *)blanktile, (uint16 *)CHAR_BASE_BLOCK_SUB(1), 64);
	dmaCopy((uint16 *)arrowLeftTile, (uint16 *) CHAR_BASE_BLOCK_SUB(1) + 32, 256);
	dmaCopy((uint16 *)arrowLeft2Tile, (uint16 *) CHAR_BASE_BLOCK_SUB(1) + 160, 256);
	dmaCopy((uint16 *)arrowRightTile, (uint16 *) CHAR_BASE_BLOCK_SUB(1) + 288, 256);
	dmaCopy((uint16 *)arrowRight2Tile, (uint16 *) CHAR_BASE_BLOCK_SUB(1) + 416, 256);
	dmaCopy((uint16 *)okbuttonTile, (uint16 *) CHAR_BASE_BLOCK_SUB(1) + 544, 512);
	dmaCopy((uint16 *)okbutton2Tile, (uint16 *) CHAR_BASE_BLOCK_SUB(1) + 800, 512);
	dmaCopy((uint16 *)dialogTiles,(uint16*) CHAR_BASE_BLOCK_SUB(1) + 1056, 640);
	
	loadFont16((unsigned short *)CHAR_BASE_BLOCK_SUB(2) , fontset,blanktile);

	uint16 *bmap0 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
	uint16 *bmap1 = (uint16 *)SCREEN_BASE_BLOCK_SUB(30);
	uint16 *bmap2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);

	for(int y = 0; y < 24; y++)
	{
		for(int x = 0; x < 32; x++)
		{
			bmap0[y*32 + x] = 33;
			bmap1[y*32 + x] = 0;
			bmap2[y*32 + x] = 0;
		}
	}
	
	displayStatList(bmap1,bmap2);

	printPointsLeft(map2);
	
	fade_in(125,100);	
	bool touched = false;
	volatile int trigger = -1;
	int oldTrigger = -1;
	
	while(true)
	{
		if(TOUCH_SCREEN)
		{
			int xt = IPC->touchXpx / 8;
			int yt = IPC->touchYpx / 8;

			if(playerInfo.statsUp == 0)
			{
				//Check for the ok collision
				if(xt >= 21 && xt <= 24 && yt>=20 && yt<=23)
				{
					touched = true;
					trigger = 6;
					DrawOkButtonDown(bmap1);
					break;
				}
			}
			if(touched) continue;
			
			for(int i = 0; i < 5; i++)
			{
				if(yt >= 1 + (i * 4) && yt <= 3 + (i *4))
				{
					//Check the left arrow
					if(xt >=16 && xt <= 18)
					{
						touched = true;
						processTouch(i, true);
						oldTrigger = i;
						break;
					}
					else if(xt >= 27 && xt <= 29)
					{
						touched = true;
						processTouch(i,false);
						oldTrigger = i;
						break;
					}
				}
			}
		}
		else
		{
			touched = false;
			DrawLeftArrowUp(bmap1,oldTrigger);
			DrawRightArrowUp(bmap1,oldTrigger);
		}
	}
	
	playSound(snd_click);
	fade_out(125,100);
}


void displayStatList(uint16 * bmap1, uint16 * bmap2)
{
	for(int i = 0; i < 5; i++)
	{
		drawDBox(bmap1, 34, 0,1+ i * 4, 12, 3);
		
		//Draw the arrows too
		DrawLeftArrowUp(bmap1,i);
		//Right
		DrawRightArrowUp(bmap1,i);
		
		DrawStat(bmap2, i);
	}
	
	printText16(attackString, bmap2, 1, 2, 1, 6);
	printText16(agilityString, bmap2, 1, 6, 1, 7);
	printText16(defenseString, bmap2, 1, 10, 1, 7);
	printText16(speedString, bmap2, 1, 14, 1, 5);
	printText16(foresightString, bmap2, 1, 18, 1, 9);
	
	//Draw the ok button
//	DrawOkButtonUp(bmap1);
}

char pointMap[] = "You have %d points left";
char pointDisplay[25];

void printPointsLeft(uint16 * map)
{
  int length = sprintf(pointDisplay,pointMap,playerInfo.statsUp);
  printText16(pointDisplay, map, 4, 20, 1, length);
}


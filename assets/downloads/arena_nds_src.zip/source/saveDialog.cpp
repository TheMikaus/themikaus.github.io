#include <NDS.h>
#include <stdio.h>
#include "dialog.h"
#include "Font.h"
#include "gameStructs.h"
#include "fade.h"
#include "images/attackup.h"
#include "sound.h"

#define GBA_SRAM ((uint8*)0x0A000000)
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))

typedef struct
{
	char used[4];
	playerInfoTag pit1;
	char used2[4];
	playerInfoTag pit2;
	
} saveTag;

saveTag saveData;
char cardId[5];

void __memcpy(char * dest, char const * src, int size)
{
	while(size--)
	{
		*dest++ = *src++;
	}
}

extern void initBottomSaveScreen();


extern bool loadedAtScreen;

void displaySlot(int which, uint16 * fmap, int FontStart)
{
	playerInfoTag * pit;
	char temp[4];
	
	if(which == 1)
	{
		pit = &saveData.pit1;
	}
	else
	{
		pit = &saveData.pit2;
	}
	which--;
	
	printText16(pit->name, fmap, 4, 2 + which*11, FontStart, pit->nameLength);
	
	printText16("Floor", fmap, 20, 2 + which * 11, FontStart, 5);
	int tempcnt = sprintf(temp,"%d", pit->towerLevel);
	printText16(temp,fmap,28,2 + which * 11, FontStart, tempcnt);
	
	printText16("Lvl.", fmap, 4, 4 + which*11, FontStart, 4);
	//print actual level here
	tempcnt = sprintf(temp,"%d",pit->level);
	printText16(temp, fmap, 10, 4 + which *11, FontStart, tempcnt);
	
	tempcnt = sprintf(temp, "%d",pit->exp);
	printText16("Exp.",fmap, 4, 6 + which *11, FontStart, 4);
	printText16(temp,fmap,10,6 + which *11, FontStart, tempcnt);
	
	//Need to move the sprites
	int cnt_sprite = 8 * which;
	
	for(int cnt_slot = 0; cnt_slot < 8; cnt_slot++)
	{
		mSprites_sub[cnt_sprite].name = 0;
		mSprites_sub[cnt_sprite].size = 1;
		mSprites_sub[cnt_sprite].color_256 = 1;
		mSprites_sub[cnt_sprite].priority = 0;

		if(cnt_slot < 4)
		{
			if(cnt_slot < pit->attackSlots - 1)
			{
				mSprites_sub[cnt_sprite].x = 160 + 20 * cnt_slot;
				mSprites_sub[cnt_sprite].y = 32 + which * 88;
			}
			else
			{
				mSprites_sub[cnt_sprite].x = 160 + 20 * cnt_slot;
				mSprites_sub[cnt_sprite].y = 196;
			}
			
		}
		else
		{
			if(cnt_slot < pit->attackSlots - 1)
			{
				mSprites_sub[cnt_sprite].x = 160 + 20 * (cnt_slot - 4);
				mSprites_sub[cnt_sprite].y = 48 + which * 88;
			}
			else
			{
				mSprites_sub[cnt_sprite].x = 160 + 20 * (cnt_slot - 4);
				mSprites_sub[cnt_sprite].y = 196;
			}
		}
		
		cnt_sprite++;
	}
	
	
	
	updateOAMSub();
}

int setupBase(uint16 * bmap, uint16 * fmap, int DialogStart, int FontStart)
{
	initBottomSaveScreen();
	
	//Upload into memory the sprite
	dmaCopy((uint16 *)attackUpPal,(uint16*)SPRITE_PALETTE_SUB,256*2);
	dmaCopy((uint16 *)attackUp, (uint16*)SPRITE_GFX_SUB,256);

	//Clear the maps
	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			bmap[cnt_y * 32 + cnt_x] = 0;
			fmap[cnt_y * 32 + cnt_x] = 0;
		}
	}
	

	saveData.used[0] = 0;
	saveData.used2[0] = 0;
	
	//Load the SRAM data
	//But first I need to check if it's a useable card
	WAIT_CR &= ~0x80;
	__memcpy(cardId,(char*)0x080000AC,4);
	if(cardId[0] != 'P' || cardId[1] != 'A' || cardId[2]  != 'S' || cardId[3] != 'S')
	{
		//Display the can't save to cart message
		//Wait for touch then return
		drawDBox(fmap, DialogStart, 1, 0, 29, 20);
		drawDBox(bmap, DialogStart, 2, 1, 27, 18);
		printText16("Must use Homebrew cart!", fmap, 4, 14, FontStart, 23);
		fade_inSub(125,100);
		playSound(snd_error);
		while(!TOUCH_SCREEN);
		return -1;
	}
	
	int retSlots = 0;
	
	//Finish loading from SRAM
	__memcpy((char *)(&saveData),(const char *)GBA_SRAM,sizeof(saveTag));
	
	
	//Display the two entries here
	
	//Draw the two boxes on the fmap
	//and underneath it on the bmap draw smaller boxes to fill in the gaps that will be made
	//See notes on the display
	drawDBox(fmap, DialogStart, 1, 0, 29, 9);	
	drawDBox(fmap, DialogStart, 1, 11, 29, 9);	
	drawDBox(bmap, DialogStart, 2, 1, 27, 7);	
	drawDBox(bmap, DialogStart, 2, 12, 27, 7);	
	
	if(saveData.used[0] == 'U' && saveData.used[1] == 'S' && 
	   saveData.used[2] == 'E' && saveData.used[3] == 'D')
	{
		//Display the saved state (temporary display)
		displaySlot(1, fmap, FontStart);
		retSlots = 1;
	}
	else
	{
	//printText16(const char * text, unsigned short * map, int x, int y, int start,int len);
		printText16("Unused Save Slot", fmap,  4, 3, FontStart, 16);
	}
	
	if(saveData.used2[0] == 'U'&& saveData.used2[1] == 'S' && 
	   saveData.used2[2] == 'E' && saveData.used2[3] == 'D')
	{
		//Display the save state (temporary display)
		displaySlot(2, fmap, FontStart);
		retSlots |= 2;
	}
	else
	{
		printText16("Unused Save Slot", fmap,  4, 14, FontStart, 16);
	}
	
	
	printText16("Back", fmap,  27, 22, FontStart, 4);
	return retSlots;
}

void saveLoadDialog(bool load, uint16 * bmap, uint16 * fmap, int DialogStart, int FontStart)
{
	while(TOUCH_SCREEN);
	swiWaitForVBlank();
	
	//Setup the dialog
	int retSlots = setupBase(bmap,fmap, DialogStart, FontStart);
	fade_inSub(125,100);
	
	if(retSlots != -1)
	{
		if(load)
		{
			//Display the load message on the top left
			printText16("Load", fmap,  0, 22, FontStart, 4);
		}
		else
		{
			//Display the save message on the top left
			printText16("Save", fmap,  0, 22, FontStart, 4);
		}
		
		int choice = -1;
		while(true)
		{
			if(TOUCH_SCREEN)
			{
				int touch_x = IPC->touchXpx / 8;
				int touch_y = IPC->touchYpx / 8;
				
				if(touch_x >= 3 && touch_x <= 30)
				{
					if(touch_y >= 0 && touch_y <= 10)
					{
						choice = 0;
						break;
					}
					
					if(touch_y >= 11 && touch_y <= 20)
					{
						choice = 1;
						break;
					}
				}
				
				if(touch_x >=27 && touch_x <= 32)
				{
					if(touch_y >= 22 && touch_y <= 24)
					{
						break;
					}
				}
			}
		}
		
		if(choice != -1)
		{
			if(load)
			{
				if(choice == 0)
				{
					if(retSlots & 1 == 1)
					{
						__memcpy((char *) &playerInfo,(char *)(&saveData.pit1),sizeof(playerInfoTag));				
						loadedAtScreen = true;
						playSound(snd_click);
					}
					else
					{
						//Play error noise
						playSound(snd_error);
					}
				}
				else
				{
					if(retSlots & 2 == 2)
					{
						__memcpy((char *) &playerInfo,(char *)(&saveData.pit2),sizeof(playerInfoTag));				
						loadedAtScreen = true;
						playSound(snd_click);
					}
					else
					{
						//Play error noise
						playSound(snd_error);
					}
				}
			}
			else
			{
				if(choice == 0)
				{
					__memcpy((char *)(&saveData.pit1),(char *) &playerInfo,sizeof(playerInfoTag));				
					saveData.used[0] = 'U';
					saveData.used[1] = 'S';
					saveData.used[2] = 'E';
					saveData.used[3] = 'D';
					playSound(snd_click);

/*					setupBase(bmap,fmap, DialogStart, FontStart);
					if(load)
					{
						//Display the load message on the top left
						printText16("Load", fmap,  0, 22, FontStart, 4);
					}
					else
					{
						//Display the save message on the top left
						printText16("Save", fmap,  0, 22, FontStart, 4);
					}
*/
				}
				else
				{
					__memcpy((char *)(&saveData.pit2),(char *) &playerInfo,sizeof(playerInfoTag));				
					saveData.used2[0] = 'U';
					saveData.used2[1] = 'S';
					saveData.used2[2] = 'E';
					saveData.used2[3] = 'D';
					playSound(snd_click);
					
/*					setupBase(bmap,fmap, DialogStart, FontStart);
					if(load)
					{
						//Display the load message on the top left
						printText16("Load", fmap,  0, 22, FontStart, 4);
					}
					else
					{
						//Display the save message on the top left
						printText16("Save", fmap,  0, 22, FontStart, 4);
					}
*/					
				}
				
				__memcpy((char *)GBA_SRAM,(char *)(&saveData),sizeof(saveTag));
			}
		}
	}	
	
	fade_outSub(125,100);
}

#ifndef sound_h
#define sound_h

#define snd_attack 1
#define snd_theAttackUp 2
#define snd_error 3
#define snd_click 4
#define snd_back 5
#define snd_dead 6

extern void playSound(int i);
#endif

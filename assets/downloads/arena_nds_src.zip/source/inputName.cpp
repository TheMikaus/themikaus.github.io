#include <NDS.h>
#include "sound.h"
#include "gameStructs.h"
#include "EnterName_247.tile"
#include "EnterName.h"
#include "input_149.tile"
#include "EnterNameSub.h"
#include "fontset.tile"
#include "blacktile.tile"

#include "font.h"
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
extern void fade_in(unsigned short fade, unsigned short delay);
extern void fade_out(unsigned short fade, unsigned short delay);

#define acceptPalNum 128
#define cancelPalNum 143

int runEnterName()
{
  playerInfo.nameLength = 0;
  for(int i = 0; i < 8; i++)
  {
   playerInfo.name[i] = ' ';
  }

  //Top Screen uses two backgrounds this time
  videoSetMode(MODE_0_2D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE);
  
  
  BG1_CR = BG_COLOR_256 | BG_32x32 | (30 << SCREEN_SHIFT) | (4 << CHAR_SHIFT) | BG_PRIORITY(0);
  
  uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK(29);
  uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK(30);
  uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
 
  //Copy the needed palette info
  dmaCopy((uint16*)enterNamePal, (uint16 *)BG_PALETTE, 256 * 2);
  dmaCopy((uint16*)enterNameSubPal, (uint16 *)BG_PALETTE_SUB, 256 * 2);
  
  //Copy the needed tile info
  dmaCopy((uint16*)enterNameTile,(uint16 *)CHAR_BASE_BLOCK(1), 32768);
  
  loadFont16((unsigned short *)CHAR_BASE_BLOCK(4), fontset,blanktile);
  
  
  dmaCopy((uint16*)enterNameSubTile,(uint16 *)CHAR_BASE_BLOCK_SUB(1), 40960);
  BG_PALETTE_SUB[acceptPalNum] = RGB15(0,0,0);
  BG_PALETTE_SUB[cancelPalNum] = RGB15(0,0,0);
      
  //Copy the maps I need
  int c= 0;
  
  for(int y = 0; y < 6; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map0[y*32 + x] = c++;
	}
  }

  for(int y = 6; y < 9; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map0[y*32 +x] = 0;
	}
  }
  
  for(int y = 9; y < 18; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map0[y*32 +x] = c++;
	}
  }
  
  for(int y = 18; y < 24; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map0[y*32 + x] = 0;
	}
  }
  
  for(int y = 0; y < 24; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map1[y*32 + x] = 0;
	}
  }
  
  c = 0;
  for(int x = 0; x < 32; x++)
  {
	map2[x] = 0;
	map2[32 + x] = 0;
	map2[64 + x] = 0;
	map2[672 + x] = 0;
	map2[704 + x] = 0;
	map2[736 + x] = 0;
  }
  
  for(int y = 3; y < 21; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map2[y*32 + x] = c++;
	}
  }

  fade_in(128,1500);
  
  volatile int letter = 0;
  bool touched = false;
  bool nameUpdate = false;
  int retValue = -1;
  
  while(true)
  {
	if(TOUCH_SCREEN)
	{
		int xt = IPC->touchXpx / 8;
		int yt = IPC->touchYpx / 8;
		
		if(yt >=15 && yt <= 16)
		{
			if(xt >= 22 && xt <= 27)
			{
				BG_PALETTE_SUB[cancelPalNum] = RGB15(31,31,31);
				retValue = 0;
				playSound(snd_click);
				while(TOUCH_SCREEN);
			}
			else if(xt >= 15 && xt <= 20)
			{
				if(playerInfo.nameLength > 0)
				{
					BG_PALETTE_SUB[acceptPalNum] = RGB15(31,31,31);
					retValue = 1;
					playSound(snd_click);
					while(TOUCH_SCREEN);
				}
				else
				{
					//Play a er er noise.
					playSound(snd_error);
					while(TOUCH_SCREEN);
				}
			}
		}
		
		letter = -1;
		
		if(xt >= 4 && xt <= 27)
		{
			if(yt >= 6 && yt <= 17)
			{
				yt -= 5;
				xt -= 3;
				//if(yt % 3 != 0 && xt % 3 != 0)
				{
					letter = (int)(yt / 3);
					letter *= 8;
					letter += (int)(xt/3);
					touched = true;
					
				}
			}
			
			
		}
	}
	else
	{
		if(retValue != -1)
		{
			BG_PALETTE_SUB[acceptPalNum] = BG_PALETTE_SUB[cancelPalNum] = RGB15(0,0,0);
			break;
		}
		else if(touched && letter != -1)
		{
			touched = false;
			if(letter == 26 && playerInfo.nameLength > 0)
			{
				//Back space
				nameUpdate=true;
				playerInfo.nameLength--;
				playerInfo.name[ playerInfo.nameLength ] = ' ';
				
				letter = -1;
				playSound(snd_back);
			}
			else if(letter > 26 && playerInfo.nameLength < 8)
			{
				letter = -1;
			}
			else
			{
				if(playerInfo.nameLength == 0)
				{
					playerInfo.name[playerInfo.nameLength++] = ('A' + letter);
				}
				else
				{
					playerInfo.name[playerInfo.nameLength++] = ('a' + letter);
				}
				playSound(snd_click);
				letter = -1;
				nameUpdate = true;
			}
		}
	}
	
	if(nameUpdate)
	{
		nameUpdate = false;
		printText16(playerInfo.name, map1, 11, 13, 1, 8);
	}
  }

  //Bottom screen still uses one
  fade_out(125,100);
  videoSetMode(MODE_0_2D | DISPLAY_BG0_ACTIVE);
  return retValue;
}

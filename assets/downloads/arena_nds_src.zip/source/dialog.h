extern void drawDBox(uint16 * bmap, int startTile, int x, int y, int w, int h);

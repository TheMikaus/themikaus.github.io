#include <NDS.h>
extern void initSprites(void);
extern void updateOAM(void);
extern void updateOAMSub(void);
extern void updateOAMMain(void);

#define PLAYER_ATTACK 0
#define PLAYER_AGILITY 1
#define PLAYER_DEFENSE 2
#define PLAYER_SPEED 3
#define PLAYER_FORESIGHT 4

struct spriteStruct	
{
//at0
	unsigned y : 8;

	unsigned rotation : 1;
	unsigned DoubleSize : 1;
	unsigned translucent : 1;
	unsigned windowed : 1;
	unsigned mosaic : 1;
	unsigned color_256 : 1;
	unsigned tall : 1;
	unsigned wide : 1;

	//at1
	unsigned x : 9;
	unsigned rotation_index : 3;
	unsigned hflip : 1;
	unsigned vflip : 1;
	unsigned size:2;
	
	//at2
	unsigned name : 10;
	unsigned priority : 2;
	unsigned pallette : 4;
	
	unsigned short at3;
	
};

extern struct spriteStruct * mSprites;
extern struct spriteStruct * mSprites_sub;
extern SpriteEntry sprites[128];
extern SpriteEntry sprites_sub[128];

#define Item_Damage10   0
#define Item_Damage25   1
#define Item_Damage50   2
#define Item_Damage100  3
#define Item_Shield10   4
#define Item_Shield25   5
#define Item_Shield50   6
#define Item_Shield100  7
#define Item_Health10   8
#define Item_Health25   9
#define Item_Health50   10
#define Item_Health100  11


struct playerInfoTag
{
	char name[9];
	unsigned short nameLength;
	unsigned int maxHp;
	char items[16];
	uint8 attackSlots;
	unsigned short leftHandItem;
	unsigned short rightHandItem;
	unsigned short exp;
	unsigned short level;
	unsigned short basicStats[5];
	unsigned short statsUp;
	char currentTown;
	unsigned short gold;
	bool events[18];
	uint8 towerLevel;
};

extern struct playerInfoTag playerInfo;

extern void resetPlayerInfo();


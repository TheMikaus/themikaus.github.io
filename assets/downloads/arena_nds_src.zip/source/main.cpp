#include <stdio.h>

#include <NDS.h>
#include <NDS/ARM9/console.h> //basic print funcionality

#include <stdlib.h>

#define abs(x) (((x)<0)?(-(x)):((x)))

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//
//

#define TOUCH_X (IPC->touchX / 14)
#define TOUCH_Y (IPC->touchY / 18 - 12)

#define TOUCH_2X (IPC->touchX / 7)
#define TOUCH_2Y (IPC->touchY / 9 - 24)

#define REG_VCOUNT *(vu16*)0x4000006		//Our good old vblank counter 
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))

#include "splash.h"

#include "gameStructs.h"
#include "font.h"

bool loadedAtScreen;

extern void runGame();
extern void saveLoadDialog(bool load, uint16 * bmap, uint16 * fmap, int DialogStart, int FontStart);

#include "fade.h"
//////////////////////////////


extern void runNeoSplash();
extern int runTitleScreen(int a);
extern int runEnterName();
extern void runIntroScreen();

void vBlank()
{
	//Do Nothing
}



int main(int argc, char ** argv) 
{
	
  powerON(POWER_ALL);
  lcdSwap();
  //set the needed video modes
  videoSetMode(MODE_0_2D | DISPLAY_BG0_ACTIVE );
  videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE );
	
  vramSetMainBanks(VRAM_A_MAIN_BG, VRAM_B_MAIN_SPRITE, VRAM_C_SUB_BG, VRAM_D_SUB_SPRITE);

  	irqInit();
	irqSet(IRQ_VBLANK, vBlank);
	irqEnable(IRQ_VBLANK);

  
  //Make both the top and the bottom maps 256 color screens
  BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(2);
  SUB_BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(1);	
	
  //runGame();	
  
  runNeoSplash();
  
  volatile int titleValue = 0;
  
  while(true)
  {
	videoSetMode(MODE_0_2D | DISPLAY_BG0_ACTIVE );
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);
	
    titleValue = runTitleScreen(titleValue);
  
	if(titleValue == 0)
	{
		//Run the player name thingy
		titleValue = runEnterName();
		if(titleValue == 1)
		{
			resetPlayerInfo();
			
			//Run the intro screen
			//The intro screen gives player stats to assign
			//This intro screen might become the level up screen as well
			//The bottom half and functionality anyway.
			runIntroScreen();
			
			//Run the game
			runGame();
		}
		titleValue = 0;
	}
	else
	{
		//Run the load game thingy
		uint16 * map2 = (uint16 *)SCREEN_BASE_BLOCK_SUB(30);
		uint16 * map3 = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);
		loadedAtScreen = false;
		saveLoadDialog(true, map2, map3, 2, 12);
		if(loadedAtScreen)
		{
			runGame();
			titleValue = 1;
		}
	}
  }

  return 0;
}


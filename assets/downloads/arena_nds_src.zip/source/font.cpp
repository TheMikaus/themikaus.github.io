#include "font.h"
#include <NDS.h>

/*
	Note that the font data passed in should contain the symbols
	A-Z a-z 0-9 . , ! ? : ' 68 tiles in total.  They should be
	inserted in the above stated order as well.

	Note also that fonts are only 8x8 or 16x16
*/

int xh;
int yh;
int starth;
uint16 * maph;
int valh;

const char periodMarker		= 88;
const char commaMarker			= 89;
const char exclamationMarker	= 90;
const char questionMarker		= 91;
const char colonMarker			= 92;
const char apostroMarker		= 93;
const char dashMarker 			= 94;

void loadFont16(unsigned short * cbb, const unsigned char * fontdata, const unsigned char * blanktile)
{
	dmaCopy((uint16*)blanktile, (uint16*)cbb,64);
	dmaCopy((uint16*)fontdata, (uint16*)(cbb) + 32, 12160);
}

//Change this to not double space if it's a lowercase letter or symbol
void printText16(const char * text, unsigned short * map, int x, int y, int start, int len)
{
	xh = x;
	yh = y;
	starth = start;
	maph = map;
	while(len!=0)
	{
		if(text[0] == '\n')
		{
			xh = x;
			yh += 2;
			text++;
			len--;
			continue;
		}
		
		printChar16_inText(*text);
		
		if(text[0] >= 'A' && text[0] <= 'Z')
		{
			xh+=2;
		}
		else
		{
			xh++;
		}
		
		text++;
		len--;
	}
}

void setTileNumber(int x, int y, uint16 * map, int spot)
{
	map[y*32+x] = spot;
}

void printChar16_inText(char c)
{
	if(c == ' ')
	{
		setTileNumber(xh,yh, maph, 0);
		setTileNumber(xh,yh+1,maph, 0);
		setTileNumber(xh+1,yh, maph, 0);
		setTileNumber(xh+1,yh+1,maph, 0);
	}
	else if(c >= 'A' && c <='Z') 
	{
		valh = c-'A';
		setTileNumber(xh  , yh  , maph, (valh*2) + starth);
		setTileNumber(xh+1, yh  , maph, (valh*2) + starth + 1);
		setTileNumber(xh  , yh+1, maph, (valh*2) + starth + 95);
		setTileNumber(xh+1, yh+1, maph, (valh*2) + starth + 96);
	}
	else 
	{
		if(c>='a' && c<='z') valh = c-'a'+ 52;
		else if(c == '.') valh = periodMarker;
		else if(c == ',') valh = commaMarker;
		else if(c == '!') valh = exclamationMarker;
		else if(c == '?') valh = questionMarker;
		else if(c == ':') valh = colonMarker;
		else if(c == '\'') valh = apostroMarker;
		else if(c == '-') valh = dashMarker;
		else if(c >= '0' && c <= '9') valh = c - '0' + 78;
		
		setTileNumber(xh  , yh  , maph, valh + starth);
		setTileNumber(xh  , yh+1, maph, valh + starth + 95);
	}		
    	
	
}

void printChar16(char c, uint16 * map, int x, int y, int start)
{
	if(c == ' ')
	{
		setTileNumber(xh,yh, maph, starth);
		setTileNumber(xh,yh+1,maph,starth);
	}
	else if(c >= 'A' && c <='Z') 
	{
		valh = c-'A';
		setTileNumber(xh  , yh  , maph, (valh*2) + starth);
		setTileNumber(xh+1, yh  , maph, (valh*2) + starth + 1);
		setTileNumber(xh  , yh+1, maph, (valh*2) + starth + 95);
		setTileNumber(xh+1, yh+1, maph, (valh*2) + starth + 96);
	}
	else 
	{
		if(c>='a' && c<='z') valh = c-'a'+52;
		else if(c == '.') valh = periodMarker;
		else if(c == ',') valh = commaMarker;
		else if(c == '!') valh = exclamationMarker;
		else if(c == '?') valh = questionMarker;
		else if(c == ':') valh = colonMarker;
		else if(c == '\'') valh = apostroMarker;
		else if(c == '-') valh = dashMarker;
		
		setTileNumber(xh  , yh  , maph, valh + starth);
		setTileNumber(xh  , yh+1, maph, valh + starth + 95);
	}		
}

#include "gamestructs.h"
#include "fade.h"
#include "Dialog.h"
#include "Font.h"
#include "enemyStats.h"
#include <stdio.h>
#include "images/duelSprites.h"
#include <string.h>
#include "sound.h"

#include <stdlib.h>
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
extern bool fadeOutAfterBattle;
extern bool playerDead;

const char * towerMessages[] =
{
	"   Only seven more\n    battles to Lot!",
	"   Only six battles\n       left to go!",
	"    Only five more\n     battles left!",
	"  Only four battles\n     till Lot!",
	" Only three enemies\n     till Lot!",
	" Only two gaurdians\n       to fight!",
	" One Gaurdian to go",
	"  On to Lot next!",
	"    You beat Lot!\n   You now control\n      the world!"
};

extern int runDuel();
extern void clearMaps();

int runTowerDialog()
{
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	swiWaitForVBlank();

	drawDBox(smap0,2, 3,6,25,11);
	
	int dialogResult = -1;
	
	
	//Draw the text
	printText16(towerMessages[playerInfo.towerLevel], smap1, 5, 7, 12, strlen(towerMessages[playerInfo.towerLevel]));

	printText16("Tap to continue",smap1, 7, 14, 12, 15);
	

	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			break;
		}
		else
		{
			touched = false;
		}
	}
	playSound(snd_click);
	
	swiWaitForVBlank();
	
	return dialogResult;
}

void runTower()
{
	//load up the current enemy.
	enemyStats[ENEMY_HEALTH] = 40 + 10 * playerInfo.towerLevel;
	enemyStats[ENEMY_SPEED] = 3 + playerInfo.towerLevel;
	enemyStats[ENEMY_ATTACK] = 5 + playerInfo.towerLevel * 3; 
	enemyStats[ENEMY_AGILITY] = 3 + playerInfo.towerLevel * 2;
	enemyStats[ENEMY_DEFENSE] = 5 + playerInfo.towerLevel * 2;
	enemyStats[ENEMY_FORESIGHT] = 3 + playerInfo.towerLevel * 2;
	enemyStats[ENEMY_ATTACKSLOTS] = playerInfo.towerLevel + 1;

	fadeOutAfterBattle = false;
	if(runDuel() == -1)
	{
		//Player Died Game Over
		playerDead = true;
	}
	else
	{
		//Player won!
		runTowerDialog();
		playerInfo.towerLevel++;
		
		//if the player beat the game notify them!
		//then exit
		if(playerInfo.towerLevel == 9)
		{
			//you beat the game!
			playerDead = true;
		}
		
		//dump them back into the world map
		
	}
	fadeOutAfterBattle = true;
	fade_out(125,100);
}

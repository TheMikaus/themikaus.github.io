#include <stdio.h>

#include <NDS.h>
#include <NDS/ARM9/console.h> //basic print funcionality

#include <stdlib.h>
#include "sound.h"
#define abs(x) (((x)<0)?(-(x)):((x)))

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//
//

#define TOUCH_X (IPC->touchX / 14)
#define TOUCH_Y (IPC->touchY / 18 - 12)

#define TOUCH_2X (IPC->touchX / 7)
#define TOUCH_2Y (IPC->touchY / 9 - 24)

#define REG_VCOUNT *(vu16*)0x4000006		//Our good old vblank counter 

#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
///////////////////////////////////////////
#include "Fade.h"

#include "titleTop.h"
#include "titleBottom.h"
#include "titleTop.Tile"
#include "titleBottom.Tile"

int runTitleScreen(int touch)
{
  BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(2);
  SUB_BG0_CR = BG_COLOR_256 | BG_32x32 | (29 << SCREEN_SHIFT) | (1 << CHAR_SHIFT) | BG_PRIORITY(1);	
	
  uint16 * map0 = (uint16 *)SCREEN_BASE_BLOCK(29);
  uint16 * map1 = (uint16 *)SCREEN_BASE_BLOCK_SUB(29);
 
  //Copy the needed palette info
  dmaCopy((uint16*)titlePal, (uint16 *)BG_PALETTE, 256 * 2);
  dmaCopy((uint16*)titleSubPal, (uint16 *)BG_PALETTE_SUB, 256 * 2);
  
  //Copy the needed tile info
  dmaCopy((uint16*)titleTile,(uint16 *)CHAR_BASE_BLOCK(1), 40960);
  dmaCopy((uint16*)titleSubTile,(uint16 *)CHAR_BASE_BLOCK_SUB(1), 40960);
      
  //Copy the maps I need
  int c= 0;
  
  for(int y = 0; y < 14; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map0[y*32 + x] = c++;
		
	}
  }
  
  for(int y = 14; y < 18; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map0[y*32 + x] = c;
	}
  }
  
  for(int y = 18; y < 24; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map0[y*32 + x] = c++;
		
	}
  }
  
  for(int x = 0; x < 32; x++)
  {
	map1[x] = 0;
	map1[32 + x] = 0;
	map1[704 + x] = 0;
	map1[736 + x] = 0;
  }
  
  c = 0;
  
  for(int y = 2; y < 22; y++)
  {
	for(int x = 0; x < 32; x++)
	{
		map1[y * 32 + x] = c++;
	}
  }
  
  if(touch == 0)
  {
	fade_in(125,100);
  }
  else
  {
    fade_inSub(125,100);
  }
  
  bool notouch = true;
  int touched = -1;
  
  while(true)
  {
    notouch = true;
	
	if(TOUCH_SCREEN)
	{
		int xt = IPC->touchXpx / 8;
		int yt = IPC->touchYpx / 8;

		touched = -1;
		if(xt > 3 && xt < 29)
		{
			if(yt>=3 && yt <=9)
			{
			 notouch = false;
			 BG_PALETTE_SUB[139] = RGB15(0,16,0);
			 touched = 0;
			 break;
			}
			else if(yt>=13 && yt <= 19)
			{
			 notouch = false;
			 BG_PALETTE_SUB[138] = RGB15(0,16,0);
			 touched = 1;
			 break;
			}
		}
		
	}
	
  }

  playSound(snd_click);
  
  if(touched == 0)
  {
	fade_out(125,100);
  }
  else
  {
    fade_outSub(125,100);
  }
  
  return touched;
}

#include "gamestructs.h"
#include "fade.h"
#include "Dialog.h"
#include "Font.h"
#include "enemyStats.h"
#include <stdio.h>
#include "images/duelSprites.h"
#include <string.h>
#include "sound.h"

#include <stdlib.h>
#define TOUCH_SCREEN (((~IPC->buttons) << 6) & (1<<12))
int playerSelectedMoves[9];
int enemySelectedMoves[9];

bool fadeOutAfterBattle = true;

int usedItems[2];
//Sprites on the bottom start at 6
//Sprites on the top start at 0
void initSelectedMoves()
{
	for(int cnt_moves = 0; cnt_moves < 9; cnt_moves++)
	{
		playerSelectedMoves[cnt_moves] = enemySelectedMoves[cnt_moves] = 0;
	}
}

const int itemToSprite[] =
{
	Sprite_Damage10, Sprite_Damage25, Sprite_Damage50, Sprite_Damage100,
	Sprite_Shield10, Sprite_Shield25, Sprite_Shield50, Sprite_Shield100,
	Sprite_Health10, Sprite_Health25, Sprite_Health50, Sprite_Health100,
	Sprite_Empty
};


const int moveToSprite[] =
{
	Sprite_Empty, Sprite_B,Sprite_S,Sprite_C,Sprite_Defense
};

const char * DiedText = "You Died!";

void runDiedDialog()
{
	playSound(snd_dead);
	for(int cnt_sprites=0; cnt_sprites < 17; cnt_sprites++)
	{
		mSprites_sub[cnt_sprites].priority = 2;
		mSprites[cnt_sprites].priority = 1;
	}
	updateOAM();
	
	videoSetMode(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE);
	
	uint16 * smap0 = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * smap1 = (uint16*)SCREEN_BASE_BLOCK_SUB(31);

	swiWaitForVBlank();
	
	drawDBox(smap0,2, 3,6,25,11);
	
	//Draw the text
	printText16(DiedText, smap1, 10, 7, 12, strlen(DiedText));

	printText16("Tap to continue",smap1, 7, 14, 12, 15);
	
	
	bool touched = true;
	
	while(true)
	{
		//Check for key touch on the Yes or No
		if(TOUCH_SCREEN)
		{
			if(touched) continue;
			break;
		}
		else
		{
			touched = false;
		}
	}
	playSound(snd_click);
	
	swiWaitForVBlank();
}

void initSelectedMoveSprites()
{
	
	for(int cnt_moves = 0; cnt_moves < 9; cnt_moves++)
	{
		mSprites_sub[6 + cnt_moves].name = Sprite_Empty;
		mSprites_sub[6 + cnt_moves].size = 2;
		mSprites_sub[6 + cnt_moves].color_256 = 1;
		mSprites_sub[6 + cnt_moves].priority = 0;
		
		mSprites[cnt_moves].name = Sprite_Empty;
		mSprites[cnt_moves].size = 2;
		mSprites[cnt_moves].color_256 = 1;
		mSprites[cnt_moves].priority = 0;
		
		if(cnt_moves < 5)
		{
			if(playerInfo.attackSlots > cnt_moves)
			{
			 mSprites_sub[6 + cnt_moves].x = cnt_moves * 42 + 28;
			 mSprites_sub[6 + cnt_moves].y = 10;
			}
			
			if(enemyStats[ENEMY_ATTACKSLOTS] > cnt_moves)
			{
			 mSprites[cnt_moves].x = cnt_moves * 42 + 28;
			 mSprites[cnt_moves].y = 138;
			}
		}
		else
		{
			if(playerInfo.attackSlots > cnt_moves)
			{
			 mSprites_sub[6 + cnt_moves].x = (cnt_moves - 5) * 42 + 49;
			 mSprites_sub[6 + cnt_moves].y = 34;
			}
			
			if(enemyStats[ENEMY_ATTACKSLOTS] > cnt_moves)
			{
			 mSprites[cnt_moves].x = (cnt_moves-5) * 42 + 49;
			 mSprites[cnt_moves].y = 114;
			}
		}
	}
}

void displaySelectedMoves()
{
	for(int cnt_moves = 0; cnt_moves < 9; cnt_moves++)
	{
		if(playerSelectedMoves[cnt_moves] == 5) //left item
		{
			mSprites_sub[6 + cnt_moves].name = itemToSprite[usedItems[0]];
		}
		else if(playerSelectedMoves[cnt_moves] == 6) //right item
		{
			mSprites_sub[6 + cnt_moves].name = itemToSprite[usedItems[1]];
		}
		else
		{
			mSprites_sub[6 + cnt_moves].name = moveToSprite[playerSelectedMoves[cnt_moves]];
		}
		
		mSprites[cnt_moves].name = moveToSprite[enemySelectedMoves[cnt_moves]];
	}
}


void displayPlayerItems()
{
	//3,5
	
	if(playerInfo.leftHandItem != 13)
	{
		mSprites_sub[3].name = itemToSprite[playerInfo.leftHandItem];
		mSprites_sub[3].x = 64;
		mSprites_sub[3].y = 156;
	}
	
	
	if(playerInfo.rightHandItem != 13)
	{
		mSprites_sub[5].name = itemToSprite[playerInfo.rightHandItem];
		mSprites_sub[5].x = 160;
		mSprites_sub[5].y = 156;
	}
	
}

void hideOld()
{
	for(int cnt_sprites = 0; cnt_sprites < 17; cnt_sprites++)
	{
		mSprites_sub[cnt_sprites].x = 256;
		mSprites_sub[cnt_sprites].y = 196;
		mSprites_sub[cnt_sprites].priority = 0;
		
		mSprites[cnt_sprites].x = 256;
		mSprites[cnt_sprites].y = 196;
		mSprites[cnt_sprites].priority = 0;
	}
}

char healthDisp[4];

void displayHealths()
{
	sprintf(healthDisp,"%3.0d",playerInfo.maxHp);
	printText16(healthDisp, (uint16*)SCREEN_BASE_BLOCK(31),7,9,1,3);
	sprintf(healthDisp,"%3.0d",enemyStats[0]);
	printText16(healthDisp, (uint16*)SCREEN_BASE_BLOCK(31),20,9,1,3);
}

void displayBattleHealths(int chealth)
{
	sprintf(healthDisp,"%3.0d",chealth);
	printText16(healthDisp, (uint16*)SCREEN_BASE_BLOCK(31),7,9,1,3);
	sprintf(healthDisp,"%3.0d",enemyStats[0]);
	printText16(healthDisp, (uint16*)SCREEN_BASE_BLOCK(31),20,9,1,3);
}


void initDisplayForDuel()
{
	//Display the bottom
	uint16 * blahGround2 = (uint16*)SCREEN_BASE_BLOCK_SUB(28);
	uint16 * blahGround = (uint16*)SCREEN_BASE_BLOCK_SUB(29);
	uint16 * background = (uint16*)SCREEN_BASE_BLOCK_SUB(30);
	uint16 * border = (uint16 *)SCREEN_BASE_BLOCK_SUB(31);
	
	//Set the bottom to blanks
	int at = 0;
	
	hideOld();
	for(int cnt_sprites = 0; cnt_sprites < 9; cnt_sprites++)
	{
		mSprites[cnt_sprites].size = 2;
		mSprites[cnt_sprites].color_256 = 1;
		mSprites[cnt_sprites].priority = 0;
	}
	
	mSprites_sub[0].name = Sprite_S;
	mSprites_sub[0].x = 112;
	mSprites_sub[0].y = 70;
	
	mSprites_sub[1].name = Sprite_B;
	mSprites_sub[1].x = 80;
	mSprites_sub[1].y = 98;
	
	mSprites_sub[2].name = Sprite_C;
	mSprites_sub[2].x= 144;
	mSprites_sub[2].y= 98;
	
	displayPlayerItems();
	mSprites_sub[3].size = 2;
	

	mSprites_sub[4].x = 112;
	mSprites_sub[4].y = 156;
	mSprites_sub[4].size = 2;
    mSprites_sub[4].priority=0;	
	mSprites_sub[4].color_256 = 1;
	mSprites_sub[4].name = Sprite_Defense;	
	
	mSprites_sub[5].color_256 = 1;
	mSprites_sub[5].size = 2;
	mSprites_sub[5].priority=0;

	
	//Display the top
	//uint16 * map0 = (uint16*)SCREEN_BASE_BLOCK(28);
	uint16 * map1 = (uint16*)SCREEN_BASE_BLOCK(29);
	uint16 * map2 = (uint16*)SCREEN_BASE_BLOCK(30);
	uint16 * map3 = (uint16*)SCREEN_BASE_BLOCK(31);

	videoSetMode(MODE_0_2D | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D | DISPLAY_BG0_ACTIVE | DISPLAY_BG1_ACTIVE | DISPLAY_BG2_ACTIVE);

	dmaCopy((uint16 *)duelItemSpritePal,(uint16*)SPRITE_PALETTE,256*2);
	dmaCopy((uint16 *)duelItemSprites, (uint16*)SPRITE_GFX,24576);
	dmaCopy((uint16 *)duelItemSpritePal,(uint16*)SPRITE_PALETTE_SUB,256*2);
	dmaCopy((uint16 *)duelItemSprites, (uint16*)SPRITE_GFX_SUB,24576);

	for(int cnt_y = 0; cnt_y < 24; cnt_y++)
	{
		
		for(int cnt_x = 0; cnt_x < 32; cnt_x++)
		{
			map2[at] = map3[at] = background[at] = border[at] = 0;
			map1[at] = blahGround[at] = blahGround2[at] = 1;
			
			at++;
		}
		
		map2[cnt_y * 32] = background[cnt_y * 32] = 6;
		map2[cnt_y *32 + 1] = background[cnt_y * 32 + 1] = 7;
		map2[cnt_y *32 + 30] = background[cnt_y * 32 + 30] = 5;
		map2[cnt_y *32 + 31] = background[cnt_y * 32 + 31] = 6;
	}


	drawDBox(map2, 2, 3, 0, 25, 3);
	drawDBox(map2, 2, 3, 5, 12, 7);
	drawDBox(map2, 2, 16, 5, 12, 7);
	printText16("duel", (uint16*)SCREEN_BASE_BLOCK(31), 14, 1, 1,4);
	printText16("player", (uint16*)SCREEN_BASE_BLOCK(31), 6, 6, 1, 6);
	printText16("enemy", (uint16*)SCREEN_BASE_BLOCK(31),20,6,1,5);
	displayHealths();
	
	initSelectedMoveSprites();
	
	updateOAM();
}

void uninitDisplayForDuel()
{
	//Need to call the functions that display the top map of the town
	//Fix the bottom to display properly, display the arena
}



void getPlayerMove(int moveat)
{
	bool touched = true;
	while(playerSelectedMoves[moveat] == 0)
	{
		if(TOUCH_SCREEN)
		{
			touched = true;
			int touchx = IPC->touchXpx;
			int touchy = IPC->touchYpx;
			
			//Time to figure out what the heck they are touching
			if(touchy > 150 && touchy < 196)
			{
				//This could be left item, right item or defense
				//Left Item
				if(touchx > 56 && touchx < 102)
				{
					if(playerInfo.leftHandItem != 12 && playerInfo.items[playerInfo.leftHandItem] > 0)
					{
						usedItems[0] = playerInfo.leftHandItem;
						playerSelectedMoves[moveat] = 5;
						playerInfo.items[playerInfo.leftHandItem]--;
						if(playerInfo.items[playerInfo.leftHandItem] == 0)
						{
							playerInfo.leftHandItem = 12;
							displayPlayerItems();
						}
						
						if(playerInfo.items[playerInfo.rightHandItem] == 0)
						{
							playerInfo.rightHandItem = 12;
							displayPlayerItems();
						}
					}
					else
					{
						playSound(snd_error);
					}
				}
				else if(touchx > 104 && touchx < 150)
				{
					playerSelectedMoves[moveat] = 4;
				}
				else if(touchx > 152 && touchx < 200)
				{
					if(playerInfo.rightHandItem != 12 && playerInfo.items[playerInfo.rightHandItem] > 0)
					{
						playerSelectedMoves[moveat] = 6;
						usedItems[1] = playerInfo.rightHandItem;
						playerInfo.items[playerInfo.rightHandItem]--;
						if(playerInfo.items[playerInfo.leftHandItem] == 0)
						{
							playerInfo.leftHandItem = 12;
							displayPlayerItems();
						}
						
						if(playerInfo.items[playerInfo.rightHandItem] == 0)
						{
							playerInfo.rightHandItem = 12;
							displayPlayerItems();
						}
					}
				}
			}
			//Standing
			else if(touchy > 62 && touchy < 102 && touchx > 104 && touchx < 144)
			{
				playerSelectedMoves[moveat] = 2;
			}
			//only other choice is Backup or charge
			else if(touchy > 90 && touchy < 130)
			{
				if(touchx > 72 && touchx < 112)
				{
					playerSelectedMoves[moveat] = 1;
				}
				else if(touchx > 136 && touchx < 176)
				{
					playerSelectedMoves[moveat] = 3;
				}
			} 
		}
		else
		{
			touched = false;
		}
	}
	
	playSound(snd_click);
	while(TOUCH_SCREEN);
}

void randomlySelectComputersMoves()
{
	for(int cnt_moves = 0; cnt_moves < enemyStats[ENEMY_ATTACKSLOTS]; cnt_moves++)
	{
		enemySelectedMoves[cnt_moves] = ((rand() % 32)/8) + 1;
	}
}

void figureOutDamage(int moveat,double * playerMultiplier,double * enemyMultiplier)
{
	//player has less moves than cpu
	if(moveat >= playerInfo.attackSlots)
	{
		*playerMultiplier = 0.0;
		if(enemySelectedMoves[moveat] == 4)
		{
			*enemyMultiplier = 0.0;
		}
		else
		{
			*enemyMultiplier = 1.0;
		}
	}
	else if(moveat >= enemyStats[ENEMY_ATTACKSLOTS])
	{
		if(playerSelectedMoves[moveat] != 4)
		{
			*playerMultiplier = 1.0;
		}
		else
		{
			*playerMultiplier = 0.0;
		}
		*enemyMultiplier = 0.0;
	}
	//Enemy is defending
	else if(enemySelectedMoves[moveat] == 4)
	{
		if(playerSelectedMoves[moveat] == 1)
		{
			*playerMultiplier = 0.0;
		}
		else if(playerSelectedMoves[moveat] != 4)
		{
			*playerMultiplier = 0.5;
		}
		*enemyMultiplier = 0.0;
	}
	//Backing up
	else if(playerSelectedMoves[moveat] == 1)
	{
		//Computer is chargin
		if(enemySelectedMoves[moveat] == 3)
		{
			*enemyMultiplier = 0.5;
			*playerMultiplier = 2.0;
		}
		//Computer is standing
		else if(enemySelectedMoves[moveat] == 2)
		{
			*enemyMultiplier = 0.5;
			*playerMultiplier = 0.5;
		}
		//Computer is backing up
		else if(enemySelectedMoves[moveat] == 1)
		{
			*enemyMultiplier = 0;
			*playerMultiplier = 0;
		}
	}
	//standing 
	else if(playerSelectedMoves[moveat] == 2)
	{
		//Computer is chargin
		if(enemySelectedMoves[moveat] == 3)
		{
			*enemyMultiplier = 2.0;
			*playerMultiplier = 0;
		}
		//Computer is standing
		else if(enemySelectedMoves[moveat] == 2)
		{
			*enemyMultiplier = 1;
			*playerMultiplier = 1;
		}
		//Computer is backing up
		else if(enemySelectedMoves[moveat] == 1)
		{
			*enemyMultiplier = 0.5;
			*playerMultiplier = 0.5;
		}
	}
	//Charging
	else if(playerSelectedMoves[moveat] == 3)
	{
		//Computer is chargin
		if(enemySelectedMoves[moveat] == 3)
		{
			*enemyMultiplier = 1;
			*playerMultiplier = 1;
		}
		//Computer is standing
		else if(enemySelectedMoves[moveat] == 2)
		{
			*enemyMultiplier = 0.0;
			*playerMultiplier = 2.0;
		}
		//Computer is backing up
		else if(enemySelectedMoves[moveat] == 1)
		{
			*enemyMultiplier = 0.5;
			*playerMultiplier = 2.0;
		}
	}
	//Player is defending or using an item
	else if(playerSelectedMoves[moveat] == 4)
	{
		*playerMultiplier = 0.0;
		if(enemySelectedMoves[moveat] == 1)
		{
			*enemyMultiplier = 0.0;
		}
		else
		{
			*enemyMultiplier = 0.5;
		}
	}
}

int runDuel()
{
	fade_out(125,100);
	initDisplayForDuel();
	
	fade_in(125,100);
//duel
	unsigned int playerHealth = playerInfo.maxHp;
	int foresightP = playerInfo.basicStats[PLAYER_SPEED]/2 + playerInfo.basicStats[PLAYER_FORESIGHT];
	int foresightE = enemyStats[ENEMY_SPEED]/2 + enemyStats[ENEMY_FORESIGHT];
	bool playerSees = foresightP > foresightE;

	
	int moveat = 0;
	int defenseUp = 0;
	
	while(true)
	{
	//run the battle till it's over and then break from the loop or return
		//Select moves
		initSelectedMoves();
		displaySelectedMoves();
		updateOAM();
		
		if(playerSees)
		{
			//Select all of the computer's moves first and then display them
			randomlySelectComputersMoves();
			displaySelectedMoves();
			updateOAM();
		}
			//They select them one at a time together
		moveat = 0;
		while(moveat < playerInfo.attackSlots)
		{
			getPlayerMove(moveat);
			displaySelectedMoves();
			updateOAMSub();
			moveat++;
		}
			
		if(!playerSees)
		{
			randomlySelectComputersMoves();
			displaySelectedMoves();
			updateOAM();
		}	
		
		while(TOUCH_SCREEN);
		
		//deal damage
		//Go through each move and deal damage
		double playerMultiplier = 0;
		double enemyMultiplier = 0;
		
		bool playerFaster = playerInfo.basicStats[PLAYER_SPEED] < enemyStats[ENEMY_SPEED];
		
		moveat = 0;
		for(moveat = 0; moveat < playerInfo.attackSlots || moveat < enemyStats[ENEMY_ATTACKSLOTS]; moveat++)
		{
			
			//Figure out damage
			figureOutDamage(moveat,&playerMultiplier,&enemyMultiplier);
			
			int damageToEnemy = (int)(playerMultiplier * (playerInfo.basicStats[PLAYER_ATTACK] + playerInfo.basicStats[PLAYER_AGILITY] - (enemyStats[ENEMY_ATTACK] + enemyStats[ENEMY_AGILITY])/2));
			int damageToPlayer = (int)(enemyMultiplier * (enemyStats[ENEMY_ATTACK] + enemyStats[ENEMY_AGILITY]/2 - defenseUp - (playerInfo.basicStats[PLAYER_ATTACK] + playerInfo.basicStats[PLAYER_AGILITY])/2));
			int healthForPlayer = 0;
			
			if(damageToEnemy < 0)
			{
				damageToEnemy = 0;
			}
			
			if(damageToPlayer < 0)
			{
				damageToPlayer = 0;
			}
			
			int item = -1;
			
			if(playerSelectedMoves[moveat] == 5)
			{
				//produce behavior for left hand item
				item = usedItems[0];
			}
			else if(playerSelectedMoves[moveat] == 6)
			{
				//produce behavior for right hand item
				item = usedItems[1];
			}
			
			playerSelectedMoves[moveat] = 0;
			enemySelectedMoves[moveat] = 0;
			//Animate the current sprite to shake a little first
			for(int cnt_times = 0; cnt_times < 2; cnt_times++)
			{
				for(int cnt_left = 0; cnt_left < 4; cnt_left++)
				{
					mSprites_sub[6 + moveat].x--;
					mSprites[moveat].x++;
					swiWaitForVBlank();
					updateOAM();
				}
				for(int cnt_right = 0; cnt_right < 8; cnt_right++)
				{
					mSprites_sub[6 + moveat].x++;
					mSprites[moveat].x--;
					swiWaitForVBlank();
					updateOAM();
				}
				for(int cnt_left = 0; cnt_left < 4; cnt_left++)
				{
					mSprites_sub[6 + moveat].x--;
					mSprites[moveat].x++;
					swiWaitForVBlank();
					updateOAM();
				}
				
			}
			displaySelectedMoves();
			updateOAM();
			//produce the behavior for the item
			int effect = 0;
			if(item != -1)
			{
				switch(item)
				{
					case 0: //damage 10%
						effect = (2 * playerInfo.basicStats[PLAYER_ATTACK] + playerInfo.basicStats[PLAYER_AGILITY]) / 10;
						if(effect == 0)
						{
							damageToEnemy++;
						}
						else
						{	
							damageToEnemy=effect;
						}
						break;
					case 1: //damage 25%
						effect = (2 * playerInfo.basicStats[PLAYER_ATTACK] + playerInfo.basicStats[PLAYER_AGILITY]) / 4;
						if(effect == 0)
						{
							damageToEnemy++;
						}
						else
						{	
							damageToEnemy=effect;
						}
						break;
					case 2: //damage 50%
						effect = (2 * playerInfo.basicStats[PLAYER_ATTACK] + playerInfo.basicStats[PLAYER_AGILITY]) / 2;
						if(effect == 0)
						{
							damageToEnemy++;
						}
						else
						{	
							damageToEnemy=effect;
						}
						break;
					case 3: //damage 100%
						effect = (2 * playerInfo.basicStats[PLAYER_ATTACK] + playerInfo.basicStats[PLAYER_AGILITY]);
						if(effect == 0)
						{
							damageToEnemy++;
						}
						else
						{	
							damageToEnemy=effect;
						}
						break;
					case 4: //shield 10%
						effect = playerInfo.basicStats[PLAYER_DEFENSE]/10;
						if(effect == 0)
						{
							defenseUp++;
						}
						else
						{
							defenseUp += effect;
						}
						break;
					case 5: //shield 25%
						effect = playerInfo.basicStats[PLAYER_DEFENSE]/4;
						if(effect == 0)
						{
							defenseUp++;
						}
						else
						{
							defenseUp += effect;
						}
						break;
					case 6: //shield 50%
						effect = playerInfo.basicStats[PLAYER_DEFENSE]/2;
						if(effect == 0)
						{
							defenseUp++;
						}
						else
						{
							defenseUp += effect;
						}
						break;
					case 7: //shield 100%
						effect = playerInfo.basicStats[PLAYER_DEFENSE];
						if(effect == 0)
						{
							defenseUp++;
						}
						else
						{
							defenseUp += effect;
						}
						break;
					case 8: //health 10%
						damageToPlayer = 0;
						healthForPlayer = playerInfo.maxHp / 10;
						if(healthForPlayer == 0)
						{
							healthForPlayer = 1;
						}
						break;
					case 9: //health 25%
						damageToPlayer = 0;
						healthForPlayer = playerInfo.maxHp / 4;
						if(healthForPlayer == 0)
						{
							healthForPlayer = 1;
						}
						break;
					case 10: //health 50%
						damageToPlayer = 0;
						healthForPlayer = playerInfo.maxHp / 2;
						if(healthForPlayer == 0)
						{
							healthForPlayer = 1;
						}
						break;
					case 11: //health 100%
						damageToPlayer = 0;
						healthForPlayer = playerInfo.maxHp;
						if(healthForPlayer == 0)
						{
							healthForPlayer = 1;
						}
						break;
				}
			}
			
			if(damageToPlayer > damageToEnemy)
			{
				playSound(snd_dead);
			}
			else
			{
				playSound(snd_click);
			}
			
			while(damageToPlayer > 0 || damageToEnemy > 0 || healthForPlayer > 0)
			{
				if(playerFaster)
				{
					//player counter goes first (deals damange to enemy first) and or heals first
					if(healthForPlayer > 0)
					{
						healthForPlayer--;
						playerHealth++;
						if(playerHealth > playerInfo.maxHp)
						{
							playerHealth--;
						}
					}
					
					if(damageToEnemy > 0)
					{
						damageToEnemy--;
						enemyStats[0]--;
						if(enemyStats[0] == 0)
						{
							displayBattleHealths(playerHealth);
							//display victory
							if(fadeOutAfterBattle)
							{
								fade_out(125,100);
							}
							hideOld();
							updateOAM();
							return 1;
						}
					}
					
					if(damageToPlayer > 0)
					{
						damageToPlayer--;
						playerHealth--;
						if(playerHealth == 0)
						{
							displayBattleHealths(0);
							runDiedDialog();
							//display Dialog
							if(fadeOutAfterBattle)
							{
								fade_out(125,100);
							}
							hideOld();
							updateOAM();
							return -1;
						}
					}
				}
				else
				{
					//Enemy counter goes first
					if(damageToPlayer > 0)
					{
						damageToPlayer--;
						playerHealth--;
						if(playerHealth == 0)
						{
							displayBattleHealths(0);
							runDiedDialog();
							//display death
							if(fadeOutAfterBattle)
							{
								fade_out(125,100);
							}
							hideOld();
							updateOAM();
							return -1;
						}
					}
					
					if(healthForPlayer > 0)
					{
						healthForPlayer--;
						playerHealth++;
						if(playerHealth > playerInfo.maxHp)
						{
							playerHealth--;
							healthForPlayer = 0;
						}
					}
					
					if(damageToEnemy > 0)
					{
						damageToEnemy--;
						enemyStats[0]--;
						if(enemyStats[0] == 0)
						{
							displayBattleHealths(playerHealth);
							if(fadeOutAfterBattle)
							{
								fade_out(125,100);
							}
							hideOld();
							updateOAM();
							return 1;
						}
					}
				}
				
				int counter = 10;
				if(damageToEnemy > 10  || damageToPlayer > 10 || healthForPlayer > 10)
				{
					counter = 2;
				}
				
				for(int cnt_frames = 0; cnt_frames < counter; cnt_frames++)
				{
					swiWaitForVBlank();
				}
				
				displayBattleHealths(playerHealth);
			}
		}
	}

	
	return -1;
}

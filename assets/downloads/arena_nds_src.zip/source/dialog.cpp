#include <NDS.h>

void drawDBox(uint16 * bmap, int startTile, int x, int y, int w, int h)
{
	bmap[y*32 +x] = startTile;
	bmap[y*32+x+w] = startTile + 2;
	bmap[(y+h)*32+x] = startTile + 6;
	bmap[(y+h)*32+x+w] = startTile + 8;
	
	for(int cnt_x = x+1; cnt_x < x+w; cnt_x++)
	{
		bmap[y*32+cnt_x] = startTile+1;
		bmap[(y+h)*32 + cnt_x] = startTile+7;
	}
	
	for(int cnt_y = y+1; cnt_y < y + h; cnt_y++)
	{
		bmap[cnt_y*32 + x] = startTile+3;
		bmap[cnt_y*32 + x + w] = startTile + 5;
		
		for(int cnt_x = x+1; cnt_x < x+w; cnt_x++)
		{
			bmap[cnt_y*32 + cnt_x] = startTile + 4;
		}
	}
}

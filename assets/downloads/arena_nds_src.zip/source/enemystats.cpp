#include "enemystats.h"
#include "gameStructs.h"
int enemyStats[7];

void loadUpEnemyStats(int town, int type)
{
	int base = town * 28 + type * 7;
	enemyStats[0] = playerInfo.maxHp + duelerStats[base];

	enemyStats[ENEMY_ATTACK] = playerInfo.basicStats[PLAYER_ATTACK] + duelerStats[ base + ENEMY_ATTACK];
	enemyStats[ENEMY_AGILITY] = playerInfo.basicStats[PLAYER_AGILITY] + duelerStats[ base + ENEMY_AGILITY];
	enemyStats[ENEMY_DEFENSE] = playerInfo.basicStats[PLAYER_DEFENSE] + duelerStats[ base + ENEMY_DEFENSE];
	enemyStats[ENEMY_SPEED] = playerInfo.basicStats[PLAYER_SPEED] + duelerStats[ base + ENEMY_SPEED];
	enemyStats[ENEMY_FORESIGHT] = playerInfo.basicStats[PLAYER_FORESIGHT] + duelerStats[ base + ENEMY_FORESIGHT];
	
	
	if(type == 3)
	{
		enemyStats[6] = playerInfo.attackSlots + 1;
	}
	else
	{
		enemyStats[6] = duelerStats[base + 6];
	}
}

//Lesser, Medium, Stronger, Dueler
const int duelerStats[] =
{
//Town1
-5, 1,  0, -1, 0, 0, 1,
 0, 2,  1, -1, 0, 0, 2,
 5, 3,  1, -1, 0, 0, 3,
10, 3,  1, -1, 0, 0, 0, 
//Town2
-5, 0, 1, 0, -1, 0, 1,
 0, 0, 2, 1, -1, 0, 2,
 5, 0, 3, 1,  0, 0, 3,
10, 0, 3, 1,  -1, 0, 0, 
//Town3
-5, 0, 0, 1, 0, -1, 1,
 0, 0, 0, 2, 1, -1, 2,
 5, 0, 0, 3, 1, -1, 4, 
10, 0, 0, 3, 1, -1, 0,
//Lot's Tower (no stats.)
0,0,0,0,0,0,0,
0,0,0,0,0,0,0,
0,0,0,0,0,0,0,
0,0,0,0,0,0,0,
//Town4
-5, -1, 0, 0, 1, 0, 1,
 0, -1, 0, 0, 3, 1, 2,
 7, -1, 0, 0, 2, 1, 3,
10, -1, 0, 0, 2, 1, 0,
//Town5
-5, 0, 0, -1, -2, 1, 1,
 0, 1, 1, -1, -2, 2, 2,
 5, 1, 2, -1, -2, 3, 3,
10, 1, 2, -1, -2, 3, 0,
//Town6
-5,-1,-1, 0, 1, -2, 1,
0, -1,-1, 1, 2, -2, 2,
-5,-1,-1, 2, 3, -2, 3,
10,-1,-1, 2, 3, -2, 0,
//Town7
-5, -2,1,-1,0,-1,1,
0, -2, 2, -1, 1, -1, 2,
5, -2, 3, -1, 2, -1, 3,
10, -2, 3, -1, 2, -1, 0,
//Town8
-5, 1, -2, 0, -2, 0, 1,
 0, 2, -2, 0, -2, 1, 2,
 5, 3, -2, 0, -2, 2, 3,
10, 3, -2, 0, -2, 2, 0
};

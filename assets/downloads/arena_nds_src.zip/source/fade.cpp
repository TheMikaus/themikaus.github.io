#include <NDS.h>
//FADE FUNCTIONS
void Fade(unsigned short factor)
{
	BLEND_CR = (3<<6) | 63;
	BLEND_Y = factor;
	SUB_BLEND_CR = (3<<6)	 | 63;
	SUB_BLEND_Y = factor;
}

void fade_in(unsigned short fade, unsigned short delay)
{
	unsigned short counter = 0;
    while(fade>0) { fade--; Fade((fade >> 2)); swiWaitForVBlank(); counter = 0; while(delay>counter) counter++;}
}

void fade_out(unsigned short fadev, unsigned short delay)
{
	unsigned short counter = 0;
	unsigned short fade = 0;
    while (fade != (fadev)) { fade++; Fade((fade >> 2)); swiWaitForVBlank(); counter = 0; while(delay>counter) counter++;}
}


void FadeMain(unsigned short factor)
{
	BLEND_CR = (3<<6) | 63;
	BLEND_Y = factor;
}

void FadeSub(unsigned short factor)
{
	SUB_BLEND_CR = (3<<6)	 | 63;
	SUB_BLEND_Y = factor;
}

void fade_inMain(unsigned short fade, unsigned short delay)
{
	unsigned short counter = 0;
    while(fade>0) { fade--; FadeMain((fade >> 2)); swiWaitForVBlank(); counter = 0; while(delay>counter) counter++;}
}

void fade_outMain(unsigned short fadev, unsigned short delay)
{
	unsigned short counter = 0;
	unsigned short fade = 0;
    while (fade != (fadev)) { fade++; FadeMain((fade >> 2)); swiWaitForVBlank(); counter = 0; while(delay>counter) counter++;}
}

void fade_inSub(unsigned short fade, unsigned short delay)
{
	unsigned short counter = 0;
    while(fade>0) { fade--; FadeSub((fade >> 2)); swiWaitForVBlank(); counter = 0; while(delay>counter) counter++;}
}

void fade_outSub(unsigned short fadev, unsigned short delay)
{
	unsigned short counter = 0;
	unsigned short fade = 0;
    while (fade != (fadev)) { fade++; FadeSub((fade >> 2)); swiWaitForVBlank(); counter = 0; while(delay>counter) counter++;}
}

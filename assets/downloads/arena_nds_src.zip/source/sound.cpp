#include <NDS.h>

#include "theattackup_raw.h"
#include "attack_raw.h"
#include "dead_raw.h"
#include "back_raw.h"
#include "error_raw.h"
#include "click_raw.h"

#include "sound.h"



__attribute__ ((section (".ewram"))) TransferSound snd;

//plays an 8 bit mono sample at 11025Hz
void playGenericSound(const void* data, const u32 length)
{
	snd.count = 1;
	snd.data[0].data = data;
	snd.data[0].len = length;
	snd.data[0].rate = 22050;
	snd.data[0].pan = 64;
	snd.data[0].vol = 52;
	snd.data[0].format = 1;

	DC_FlushAll();
	IPC->soundData = &snd;
}

void playSound(int type)
{
	switch(type)
	{
		case snd_attack:
			playGenericSound(attack_raw,(u32)attack_raw_size);
			break;
		case snd_theAttackUp:
			playGenericSound(theattackup_raw,(u32)theattackup_raw_size);
			break;
		case snd_error:
			playGenericSound(error_raw,(u32)error_raw_size);
			break;
		case snd_click:
			playGenericSound(click_raw,(int)click_raw_end-(int)click_raw);
			break;
		case snd_back:
			playGenericSound(back_raw,(u32)back_raw_size);
			break;
		case snd_dead:
			playGenericSound(dead_raw,(u32)dead_raw_size);
			break;
	}
}

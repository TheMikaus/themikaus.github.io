MonsterBlock by Mikaus
website www.themikausprojects.com
For the Kraln Back to (old) school competition.
------------------------------------------------

Random Notes:
-The binary MonsterBlock.gba has music and sound thanks to the AAS lib.
-The zip file contains the binary, the source code (of the non-AAS branch) and a level editor (w/ source, C#)

------------------------------------------------
September 2005 release
------------------------------------------------
Monster Block is a game that mixes a tetris attack-ish type block game with a get your guy to the exit game.  
I know that the description is rather vague, but that's really the best I can come up with.  The goal of the game
is to complete all 25 stages.  You can save between stages, so you don't have to worry about going through all 25 in one
sitting.

=======Controls==========
The player controls the left side of the screen using the GBA controls.  The D-pad moving the cursor and A swapping blocks.  You can
press L or R to change the cursor from horizontal to vertical swapping. You can also press B to remove the current row or column (depends
on what orientation the cursor is) (Also, you can swap these two LR with B by going to the ingame menu [pressing start]).  When you remove blocks, new blocks fall from the top to replace them.

If after swapping you get three in a row of the same type of block, you will be asked if you want to queue that particular action.  You can 
only have six actions in the queue at a time.  If you get more than three in a row then the action is performed an extra time
for every block over three.  So if you had four attack blocks in a row then you would attack twice, and if you had five up movement blocks
in a row then you would move up three times on the map.

What's this map you say?  Well, I'll get to that.  But first...

There are six types of blocks to be found on the play field.  Up, Down, Left, Right, Pick up item and attack action blocks.  The first four actions
are explanitory.  Pick up item will make the player pick up an item that is under them on the map.  To get any item you must pick it up, you can not simply
walk over it.  The attack sends out a red "bullet".  This bullet will travel a default of 2 spaces.  The number of spaces can be increased by picking up a
range item (looks like a +1).  

You can pause the game by pressing start.  This will bring up a menu with four options.

======Items==========
Through out levels you can find a couple of items:
Range up : increases weapon range by one grid space (looks like a +1)
Health Up : increases the player's health by one at a max of four (looks like a little red cross)
Pauser : will prevent monsters from moving for a short period of time (looks like an hour glass)
Split Shot : is a weapon upgrade that makes the player shoot left, right and forward
Cross Shot : is a weapon upgrade that makes the player shoot in all four directions.

======The Map========
The map is on the right hand side of the screen.  It is an 8 by 14 space grid.  Bright green blocks are walls, anything that's red or blue and moving
is probably a monster or a boss (the exception being the player's "bullet").  The player is a green triangle and the exit is a green X.  You can complete a
stage by either defeating all the monsters on the map or by reaching the exit.  You get 100 points extra for every monster that is alive if you reach
the exit point.  Some stages will not have an exit.  On these stages you must defeat all the monsters to continue.

======Play stuff======
-Monsters, Bosses and players move at the same rate.  So use that to help you decide when to move and how much of what action to perform.
-Monsters (red) take 1 point of damage to be rid of
-Bosses (blue) take 5 points of damage to be rid of
-When a player and a monster (or boss) touch (collide with each other) they each take one point of damage and the player is sent back to the start.




===========================BUGS===============================
-So far the only real bug I can find is the sound.  It has some static when you get in to playing the actual game and I don't know why.  I originally wanted no 
music during game play, but the static was really annoying me so now the title screen music carries over.  Still some static but it's harder to hear.
I'm sure if I looked it up I could find the reason, but that's ok.

-At one point during the development of the game the blocks on the play field would just start falling through themselves.  Haven't had this happen since I added
the question for action queue system (where it prompts the player before adding the action to the queue).

-Also.  I haven't played through to the end yet.  I'm on level 7.  There shouldn't be anything funky at the end.  I would play test it more, 
but I need to start studying for my exam coming up.


---------------------------------
Post Mort.
---------------------------------
I think that the idea is an ok idea.  I also feel that some one else might have been able to execute it
in a much better fashion.  Sometimes I feel that the entities move too slow and sometimes I feel the entities 
move too fast, so I can't really decide if I balanced the play very well.  Also.  If you just go through
the game by killing the monsters and bosses you take the whole difficulty out of the game.  I also wish that I
had a better grasp of GBA sound so I could fix the static problems.  But for now I'm alright with the product.
I think this is the most complex console game I've ever written so far, so I'm happy with it.
Thank you for downloading Fall.

This game is inspired by the game Fall Down Forever for the calculator.
If it was made for something else, I don't know about it.  It's taken me two-three
weeks to finish.  It runs pretty good. 

I assume its glitchy, I'm not entirely good at programming, but hey it works!

F12 Switches from full screen to windowed and windowed to full screen.
Try not to switch too often.  There is a small delay after switching, but the game still updates
and runs, so even though you can't see it, there is a chance you'll die anyway.  It pauses perfectly
in windowed mode, when you unselect it.

Enjoy!

-Mikaus
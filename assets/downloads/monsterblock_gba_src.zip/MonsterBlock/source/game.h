#ifndef game_h

extern void initPlayer();
extern void runGame();

#endif

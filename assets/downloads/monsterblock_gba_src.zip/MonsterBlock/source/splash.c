#include "splash.h"
#include "registers.h"
#include <stdlib.h>

#include "map_splash_bin.h"
#include "tiles_splash_bin.h"
#include "pal_splash_bin.h"


void runSplash()
{
	int value = 0;
	//You know I don't really need the palette since I'm going to be setting it manually
	//So I'll just set the needed palettes to white at first
	for(value = 0; value <= 31; value++)
	{
		BackgroundPalette_Memory[0] = RGB(value,value,value);
		BackgroundPalette_Memory[1] = RGB(value,value,value);
		BackgroundPalette_Memory[2] = RGB(value,value,value);
	}
	
	SetMode(0 | BG0_ENABLE );
	
	Register_Bg0Ctrl = 2 | TextBackground_Size256x256 | (29 << SCREEN_SHIFT) | (0 << CHAR_SHIFT);
	
	//Copy the splash to memory
	DMACopy(tiles_splash_bin,CharBaseBlock(0), DMA_32NOW,tiles_splash_bin_size / 4);
	DMACopy(map_splash_bin,ScreenBaseBlock(29), DMA_32NOW, map_splash_bin_size / 4);
	
	
	//Initialize the random seed to vcount + the sram variable
	srand(Register_DisplayCount);
	//Fade in the grey
	for(value = 31; value > 15; value--)
	{
		BackgroundPalette_Memory[1] = RGB(value,value,value);
		rand();
		if( *JOY_REG < 0x3ff) 
		{
			return;
		}
		vsync();
	}
	
	
	//Fade in the black
	for(value = 31; value >= 00; value--)
	{
		BackgroundPalette_Memory[0] = RGB(value,value,value);
		rand();
		if( *JOY_REG < 0x3ff) 
		{
			return;
		}
		vsync();
	}
	
	while(1) 
	{
		if( *JOY_REG < 0x3ff) break;
		value = rand(); //Generate a random number just for the crap of it
		//I make it assign a variable because I don't know if the optimizer will eliminate just
		//a random number generation.  Best be safe than sorry I suppose.
	}
	
	//Fade out the palette
	//I know I could use the fade register and blending
	//but this is much easier since I don't feel like looking it up
	for(value = 31; value >= 0; value--)
	{
		if(value < 15)
		{
			BackgroundPalette_Memory[1] = RGB(value,value,value);
		}
		BackgroundPalette_Memory[2] = RGB(value,value,value);
		vsync();
	}
	
}

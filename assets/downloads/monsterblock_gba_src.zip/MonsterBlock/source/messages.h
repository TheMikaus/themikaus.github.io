#ifndef messages_h
#define messages_h


//message displayed when the player looses
//it asks the player if they wish to try the level again or not.
//Returns a 1 if they say no
extern char message_gameOver();


//Displays a message that states that the stage is cleared by way of monsters
//and states the number of points awarded
extern void message_monstersDefeated();

//Displays a message that states that the stage was cleared by the exit path
//and states the number of points awarded
extern void message_levelExited();

extern void message_win();
#endif

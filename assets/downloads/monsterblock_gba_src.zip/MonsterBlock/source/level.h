#ifndef level_h
#define level_h

#define LAST_LEVEL 25

//This is the level structure and pointer structure used
//A level is an 8 by 14 grid (this is not the tiles portion, just the movement)
//The grid portion is 6 by 7 for the blocks


//Blocks

//These variables that are listed are used to store
//Information about it moving when switching tiles
//However they wont be used in the first pass through
//They will be used when I start implementing the "pretty" stuff
//////////////////////////////////////////////////////////
//Direction is either negative or positive;
//xOffset is the current amount of offset
//yOffset is the current amoutn of offset
//////////////////////////////////////////////////////////

//When a block falls from the sky it has a state of falling and a type that is not None
//it's direction will be marked as position (as y + 1 moves down the screen)
//It's state will be marked as not falling as soon as it's bottom edge touches
//A block that has a state of Sitting and a type not equal to None
//After a block falls and is switched to the sitting state, a check needs to be made
//That sees if the blocks are to fall.

//When a block is switched it enters into the state switching
//and will have a direction set 0,1,2,3 (corresponding to the Defines)
//It will then increase the Y or X Offset accordingly
//After the Xoffset or Yoffset has reached an absolute value of 16 the blocks
//are official switched and the information of the blocks must be set appropriately
//Basically Block A switches with Block B so the Spot in the Play grid occupied by block A
//Will now have an X and Y offset of zero and all the information set that Block B previously had
//And vv.

//After a block is switched or after a row is eliminated
//The left over blocks all get switched to a state of Falling
//To be handled as regular falling blocks


//Type defines
#define Type_Up 0
#define Type_Down 1
#define Type_Left 2
#define Type_Right 3
#define Type_Action 4
#define Type_Pickup 5
#define Type_None 6

//State Defines
#define State_Sitting 0
#define State_Falling 1
#define State_Switching 2
#define State_Disappearing 3

#define Block_SpriteStart 1
#define Block_SpriteEnd 55 

struct blockTag
{
	char yOffset;
	char delay;
	char state;
	char type;
	char x,y;
	char clean;
	
	int sprite;
};

typedef struct blockTag block;

//This is just the play grid that is a set of pointers to the blocks
extern block ** playGrid; //This needs to be allocated to sizeof(block *) * 42
//Size
#define Block_Width 6
#define Block_Height 9 // 0 and 8 are dummies rows that should never be counted
#define blockAt(x,y) playGrid[ (x) + ((y) * Block_Width)]

//This is the list of actual blocks
//Note that no block should be of the type None for long
extern block * blocks; //This needs to be allocated to sizeof(block) * 42

//The blocks are processed linearly in movement and as they pass into the next available play grid
//The playgrid pointer is updated.


//The level on the right
extern char * playGround; //This is the map
#define Map_Height 14
#define Map_Width 8
#define Map_StartX 19
#define Map_StartY 3
#define tileAt(x,y) playGround[ (x) + ((y) * Map_Width)]

//Tile defines
#define Tile_Empty 0
#define Tile_Block 1
#define Tile_Exit 2
#define Tile_Player 3
//Then the item defines
#define Tile_ForwardShot 4
#define Tile_SplitShot 5
#define Tile_CrossShot 6
#define Tile_RangeUp 7
#define Tile_Health 8
#define Tile_Pauser 9
//And anything after that is a monster that is loaded up
#define Tile_Monster_UpDown 10
#define Tile_Monster_LeftRight 11
#define Tile_Monster_DownRight 12
#define Tile_Monster_UpRight 13
#define Tile_Monster_UpLeft 14
#define Tile_Monster_DownLeft 15
#define Tile_Monster_Random 16
//Bosses
#define Tile_Boss_UpDown 17
#define Tile_Boss_LeftRight 18
#define Tile_Boss_DownRight 19
#define Tile_Boss_UpRight 20
#define Tile_Boss_UpLeft 21
#define Tile_Boss_DownLeft 22
#define Tile_Boss_Random 23



//This is the tile for the block and then the exit (5,6)
//These defines will change if the blocks get moved around on the board
#define BackgroundTile_Block 5
#define BackgroundTile_Exit 6
#define BackgroundTile_Damage 11
#define BackgroundTile_Empty 19

//Define the sprites for different stuff
#define Sprite_ForwardShot 25
#define Sprite_SplitShot Sprite_ForwardShot + 1
#define Sprite_CrossShot Sprite_SplitShot + 1
#define Sprite_RangeUp   Sprite_CrossShot + 1
#define Sprite_Health    Sprite_RangeUp + 1
#define Sprite_Pauser    Sprite_Health + 1
#define Sprite_Player	 Sprite_Pauser + 1
#define Sprite_Enemy1	 Sprite_Player + 1 
#define Sprite_Enemy2	 Sprite_Enemy1 + 1 
#define Sprite_Enemy3	 Sprite_Enemy2 + 1 
#define Sprite_Boss1	 Sprite_Enemy3 + 1 
#define Sprite_Boss2	 Sprite_Boss1 + 1 
#define Sprite_Boss3	 Sprite_Boss2 + 1 
#define Sprite_PlayerRight 42
#define Sprite_MonsterRight Sprite_PlayerRight + 1
#define Sprite_BossRight Sprite_MonsterRight + 1

//Define the OAM stuff for the new sprites (used on the map)
#define OAM_ActionStart 68
#define OAM_ActionEnd OAM_ActionStart + 6
#define OAM_Player OAM_ActionEnd + 1
#define OAM_MonsterStart OAM_Player + 1
#define OAM_MonsterEnd   OAM_MonsterStart + 16
#define OAM_BossStart    OAM_MonsterEnd + 1
#define OAM_BossEnd		 OAM_BossStart + 10
#define OAM_ItemStart OAM_BossEnd + 1
#define OAM_ItemEnd OAM_ItemStart + 12

//This is for the level itself
extern char player_start_x;
extern char player_start_y;
extern char player_start_health;
extern char player_start_weapon;
extern char player_start_range;


extern void initBlocks();
extern void freeBlocks();
extern char processBlocks();
extern char getNewBlock(char x, char y);
extern char invalid(char x, int y, char type);
extern void loadMap(const char * pointer);
#endif

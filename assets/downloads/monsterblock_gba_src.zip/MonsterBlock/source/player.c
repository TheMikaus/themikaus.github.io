#include "player.h"
#include "sprites.h"
#include "level.h"
#include "items.h"
#include "dialog.h"
#include "attack.h"
#include <stdlib.h>

#define FRAME_DELAY 150



playerInfo thePlayer;

//Displays the players health in the top right box
#define Health_Sprites Block_SpriteEnd + 4

//Player is allowed to have up to 4 health blocks?
void initPlayerHealth()
{
	char counter;
	spriteHolder * tag;
	
	for(counter = 0; counter < 4; counter++)
	{
		tag = (spriteHolder *) &oSprites[Health_Sprites + counter];
		tag->y = 7;
		tag->color_256 = 0;
		tag->spriteSize = 0;
		tag->x = 240; //start it off the screen
		tag->name = 29;
		tag->palette = 0;
		tag->priority = 2;
	}
	
}


void displayPlayerHealth()
{
	char counter;
	spriteHolder * tag;
	
	
	for(counter = 0; counter < 4; counter++)
	{
		tag = (spriteHolder *)&oSprites[Health_Sprites + counter];
		
		if(thePlayer.health > counter)
		{
			//Display the tag then
			tag->x = 20 * 8 + counter * 13;
		}
		else
		{
			tag->x = 240;
		}
	}
	
	updateSprites();
}

#define Item_Sprites Health_Sprites + 4


//There are only three sprite tiles that can be displayed here
//The pauser, weapon and range
//One sprite for pauser
//One sprite for weapon
//Three for Range (3,4,5)
void initPlayerItems()
{
	spriteHolder * tag;
	int counter;
	
	//Weapon First
	tag = (spriteHolder *)&oSprites[Item_Sprites];
	tag->x = 160;
	tag->y = 18 * 8;
	tag->palette = 0;
	tag->color_256 = 0;
	tag->spriteSize = 0;
	tag->priority = 2;
	
	//Then pauser Which will be stored off screen
	tag++;
	tag->x = 173;
	tag->y = 160; //off screen
	tag->palette = 0;
	tag->color_256 = 0;
	tag->spriteSize = 0;
	tag->priority = 2;
	tag->name = 30;
	
	//The next three need to be set up differently
	//They are the range extensions
	for(counter = 0; counter < 3; counter++)
	{
		tag++;
		tag->x = 186 + counter * 8;
		tag->y = 160;
		tag->palette = 0;
		tag->color_256 = 0;
		tag->spriteSize = 0;
		tag->priority = 2;
		tag->name = 28;
	}
}

//Displays the player items in the bottom right box
void displayPlayerItems()
{
	spriteHolder * tag;
	int counter;
	
	//Display the weapon first
	tag = (spriteHolder *)&oSprites[Item_Sprites];
	tag->name = thePlayer.currentWeaponType + 25;
	
	tag++;
	if(thePlayer.pauser > 0)
	{
		tag->y = 18 * 8;
	}
	else
	{
		tag->y = 160;
	}
	
	for(counter = 0; counter < 3; counter++)
	{
		tag++;
		if(thePlayer.range - 2 > counter)
		{
			tag->y = 18 * 8;
		}
		else
		{
			tag->y = 160;
		}
	}
	
	updateSprites();
}



//Resets the player information to the needed stats
spriteHolder * tag1; // top left
spriteHolder * tag2; // top right
spriteHolder * tag3; // bottom left
spriteHolder * tag4; // bottom right



//Display Current Sprite Position
void displayPlayerPosition()
{
	tag1->x = thePlayer.x * 16 + 24 - 1 - thePlayer.pulse;
	tag1->y = thePlayer.y * 16 + 8 - 1 - thePlayer.pulse;
	
	tag2->y = thePlayer.y * 16 + 8 - 1 - thePlayer.pulse;
	if(thePlayer.orientation == Orientation_Horizontal)
	{
		tag2->x = thePlayer.x * 16 + 48 + 1 + thePlayer.pulse;
	}	
	else
	{
		tag2->x = thePlayer.x * 16 + 32 + 1 + thePlayer.pulse;
	}
	
	tag3->x = thePlayer.x * 16 + 24 - 1 - thePlayer.pulse;
	
	if(thePlayer.orientation == Orientation_Vertical)
	{
		tag3->y = thePlayer.y * 16 + 32 + 1 + thePlayer.pulse;
	}
	else
	{
		tag3->y = thePlayer.y * 16 + 16 + 1+ thePlayer.pulse;
	}
	
	if(thePlayer.orientation == Orientation_Vertical)
	{
		tag4->y = thePlayer.y * 16 + 32 + 1 + thePlayer.pulse;
		tag4->x = thePlayer.x * 16 + 32 + 1 + thePlayer.pulse;
	}
	else
	{
		tag4->y = thePlayer.y * 16 + 16 + 1 + thePlayer.pulse;
		tag4->x = thePlayer.x * 16 + 48 + 1 + thePlayer.pulse;
	}	
	
	if(thePlayer.pulseTime <= 0)
	{
		thePlayer.pulseTime = 100;
		
		thePlayer.pulse += thePlayer.pulseDirection;
		if(thePlayer.pulse == -2 || thePlayer.pulse == 1)
		{
			thePlayer.pulseDirection = -1 * thePlayer.pulseDirection;
		}
	}
	else
	{
		thePlayer.pulseTime--;
	}
	updateSprites();
}


void initPlayer()
{
	//Initialize the player to be at level 1 with 2 health
	//and a zero score.  Weapon Needs to be set to the first
	//weapon and range needs to be set to two 
	thePlayer.swapButtons = 0; //B is the default elimination key
	thePlayer.level = 1;
	thePlayer.score = 0;
	thePlayer.currentWeaponType = 0;
	thePlayer.range = 2;
	thePlayer.health = 2;
	thePlayer.pauser = 0;
	thePlayer.pulse = 0;
	thePlayer.pulseDirection = -1;
	
}

void setupPlayer()
{
	thePlayer.orientation = Orientation_Horizontal;
	thePlayer.x = 2;
	thePlayer.y = 7;


	tag1 = (spriteHolder *) &oSprites[Block_SpriteEnd];
	tag1->color_256 = 0;
	tag1->spriteSize = 0;
	tag1->name = 38;
	tag1->priority = 2;
	tag1->palette = 0;
	
	tag2 = (spriteHolder *) &oSprites[Block_SpriteEnd + 1];
	tag2->color_256 = 0;
	tag2->spriteSize = 0;
	tag2->name = 39;
	tag2->priority = 2;
	tag2->palette = 0;

	tag3 = (spriteHolder *) &oSprites[Block_SpriteEnd + 2];
	tag3->color_256 = 0;
	tag3->spriteSize = 0;
	tag3->name = 40;
	tag3->priority = 2;
	tag3->palette = 0;

	tag4 = (spriteHolder *) &oSprites[Block_SpriteEnd + 3];
	tag4->color_256 = 0;
	tag4->spriteSize = 0;
	tag4->name = 41;
	tag4->priority = 2;
	tag4->palette = 0;

	//Sprite_Palette[7] = RGB(31,31,31);
	//Sprite_Palette[8] = RGB(0,0,31);
	Sprite_Palette[8] = RGB(31,31,0);
	Sprite_Palette[10] = RGB(31,31,31);
	

	initPlayerHealth();
	initPlayerItems();
	resetPlayerQueue();
	updatePlayerQueue();
	displayPlayerHealth();
	displayPlayerPosition();
}

//Setup the player Sprite
void initPlayerOnMap()
{
	spriteHolder * tag;
	
	tag = (spriteHolder *) &oSprites[OAM_Player];
	tag->x = thePlayer.map_x * 8 + Map_StartX * 8;
	tag->y = thePlayer.map_y * 8 + Map_StartY * 8;
	tag->name = Sprite_Player;
	tag->color_256 = 0;
	tag->palette = 0;
	tag->spriteSize = 0;
	tag->priority = 2;
	
	updateSprites();
}

const char * confirmMessages[] =	{
								"queue up?",
								"queue down?",
								"queue left?",
								"queue right?",
								"queue attack?",
								"queue pickup?"
							};
							
const char * confirmOptions[] =	{
									"yes",
									"no"
									};

const unsigned char confirmReturns[] = { 1,0 };

dialog_menuOptions confirmMenu;

//This will return 1 if it worked
//0 if the queue was full
char queuePlayerAction(char type, char count)
{
	int spot = thePlayer.currentAction + thePlayer.actionsInQueue;
	int result = 0;
	dialog_tracker * dt;
	
	spot = spot % 6;
	
	if(type == Type_None)
	{
		return 1;
	}
	if(thePlayer.actionsInQueue == 6)
	{
		return 0;
	}
	
	//Check if they want the action to be added to the queue
	dt = dialog_displayOpen(8, 6, 14, 2, (char *)confirmMessages[(int)type], 0);
	
	confirmMenu.menuText = confirmOptions;
	confirmMenu.menuReturns = confirmReturns;
	confirmMenu.options = 2;
	
	result = dialog_displayMenu(12, 9, 0, 0, &confirmMenu, 0, 0);
	
	dialog_displayClose(dt, (dialog_transitionAction*)0);
	free(dt);
	
	
	if(result == 0 || result == -1)
	{
		return 0;
	}
	
	if(thePlayer.actionsInQueue == 0)
	{
		thePlayer.actionFrames = -1;
	}
	
	thePlayer.actionQueue[spot].count = count - 1; //If it's a three combo this counter will be 2 which performs one action 1 = 3 - 2
	thePlayer.actionQueue[spot].action = type;
	
	thePlayer.actionsInQueue++;
	return 1;
}

//This will move the player to the x and y coordinates on the map grid
//It will also update the movement information, queue information and that fun stuff
void updatePlayerOnMap()
{
	spriteHolder * tag = (spriteHolder *) &oSprites[OAM_Player];

	//If there is anything to do
	if(thePlayer.actionsInQueue > 0)
	{
		//Check and see whether or not the action started
		if(thePlayer.actionFrames == -1)
		{
			//Start processing the action
			thePlayer.actionFrames = 8; //This is the number of animations 
			thePlayer.animationDelay = FRAME_DELAY; //number of loops to delay the count
			
			switch (thePlayer.actionQueue[thePlayer.currentAction].action)
			{
				case Type_Up:
					tag->name = Sprite_Player;
					tag->vflip = 0;
					thePlayer.map_orientation = PLAYER_UP;
					//Collision Check up
					if(thePlayer.map_y == 0 || tileAt(thePlayer.map_x,thePlayer.map_y-1) == Tile_Block)
					{
						thePlayer.actionFrames = 0;
					}
					break;			
				case Type_Down:
					tag->name = Sprite_Player;
					tag->vflip = 1;
					thePlayer.map_orientation = PLAYER_DOWN;
					//Collision Check down
					if(thePlayer.map_y == Map_Height - 1 || tileAt(thePlayer.map_x,thePlayer.map_y+1) == Tile_Block)
					{
						thePlayer.actionFrames = 0;
					}
					break;			
				case Type_Right:
					tag->name = Sprite_PlayerRight;
					tag->hflip = 0;
					thePlayer.map_orientation = PLAYER_RIGHT;
					//Collision Check right
					if(thePlayer.map_x == Map_Width - 1 || tileAt(thePlayer.map_x+1,thePlayer.map_y) == Tile_Block)
					{
						thePlayer.actionFrames = 0;
					}
					break;			
				case Type_Left:
					tag->name = Sprite_PlayerRight;
					tag->hflip = 1;
					thePlayer.map_orientation = PLAYER_LEFT;
					//Collision Check left
					if(thePlayer.map_x == 0 || tileAt(thePlayer.map_x-1,thePlayer.map_y) == Tile_Block)
					{
						thePlayer.actionFrames = 0;
					}
					break;			
				case Type_Pickup:
					//Check for pick ups here
					//add them to player inventory
					pickupItem(thePlayer.map_x,thePlayer.map_y);
					break;
				case Type_Action:
					//Start the attack sequence
					fireWeapon();
					break;
			}
			updateSprites();
		}
		else if(thePlayer.actionFrames == 0)
		{
			thePlayer.offset = 0;
			switch (thePlayer.actionQueue[thePlayer.currentAction].action)
			{
				case Type_Up:
					if(thePlayer.map_y > 0 && tileAt(thePlayer.map_x, thePlayer.map_y - 1) != Tile_Block)
					{
						thePlayer.map_y--;
					}
					break;			
				case Type_Down:
					if(thePlayer.map_y < Map_Height - 1 && tileAt(thePlayer.map_x, thePlayer.map_y + 1) != Tile_Block)
					{
						thePlayer.map_y++;
					}
					break;			
				case Type_Right:
					if(thePlayer.map_x < Map_Width - 1 && tileAt(thePlayer.map_x + 1, thePlayer.map_y ) != Tile_Block)
					{
						thePlayer.map_x++;
					}
					break;			
				case Type_Left:
					if(thePlayer.map_x > 0 && tileAt(thePlayer.map_x - 1, thePlayer.map_y) != Tile_Block)
					{
						thePlayer.map_x--;
					}
					break;
			}
			
			//Check to see if this action needs to be performed any more
			thePlayer.actionQueue[thePlayer.currentAction].count--;
			if(thePlayer.actionQueue[thePlayer.currentAction].count == 0)
			{
				//Move to the next action
				thePlayer.actionsInQueue--;
				
				//initialize the falling of actions
				
				//update the queue information
				thePlayer.currentAction++;
				if(thePlayer.currentAction == 6)
				{
					thePlayer.currentAction = 0;
				}
				//Set the player up to process the next action
				thePlayer.actionFrames = -1;
			}
			else
			{
				thePlayer.actionFrames = -1; //Reprocess current aciton
			}
			
			updatePlayerQueue();
			updateSprites();
		}
		else
		{
			if(thePlayer.animationDelay == 0)
			{
				thePlayer.animationDelay = FRAME_DELAY;
				thePlayer.actionFrames--;
				
				if(thePlayer.actionFrames >= 0)
				{
					//Process the current action
					thePlayer.offset++;
					if(thePlayer.offset < 9)
					{
						switch (thePlayer.actionQueue[thePlayer.currentAction].action)
						{
							case Type_Up:
								tag->y = thePlayer.map_y * 8 + Map_StartY * 8 - thePlayer.offset;
								break;			
							case Type_Down:
								tag->y = thePlayer.map_y * 8 + Map_StartY * 8 + thePlayer.offset;
								break;			
							case Type_Right:
								tag->x = thePlayer.map_x * 8 + Map_StartX * 8 + thePlayer.offset;
								break;			
							case Type_Left:
								tag->x = thePlayer.map_x * 8 + Map_StartX * 8 - thePlayer.offset;
								break;			
							case Type_Pickup:
								break;
							case Type_Action:
								break;
						}
					}
				}
			}
			else
			{
				thePlayer.animationDelay--;
			}
		}
	}
}

//This should set up the sprites accordingly
void resetPlayerQueue()
{
	char counter;
	spriteHolder * tag;
	
	//Display from the bottom up
	for(counter = 0; counter < 6; counter++)
	{
		tag = (spriteHolder *) &oSprites[OAM_ActionStart + counter];	
		tag->x = (Map_StartX - 3) * 8;
		tag->y = 160; //Top of the action pipe
		tag->spriteSize = 1;
		tag->palette = 0;
		tag->color_256 = 0;
		tag->priority = 3;
	}
	
	thePlayer.currentAction = 0;
	thePlayer.actionsInQueue = 0;
}

//This will just display the actions
void updatePlayerQueue()
{
	//Move the sprite to the needed locations
	char counter;
	spriteHolder * tag;
	
	//Display from the bottom up
	for(counter = 0; counter < thePlayer.actionsInQueue; counter++)
	{
		tag = (spriteHolder *) &oSprites[OAM_ActionStart + counter];	
		tag->y = (Map_StartY - 1) * 8 + (6 - counter) * 16; //Top of the action pipe
		tag->name = thePlayer.actionQueue[ (thePlayer.currentAction + counter) % 6].action * 4 + 1;
	}
	
	for(counter = thePlayer.actionsInQueue; counter < 6; counter++)
	{
		tag = (spriteHolder *) &oSprites[OAM_ActionStart + counter];	
		tag->y = 160;
	}
}

//This function is used to check to see if there is an item
//underneath the player.
//If there is then it will put it in the player's inventory and then
//mark it as picked up from the map.
void pickupItem(char x, char y)
{
	//I'm going to loop through the mapItems object
	//and if there is one that is not take and it is at this x,y
	//Add it to the player's struct
	int counter = 0;
	spriteHolder * tag;
	
	for(counter = 0; counter < ITEM_MAX; counter++)
	{
		if(mapItems[counter].inUse == 1 && mapItems[counter].x == x && mapItems[counter].y == y)
		{
			//if the item has not been taken already then 
			//take it
			if(mapItems[counter].taken == 0)
			{
				mapItems[counter].taken = 1;
				
				//Move the sprite off the screen for this item
				tag = ((spriteHolder *)&oSprites[OAM_ItemStart + counter]);
				tag->y = 160;
				
				if(mapItems[counter].item < Tile_RangeUp)
				{
					thePlayer.currentWeaponType = mapItems[counter].item - Tile_ForwardShot;
				}
				else if (mapItems[counter].item < Tile_Health)
				{
					thePlayer.range++;
					if(thePlayer.range > 5)
					{
						thePlayer.range = 5;
					}
				}
				else if (mapItems[counter].item < Tile_Pauser)
				{
					thePlayer.health++;
					if(thePlayer.health > 4)
					{
						thePlayer.health = 4;
					}
				}
				else
				{
					thePlayer.pauser = 6000;
				}
				
				//Update the display of the items
				displayPlayerItems();
				displayPlayerHealth();
			}
			
			//I break here because more than one item can not exist in the same spot
			//ever.  So at this point you've reached the item that will be at the correct
			//spot.  If it's not taken or taken it doesn't matter, you'll no longer
			//need to go through the list.
			break;
		}
	}
}


char playerHit(int counter)
{
	spriteHolder * tag = (spriteHolder *)&oSprites[OAM_MonsterStart + counter];
	spriteHolder * tag2 = (spriteHolder *)&oSprites[OAM_Player];
	char x,y, x2,y2;
	
	//The bounding grid for the tile of attacking
	//it's just easier to use these than the proj->x stuff, less to type
	char bx,by, bx2, by2;
	
	//Use bounding box on the monsters and tile
	//Set the temp variables to the needed sprite variables
	x = tag->x + 2; //I minus two just to make it farther in from the edges
	x2 = tag->x + 6; // 2 from the edge of the monster
	y = tag->y + 2;
	y2 = tag->y + 6;
	
	//Set up the attack
	bx = tag2->x + 2;
	bx2 = tag2->x + 6;
	by = tag2->y + 2;
	by2 = tag2->y + 6;

	//start the collision detection
	return ( (betweenPoint(x,bx,bx2) || betweenPoint(x2,bx,bx2)) &&
			  (betweenPoint(y,by,by2) || betweenPoint(y2,by,by2)) );

}

//Moves the player on the map to the start position
void movePlayerToStart()
{
	spriteHolder * tag = (spriteHolder *)&oSprites[OAM_Player];
	thePlayer.map_x = player_start_x;
	thePlayer.map_y = player_start_y;
	thePlayer.map_orientation = PLAYER_UP;
	thePlayer.offset = 0;
	thePlayer.actionFrames = 0;
	thePlayer.animationDelay = 0;
	
	thePlayer.currentAction = 0;
	thePlayer.actionsInQueue = 0;
	
	tag->x = Map_StartX * 8 + player_start_x * 8;
	tag->y = Map_StartY * 8 + player_start_y * 8;
}

void resetPlayer()
{
	movePlayerToStart();
	thePlayer.health = player_start_health;
	thePlayer.range = player_start_range;
	thePlayer.currentWeaponType = player_start_weapon;
	setupPlayer();
	resetPlayerQueue();
}

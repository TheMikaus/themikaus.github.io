#include "messages.h"
#include "registers.h"
#include "dialog.h"
#include "monsters.h"
#include "player.h"
#include "sram.h"

#include <stdlib.h>
#include <stdio.h>

char message_menusInit = 0;


////////GAME OVER MENU
const char * message_gameOverOptions[] =	{
											"restart stage",
											"exit to title"
											};

const unsigned char message_gameOverReturns[] = { 0,1 };

const char * message_gameOverText = "   you died!";

dialog_menuOptions message_gameOverMenu;


////////Messages
const char * message_levelExitText = "level exited";
const char * message_monstersDefeatedText = "monsters defeated!";
const char * message_winText = "you beat the game!";
const char * message_scoreFormat = "  you gained\n\n %d points!";



//Made it up to 35 characters just in case
char scoreText[35];




//Sets up the menu variables properly
void message_initMenu()
{
	message_menusInit = 1;
	
	//Load the variables up properly
	
	//game over menu
	message_gameOverMenu.menuText = message_gameOverOptions;
	message_gameOverMenu.menuReturns = message_gameOverReturns;
	message_gameOverMenu.options = 2;

}

//message displayed when the player looses
//it asks the player if they wish to try the level again or not.
//Returns a 1 if they say no
char message_gameOver()
{
	char result;
	
	dialog_tracker * dt;
	
	//If the menus haven't been set up yet
	//set them up
	//It would be more efficient to just call it when the game is loaded
	//but I'm here now and this is where it'll go
	if(!message_menusInit)
	{
		message_initMenu();
	}
	

	//Display the you died message
	dt = dialog_displayOpen(8, 4, 15, 2, (char *)message_gameOverText, 0);
	
	//Run the menu underneath it
	result = dialog_displayMenu(8, 7, 0, 0, &message_gameOverMenu, 1, 0);
	
	//Close the you died message and free the memory allocated
	dialog_displayClose(dt, 0);
	free(dt);
	
	//Return the result from the game over dialog
	return result;
}


//This function calculates the score given to the player
//counts up the number of living monsters
//and adding 1000 + numberoflivingmonsters * 100 points
//displays the score after calculation
dialog_tracker * message_displayScore()
{
	int score = 1000;
	int monsterC = 0;
	int counter = 0;
	
	//Check only the regular monsters
	//The levels should be set up so that there can not be
	//a boss and an exit at the same time
	//bosses must be defeated (on stages with bosses and monsters all of them must be defeated)
	for(counter = 0; counter < monsterCount; counter++)
	{
		if(monsters[counter].health > 0)
		{
			monsterC++;
		}
	}
	
	score += (monsterC * 100);
	
	//Sprint the text
	sprintf(scoreText,message_scoreFormat,score);
	
	thePlayer.score += score;
	sram_checkHighScore();
	
	//Display the dialog and return the pointer
	return dialog_displayOpen(7,6,15,4, scoreText, 0);
}

//I know I should just combine the two functions below into one
//but I have already done this and so I'll leave it this way


//Displays a message that states that the stage is cleared by way of monsters
//and states the number of points awarded
void message_monstersDefeated()
{
	dialog_tracker * dt;
	dialog_tracker * dt2;
	
	//Display the text message
	dt = dialog_displayOpen(5,3,19,2, (char *)message_monstersDefeatedText,0);
	
	//display the scoring message (using a function)
	dt2 = message_displayScore();
	
	//Call the save menu function
	sram_saveGameMenu();
	
	//Clean up
	dialog_displayClose(dt,0);
	dialog_displayClose(dt2,0);
	free(dt);
	free(dt2);
}

//Displays a message that states that the stage was cleared by the exit path
//and states the number of points awarded
void message_levelExited()
{
	dialog_tracker * dt;
	dialog_tracker * dt2;
	
	//Display the text message
	dt = dialog_displayOpen(5,3,19,2, (char *)message_levelExitText,0);
	
	//display the scoring message (using a function)
	dt2 = message_displayScore();
	
	//Call the save menu function
	sram_saveGameMenu();

	//Clean up
	dialog_displayClose(dt,0);
	dialog_displayClose(dt2,0);
	free(dt2);
	free(dt);
}

void message_win()
{
	KeyReleased();
	free(dialog_displayOpen(5,3,19,2,(char *)message_winText,0));
	
	KeyPressed();
}

#ifndef leveldata_h
#define leveldata_h

extern const char levelData[];
#endif

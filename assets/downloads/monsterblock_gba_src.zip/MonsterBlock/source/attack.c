#include "attack.h"
#include "sprites.h"
#include "player.h"
#include "level.h"
#include "monsters.h"

#define PROJECTILE_DELAY 400

projectile projectiles[PROJECTILE_MAX];
int projectileCounter;

void resetProjectiles()
{
	int counter;
	projectileCounter = 0;
	for(counter = 0; counter < PROJECTILE_MAX; counter++)
	{
		projectiles[counter].inUse = 0;
	}
}

void addPlayerProjectile(char x, char y, char direction, char tilesLeft)
{
	int counter;
	
	//If there is no more room don't do anything
	//Maybe in the future play a noise or something
	if(projectileCounter == PROJECTILE_MAX)
	{
		return;
	}
	
	//find the first available projectile
	for(counter = 0; counter < PROJECTILE_MAX; counter++)
	{
		if(projectiles[counter].inUse == 0)
		{
			//Found it leave after initialization
			projectiles[counter].x = x;
			projectiles[counter].y = y;
			projectiles[counter].direction = direction;
			projectiles[counter].inUse = 1;
			projectiles[counter].tilesLeft = tilesLeft;
			projectiles[counter].tileDelay = 0;
			
			return;
		}
	}
}

/*
	char x,y; //Where the projectile is on the screen
	char direction; //Use the player orientation stuff again
	char tileDelay; //number of cycles before it moves to the next frame
	char inUse; //is this projectile frame in use?
	char playerOwner; //for now this will always be 1, till I make monsters attack
	char tilesLeft; // how many more tiles does this need to travel
	
*/




//I branched it out into a function for the following reason
//You can just do a simple x=x y=y because the monster is moving
//Which means you just have to find out if the monster touches the given
//projectile's grid.  Projectiles always take up the whole grid and never
//have intermediate spaces.  So if more than a quarter of the monster (2 pixels) is 
//in the tile then whack!
char monsterHit(projectile * proj, int monster)
{
	spriteHolder * tag = (spriteHolder *)&oSprites[OAM_MonsterStart + monster];
	char x,y, x2,y2;
	
	//The bounding grid for the tile of attacking
	//it's just easier to use these than the proj->x stuff, less to type
	char bx,by, bx2, by2;
	
	//Use bounding box on the monsters and tile
	//Set the temp variables to the needed sprite variables
	x = tag->x + 2; //I minus two just to make it farther in from the edges
	x2 = tag->x + 6; // 2 from the edge of the monster
	y = tag->y + 2;
	y2 = tag->y + 6;
	
	//Set up the attack
	bx = proj->x * 8 + Map_StartX * 8;
	bx2 = bx + 8;
	by = proj->y * 8 + Map_StartY * 8;
	by2 = by + 8;

	//start the collision detection
	return ( (betweenPoint(x,bx,bx2) || betweenPoint(x2,bx,bx2)) &&
			  (betweenPoint(y,by,by2) || betweenPoint(y2,by,by2)) );
}

//This function processes the projectiles
//What does this mean?
//Well it means that it moves all of them as it needs to
//The collision detection I think should be done here
//but I may decide to do it in the game function anyway
//not sure.  Depends on how I feel
void processProjectiles()
{
	int counter;
	int monster_counter;
	projectile * proj;
	unsigned short * map = (unsigned short *)ScreenBaseBlock(29);
	
	//first things first.  Loop through them
	//Find one in use
	//update it's information
	//update the background if needed
	for(counter = 0; counter < PROJECTILE_MAX; counter++)
	{
		if(projectiles[counter].inUse == 1)
		{
			proj = &projectiles[counter];
			
			//Check to see if we hit any monsters
			for(monster_counter = 0; monster_counter < TotalEnemies; monster_counter++)
			{
				if(monsters[monster_counter].health > 0 && monsterHit(proj,monster_counter))
				{
					map[ (proj->x + Map_StartX) + (proj->y + Map_StartY) * 32] = BackgroundTile_Empty;
					proj->inUse = 0;
					takeDamage(monster_counter);
					break;
				}
			}
			
			//hit a monster/Boss
			if(proj->inUse == 0)
			{
				continue;
			}
			
			if(proj->tileDelay <= 0)
			{
				//Clear the old spot
				//then process the projectile
				map[ (proj->x + Map_StartX) + (proj->y + Map_StartY) * 32] = BackgroundTile_Empty;
				
				//if the projectiles existance is up
				//then it's make it go away
				if(proj->tilesLeft <= 0)
				{
					proj->inUse = 0;
				}
				else
				{
					proj->tileDelay = PROJECTILE_DELAY;
					proj->tilesLeft--;
					
					switch(proj->direction)
					{
						case PLAYER_UP:
							if(proj->y == 0 || tileAt(proj->x,proj->y - 1) == Tile_Block)
							{
								proj->inUse = 0;
							}
							else
							{
								proj->y--;
							}
							break;
						case PLAYER_DOWN:
							if(proj->y == Map_Height - 1 || tileAt(proj->x, proj->y + 1) == Tile_Block)
							{
								proj->inUse = 0;
							}
							else
							{
								proj->y++;
							}
							break;
						case PLAYER_LEFT:
							if(proj->x == 0 || tileAt(proj->x - 1, proj->y) == Tile_Block)
							{
								proj->inUse = 0;
							}
							else
							{
								proj->x--;
							}
							break;	
						case PLAYER_RIGHT:
							if(proj->x == Map_Width - 1 || tileAt(proj->x + 1, proj->y) == Tile_Block)
							{
								proj->inUse =  0;
							}
							else
							{
								proj->x++;
							}
							break;
					}
					
					if(proj->inUse == 1)
					{
						map[ (proj->x + Map_StartX) + (proj->y + Map_StartY) * 32] = BackgroundTile_Damage;
					}
				}
				
			}
			else
			{
				proj->tileDelay--;
			}
		}
	}
}


//Fire the weapon based on the player's inventory
void fireWeapon()
{
	//I could number this 0 - > 2 or even use different defines
	//but this works ok.  I just didn't feel like changing it
	switch(thePlayer.currentWeaponType)
	{
		case Tile_ForwardShot - Tile_ForwardShot:
			addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,thePlayer.map_orientation,thePlayer.range);
			break;
		case Tile_SplitShot - Tile_ForwardShot:
			addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,thePlayer.map_orientation,thePlayer.range);
			
			if(thePlayer.map_orientation == PLAYER_UP || thePlayer.map_orientation == PLAYER_DOWN)
			{
				addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_LEFT,thePlayer.range);
				addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_RIGHT,thePlayer.range);
			}
			else
			{
				addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_UP,thePlayer.range);
				addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_DOWN,thePlayer.range);
			}
			
			break;
		case Tile_CrossShot - Tile_ForwardShot:
			addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_UP,thePlayer.range);
			addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_DOWN,thePlayer.range);
			addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_LEFT,thePlayer.range);
			addPlayerProjectile(thePlayer.map_x,thePlayer.map_y,PLAYER_RIGHT,thePlayer.range);
			break;
	}
}

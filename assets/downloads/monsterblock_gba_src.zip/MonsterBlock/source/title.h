#ifndef title_h
#define title_h
//This will either return 1 or 0
//A 0 means new game
//A 1 means loaded
extern int runTitleScreen();
#endif 

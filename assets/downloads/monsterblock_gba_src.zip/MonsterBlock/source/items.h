#ifndef items_h
#define items_h

#define ITEM_MAX 12
struct itemInfoTag
{
	char x, y; //The position on the map that the item is
	char taken; //Usually set to 0
	char inUse; //Whether or not this tag object contains an items
	char item; //What item does it contain
};

typedef struct itemInfoTag itemInfo;


extern itemInfo mapItems[]; 
extern int itemCount;
extern void loadNewItem(char tile, char x, char y);
extern void resetItems();
#endif

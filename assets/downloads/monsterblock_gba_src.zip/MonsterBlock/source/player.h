#ifndef player_h
#define player_h

#define Orientation_Horizontal 0
#define Orientation_Vertical 1


struct playerQueueTag
{
	char count; //Number of times this action is performed
	char action; //Duh.
};

typedef struct playerQueueTag playerQueue;

#define PLAYER_UP 0
#define PLAYER_RIGHT 1
#define PLAYER_DOWN 2
#define PLAYER_LEFT 3

struct playerInfoTag
{
	//The following pieces of information are those that are saved
	char swapButtons; //If this is 1 then LR eliminates
	char level; //This will probably be between 1 and 50 (inclusive)
	unsigned long int score; //This can be from 0->max(u32), make sure the levels are set up to not breach this value
	char currentWeaponType; //This can be either Forward, Left/Right/Forward, or Cross
	char range; //This can be 2->5, starting value is 2
	int health; //Current health, max 4
				  //At the end of the stage this becomes Max(minimum start health, playerInfo.health)
	
	//The next set of information is level specific and is not saved.
	char x,y; //Current position on the field
	char orientation; //Current orientation
	int pauser;
	int pulse; //This is the value used to modify the users cursor position
	int pulseDirection; //added to the pulse
	int pulseTime; //time till pulse addition
	
	
	//This information here isn't saved either and is used for the player's position on the Map
	char map_x, map_y; //Current Position on the field
	char map_orientation; //UP, RIGHT, DOWN, LEFT
	char offset; //How far into the next tile the player is
	int actionFrames; //How long till the action is done, if this is -1 then the action hasn't been started, decremented whenever animation delay = 0
	char animationDelay; //Just used to keep track of when to update based on the action
	
	//The next thing is the player action queue.  The player can have up to eight actions in queue
	//The action queue is used like a circular queue (I think that's what it is called)
	//Basically, when you queue it queses at (currentAction + actionsInQueue) % 6
	//the next action will be added if and only if actionsInQueue < 7 (0->5 == 6 positions)
	//and the current head of the queue is the currentAction variable; which wraps at 6 to 0
	playerQueue actionQueue[6];
	char actionsInQueue; //This keeps track of the number of Actions in the Queue
	int currentAction; //This is at what point in the queue you are at
};

typedef struct playerInfoTag playerInfo;

extern playerInfo thePlayer;

extern void initPlayer();
extern void setupPlayer();
extern void displayPlayerPosition();
extern void displayPlayerItems();
extern void displayPlayerHealth();
extern void updatePlayerOnMap();
extern void initPlayerOnMap();
extern char queuePlayerAction(char type, char count);
extern void updatePlayerQueue();
extern void resetPlayerQueue();
extern void pickupItem(char x, char y);
extern void movePlayerToStart();
extern char playerHit(int counter);
extern void resetPlayer();
#endif

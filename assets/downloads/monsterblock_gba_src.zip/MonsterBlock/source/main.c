#include "registers.h"
#include "sprites.h"
#include <stdlib.h>
#include "title.h"
#include "player.h"
#include "game.h"
#include "splash.h"


int main()
{
	int c;

	//Move sprites around to the correct spots
	clearSprites();
	
	
	
	//Display the Mikaus projects splash screen
	//And have it cycle random numbers till a key is pressed.
	runSplash();
	
	while(1)
	{
		
		c = runTitleScreen();
		rand();
		
		KeyReleased();
		
		if(c == 0)
		{
			initPlayer();
		}

		runGame();
	}
	
	return 0;
}

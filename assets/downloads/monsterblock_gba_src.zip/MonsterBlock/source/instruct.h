#ifndef instruct_h
#define instruct_h

extern void runInstructions();
#endif

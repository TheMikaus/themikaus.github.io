#include "game.h"
#include "dialog.h"
#include "sprites.h"
#include "player.h"
#include "level.h"
#include "Registers.h"
#include "leveldata.h"
#include "monsters.h"
#include "pause.h"
#include "attack.h"
#include "messages.h"
#include "sram.h"
#include "items.h"

#include <stdlib.h>
#include <stdio.h>

#include "tiles_dialog_bin.h"
#include "tiles_font_bin.h"
#include "sprites_menu_bin.h"

#include "map_board_bin.h"
#include "pal_board_bin.h"
#include "tiles_board_bin.h"

#include "pal_blocks_bin.h"
#include "tiles_blocks_bin.h"

//This displays the current level and current score
char level[10];
char score[11];

//Returns 0 if there is a monster/boss on the board
char gameWin_noMonsters()
{
	int monster_counter = 0;
	
	//Check monsters
	for(monster_counter = 0; monster_counter < monsterCount; monster_counter++)
	{
		if(monsters[monster_counter].health > 0)
		{
			return 0;
		}
	}

	//Check bosses
	for(monster_counter = 0; monster_counter < bossCount; monster_counter++)
	{
		if(monsters[MonsterCount + monster_counter].health > 0)
		{
			return 0;
		}
	}
	
	return 1;
}

//returns > 0 if the player is at the exit
char gameWin_exit()
{
	return tileAt(thePlayer.map_x,thePlayer.map_y) == Tile_Exit;
}

//If any block in this row is falling then they can't eliminate the row
char canEliminateRow(char y)
{
	char x;
	for(x = 0; x < Block_Width; x++)
	{
		if(blockAt(x,y)->state == State_Falling)
		{
			return 0;
		}
	}
	return 1;
}

//Take out the given row all the way over
void eliminateRow(char y)
{
	char x = 0;
	int counter = y - 1;
	block * at;

	//It does a check if the row is killable
	//basically if any block in the row is falling you can't kill it
	if(!canEliminateRow(y))
	{
		return;
	}
	//This is essentially the same function I use in the isCombo function
	//It goes through every block in the row
	//And sets all the above blocks to falling
	//It then sets the current y to type none
	for(; x < Block_Width; x++)
	{
		for(counter = y - 1; counter >= 0; counter--)
		{
			at = blockAt(x,counter);
			//Make sure not to affect any blocks that are already falling
			if(at->state != State_Falling)
			{
				at->state= State_Falling;
				at->yOffset = 0;
				at->delay = 5;
			}
		}
		at = blockAt(x,y);
		at->type = Type_None;
		((spriteHolder *)&oSprites[at->sprite])->name = 64;
	}
}

//If any block in this column is falling then they can't eliminate the column
char canEliminateColumn(char x)
{
	char y;
	
	for(y = 1; y < Block_Height - 1; y++)
	{
		if(blockAt(x,y)->state == State_Falling)
		{
			return 0;
		}
	}
	return 1;
}

void cleanUpBlocks()
{
	int x,y;
	int above;
	block * at;
	spriteHolder * tag;
	
	for(y = 1; y < Block_Height - 1; y++)
	{
		for(x = 0; x < Block_Width; x++)
		{
			at = blockAt(x,y);
			if(at->clean)
			{
				at->clean = 0;
				at->type = Type_None;
				tag = (spriteHolder *)&oSprites[at->sprite];
				tag->name = 64;
				for(above = y - 1; above >= 0; above--)
				{
					at = blockAt(x,above);
					if(at->type != Type_None)
					{
						if(at->state != State_Falling)
						{
							at->state = State_Falling;
							at->yOffset = 0;
							at->delay = 5;
						}
					}
					else
					{
						at->state = State_Sitting;
					}
				}
			}
		}
	}
}


//Remove the given column
void eliminateColumn(char x)
{
	char y = 1;
	block * at; 
	
	//It does a check if the column is killable
	//basically if any block in the column is falling you can't kill it
	if(!canEliminateColumn(x))
	{
		return;
	}
	
	//Remove all the blocks in this column
	for(;y < Block_Height - 1; y++)
	{
		at = blockAt(x,y);
		at->type = Type_None;
		at->state = State_Sitting;
		((spriteHolder *) &oSprites[at->sprite])->name = 64;		
	}
	
	//And set the hidden top block to fall
	//This causes the chain reaction that will start populating the system
	at = blockAt(x,0);
	if(at->state != State_Falling)
	{
		at->state = State_Falling;
		at->delay = 5;
		at->yOffset = 0;
	}
}

//Displays the player's current level and score
void displayStaticInformation()
{
	sprintf(level, "Level %d", thePlayer.level);
	sprintf(score, "%010lu",thePlayer.score);
	
	free(dialog_displayText(4, 1, level, 0));
	free(dialog_displayText(4, 18, score, 0));
}


//Flips the blocks that are selected
//If the player tries to flip a pair that has a falling block in it
//Don't let them actually swap it.
void swapBlocks()
{
	//Takes the current position and figures out the x,ys of the blocks to switch and then switches them
	block * temp = blockAt(thePlayer.x,thePlayer.y);
	block * temp2;
	spriteHolder * tempS;
	
	if(thePlayer.orientation == Orientation_Horizontal)
	{
		temp2 = blockAt(thePlayer.x + 1, thePlayer.y);
		
		//If it's falling or it's nothing don't do this operation
		if(temp->type == Type_None || temp2->type == Type_None ||
			temp->state == State_Falling || temp2->state == State_Falling)
			{
				return;
			}
		
		//Set the new blocks
		blockAt(thePlayer.x + 1, thePlayer.y) = temp;
		blockAt(thePlayer.x, thePlayer.y) = temp2;
		
		//the blocks keep track of their own position
		//for use later, so update their information
		temp2->x--;
		temp->x++;
		
		//Update the sprites
		tempS = (spriteHolder *)&oSprites[temp->sprite];
		tempS->x = temp->x * 16 + 24;
		
		tempS = (spriteHolder *)&oSprites[temp2->sprite];
		tempS->x = temp2->x * 16 + 24;
		
	}
	else
	{
		temp2 = blockAt(thePlayer.x, thePlayer.y+1);
		
		//If it's falling or it's nothing don't do this operation
		if(temp->type == Type_None || temp2->type == Type_None ||
			temp->state == State_Falling || temp2->state == State_Falling)
			{
				return;
			}
			
		//set the new blocks
		blockAt(thePlayer.x, thePlayer.y + 1) = temp;
		blockAt(thePlayer.x,thePlayer.y) = temp2;
		
		//the blocks keep track of their own position
		//for use later, so update their information
		temp2->y--;
		temp->y++;
		
		//update the sprite positions
		tempS = (spriteHolder *)&oSprites[temp->sprite];
		tempS->y = temp->y * 16 + 8;
		
		tempS = (spriteHolder *)&oSprites[temp2->sprite];
		tempS->y = temp2->y * 16 + 8;
	}
	
	//Setup the sprites in memory
	//I might eventually remove this and put it somewhere else,
	//but for now this will do
	updateSprites();
}


//Copy stuff to memory (board, blocks, monsters, player and items)
//This will also setup the background that has the board on it.
void initBoard()
{
	//The game will be using the same background that the title screen was using.
	//So it will need to overwrite the information there.
	SetMode(0 | BG0_ENABLE | BG2_ENABLE | BG3_ENABLE | 0x40 | 0x1000);
	
	Register_Bg0Ctrl = 2 | TextBackground_Size256x256 | (29 << SCREEN_SHIFT) | (0 << CHAR_SHIFT);
	
	//Copy all the tiles, maps and palettes now, then set up the dialog system again
	//Copy the board first
	DMACopy(tiles_board_bin,CharBaseBlock(0), DMA_32NOW,tiles_board_bin_size / 4);
	DMACopy(map_board_bin,ScreenBaseBlock(29), DMA_32NOW, map_board_bin_size / 4);
	DMACopy(pal_board_bin,BackgroundPalette_Memory,DMA_32NOW, 4);
	
	//Copy the blocks into sprite memory
	//The sprite tiles need to start after the first one
	//since we use the first one for the menu sprite
	DMACopy(tiles_blocks_bin, Sprite_Tiles + 16, DMA_32NOW, tiles_blocks_bin_size / 4);
	DMACopy(pal_blocks_bin, Sprite_Palette, DMA_32NOW, 4);

	//This sets up the main dialog stuff
	dialog_init();
	
	dialog_loadDialogTiles((void *)tiles_dialog_bin,(void *)tiles_font_bin);
	dialog_setMenuSprite((void *)sprites_menu_bin);
	dialog_setMenuSpriteColor(RGB(31,31,31)); //This will cover up the 15th slot in sprite pal
	dialog_setBackgroundColor(RGB(0,0,0)); //Should use 13
	dialog_setDialogColor(RGB(31,31,31)); //Should use 14
	dialog_setTextColor(RGB(31,31,31)); //Should use 15
	
	//Change colors in memory
	BackgroundPalette_Memory[3] = RGB(0,0,0);
	BackgroundPalette_Memory[5] = RGB(15,0,0);
	BackgroundPalette_Memory[6] = RGB(31,0,0);
	
}




//This will automatically update the player's action queue as well as 
//eliminate the blocks
//I do this because it's easier
char isCombo(char x, int y)
{
	int vcount = 0;
	int hcount = 0;
	char type;
	int tempX = x;
	int tempY;
	char tempAdd = 0;
	int eliminatedSection = -1;
	block * at = 0;
	char totalBlocks = 0;
	
	//Get the type that we are checking for
	at = blockAt(x,y);
	type = at->type;
	
	//First check the --->
	//                 |
	//type
	//Only count the vertical if the horizontal was taken.
	//To keep track of what the column that I need to remove is
	//I use the eliminatedSection variable
	do
	{
		hcount++;
		if(y != Block_Height - 1 && blockAt(tempX,y + 1)->type == type)
		{
			//check the vertical blocks
			//it starts on the next block down
			//so that means it skips this row
			//it will be compensated for later
			vcount = 0;
			tempY = y + 1;
			do
			{
				tempY++;
				vcount++;
			}
			while(tempY < Block_Height - 1 && type == blockAt(tempX,tempY)->type && blockAt(tempX,tempY)->state != State_Falling);
			
			//This means that the vertical row had more than 3 total (includes top)
			if(vcount > 1)
			{
				eliminatedSection = tempX;
				tempAdd = vcount;
			}
		}
		tempX++;
	} while( tempX < Block_Width && type == blockAt(tempX,y)->type && blockAt(tempX,y)->state != State_Falling);
	
	//if their was a row horizontally
	//clean it out
	//then add it to totalBlocks
	//and return the total block count
	//Also want to add the tempAdd variable
	//which keeps track of the length of the vertical column
	if(hcount > 2)
	{
		
		//handle the horizontal part first
		totalBlocks = hcount;
		
		//set the horizontal blocks up for deletion
		
		for(hcount = 0;hcount < totalBlocks; hcount++)
		{
			blockAt(x + hcount, y)->clean = 1;
		}
		
		//if a vertical column was eliminated then
		//set those to be cleaned up too
		if(eliminatedSection != -1)
		{
			totalBlocks += tempAdd;
			for(vcount = 0; vcount < tempAdd; vcount++)
			{
				blockAt(eliminatedSection,y + vcount + 1)->clean = 1;
			}
		}
		
		queuePlayerAction(blockAt(x,y)->type,totalBlocks - 1);
		return totalBlocks;
	}

	//The grid has passed the horizontal test
	//now time to test the vertical
	//so reset the stuff here
	tempAdd = 0;
	vcount = 0;
	eliminatedSection = -1;
	tempY = y;
	do
	{
		vcount++;
		if( eliminatedSection == -1)
		{ 
			hcount = 0;
			//scan to the right first
			//then scan to then the left 
			//if the added sum is > 1 then this row can be eliminated
			//then you'll just have to set the eliminated section to the tempY
			//and then tempX variable will be the first value on the left
			tempX = x + 1;
			while(tempX < Map_Width && blockAt(tempX, tempY)->type == type && blockAt(tempX,tempY)->state != State_Falling)
			{
				hcount++;
				tempX++;
			}
			
			
			tempX = x - 1;
			while(tempX >= 0 && blockAt(tempX, tempY)->type == type)
			{
				hcount++;
				tempX--;
			}
			
			
			
			//this means that there is three in a row (excludes the column)
			//so it means that there are at least two other than the column
			if(hcount > 1)
			{
				tempAdd = hcount;
				eliminatedSection = tempY;
			}
		}
		tempY++;
	}
	while(tempY < Block_Height - 1 && blockAt(x,tempY)->type == type && blockAt(x,tempY)->state != State_Falling);
	
	//if vcount > 2 that means that the column can be eliminated
	if(vcount > 2)
	{
		//handle the horizontal part first
		totalBlocks = vcount;
		
		//set the horizontal blocks up for deletion
		vcount--;
		for(;vcount >= 0; vcount--)
		{
			blockAt(x, y + vcount)->clean = 1;
		}
		
		//if a row was eliminated then
		//set those to be cleaned up too
		if(eliminatedSection != -1)
		{
			totalBlocks += tempAdd;
			tempX++;
			for(hcount = 0; hcount <= tempAdd; hcount++)
			{
				blockAt(tempX + hcount, eliminatedSection)->clean = 1;
			}
		}
		queuePlayerAction(blockAt(x,y)->type,totalBlocks - 1);
		return totalBlocks;
	}

	return 0;
}



//This function should check to see if blocks get eliminated
//If they do then it'll return the block type
//It also gives the player a point for completing a block
char checkBlocks()
{
	char x, y, t;
	char set = 0;
	t = Type_None;
	for( y = 1; y < Block_Height - 1; y++)
	{
		for(x = 0; x < Block_Width; x++)
		{
			if(blockAt(x,y)->type != Type_None)
			{
			
				t = isCombo(x,y);
				if(t != 0)
				{
					return 1;
				}
			}
		}
	}
	
	
	return set;
}

//This will load the sprites and maps and everything needed
//here. It will also initialize the block tiles into place
void loadLevel()
{
	char x,y,count = 0;
	spriteHolder * theCurrentSprite = 0;


	//initialize blocks
	initBlocks();
	initBoard();

	//randomly set up each block
	for(y = 0; y < Block_Height; y++)
	{
		for(x = 0; x < Block_Width; x++)
		{
			theCurrentSprite = (spriteHolder *)&oSprites[Block_SpriteStart + count];
		
			blockAt(x,y)->type = getNewBlock(x,y);
			theCurrentSprite->x = x * 16 + 24;
			theCurrentSprite->y = y * 16 + 8;
			theCurrentSprite->color_256 = 0;
			theCurrentSprite->spriteSize = 1;
			theCurrentSprite->name = 1 + (blockAt(x,y)->type * 4);
			theCurrentSprite->priority = 3;
			theCurrentSprite->palette = 0;
			blockAt(x,y)->sprite = Block_SpriteStart + count;
			
			count++;
		}
	}
	
	
	//Border of the blocks
	//Sprite_Palette[10] = RGB(20,20,20);
	
	//Reset Everything
	//Then update the score
	//Reset projectiles
	//Player
	//Action Queue
	setupPlayer();
	resetProjectiles();
	resetMonsters();
	resetItems();
	displayStaticInformation();
	displayPlayerHealth();
	displayPlayerItems();
	
	
	loadMap((const char *)&levelData[8 * 14 * (thePlayer.level-1)]);
	
	//Move the player cursor to the bottom center
	updateSprites();
}


//Swaps the player cursor orientation
void swapOrientation()
{
	if(thePlayer.orientation == Orientation_Vertical)
	{
		thePlayer.orientation = Orientation_Horizontal;
		
		//If they are at the far right and they flip to horizontal
		//then move the cursor left
		if(thePlayer.x == Block_Width - 1)
		{
			thePlayer.x = Block_Width - 2;
		}
	}
	else
	{
		thePlayer.orientation = Orientation_Vertical;
		
		//If they are at the bottom and they flip to vertical then
		//move the cursor up.
		if(thePlayer.y == Block_Height - 2)
		{
			thePlayer.y = Block_Height - 3;
		}
	}
}

//Performs the elimination based on the orientation of the player's cursor
void performElimination()
{
	if(thePlayer.orientation == Orientation_Vertical)
	{
		eliminateColumn(thePlayer.x);
	}
	else
	{
		eliminateRow(thePlayer.y);
	}
}

//This assumes that the level is already loaded into the level
//pointer
int runLevel()
{
	char Up_pressed = 1;
	char Down_pressed = 1;
	char Left_pressed = 1;
	char Right_pressed = 1;
	char A_pressed = 1;
	char B_pressed = 1;
	char LR_pressed = 1;
	char blockType = 0;
	char blockSwitched = 0;
	char tempHp = 0;
	
	
	//This is the main loop for the level
	
	//Display the board
	//This is based on the loaded level pointer
	//And is only necessary once
	displayPlayerPosition();
	while(1)
	{
		//Display the tiles
		vsyncB();
		
		blockSwitched = 0;
		
		
		//Process player
		updatePlayerOnMap();
		
		//Check the player keys

		//Move up if the player has pressed the pad only and if they aren't 
		//at the top of the playing field
		if(DPAD_UP)
		{
			if( !Up_pressed && thePlayer.y > 1)
			{
				Up_pressed = 1;
				thePlayer.y--;
				
			}
		}
		else
		{
			Up_pressed = 0;
		}

		//Move down if the player has pressed the pad only and if the aren't
		//at the bottom of the playing field
		if(DPAD_DOWN)
		{
			if(!Down_pressed)
			{
				Down_pressed = 1;
				
				//The "bottom" of the playing field changes it's definition depending on the orientation of
				//the block
				if(thePlayer.orientation == Orientation_Horizontal && thePlayer.y < Block_Height - 2)
				{
					thePlayer.y++;
					
				}
				else if(thePlayer.orientation == Orientation_Vertical && thePlayer.y < Block_Height - 3)
				{
					thePlayer.y++;
				}
			}
		}
		else
		{
			Down_pressed = 0;
		}
		
		//Move left if pressed and not at the edge
		if(DPAD_LEFT)
		{
			if(!Left_pressed)
			{
				Left_pressed = 1;
				if(thePlayer.x > 0)
				{
					thePlayer.x--;
					
				}
			}
		}
		else
		{
			Left_pressed = 0;
		}
		
		
		//Move right if pressed and not at the edge
		if(DPAD_RIGHT)
		{
			if(!Right_pressed)
			{
				Right_pressed = 1;
				//The right boundary changes depending on what orientation the player's block is
				if(thePlayer.orientation == Orientation_Horizontal && thePlayer.x < Block_Width - 2)
				{
					thePlayer.x++;
					
				}
				else if(thePlayer.orientation == Orientation_Vertical && thePlayer.x < Block_Width - 1)
				{
					thePlayer.x++;
					
				}
			}
		}
		else
		{
			Right_pressed = 0;
		}
		
		//By using the l and R buttons the player can eliminate rows or columns
		//the row/column depends on what orientation the player's cursor is
		if(DPAD_B)
		{
			if(!B_pressed)
			{
				B_pressed = 1;
				if(thePlayer.swapButtons)
				{
					swapOrientation();
				}
				else
				{
					performElimination();
				}
			}
		}
		else
		{
			B_pressed = 0;
		}
		
		//Using this button will change the orientation of the player's cursor.
		//Right now it only flips from vertical to horizontal around one point
		// so it's
		// [][] or []--
		// ----    []--
		//What I want is have it go around on the rotation point
		// [][] or []-- to ----    --[]
		// ----    []--    [][] to --[]
		//But I think that might be bad for gameplay.
		if(DPAD_L || DPAD_R)
		{
			if(!LR_pressed)
			{
				LR_pressed = 1;
				if(thePlayer.swapButtons)
				{
					performElimination();
				}
				else
				{
					
					swapOrientation();
				}
			}
		}
		else
		{
			LR_pressed = 0;
		}
		
		
		//Swap the blocks if pressed
		if(DPAD_A)
		{
			if(!A_pressed)
			{
				A_pressed = 1;
				//Swap the blocks
				swapBlocks();
				
				//Check for eliminations
				//The elimination goes from Left to Right, top to bottom
				blockSwitched = 1;
			}
		}
		else
		{
			A_pressed = 0;
		}
	
		//bring up the paused menu
		if(DPAD_START)
		{
			switch ( runPauseMenu() )
			{
				case 0:
					return -2; //exit the game
				case 1:
					return 0; //restart the stage
				case 3:
					//Swap the buttons
					thePlayer.swapButtons = !thePlayer.swapButtons;
					break;
			}
			
			//Make sure that the game doesn't think that their acceptance
			//on the menu is a move
			A_pressed = 1;
			B_pressed = 1;
		}
		//if they are pressed then displayPlayerPosition()
		displayPlayerPosition();
	
		//Process objects in list
		//While blocks are still landing, process the actions
		//I think this will change.
		//I think I'll remove the processing after the switch
		//And make it just do the process once here
		//no loop.  That way I don't duplicate code for que actions
		//we'll see what I end up doing.
		if(processBlocks() || blockSwitched)
		{
			do
				{
					//This function will automatically set the blocks in motion for falling
					//and it returns the block type which let's us know what to tell the player to do
					blockType = checkBlocks(); 
					
					cleanUpBlocks();
					
					//Queue player actions:
					//The player will be able to que up to 6 actions at one time
					//After that the actions no longer get added to the queue till 
					//a slot opens up.
					//When multiactions (those that get 4 lefts in a row (yields to left moves)) only
					//takes up one queue spot, thus allowing for more moves in the queue
					//Here merely queues the movement, it doesn't actually process it.
					//Actually, I don't have to do anything here
					//the check blocks function uses the isCombo function
					//which will automatically update the player's action queue
					if(blockType)
					{
						updatePlayerQueue();
					}
					
					updateSprites();
				} while(blockType);
			
		}
		
		
		if(thePlayer.pauser >= 0)
		{
			moveMonsters();
		}
		else
		{
			thePlayer.pauser--;
			if(thePlayer.pauser == 0)
			{
				displayPlayerItems();
			}
		}
		
		//I'll want to process the attack actions here
		//Should just be a call to a function
		processProjectiles();
		
		//Make sure the monster interaction happens
		tempHp = monsterToPlayerCollision();
		if(tempHp > 0)
		{
			thePlayer.health -= tempHp;
			if(thePlayer.health <= 0)
			{
				//player died
				return -1;
			}
			
			//update the player's health now
			displayPlayerHealth();
			
			//Move player back to start
			movePlayerToStart();
			updatePlayerOnMap();
			resetPlayerQueue();
			updatePlayerQueue();
		}
		
		
		//Check to see if any of the end game conditions happened
		//the better way to do this would be to check only when things that affect 
		//the said checks happen but that would have taken some more time to go and implement :)
		if(gameWin_noMonsters())
		{
			thePlayer.level++;
			
			//Display the you beat the stage by killing monsters message
			//add score
			message_monstersDefeated();
			
			if(thePlayer.level > LAST_LEVEL)
			{
				return 3;
			}
			
			return 1;
		}
		
		if(gameWin_exit())
		{
			thePlayer.level++;
			
			
			//Display the you move on to the next stage message
			//add score
			message_levelExited();
			
			if(thePlayer.level > LAST_LEVEL)
			{
				return 3;
			}
			
			return 1;
		}
		
		//Update the display
		updateSprites();
	}
	
	
	//I don't ever really get to this point
	//But just incase I put this here anyway
	return -1;
}

//Starts the game
//This calls the initialization routines that copy the board
void runGame()
{
	volatile int result = 0;
	//Copy stuff to memory (board, blocks, monsters, player and items)
	//This will also setup the background that has the board on it.
	
	
	//Runs a loop that continues till player quits
	//You can continue at the beginning of a stage if you lose
	while(1)
	{
		//load level
		loadLevel();
		
		//run level
		result = runLevel();
		//check return value
		//if return value == -1 then exit
		//if return value == 0 then replay stage
		//if return value == 1 then increase level
		if(result == -1 && message_gameOver())
		{
			break;
		}
		else if(result == 1)
		{
			//the Player has already been asked to save
			//and score has been added
			
		}
		else if(result == 3)
		{
			//This is the player beat the game!
			message_win();
			break;
		}
		else if(result == -2)
		{
			break;
		}
		else
		{
			//Reset the player to default values
			//Health, range, weapon
			//They died or started the stage over
			resetPlayer();
		}
		
		//Clear the pauser that they might have picked up during the play.
		thePlayer.pauser = 0;
	}
	
	freeBlocks();
}

#ifndef sprites_h
#include "registers.h"

struct spriteByteStruct
{
	unsigned short at0;
	unsigned short at1;
	unsigned short at2;
	unsigned short at3;
};

typedef struct spriteHolderTag
{
	unsigned y : 8;

	unsigned rotation : 1;
	unsigned DoubleSize : 1;
	unsigned translucent : 1;
	unsigned windowed : 1;
	unsigned mosaic : 1;
	unsigned color_256 : 1;
	unsigned tall : 1;
	unsigned wide : 1;

	//at1
	unsigned x : 9;
	unsigned rotation_index : 3;
	unsigned hflip : 1;
	unsigned vflip : 1;
	unsigned spriteSize:2;
	
	//at2
	unsigned name : 10;
	unsigned priority : 2;
	unsigned palette : 4;
	
	unsigned short at3;
} spriteHolder;

extern struct spriteByteStruct oSprites[128];

extern void clearSprites();

#define Sprite_Memory ((volatile unsigned short *) 0x7000000)
#define Sprite_Tiles  ((unsigned short *) 0x6010000)
#define Sprite_Palette ((unsigned short *) 0x5000200)

#define updateSprites()	DMACopy((void *)oSprites, (void *)Sprite_Memory,DMA_32NOW, 256)


#endif

#ifndef splash_h
#define splash_h

extern void runSplash();

#endif

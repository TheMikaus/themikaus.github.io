#ifndef registers_h

#define u8 unsigned char
#define u32 unsigned int
#define RGB(r,g,b) ((r) + (g << 5) + (b << 10))

#define BG0_ENABLE 0x100
#define BG1_ENABLE 0x200
#define BG2_ENABLE 0x400
#define BG3_ENABLE 0x800
#define Register_DisplayController *(unsigned int *)0x4000000
#define SetMode(mode) Register_DisplayController = mode;
#define JOY_REG (volatile unsigned short *)0x04000130
#define KeyReleased() while(1) if(!(*JOY_REG < 0x3ff)) break;
#define KeyDown() while(1) if( *JOY_REG < 0x3ff) break;
#define KeyPressed() KeyDown();KeyReleased();

#define Controller_A 1
#define Controller_B 2
#define Controller_SELECT 4
#define Controller_START 8
#define Controller_RIGHT 16
#define Controller_LEFT 32
#define Controller_UP 64
#define Controller_DOWN 128
#define Controller_R 256
#define Controller_L 512

#define DPAD_Pressed !(*JOY_REG & (Controller_UP + Controller_DOWN + Controller_LEFT + Controller_RIGHT))
#define DPAD_UP      !(*JOY_REG & Controller_UP)
#define DPAD_DOWN    !(*JOY_REG & Controller_DOWN)
#define DPAD_LEFT    !(*JOY_REG & Controller_LEFT)
#define DPAD_RIGHT   !(*JOY_REG & Controller_RIGHT)
#define DPAD_A		 !(*JOY_REG & Controller_A)
#define DPAD_B		 !(*JOY_REG & Controller_B)
#define DPAD_R		 !(*JOY_REG & Controller_R)
#define DPAD_L		 !(*JOY_REG & Controller_L)
#define DPAD_SELECT	 !(*JOY_REG & Controller_SELECT)
#define DPAD_START	 !(*JOY_REG & Controller_START)


#define KeyReleased() while(1) if(!(*JOY_REG < 0x3ff)) break;
#define BackgroundPalette_Memory ((unsigned short *)0x5000000)
#define Register_DisplayCount (*(volatile unsigned short *)0x04000006)  /* 0-159: draw; 160-227 vblank */
#define Register_DisplayStatus *(volatile unsigned short *)0x4000004
#define vsync() while((Register_DisplayStatus & 1)); while(!(Register_DisplayStatus & 1));
#define vsyncB() while((Register_DisplayStatus & 1)); 

#define CharBaseBlock(n) (((n)*0x4000) | 0x6000000)
#define ScreenBaseBlock(n) (((n)*0x800) | 0x6000000)

#define Register_Bg0Ctrl *(volatile unsigned short *) 0x4000008
#define Register_Bg0HOffset *(volatile unsigned short *)0x4000010
#define Register_Bg0VOffset *(volatile unsigned short *)0x4000012

#define Register_Bg1Ctrl *(volatile unsigned short *) 0x400000A
#define Register_Bg1HOffset *(volatile unsigned short *)0x4000014
#define Register_Bg1VOffset *(volatile unsigned short *)0x4000016

#define Register_Bg2Ctrl *(volatile unsigned short *) 0x400000C
#define Register_Bg2HOffset *(volatile unsigned short *)0x4000018
#define Register_Bg2VOffset *(volatile unsigned short *)0x400001A

#define Register_Bg3Ctrl *(volatile unsigned short *) 0x400000E
#define Register_Bg3HOffset *(volatile unsigned short *)0x400001C
#define Register_Bg3VOffset *(volatile unsigned short *)0x400001E

#define TextBackground_Size256x256 0x0000
#define TextBackground_Size256x512 0x8000
#define TextBackground_Size512x256 0x4000
#define TextBackground_Size512x512 0xC000

#define SCREEN_SHIFT 8
#define CHAR_SHIFT 2

#define Register_DMASource  * (volatile unsigned int *) 0x40000D4
#define Register_DMADest    * (volatile unsigned int *) 0x40000D8
#define Register_DMAControl * (volatile unsigned int *) 0x40000DC

#define DMA_32 0x04000000
#define DMA_ENABLE 0x80000000
#define DMA_32NOW (DMA_ENABLE | DMA_32)
#define DMACopy(a,b,c,d) { Register_DMASource = (unsigned int)(a); Register_DMADest = (unsigned int)(b); Register_DMAControl = (((unsigned int)(c)) | ((unsigned int)(d))); }



#endif

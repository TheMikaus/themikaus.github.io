#include "monsters.h"
#include "player.h"
#include "sprites.h"
#include "level.h"
#include "attack.h"
#include <stdlib.h>

//There will be 16 Monsters
//And 10 boss slots 
monsterInfo monsters[MonsterCount + BossCount];
int monsterCount;
int bossCount;


//Reset the monster object as well as the OAM sprites
void resetMonsters()
{
	char counter;
	spriteHolder * tag;
	bossCount = 0;
	monsterCount = 0;
	
	for(counter = 0; counter < MonsterCount + BossCount; counter++)
	{
		monsters[(int)counter].health = 0; //A monster with a health of zero will not be processed
		
		tag = ((spriteHolder *)&oSprites[OAM_MonsterStart + counter]);
		tag->x = 240;
		tag->y = 160;
	}
	
	updateSprites();
}

void loadNewMonster(char type, char x, char y)
{

	spriteHolder * tag;
	
	monsters[monsterCount].x = x;
	monsters[monsterCount].y = y;
	
	monsters[monsterCount].orientation = PLAYER_UP;
	monsters[monsterCount].offset = 0;
	monsters[monsterCount].actionDelay = -1;
	monsters[monsterCount].health = 1;
	monsters[monsterCount].type = type;

	//Move the sprite
	tag = ((spriteHolder *)&oSprites[OAM_MonsterStart + monsterCount]);
	tag->x = Map_StartX * 8 + x * 8;
	tag->y = Map_StartY * 8 + y * 8;
	
	if(type == Tile_Monster_UpDown || type == Tile_Monster_LeftRight)
	{
		tag->name = Sprite_Enemy1;
	}
	else if (type < Tile_Monster_Random)
	{
		tag->name = Sprite_Enemy2;
	}
	else
	{
		tag->name = Sprite_Enemy3;
	}
	
	if(type == Tile_Monster_DownRight || type == Tile_Monster_DownLeft)
	{
		monsters[monsterCount].orientation = PLAYER_DOWN;
		tag->vflip = 1;
	}
	
	tag->color_256 = 0;
	tag->palette = 0;
	tag->spriteSize = 0;
	tag->priority = 2;
	
	updateSprites();


	monsterCount++;
}

void loadNewBoss(char type, char x, char y)
{
	spriteHolder * tag;
	
	monsters[MonsterCount + bossCount].x = x;
	monsters[MonsterCount + bossCount].y = y;
	monsters[MonsterCount + bossCount].orientation = PLAYER_UP;
	monsters[MonsterCount + bossCount].offset = 0;
	monsters[MonsterCount + bossCount].actionDelay = -1;
	monsters[MonsterCount + bossCount].currentAction = 0; //None
	monsters[MonsterCount + bossCount].health = 5;
	monsters[MonsterCount + bossCount].type = type;

	//Move the sprite
	tag = ((spriteHolder *)&oSprites[OAM_MonsterStart + MonsterCount + bossCount]);
	tag->x = Map_StartX * 8 + x * 8;
	tag->y = Map_StartY * 8 + y * 8;
	
	if(type == Tile_Boss_UpDown || type == Tile_Boss_LeftRight)
	{
		tag->name = Sprite_Boss1;
	}
	else if (type < Tile_Boss_Random)
	{
		tag->name = Sprite_Boss2;
	}
	else
	{
		tag->name = Sprite_Boss3;
	}
	
	if(type == Tile_Boss_DownRight || type == Tile_Boss_DownLeft)
	{
		monsters[monsterCount].orientation = PLAYER_DOWN;
		tag->vflip = 1;
	}
	
	tag->color_256 = 0;
	tag->palette = 0;
	tag->spriteSize = 0;
	tag->priority = 2;
	
	updateSprites();


	bossCount++;
}



#define FRAME_DELAY 150
//Update both monsters and bosses
void moveMonsters()
{
	int counter = 0;
	char type = 0;
	char done = 0;
	spriteHolder * tag = 0;
	
	//First the monsters then the bosses
	for(counter = 0; counter < MonsterCount + BossCount; counter++)
	{
		//If there's a monster that is active then
		//process their movement pattern
		if(monsters[counter].health > 0)
		{
			done = 0;
			tag = (spriteHolder *)&oSprites[OAM_MonsterStart + counter];
			
			if(monsters[counter].actionDelay == -1)
			{
				//the monster is doing no action
				//therefore I'll need to create a new action
				
				//This depends on the monster.
				
				monsters[counter].offset = 1;
				monsters[counter].actionDelay = 7;
				monsters[counter].animationDelay = FRAME_DELAY;
				
				switch(monsters[counter].type)
				{
					case Tile_Monster_UpDown:
					case Tile_Boss_UpDown:
						//If they can't go up anymore
						//Make the go down
						while(!done)
						{
							if(monsters[counter].orientation == PLAYER_UP)
							{
								//Check to see if the monster/boss can still move up
								if(monsters[counter].y == 0 || tileAt(monsters[counter].x,monsters[counter].y-1) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_DOWN;
									tag->vflip = 1;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
									monsters[counter].orientation = PLAYER_UP;
								}
							}
							else
							{
								if(monsters[counter].y == Map_Height - 1 || tileAt(monsters[counter].x,monsters[counter].y+1) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_UP;
									tag->vflip = 0;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
									monsters[counter].orientation = PLAYER_DOWN;
								}
							}
						}
						break;
					case Tile_Monster_LeftRight:
					case Tile_Boss_LeftRight:
						while(!done)
						{
							if(monsters[counter].orientation == PLAYER_LEFT)
							{
								if(monsters[counter].x == 0 || tileAt(monsters[counter].x - 1, monsters[counter].y) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_RIGHT;
									tag->hflip = 0;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
									monsters[counter].orientation = PLAYER_LEFT;
								}
							}
							else
							{
								if(monsters[counter].x == Map_Width - 1 || tileAt(monsters[counter].x + 1, monsters[counter].y) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_LEFT;
									tag->hflip = 1;
									monsters[counter].offset = 0;
								}
								else
								{
									monsters[counter].orientation = PLAYER_RIGHT;								
									done = 1;
								}
							}
						}
						break;
					case Tile_Monster_DownRight:
					case Tile_Boss_DownRight:
					case Tile_Monster_UpLeft:
					case Tile_Boss_UpLeft:
						while(!done)
						{
							if(monsters[counter].orientation == PLAYER_UP)
							{
								//Check to see if they can still go up, if they can't then change directions
								if(monsters[counter].y == 0 || tileAt(monsters[counter].x,monsters[counter].y-1) == Tile_Block)
								{
									//Turn left now
									monsters[counter].orientation = PLAYER_LEFT;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
							else if(monsters[counter].orientation == PLAYER_LEFT)
							{
								//They'll turn down if they can't go left anymore
								if(monsters[counter].x == 0 || tileAt(monsters[counter].x - 1, monsters[counter].y) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_DOWN;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
							else if(monsters[counter].orientation == PLAYER_DOWN)
							{
								//They'll turn right
								if(monsters[counter].y == Map_Height - 1 || tileAt(monsters[counter].x,monsters[counter].y + 1) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_RIGHT;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
							else
							{
								if(monsters[counter].x == Map_Width - 1 || tileAt(monsters[counter].x + 1, monsters[counter].y) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_UP;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
						}
						tag->y = Map_StartY * 8 + monsters[counter].y * 8;
						tag->x = Map_StartX * 8 + monsters[counter].x * 8;
						break;
					case Tile_Monster_UpRight:
					case Tile_Boss_UpRight:
					case Tile_Monster_DownLeft:
					case Tile_Boss_DownLeft:
						while(!done)
						{
							if(monsters[counter].orientation == PLAYER_UP)
							{
								//Check to see if they can still go up, if they can't then change directions
								if(monsters[counter].y == 0 || tileAt(monsters[counter].x,monsters[counter].y-1) == Tile_Block)
								{
									//Turn left now
									monsters[counter].orientation = PLAYER_RIGHT;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
							else if(monsters[counter].orientation == PLAYER_LEFT)
							{
								//They'll turn down if they can't go left anymore
								if(monsters[counter].x == 0 || tileAt(monsters[counter].x - 1, monsters[counter].y) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_UP;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
							else if(monsters[counter].orientation == PLAYER_DOWN)
							{
								//They'll turn right
								if(monsters[counter].y == Map_Height - 1 || tileAt(monsters[counter].x,monsters[counter].y + 1) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_LEFT;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
							else
							{
								if(monsters[counter].x == Map_Width - 1 || tileAt(monsters[counter].x + 1, monsters[counter].y) == Tile_Block)
								{
									monsters[counter].orientation = PLAYER_DOWN;
									monsters[counter].offset = 0;
								}
								else
								{
									done = 1;
								}
							}
						}
						tag->y = Map_StartY * 8 + monsters[counter].y * 8;
						tag->x = Map_StartX * 8 + monsters[counter].x * 8;
						break;
					case Tile_Monster_Random:
					case Tile_Boss_Random:
						//randomly pick a direction to go until it's a useable direction
						monsters[counter].offset = 0;						
						while(!done)
						{
							
							switch(monsters[counter].orientation)
							{
								case PLAYER_UP:
									if(monsters[counter].y > 0 && tileAt(monsters[counter].x,monsters[counter].y-1) != Tile_Block)
									{
										if(monsters[counter].type == Tile_Monster_Random)
										{
											tag->name = Sprite_Enemy3;
										}
										else
										{
											tag->name = Sprite_Boss3;
										}
										tag->vflip = 0;
										done = 1;
									}
									break;
								case PLAYER_DOWN:
									if(monsters[counter].y < Map_Height - 1 && tileAt(monsters[counter].x,monsters[counter].y+1) != Tile_Block)
									{
										if(monsters[counter].type == Tile_Monster_Random)
										{
											tag->name = Sprite_Enemy3;
										}
										else
										{
											tag->name = Sprite_Boss3;
										}
										tag->vflip = 1;
										done = 1;
									}
									break;
								case PLAYER_LEFT:
									if(monsters[counter].x > 0 && tileAt(monsters[counter].x - 1, monsters[counter].y) != Tile_Block)
									{
										if(monsters[counter].type == Tile_Monster_Random)
										{
											tag->name = Sprite_MonsterRight;
										}
										else
										{
											tag->name = Sprite_BossRight;
										}
										tag->hflip = 1;
										done = 1;
									}
									break;
								case PLAYER_RIGHT:
									if(monsters[counter].x < Map_Width - 1 && tileAt(monsters[counter].x + 1, monsters[counter].y) != Tile_Block)
									{
										if(monsters[counter].type == Tile_Monster_Random)
										{
											tag->name = Sprite_MonsterRight;
										}
										else
										{
											tag->name = Sprite_BossRight;
										}
										tag->hflip = 0;
										done = 1;
									}
									break;
							}
							
							if(!done)
							{
								type = rand() % 16;
								
								type /= 4;
								monsters[counter].orientation = type;
							}
						}
						
						tag->y = Map_StartY * 8 + monsters[counter].y * 8;
						tag->x = Map_StartX * 8 + monsters[counter].x * 8;
						
						break;
				}
			}
			else if(monsters[counter].animationDelay == 0)
			{
				//in the middle of the action
				monsters[counter].animationDelay = FRAME_DELAY;
				monsters[counter].actionDelay--;
				monsters[counter].offset++;
				//Move the monster around depends on the current action of the monster
				switch(monsters[counter].orientation)
				{
					case PLAYER_UP:
						if(monsters[counter].actionDelay == 0)
						{
							monsters[counter].offset = 0;
							monsters[counter].y--;
						}
						tag->y = Map_StartY * 8 + monsters[counter].y * 8 - monsters[counter].offset;
						break;
					case PLAYER_DOWN:
						if(monsters[counter].actionDelay == 0)
						{
							monsters[counter].offset = 0;
							monsters[counter].y++;
						}
						tag->y = Map_StartY * 8 + monsters[counter].y * 8 + monsters[counter].offset;
						break;
					case PLAYER_LEFT:
						if(monsters[counter].actionDelay == 0)
						{
							monsters[counter].offset = 0;
							monsters[counter].x--;
						}
						tag->x = Map_StartX * 8 + monsters[counter].x * 8 - monsters[counter].offset;
						break;
					case PLAYER_RIGHT:
						if(monsters[counter].actionDelay == 0)
						{
							monsters[counter].offset = 0;
							monsters[counter].x++;
						}
						tag->x = Map_StartX * 8 + monsters[counter].x * 8 + monsters[counter].offset;
						break;
				}
			}
			else
			{
				monsters[counter].animationDelay--;
			}
		}
	}

}

//The monster at the index takes damage
//If the monsters health goes below 0 then delete them
void takeDamage(int index)
{
	spriteHolder * tag;
	
	if(monsters[index].health > 0)
	{
		monsters[index].health--;
		if(monsters[index].health == 0)
		{
			//Remove it from the board
			tag = ((spriteHolder *)&oSprites[OAM_MonsterStart + index]);
			tag->x = 240;
			tag->y = 160;
		}
	}
}

char monsterToPlayerCollision()
{
	char dmg = 0;
	char counter = 0;
	
	for(counter = 0; counter < TotalEnemies; counter++)
	{
		//Loop through every enemy and do a collision check with it
		//if the player is in the same grid as the enemy
		//the player takes damage and the enemy takes damage too
		if(playerHit((int)counter))
		{
			takeDamage(counter);
			dmg++;
		}
	}
	
	
	return dmg;
}

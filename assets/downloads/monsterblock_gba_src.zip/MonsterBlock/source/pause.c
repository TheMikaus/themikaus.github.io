#include "pause.h"
#include "dialog.h"


const char * pauseOptions[] =	{
									"return to game",
									"restart stage",
									"swap buttons",
									"exit to title"
									};

const unsigned char pauseReturns[] = { 2,1,3, 0 };

dialog_menuOptions confirmMenu;


int runPauseMenu()
{
	confirmMenu.menuText = pauseOptions;
	confirmMenu.menuReturns = pauseReturns;
	confirmMenu.options = 4;
	
	return dialog_displayMenu(7, 6, 0, 0, &confirmMenu, 0, 0);
}

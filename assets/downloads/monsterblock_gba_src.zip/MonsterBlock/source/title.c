#include "registers.h"
#include "Dialog.h"
#include "Sprites.h"
#include "sram.h"
#include "instruct.h"
#include <stdlib.h>
#include <stdio.h>



#include "tiles_dialog_bin.h"
#include "tiles_font_bin.h"
#include "sprites_menu_bin.h"

#include "tiles_titlescreen_bin.h"
#include "map_titlescreen_bin.h"
#include "pal_titlescreen_bin.h"





const char * menuOption[] =	{
									"New Game",
									"Load Game",
									"Options"
								};

const unsigned char menuReturns[] = { 0,1,2 };


const char * theOptionsMenu[] = { 
									"Clear Saves",
									"Reset High Score ",
									"View Instructions"
								  };

const unsigned char optionsReturns[] = { 0, 1, 2 };

dialog_menuOptions titleScreenMenu;
dialog_menuOptions optionsMenu;


void initTitleScreen()
{
//First load the required stuff for the title
	SetMode(0 | BG0_ENABLE | BG2_ENABLE | BG3_ENABLE | 0x40 | 0x1000);
	
	Register_Bg0Ctrl = 2 | TextBackground_Size256x256 | (29 << SCREEN_SHIFT) | (0 << CHAR_SHIFT);
	
	clearSprites();
	
	//Push the background off the screen
	//DMACopy(dialogTiles,CharBaseBlock(2),DMA_32NOW,72);
	//What's the count on the title screen?
	//This will copy the tiles, map and palette
	DMACopy(tiles_titlescreen_bin,CharBaseBlock(0), DMA_32NOW,tiles_titlescreen_bin_size);
	DMACopy(map_titlescreen_bin,ScreenBaseBlock(29), DMA_32NOW, map_titlescreen_bin_size);
	DMACopy(pal_titlescreen_bin,BackgroundPalette_Memory,DMA_32NOW,pal_titlescreen_bin_size);
	
	//This sets up the main dialog stuff
	dialog_init();
	
	dialog_loadDialogTiles((void *)tiles_dialog_bin,(void *)tiles_font_bin);
	dialog_setMenuSprite((void *)sprites_menu_bin);
	dialog_setMenuSpriteColor(RGB(31,31,31)); //This will cover up the 15th slot in sprite pal
	dialog_setBackgroundColor(RGB(0,0,0)); //Should use 13
	dialog_setDialogColor(RGB(31,31,31)); //Should use 14
	dialog_setTextColor(RGB(31,31,31)); //Should use 15
	
	titleScreenMenu.menuText = menuOption;
	titleScreenMenu.menuReturns = menuReturns;
	titleScreenMenu.options = 3;
	
	optionsMenu.menuText= theOptionsMenu;
	optionsMenu.menuReturns = optionsReturns;
	optionsMenu.options = 3;
	
}


char title_score[30];

void displayHighScore()
{
	unsigned long int hscore;
	
	sram_loadHighScore(&hscore);
	sprintf(title_score, "high score : %010lu",hscore);
	
	free(dialog_displayText(4, 19, title_score, 0));
}

int runTitleScreen()
{
	int choice = 0;
		
	initTitleScreen();
	displayHighScore();
	
	choice = -1;
	
	
	while(1)
	{
		rand();
		choice = dialog_displayMenu(9, 12, 0, 0, &titleScreenMenu, 1, 1);
		rand();
		
		if(choice == 0)
		{
			//it's a new game
			//You should return 0;
			return 0;
		}
		else if(choice == 1)
		{
			//it's time to load a game, so call the load game option
			//If the load game option returns a selection then
			//Return a 1
			//other wise don't return anything
			choice = sram_loadGameMenu();
			if(choice == 1)
			{
				return 1;
			}
		}
		else if(choice == 2)
		{
			//bring up the options menu
			//There are only three options
			//Reset Saves
			//Reset High Score
			//Display the instructions for the game
			while(1)
			{
				choice = dialog_displayMenu(5, 12, 0, 0, &optionsMenu, 1, 1);
				if(choice == 0)
				{
					//Clear Saves
					sram_clearSave();
				}
				else if(choice == 1)
				{
					//Clear High Score
					sram_clearHighScore();
					displayHighScore();
				}
				else if(choice == 2)
				{
					//Display the instruction set
					runInstructions();
					initTitleScreen();
				}
				else
				{
					break;
				}
			}
		}
	
	}

	return 0;
}

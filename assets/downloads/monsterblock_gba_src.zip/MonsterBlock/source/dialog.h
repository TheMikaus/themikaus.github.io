#ifndef dialog_h
#define dialog_h

//I would include the GBA header, but I think I should just
//Write all the defines that I need for the spots in the c file
//That way I don't have to depend on it at all.  I just need to use
//the actual locations

//I think that all functions in this h should use the dialog_ prefix
//Just in case the names become a problem later.

//I haven't implemented any transition functions for the dialogs

//Initialization functions

extern void dialog_init();

//This function will take two pointers the dialogTiles and the fontTiles
//Dialog Tiles should consist of 9 8x8 tiles.  Top Left, Top, Top Right,
//Left, Middle, Right, Bottom Left, Bottom, Bottom Right
//Remeber that you can only use 16 bit color schema for all backgrounds total
//So dialog tiles should really only be black and white

//Font tiles should consist of the ASCII tiles 32->127 I think.  Might not be 127.
//Either way.  Each letter is one tile.  So keep that in mind when designing the tile

//The Colors for the dialog palette are reserved at the end of the 16 color palette
//There are three colors at the end reserved for use.  Background, Text,Dialog
//Note that this only leaves you with 13 colors to mess with and in actuality
//only 12 since the first palette index is transparent.
//Note that this also means the the dialogTiles and the fontTiles must reference
//The last three index values (13,14,15)
//The tiles are copied to a space allocated in memory specifically for the last 2 backgrounds.
//############## COMMENT ABOUT WHERE IT IS PLACED IN MEMORY #########################
//They are placed in CharBaseBlock(2)
//The tile map will be stored at screen base block 31 for the text
//And 30 for the dialog box itself
extern void dialog_loadDialogTiles(void * dialogTiles, void * fontTiles);

//These three functions set the palette colors.
extern void dialog_setBackgroundColor(unsigned int color); //Should use 14
extern void dialog_setDialogColor(unsigned int color); //Should use 13
extern void dialog_setTextColor(unsigned int color); //Should use 15


//Transition Type enumeration
typedef enum dialog_transitionTypeTag { LEFT_SLIDE,RIGHT_SLIDE,TOP_SLIDE,BOTTOM_SLIDE,COLLAPSE,EXPAND, DROP_DOWN, ROLL_UP} dialog_transitionType;

//The next is the structure required for dialog transitions
//It'll be a linked list of values that are chained together.
//That way you can have more than one transition per dialog.
typedef struct dialog_transitionActionTag
{
	struct dialog_transitionActionTag * nextTransition;
	dialog_transitionType transitionType;
	unsigned char specialData;
	unsigned char specialData2;
} dialog_transitionAction;

//Description of the transitions and what they should use of the dialog_transitionAction struct
// LEFT_SLIDE <- slide in to position from the left side of the screen.  The dialog will use the same
//		 y values for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// RIGHT_SLIDE <- slide in to position from the right side of the screen.  The dialog will use the same
//		  y values for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// TOP_SLIDE <- slide in to position from the top of the screen.  The dialog will use the same x values 
//		for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// BOTTOM_SLIDE <- slide in to position from the bottom of the screen. The dialog will use the same x values
//		   for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// COLLAPSE <- will open starting from the centered position of the menu, into the x,y,w,h of passed in values
// EXPAND <- will close to the centered position of the menu.
// DROP_DOWN <- will start the menu as just a little [===] and open it downward.
// ROLL_UP <- will roll the menu up to [===]
//	      -specialData will contain a 0 if it is to close to nothing or a 1 if is to close to [===]
//Sliding is done by moving the background to be off screen and then scrolling to the specified position

//This function generates a new dialog_transitionAction
extern dialog_transitionAction * dialog_newTransition(dialog_transitionType type, unsigned char sd, unsigned char sd2);
extern void dialog_deleteTransitions(dialog_transitionAction * transitions);


//This structure is used to hold onto information dealing with dialogs
//Will be used to pass in to hide a particular dialog
typedef struct dialog_trackerTag
{
	int x,y,w,h;
} dialog_tracker;


//For menus I need to have set aside one sprite.
//Uses the first tile in memory and the first oam data object in memory
extern void dialog_setMenuSprite(void * data);

//Sets the color of the sprite
//Note that the sprite can use any of the 15 colors available in the palette, it's just that
//the reserved value is 15 and will be modified by this function
extern void dialog_setMenuSpriteColor(int color);

//This structure will be used for menus
//Basically it's easy.  Just make a const variable
//in the rom that is an array of strings and assign that to menuText
//and then make an array of unsigned chars that are the return values for the menu options
typedef struct dialog_OptionsTag
{
  const char ** menuText;
  const unsigned char * menuReturns;
  unsigned char options; 
} dialog_menuOptions;

//Dialog display functions
extern dialog_tracker * dialog_displayOpen(char x, char y, char w, char h, char * text, dialog_transitionAction * open);
extern void dialog_displayClose(dialog_tracker * dt, dialog_transitionAction * close);

//The width and the height are removed from this because the value is automatically created by the menu options.  It'll find the longest menu, 
//and you pass in the count of menu options so it does that.
//The text that is passed in, will be on the top left of the dialog box. +-title----+
//So I should make sure that a font has black value around it and transparent filler in the background and a white font color (or something similar).
extern int dialog_displayMenu(char x, char y, dialog_transitionAction * open, dialog_transitionAction * close, dialog_menuOptions * menu, unsigned char optionSpace, char xOffset);

//This function just display text at a designated location
extern dialog_tracker * dialog_displayText(char x, char y, char * text, char delay);

//Don't forget to have actual dialog functions now
extern void dialog_displayDialog(char x, char y, char w, char h, char * text[], char dialogCount, dialog_transitionAction * open, dialog_transitionAction * close, char delayPerChar);
extern void dialog_clearText(dialog_tracker * dt);
extern void dialog_setBlinkSpeed(unsigned blink);
#endif 

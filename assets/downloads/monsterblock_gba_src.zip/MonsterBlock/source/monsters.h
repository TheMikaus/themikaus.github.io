#ifndef monsters_h
#define monsters_h
#include "attack.h"

struct monsterInfoTag
{
	//This information here isn't saved either and is used for the player's position on the Map
	char x, y; //Current Position on the field
	char orientation; //UP, RIGHT, DOWN, LEFT (Use the player defines)
	char offset; //How far into the next tile the player is
	int actionDelay; //How long till the action is done
	char animationDelay; //Just used to keep track of when to update based on the action
	char currentAction;
	char health; //Usually set to 1 but could be more (if it's a boss)
	char type; //What type of monster is it?
};

typedef struct monsterInfoTag monsterInfo;


#define MonsterCount 16
#define BossCount 10
#define TotalEnemies MonsterCount + BossCount
extern monsterInfo monsters[];
extern int monsterCount;
extern int bossCount;
extern projectile thePlayerProjectile;

extern void resetMonsters();
extern void loadNewMonster(char type, char x, char y);
extern void loadNewBoss(char type, char x, char y);
extern void moveMonsters();
extern void takeDamage(int index);
extern char monsterToPlayerCollision();

#endif

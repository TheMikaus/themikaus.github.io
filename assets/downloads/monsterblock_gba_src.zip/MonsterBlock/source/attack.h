#ifndef attack_h
#define attack_h

#define betweenPoint(x1, bx, bx2) ( (bx) <= (x1) && (x1) <= (bx2))

//Projectiles use the background map for attacking
//it turns the floor grid red

typedef struct projectileTag
{
	char x,y; //Where the projectile is on the screen
	char direction; //Use the player orientation stuff again
	int tileDelay; //number of cycles before it moves to the next frame
	char inUse; //is this projectile frame in use?
	char playerOwner; //for now this will always be 1, till I make monsters attack
	char tilesLeft; // how many more tiles does this need to travel
} projectile;

//Player can shoot the cross five times in a row
#define PROJECTILE_MAX 20


extern int projectileCounter;
extern projectile projectiles[];
extern char monsterHit(projectile * proj, int monster);
extern void fireWeapon();
extern void resetProjectiles();
extern void addPlayerProjectile(char x, char y, char direction, char tilesLeft);
extern void processProjectiles();
#endif

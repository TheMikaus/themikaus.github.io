#include "sram.h"
#include "dialog.h"
#include "player.h"
#include <stdlib.h>
#include <stdio.h>

#define BeginSRAM ((unsigned short *)0x0E000000)
#define EndSRAM	  ((unsigned short *)0x0E00FFFF)

char * sram_saveGameOptions[] = { 	"slot 1",
									"slot 2",
									"do not save"
								};

char sram_slot1[10];
char sram_slot2[10];

const char * sram_doNotSave = "do not save";
const char * sram_doNotLoad = "do not load";
const char sram_saveGameReturns[] = { 0, 1, 2};
const char * sram_saveFormat = "level %3d";
const char * sram_notUsed = "-not used-";

dialog_menuOptions sram_saveGameOptionMenu;

void SRAM_Save(void *savedata, int size, int offset)
{
	char * src = (char *)savedata;
	char * dest = (char *)BeginSRAM;
	dest = &dest[offset];

	while(size > 0)
	{
		(*dest)=(*src);
		src++;
		dest++;
		size--;
	}
}

void SRAM_Load(void * loaddata, int size, int offset)
{
	char * src = (char *)BeginSRAM;
	src = &src[offset];
	char * dest = (char *)loaddata;
	while(size > 0)
	{
		(*dest)=(*src);
		src++;
		dest++;
		size--;
	}
}

void sram_loadHighScore(unsigned long int * t)
{
	SRAM_Load(t, sizeof(unsigned long int), 4);
}

void sram_checkHighScore()
{
	unsigned long int score;
	SRAM_Load(&score, sizeof(unsigned long int), 4);
	if(score < thePlayer.score)
	{
		SRAM_Save(&thePlayer.score, sizeof(unsigned long int), 4);
	}
}

//Slot struct
typedef struct sram_saveInfo
{
	char inUse[4];
	char swapButtons; //If this is 1 then LR eliminates
	char level; //This will probably be between 1 and 50 (inclusive)
	unsigned long int score; //This can be from 0->max(u32), make sure the levels are set up to not breach this value
	char currentWeaponType; //This can be either Forward, Left/Right/Forward, or Cross
	char range; //This can be 2->5, starting value is 2
	int health; //Current health, 
} sram_saveInfo;


//Displays the menu needed to save and load games
int sram_displayMenu(char save)
{
	sram_saveInfo slot;
	char canLoad1 = 1;
	char canLoad2 = 1;
	int result;

	if(save == 0)
	{
		sram_saveGameOptions[2] = sram_doNotLoad;
	}
	else
	{
		sram_saveGameOptions[2] = sram_doNotSave;
	}

	//First Slot
	SRAM_Load(&slot, sizeof(sram_saveInfo), 8);		
	
	if(slot.inUse[0] == 'U' && slot.inUse[1] == 'S' && slot.inUse[2] == 'E' && slot.inUse[3] == 'D')
	{
		sprintf(sram_slot1,sram_saveFormat,slot.level);
		canLoad1 = 1;
	}
	else
	{
		sprintf(sram_slot1,sram_notUsed);
		canLoad1 = 0;
	}
	
	sram_saveGameOptions[0] = sram_slot1;
	
	//Second slot
	SRAM_Load(&slot, sizeof(sram_saveInfo), 8 + sizeof(sram_saveInfo));		
	
	if(slot.inUse[0] == 'U' && slot.inUse[1] == 'S' && slot.inUse[2] == 'E' && slot.inUse[3] == 'D')
	{
		sprintf(sram_slot2,sram_saveFormat,slot.level);
		canLoad2 = 1;
	}
	else
	{
		sprintf(sram_slot2,sram_notUsed);
		canLoad2 = 0;
	}
	
	sram_saveGameOptions[1] = sram_slot2;
	
	sram_saveGameOptionMenu.menuText = sram_saveGameOptions;
	sram_saveGameOptionMenu.menuReturns = sram_saveGameReturns;
	sram_saveGameOptionMenu.options = 3;
	
	result = dialog_displayMenu(8, 12, 0, 0, &sram_saveGameOptionMenu, 0, 0);
	
	//If they are unused slots then return the same as back out
	if(!save && ( (result == 0 && !canLoad1) || (result == 1 && !canLoad2)))
	{
		return 2;
	}
	
	return result;
}

//The save game menu will process the save by itself
void sram_saveGameMenu()
{
	char selection = sram_displayMenu(1);
	sram_saveInfo slot;
	
	if(selection != 2)
	{
		slot.health = thePlayer.health;
		slot.level = thePlayer.level;
		slot.currentWeaponType = thePlayer.currentWeaponType;
		slot.swapButtons = thePlayer.swapButtons;
		slot.score = thePlayer.score;
		slot.range = thePlayer.range;
		slot.inUse[0] = 'U';
		slot.inUse[1] = 'S';
		slot.inUse[2] = 'E';
		slot.inUse[3] = 'D';
		
		SRAM_Save(&slot, sizeof(sram_saveInfo), 8 +  sizeof(sram_saveInfo) * selection);
	}
}

//the load game menu will load the slot
//it returns a 1 so the program knows if anything was loaded
//returns a 0 if nothing was loaded
char sram_loadGameMenu()
{
	int selection = sram_displayMenu(0);
	sram_saveInfo slot;
	
	if(selection != 2)
	{
		SRAM_Load(&slot, sizeof(sram_saveInfo), 8 +  sizeof(sram_saveInfo) * selection);
		
		thePlayer.level = slot.level;
		thePlayer.health = slot.health;
		thePlayer.currentWeaponType = slot.currentWeaponType;
		thePlayer.swapButtons = slot.swapButtons;
		thePlayer.score = slot.score;
		thePlayer.range = slot.range;
		thePlayer.pulse = 0;
		thePlayer.pulseDirection = -1;
		thePlayer.pulseTime = 100;
	}
	
	return selection != 2 && selection != -1;
}


void sram_clearSave()
{
	sram_saveInfo slot;
	slot.inUse[0] = 'Q';
	
	SRAM_Save(&slot, sizeof(sram_saveInfo), 8 );	
	SRAM_Save(&slot, sizeof(sram_saveInfo), 8 + sizeof(sram_saveInfo));	
}

void sram_clearHighScore()
{
	unsigned long int score = 0;
	SRAM_Save(&score, sizeof(unsigned long int), 4);
}

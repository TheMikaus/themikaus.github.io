#include "items.h"
#include "sprites.h"
#include "level.h"

itemInfo mapItems[ITEM_MAX]; 
int itemCount;

//The reason I have to keep a separate structure is because
//the leveldata array is marked as const.  Which means I can't just
//erase it's conents

//setup the mapItems object
//Move the sprite
//increas the itemCount variable
void loadNewItem(char tile, char x, char y)
{

	spriteHolder * tag;
	
	mapItems[itemCount].x = x;
	mapItems[itemCount].y = y;
	mapItems[itemCount].taken = 0;
	mapItems[itemCount].inUse = 1;
	mapItems[itemCount].item = tile;

	//Move the sprite
	tag = ((spriteHolder *)&oSprites[OAM_ItemStart + itemCount]);
	tag->x = Map_StartX * 8 + x * 8;
	tag->y = Map_StartY * 8 + y * 8;
	tag->name = Sprite_ForwardShot + (tile - Tile_ForwardShot);
	tag->color_256 = 0;
	tag->palette = 0;
	tag->spriteSize = 0;
	tag->priority = 2;
	
	updateSprites();


	itemCount++;
}

//Sets all the used to false
void resetItems()
{
	spriteHolder * tag;
	
	for(itemCount = 0; itemCount < 13; itemCount++)
	{
		mapItems[itemCount].inUse = 0;
		
		//Move the sprites off screen
		tag = ((spriteHolder *)&oSprites[OAM_ItemStart + itemCount]);
		tag->x = 240;
		tag->y = 160;
	}
	
	itemCount = 0;
	updateSprites();
}

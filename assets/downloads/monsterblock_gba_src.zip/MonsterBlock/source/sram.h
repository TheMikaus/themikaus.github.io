#ifndef sram_h
#define sram_h

#include "player.h"

///////////////////////////////////
// SRAM has the following structure
///////////////////////////////////
// 4 byte vert. blank (all ones)
// 4 byte high score
////////////There are 2 of these
// 4 "USED"
// 1 level
// 4 score
// 1 currentWeaponType
// 1 range
// 1 health
////////////////////////////////////



//The save game menu will process the save by itself
extern void sram_saveGameMenu();

//the load game menu will load the slot
//it returns a 1 so the program knows if anything was loaded
//returns a 0 if nothing was loaded
extern char sram_loadGameMenu();

extern void sram_checkHighScore();
extern void sram_loadHighScore(unsigned long int * t);
extern void sram_clearSave();
extern void sram_clearHighScore();
#endif

#ifndef pause_h
#define pause_h
extern int runPauseMenu();
#endif

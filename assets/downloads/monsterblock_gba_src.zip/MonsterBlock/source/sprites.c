#include "sprites.h"
struct spriteByteStruct oSprites[128];


void clearSprites()
{
	int c = 0;
	for(c = 0; c < 128; c++)
	{
		oSprites[c].at0 = 160;
		oSprites[c].at1 = 240;
	}
	updateSprites();
}


#include "level.h"
#include "sprites.h"
#include "player.h"
#include "items.h"
#include "monsters.h"
#include "registers.h"
#include <stdlib.h>

char player_start_x;
char player_start_y;
char player_start_health;
char player_start_weapon;
char player_start_range;

block ** playGrid; //This needs to be allocated to sizeof(block *) * 42

//This is the list of actual blocks
//Note that no block should be of the type None for long
block * blocks; //This needs to be allocated to sizeof(block) * 42

char * playGround; //This is used to store the pointer to the constant data

void initBlocks()
{
	int x = 0;
	int y = 0;
	int counts = 0;
	
	playGrid = (block **) malloc(sizeof(block *) * (Block_SpriteEnd - Block_SpriteStart));
	blocks = (block*) malloc(sizeof(block) * (Block_SpriteEnd - Block_SpriteStart));
	
	//Setup all the blocks
	for(y = 0; y < Block_Height; y++)
	{
		for(x = 0; x < Block_Width; x++)
		{
			playGrid[counts] = &blocks[counts];
			blocks[counts].yOffset = 0;
			blocks[counts].state = State_Sitting;
			blocks[counts].type = Type_None;
			blocks[counts].delay = 0;
			blocks[counts].x = x;
			blocks[counts].y = y;
			blocks[counts].sprite = counts + 1;
			blocks[counts].clean = 0;
			counts++;
		}
	}
	
//	Sprite_Palette[1] = RGB(0,0,0);
}

void freeBlocks()
{
	free(playGrid);
	free(blocks);
}


//Needs to do the actuall check here
char invalid(char x, int y, char type)
{
	//Check the horizontal for same stuff
	//Find the farthest left from that coordinate it can go while being of type
	int leftOver = x - 1;
	int counter = 0;
	
	while(1)
	{
		if(leftOver < 0)
		{
			break;
		}
		else if(blockAt(leftOver,y)->type != type)
		{
			break;
		}
		else
		{
			leftOver--;
			counter++;
		}
	}
	
	//Now go right
	leftOver = x + 1;
	while(1)
	{
		if(leftOver > Block_Width - 1)
		{
			break;
		}
		else if(blockAt(leftOver,y)->type != type)
		{
			break;
		}
		else
		{
			leftOver++;
			counter++;
		}
	}
	
	//This means that with the addition of this block there will be a combination
	if(counter >= 2)
	{
		return 1;
	}
	
	//Time to check up and down
	leftOver = y - 1;
	counter = 0;
	
	while(1)
	{
		if(leftOver < 0)
		{
			break;
		}
		else if(blockAt(x,leftOver)->type != type)
		{
			break;
		}
		else
		{
			leftOver--;
			counter++;
		}
	}
	
	leftOver = y + 1;
	while(1)
	{
		if(leftOver > Block_Height - 2)
		{
			break;
		}
		else if(blockAt(x,leftOver)->type != type)
		{
			break;
		}
		else
		{
			leftOver++;
			counter++;
		}
	}
	
	if(counter >= 2)
	{
		return 1;
	}
	
	return 0;
}

//Gets a new block for the given x,y coordinate, it needs to check and make sure that it's not
//adding a block that would make a combo
char getNewBlock(char x, char y)
{
	char blockType = rand() % Type_None;
	
	while(invalid(x,y,blockType))
	{
		blockType = rand() % Type_None;
	}
	
	return blockType;
}


//This is a bit of an annoying process.
//it took a little bit of time to figure it out
//collision is not my strong suit
//Basically it goes up the playGrid from bottom to top
//It doesn't touch the very bottom row or the very top row.
//The very bottom row and very top row are hidden behind the background
//They are there to prevent any special handling that I might have had to
//do with boundary cases.  But as is. with the vbr and the vtr I will always
//have a block above that will start falling and I will always have a block
//at the bottom sitting.  It simply removes a couple of if statements that
//I didn't feel like thinking about
char processBlocks()
{
	char blockStopped = 0;
	char counter = 0;
	int counterY = 0;
	block * at;
	block * next;
	
	//Loop from just above the vbr to the vtr
	for(counterY = Block_Height - 2; counterY >= 0; counterY--)
	{
		//Left to right
		for(counter = 0; counter < Block_Width; counter++)
		{
			//Grab the current blocks
			at = blockAt(counter,counterY);
			next = blockAt(counter,counterY+1);
			
			//If the current block is falling
			if(at->state == State_Falling)
			{
				//And it looks like it's in the new grid spot
				if(at->yOffset == 0)
				{
					//If the next spot is empty then move my block w/o checking anything
					if(next->type == Type_None)
					{
						//Move self and reset my offset
						//Then move the empty block up
						at->y++;
						at->yOffset = 16;
						next->y--;
						
						//move the sprite into place
						//I minus the offset to make it look like it hasn't fallen into place yet
						//I was originally adding the offset but that made the collision visualization
						//in my head harder to do for some reason, even though in theory it's close
						//to the same thing
						((spriteHolder *)&oSprites[at->sprite])->y = at->y * 16 + 8 - at->yOffset;
						
						//If the empty block I moved is now at the top
						//Create a new block and set it to falling
						//I set it to falling, just in case there were more than one
						//empty block (in the case of vertical elimination)
						if(next->y == 0)
						{
							next->delay = at->delay;
							next->yOffset = 16;
							next->state = State_Falling;
							next->type = getNewBlock(next->x,next->y);
							((spriteHolder *)&oSprites[next->sprite])->y = next->y * 16 + 8 - next->yOffset;
							((spriteHolder *)&oSprites[next->sprite])->name = 1 + (next->type * 4);
						}
						
						//Update the grid
						blockAt(at->x,at->y) = at;
						blockAt(next->x,next->y) = next;
					}
					else if(next->state == State_Sitting)
					{
						//If the block landed on a block that isn't move
						//make it stop moving
						at->state = State_Sitting;
						((spriteHolder *)&oSprites[at->sprite])->y = at->y * 16 + 8 - at->yOffset;
						blockStopped = 1;
					}
					else
					{
						//Otherwise the block is falling with the reset of them
						at->y++;
						at->yOffset = 16;
					}
				}
				else if(at->delay == 0)
				{
					//After the delay time move the block a little
					at->delay = 10;
					at->yOffset--;
					((spriteHolder *)&oSprites[at->sprite])->y = at->y * 16 + 8 - at->yOffset;
				}
				else
				{
					//Decrease the delay time
					at->delay--;
				}
			}
		}
	}
	
	return blockStopped ;
}

//This will set the pointer
//Load the tiles
//Load the enemies, items and player
//I'm thinking that I might do the same trick with the map that
//I do with the tiles
//I might line the outer wall with blocks
//That the player can't see or move into
//It will simplify the collision detection
void loadMap(const char * pointer)
{
	char x,y;
	char tile;
	unsigned short * map = (unsigned short *)ScreenBaseBlock(29);
	
	resetItems();
	resetMonsters();
	
	//First set the pointer
	playGround = (char *)pointer;
	
	//Next process from left to right, top to bottom to load the level
	for(y = 0; y < Map_Height; y++)
	{
		for(x = 0; x < Map_Width; x++)
		{
			tile = tileAt(x,y);
			if(tile == Tile_Block)
			{
				//Set the tile to the block
				map[ (x + Map_StartX) + (y + Map_StartY) * 32] = BackgroundTile_Block;
			}
			else if(tile == Tile_Exit)
			{
				map[ (x + Map_StartX) + (y + Map_StartY) * 32] = BackgroundTile_Exit;
			}
			else if(tile == Tile_Empty)
			{
				map[ (x + Map_StartX) + (y + Map_StartY) * 32] = BackgroundTile_Empty;
			}
			else
			{
				map[ (x + Map_StartX) + (y + Map_StartY) * 32] = BackgroundTile_Empty;
				//The tile was a monster, an Item or the player
				//Process accordingly
				if(tile == Tile_Player)
				{
					player_start_x = x;
					player_start_y = y;
					player_start_health = thePlayer.health;
					player_start_weapon = thePlayer.currentWeaponType;
					player_start_range = thePlayer.range;
					thePlayer.map_x = x;
					thePlayer.map_y = y;
					thePlayer.map_orientation = PLAYER_UP;
					thePlayer.offset = 0;
					thePlayer.actionFrames = 0;
					thePlayer.animationDelay = 0;
					
					thePlayer.currentAction = 0;
					thePlayer.actionsInQueue = 0;
					
					initPlayerOnMap();
					updatePlayerOnMap();
				}
				else if(tile < Tile_Monster_UpDown)
				{
					//it's an item
					loadNewItem(tile,x,y);
					
				}
				else if(tile < Tile_Boss_UpDown)
				{
					//it's a monster
					loadNewMonster(tile,x,y);
				}
				else if(tile < Tile_Boss_Random + 1)
				{
					//it's a boss
					loadNewBoss(tile,x,y);
				}
				
			}
		}
	}
}

#include "dialog.h"
#include <stdlib.h>
#include <string.h>

//I would include the GBA header, but I think I should just
//Write all the defines that I need for the spots in the c file
//That way I don't have to depend on it at all.  I just need to use
//the actual locations

//Special Defines needed just for this files
#define Controller_A 1
#define Controller_B 2
#define Controller_SELECT 4
#define Controller_START 8
#define Controller_RIGHT 16
#define Controller_LEFT 32
#define Controller_UP 64
#define Controller_DOWN 128
#define Controller_R 256
#define Controller_L 512

#define DPAD_Pressed !(*JOY_REG & (Controller_UP + Controller_DOWN + Controller_LEFT + Controller_RIGHT))
#define DPAD_UP      !(*JOY_REG & Controller_UP)
#define DPAD_DOWN    !(*JOY_REG & Controller_DOWN)
#define DPAD_LEFT    !(*JOY_REG & Controller_LEFT)
#define DPAD_RIGHT   !(*JOY_REG & Controller_RIGHT)
#define DPAD_A		 !(*JOY_REG & Controller_A)

#define updateMenuSprite()	DMACopy((void *)&dialog_menuSprite, (void *)Sprite_Memory,DMA_32NOW, 2)
#define KeyReleased() while(1) if(!(*JOY_REG < 0x3ff)) break;
#define BackgroundPalette_Memory ((unsigned short *)0x5000000)
#define Register_DisplayStatus *(volatile unsigned short *)0x4000004
#define vsync() while((Register_DisplayStatus & 1)); while(!(Register_DisplayStatus & 1));

#define CharBaseBlock(n) (((n)*0x4000)|0x6000000)
#define ScreenBaseBlock(n) (((n)*0x800) | 0x6000000)

#define Register_Bg2Ctrl *(volatile unsigned short *) 0x400000C
#define Register_Bg2HOffset *(volatile unsigned short *)0x4000018
#define Register_Bg2VOffset *(volatile unsigned short *)0x400001A

#define Register_Bg3Ctrl *(volatile unsigned short *) 0x400000E
#define Register_Bg3HOffset *(volatile unsigned short *)0x400001C
#define Register_Bg3VOffset *(volatile unsigned short *)0x400001E

#define TextBackground_Size512x512 0xC000

#define SCREEN_SHIFT 8
#define CHAR_SHIFT 2

#define Register_DMASource  * (volatile unsigned int *) 0x40000D4
#define Register_DMADest    * (volatile unsigned int *) 0x40000D8
#define Register_DMAControl * (volatile unsigned int *) 0x40000DC

#define DMA_32 0x04000000
#define DMA_ENABLE 0x80000000
#define DMA_32NOW (DMA_ENABLE | DMA_32)
#define DMACopy(a,b,c,d) { Register_DMASource = (unsigned int)(a); Register_DMADest = (unsigned int)(b); Register_DMAControl = (((unsigned int)(c)) | ((unsigned int)(d))); }

#define Sprite_Memory ((volatile unsigned short *) 0x7000000)
#define Sprite_Tiles  ((unsigned short *) 0x6010000)
#define Sprite_Palette ((unsigned short *) 0x5000200)

#define JOY_REG (volatile unsigned short *)0x04000130
//I need to keep a copy of the sprite pointer here in memory
typedef struct dialogSpriteHolderTag
{
	unsigned y : 8;

	unsigned rotation : 1;
	unsigned DoubleSize : 1;
	unsigned translucent : 1;
	unsigned windowed : 1;
	unsigned mosaic : 1;
	unsigned color_256 : 1;
	unsigned tall : 1;
	unsigned wide : 1;

	//at1
	unsigned x : 9;
	unsigned rotation_index : 3;
	unsigned hflip : 1;
	unsigned vflip : 1;
	unsigned spriteSize:2;
	
	//at2
	unsigned name : 10;
	unsigned priority : 2;
	unsigned palette : 4;
	
	unsigned short at3;
} dialogSpriteHolder;

dialogSpriteHolder dialog_menuSprite;
unsigned char dialog_blinkSpeed;

void dialog_setBlinkSpeed(unsigned blink)
{
	dialog_blinkSpeed = blink;
}

//Initialization functions
//This function should set up backgrounds 2 and 3 for use
//I'll be using tile 9 since that's the space in the font is going to be the 9th tile
void dialog_init()
{
	unsigned char * bg2Map = (unsigned char *)ScreenBaseBlock(31);
	unsigned char * bg3Map = (unsigned char *)ScreenBaseBlock(30);
	unsigned long int counter = 0;
	
	//Set up the two background
	//Need to figure out priorities
	Register_Bg2Ctrl = 1 | TextBackground_Size512x512 | (31 << SCREEN_SHIFT) | (2 << CHAR_SHIFT);
	Register_Bg3Ctrl = 0 | TextBackground_Size512x512 | (30 << SCREEN_SHIFT) | (2 << CHAR_SHIFT);
	
	//Set the maps to the correct spot
	//I haven't quite figured out what the correct spacing on this is.
	//I had it at the following equation
	// 512 * 512 (tiles) = 262144
	//Which left artifacts all over the place
	//So then i divided it by 4 and it was still all over the place
	//When I got it to 32768 it was a little less artifacty, but
	//starting whipin' out my sprite memory after tile one.
	//No clue why, it just did, maybe it was overwriting the sprite palette memory.
	for(counter = 0; counter < 0x800; counter++)
	{
		bg2Map[counter] = 9;
		bg3Map[counter] = 9;
	}
}

//This function will take two pointers the dialogTiles and the fontTiles
//Dialog Tiles should consist of 9 8x8 tiles.  Top Left, Top, Top Right,
//Left, Middle, Right, Bottom Left, Bottom, Bottom Right
//Remeber that you can only use 16 bit color schema for all backgrounds total
//So dialog tiles should really only be black and white

//Font tiles should consist of the ASCII tiles 32->126
//Each letter is one tile.  So keep that in mind when designing the tile

//The Colors for the dialog palette are reserved at the end of the 16 color palette
//There are three colors at the end reserved for use.  Background, Text,Dialog
//Note that this only leaves you with 13 colors to mess with and in actuality
//only 12 since the first palette index is transparent.
//Note that this also means the the dialogTiles and the fontTiles must reference
//The last three index values (13,14,15)
//The tiles are copied to a space allocated in memory specifically for the last 2 backgrounds.
//############## COMMENT ABOUT WHERE IT IS PLACED IN MEMORY #########################
//They are placed in CharBaseBlock(2)
//The tile map will be stored at screen base block 31 for the text
//And 32 for the dialog box itself
void dialog_loadDialogTiles(void * dialogTiles, void * fontTiles)
{
	//Load the dialog Tiles into memory
	//Each dialog tile is 4 bits per pixel
	//Each tile is 8x8 which is 64 pixels * 4 bits
	//Which ends up being 256 bits
	//Which is 32 bytes per tile
	//32 * 9 = 288 bytes
	//DMA copy by 4 bytes at a time
	//288/4 = 72
	//The destination should be the last character base block
	DMACopy(dialogTiles,CharBaseBlock(2),DMA_32NOW,72);
	
	//Load the font tiles into memory
	//32 -> 126 which is 94 tiles
	//94 * 32 = 3008 bytes
	//3008 / 4 = 752
	//This will be stored in the same base block, but will be offset
	//By the dialog tiles
	//I don't know why 752 is wrong
	//I probably missed a character or something in the addition.
	DMACopy(fontTiles,CharBaseBlock(2) + 288	, DMA_32NOW, 752 + 8);
}

//These three functions set the palette colors.
void dialog_setBackgroundColor(unsigned int color)
{
	//Should use 14
	//Should be a simple Pallete[14] = blah or something similar
	BackgroundPalette_Memory[14] = color;
}

void dialog_setDialogColor(unsigned int color)
{
	//Should use 13
	BackgroundPalette_Memory[13] = color;
}

void dialog_setTextColor(unsigned int color)
{
	//Should use 15
	BackgroundPalette_Memory[15] = color;
}



//This function generates a new dialog_transitionAction
//And sets the next pointer to null
dialog_transitionAction * dialog_newTransition(dialog_transitionType type, unsigned char sd, unsigned char sd2)
{
	dialog_transitionAction * retValue = (dialog_transitionAction *)malloc(sizeof(dialog_transitionAction));
	
	retValue->nextTransition = 0;
	retValue->transitionType = type;
	retValue->specialData = sd;
	retValue->specialData2 = sd2;
	
	return retValue;
}

//This should delete all the transactions allocated
//This is a recursive solution as I don't remember a 
//non-recursive way to do this well
void dialog_deleteTransitions(dialog_transitionAction * transitions)
{
	//I hope the call stack is big enough for this
	if(transitions->nextTransition != 0)
	{
		dialog_deleteTransitions(transitions->nextTransition);
	}
	
	free(transitions);
}


//For menus I need to have set aside one sprite.
//So I will, the last sprite 124 or 255 (I don't remember what it'll be) is set aside for a 
//menu pointer.  It can only be one color in the sprite palette and so it is the last one as well color 15
//This is the function that loads the sprite data for the menu.
//It'll copy the data to the sprite location at the end of sprite data as well.
//I wanted this to be at the end, but I think I'll just make it at the beginning instead.  
//It's easier that way
void dialog_setMenuSprite(void * data)
{
	//Copy sprite data to the needed location
	//4 bits per pixels 8x8 pixels
	//64 * 4 = 256 bits
	//256/32 = 8 count
	//Sprite_Memory
	DMACopy(data, Sprite_Tiles, DMA_32NOW, 8);
}

//The sprite color used for the menu is the last in it's state
void dialog_setMenuSpriteColor(int color)
{
	//Set the sprite color
	Sprite_Palette[15] = color;
}

//Dialog display functions
//Description of the transitions and what they should use of the dialog_transitionAction struct
// LEFT_SLIDE <- slide in to position from the left side of the screen.  The dialog will use the same
//		 y values for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// RIGHT_SLIDE <- slide in to position from the right side of the screen.  The dialog will use the same
//		  y values for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// TOP_SLIDE <- slide in to position from the top of the screen.  The dialog will use the same x values 
//		for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// BOTTOM_SLIDE <- slide in to position from the bottom of the screen. The dialog will use the same x values
//		   for the dialog as passed into the function that displays the dialog.
//		-specialData will contain the speed in pixels that you want this to slide
//		-specialData2 will contain a 0 if the menu is to start at [===] and a 1 if it is to be fully open
// COLLAPSE <- will open starting from the centered position of the menu, into the x,y,w,h of passed in values
// EXPAND <- will close to the centered position of the menu.
// DROP_DOWN <- will start the menu as just a little [===] and open it downward.
// ROLL_UP <- will roll the menu up to [===]
//	      -specialData will contain a 0 if it is to close to nothing or a 1 if is to close to [===]
//Sliding is done by moving the background to be off screen and then scrolling to the specified position

//If the open or close actions are null (0) then don't do anything special for that action
dialog_tracker * dialog_displayOpen(char x, char y, char w, char h, char * text, dialog_transitionAction * open)
{
	dialog_tracker * dt = (dialog_tracker *)malloc(sizeof(dialog_tracker));
	unsigned short * bg2map = (unsigned short *)ScreenBaseBlock(31);
	unsigned short moverX = 0;
	unsigned short moverY = 0;
	
	
	dt->x=x;
	dt->y=y;
	dt->w=w;
	dt->h=h;
	
	if(open == 0)
	{
		//Display the form
		h += y;
		w += x;
		
		//Display the bars first
		for(moverY = y ; moverY < h + 1; moverY++)
		{
			if(moverY == y)
			{
				for(moverX = x + 1 ; moverX < w; moverX++)
				{
					bg2map[moverX + moverY * 32] = 1;
				}
			}
			else if(moverY == h)
			{
				for(moverX = x + 1; moverX < w; moverX++)
				{
					bg2map[moverX + moverY * 32] = 7;
				}				
			}
			else
			{
				for(moverX = x + 1; moverX < w; moverX++)
				{
					bg2map[moverX + moverY * 32] = 4;
				}				
			}
			
			bg2map[x + moverY * 32] = 3;
			bg2map[w + moverY * 32] = 5;
		}
		
		bg2map[x + y * 32] = 0;
		bg2map[w + y * 32] = 2;
		bg2map[x + h * 32] = 6;
		bg2map[w + h * 32] = 8;
		
		//Display the text
		free(dialog_displayText(x + 1, y + 1, text,0));
	}
	else
	{
		//Perform the transition
	}
	
	
	//This does not do any special actions on the text, doesn't wait to display the next line or
	//anything like that.  That sort of stuff, must be implemented by something else.
	//Like a run dialog function that I shoudl write after I get this thing working.
	return dt;
}

void dialog_displayClose(dialog_tracker * dt, dialog_transitionAction * close)
{
	unsigned short * bg2map = (unsigned short *)ScreenBaseBlock(31);
	unsigned short * bg3map = (unsigned short *)ScreenBaseBlock(30);
	unsigned short moverY = dt->y;
	
	if(close != 0)
	{
		//Perform transition
	}
	else
	{
		//Hide the dialog
		//Clear both map grounds
		dt->w += dt->x;
		dt->h += dt->y;
		for(;dt->x < dt->w + 1; dt->x++)
		{
			dt->y = moverY;
			for(;dt->y < dt->h + 1; dt->y++)
			{
				bg2map[dt->x + dt->y * 32] = 9;
				bg3map[dt->x + dt->y * 32] = 9;
			}
		}
	}
}

//The width and the height are removed from this because the value is automatically created by the menu options.  It'll find the longest menu, 
//and you pass in the count of menu options so it does that.
//The text that is passed in, will be on the top left of the dialog box. +-text----+
//So I should make sure that a font has black value around it and transparent filler in the background and a white font color (or something similar).
int dialog_displayMenu(char x, char y, dialog_transitionAction * open, dialog_transitionAction * close, dialog_menuOptions * menu, unsigned char optionSpace, char xOffset)
{
	//First I need to figure out how wide and how tall this thing needs to be so lets do that now.
	unsigned char w = 0, temp = 0;
	unsigned char menuCounter = 0;
	unsigned char textCounter = 0;
	unsigned char uCounter = 0;
	unsigned char selectedOption = 0;
	unsigned char ypos = 0;
	char * text = 0;
	dialog_tracker * dt = 0;
	
	for(menuCounter = 0; menuCounter < menu->options; menuCounter++)
	{
		temp = strlen(menu->menuText[menuCounter]);
		if(temp > w)
		{
			w = temp;
		}
		textCounter += temp + 2 + optionSpace; //The additional lines for the spacing "\n"
	}

	
	//Allocate the needed space for text and then cat the strings
	text = (char *)malloc(textCounter);
	text[0] = 0;
	for(menuCounter = 0; menuCounter < menu->options; menuCounter++)
	{
		strcat(text," ");
		strcat(text,menu->menuText[menuCounter]);
		for(uCounter = 0; menuCounter + 1 < menu->options && uCounter <= optionSpace; uCounter++)
		{
			strcat(text,"\n");
		}
	}
	
	
	//Display the menu now
	//I add two to w and h because I need room for the borders
	dt = dialog_displayOpen(x,y,w + 2, (menu->options-1) * (1 + optionSpace) + 2,text,open);
	
	
	//Now we need to run the menu here
	//Move the sprite to the correct location
	//(usually the top menu option)
	//Start a loop
	//Loop lets the player select an option
	//I should extend the structure to allow a description per option, but not at the moment
	//Move the mouse
	
	//Display the main sprite
	dialog_menuSprite.x = (x + 1) * 8 + xOffset;
	dialog_menuSprite.y = (y + 1) * 8;
	dialog_menuSprite.color_256 = 0;
	dialog_menuSprite.priority = 0;
	dialog_menuSprite.name=0;
	dialog_menuSprite.palette = 0; //first 16 color pal.
	updateMenuSprite();
	
	KeyReleased();
	
	while( (*JOY_REG & Controller_A) && (*JOY_REG & Controller_B))
	{
		//Check the movements here
		if(DPAD_UP)
		{
			if(selectedOption == 0)
			{
				selectedOption = menu->options-1;
			}
			else
			{
				selectedOption--;
			}
			
			//Update the menu Sprite
			ypos = (selectedOption);
			ypos *= (optionSpace + 1);
			ypos += y;
			ypos++;
			ypos *= 8;
			
			dialog_menuSprite.y = ypos;
			
			updateMenuSprite();
			KeyReleased();
		}
		else if(DPAD_DOWN)
		{
			selectedOption++;
			if(selectedOption == menu->options)
			{
				selectedOption = 0;
			}
			
			//Update the menu sprite
			ypos = (selectedOption);
			ypos *= (optionSpace + 1);
			ypos += y;
			ypos++;
			ypos *= 8;
			
			
			dialog_menuSprite.y = ypos;
			
			updateMenuSprite();
			KeyReleased();
		}
	}
	
	dialog_displayClose(dt,close);
	free(dt);


	dialog_menuSprite.y = 240;
	updateMenuSprite();
	
	if(!(*JOY_REG & Controller_B)) 
	{
		KeyReleased();
		return -1;
	}
	KeyReleased();
	
	return menu->menuReturns[selectedOption]; //This needs to be the player's selection
}

//This pretty much just half of the close function
void dialog_clearText(dialog_tracker * dt)
{
	unsigned short * bg3map = (unsigned short *)ScreenBaseBlock(30);
	unsigned short moverY = dt->y;
	
	//Hide the dialog
	//Clear both map grounds
	dt->w += dt->x;
	dt->h += dt->y;
	for(;dt->x < dt->w + 1; dt->x++)
	{
		dt->y = moverY;
		for(;dt->y < dt->h + 1; dt->y++)
		{

			bg3map[dt->x + dt->y * 32] = 9;
		}
	}
}

//This function just display text at a designated location
dialog_tracker * dialog_displayText(char x, char y, char * text, char delay)
{
	//This will just display text at a particular location
	dialog_tracker * dt = (dialog_tracker *)malloc(sizeof(dialog_tracker));
	unsigned short length = 0;
	unsigned short counter = 0;
	unsigned short subCounter = 0;
	unsigned short * bg3map = (unsigned short *)ScreenBaseBlock(30);
	unsigned char maxChar = 0;
	
	dt->x = x;
	dt->y = y;
	dt->h = 0;
	
	length = strlen(text);
	for(counter = 0; counter < length; counter++)
	{
		if(text[counter] == '\n')
		{
			dt->h++;
			if(maxChar > dt->w)
			{
				dt->w = maxChar;
			}
			maxChar = 0;
		}
		else
		{
			//Display the character
			bg3map[dt->x + maxChar + (y + dt->h) * 32] = text[counter] - 23;
			
			for(subCounter = 0; subCounter < delay; subCounter++)
			{
				vsync();
			}
			
			maxChar++;
		}
	}
	
	return dt;
}


//Will display a box of text.  Each array element of text (first level) is one dialog
//It will display the text at the given delay speed per character and then it'll chill with the flashy thingy
void dialog_displayDialog(char x, char y, char w, char h, char * text[], char dialogCount, dialog_transitionAction * open, dialog_transitionAction * close, char delayPerChar)
{
	int waitCounter = 0;
	int overAllCounter = 0;

	
	//It should automatically split lines.
	//Open the dialog with the transition and no text
	dialog_tracker * dt = dialog_displayOpen(x,y,w,h,"",open);
	dialog_tracker * dt2;
	
	y++;
	x++;
	for(overAllCounter = 0; overAllCounter < dialogCount; overAllCounter++)
	{
		//Display the text
		dt2 = dialog_displayText(x, y, text[overAllCounter], delayPerChar);
		
		//Move menu sprite to lower right of dialog
		dialog_menuSprite.x = (x + w - 1) * 8 - 4;
		dialog_menuSprite.y = (y + h - 1) * 8 - 4;
		updateMenuSprite();
		
		while(1)
		{
			if(*JOY_REG < 0x3ff)
			{
				break;
			}
			
			for(waitCounter = 0; waitCounter < dialog_blinkSpeed && !DPAD_A; waitCounter++)
			{
				vsync();
			}
			
			//Flip the menu Sprite Icon
			if(dialog_menuSprite.y < 160)
			{
				dialog_menuSprite.y = 160;
			}
			else
			{
				dialog_menuSprite.y = (y+h - 1) * 8 - 4;
			}

			dialog_menuSprite.x = (x + w - 1) * 8 - 4;
			
			updateMenuSprite();
		}
		
		//move menu sprite off screen
		dialog_menuSprite.y = 160;
		updateMenuSprite();
		KeyReleased();
		
		dialog_clearText(dt2);
		free(dt2);
	}
	
	
	dialog_displayClose(dt,close);
	free(dt);
}

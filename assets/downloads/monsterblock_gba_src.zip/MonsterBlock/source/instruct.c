#include "instruct.h"
#include "registers.h"

#include "tiles_instructions1_bin.h"
#include "map_instructions1_bin.h"
#include "pal_instructions1_bin.h"
#include "tiles_instructions2_bin.h"
#include "map_instructions2_bin.h"
#include "pal_instructions2_bin.h"
#include "tiles_instructions3_bin.h"
#include "map_instructions3_bin.h"
#include "pal_instructions3_bin.h"
#include "tiles_instructions4_bin.h"
#include "map_instructions4_bin.h"
#include "pal_instructions4_bin.h"
#include "tiles_instructions5_bin.h"
#include "map_instructions5_bin.h"
#include "pal_instructions5_bin.h"
#include "tiles_instructions6_bin.h"
#include "map_instructions6_bin.h"
#include "pal_instructions6_bin.h"


//Copy the page to memory
void loadInstructions(int page)
{
	switch(page)
	{
		case 0:
			DMACopy(tiles_instructions1_bin,CharBaseBlock(0), DMA_32NOW,tiles_instructions1_bin_size/4);
			DMACopy(map_instructions1_bin,ScreenBaseBlock(29), DMA_32NOW, map_instructions1_bin_size/4);
			DMACopy(pal_instructions1_bin,BackgroundPalette_Memory,DMA_32NOW,pal_instructions1_bin_size/4);
			break;
		case 1:
			DMACopy(tiles_instructions2_bin,CharBaseBlock(0), DMA_32NOW,tiles_instructions2_bin_size/4);
			DMACopy(map_instructions2_bin,ScreenBaseBlock(29), DMA_32NOW, map_instructions2_bin_size/4);
			DMACopy(pal_instructions2_bin,BackgroundPalette_Memory,DMA_32NOW,pal_instructions2_bin_size/4);
			break;
		case 2:
			DMACopy(tiles_instructions3_bin,CharBaseBlock(0), DMA_32NOW,tiles_instructions3_bin_size/4);
			DMACopy(map_instructions3_bin,ScreenBaseBlock(29), DMA_32NOW, map_instructions3_bin_size/4);
			DMACopy(pal_instructions3_bin,BackgroundPalette_Memory,DMA_32NOW,pal_instructions3_bin_size/4);
			break;
		case 3:
			DMACopy(tiles_instructions4_bin,CharBaseBlock(0), DMA_32NOW,tiles_instructions4_bin_size/4);
			DMACopy(map_instructions4_bin,ScreenBaseBlock(29), DMA_32NOW, map_instructions4_bin_size/4);
			DMACopy(pal_instructions4_bin,BackgroundPalette_Memory,DMA_32NOW,pal_instructions4_bin_size/4);
			break;
		case 4:
			DMACopy(tiles_instructions5_bin,CharBaseBlock(0), DMA_32NOW,tiles_instructions5_bin_size/4);
			DMACopy(map_instructions5_bin,ScreenBaseBlock(29), DMA_32NOW, map_instructions5_bin_size/4);
			DMACopy(pal_instructions5_bin,BackgroundPalette_Memory,DMA_32NOW,pal_instructions5_bin_size/4);
			break;
		case 5:
			DMACopy(tiles_instructions6_bin,CharBaseBlock(0), DMA_32NOW,tiles_instructions6_bin_size/4);
			DMACopy(map_instructions6_bin,ScreenBaseBlock(29), DMA_32NOW, map_instructions6_bin_size/4);
			DMACopy(pal_instructions6_bin,BackgroundPalette_Memory,DMA_32NOW,pal_instructions6_bin_size/4);
			break;
	}
}

void runInstructions()
{
	int page = 0;
	
	KeyReleased();
	SetMode(0 | BG0_ENABLE );
	
	for(page = 0; page < 6; page++)
	{
		//Load the page
		loadInstructions(page);
		
		//Wait for A or B
		while(1)
		{
			KeyDown();
			
			//if B then exit
			if(DPAD_B)
			{
				break;
			}
			
			//if A then continue
			if(DPAD_A)
			{
				KeyReleased();
				break;
			}
		}
	}
}

using System;
using System.IO;

namespace mbEditor
{
	/// <summary>
	/// The Level
	/// </summary>
	public class Level
	{
		public int[,] data;

		public Level()
		{
			data = new int[8,14];
			setToBlocks();
		}

		public Level(StreamReader sr)
		{
			data = new int[8,14];
			//Read in the dummy //LEVEL X line
			sr.ReadLine();

			//Read in 14 lines and set the characters accordingly
			for(int cnt_lines = 0; cnt_lines < 14; cnt_lines++)
			{
				string[] split = sr.ReadLine().Split(',');
				for(int cnt_width = 0; cnt_width < 8; cnt_width++)
				{
					data[cnt_width,cnt_lines] = Convert.ToInt32(split[cnt_width].Trim());
				}
			}
		}

		public void save(StreamWriter sw, int counter)
		{
			//Drops it to the file in the same format it reads in
			sw.WriteLine("//Level " + counter);

			for(int cnt_lines = 0; cnt_lines < 14; cnt_lines++)
			{
				for(int cnt_width = 0; cnt_width < 8; cnt_width++)
				{
					sw.Write(data[cnt_width,cnt_lines]);
					sw.Write(",");
				}
				sw.WriteLine("");
			}
		}

		public void setToBlocks()
		{
			for(int cnt_lines = 0; cnt_lines < 14; cnt_lines++)
			{
				for(int cnt_width = 0; cnt_width < 8; cnt_width++)
				{
					data[cnt_width,cnt_lines] = 1;
				}
			}
		}
	}
}

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace mbEditor
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox_levelEditor;
		private System.Windows.Forms.HScrollBar hScrollBar_levels;
		private System.Windows.Forms.ComboBox comboBox_tile;
		private System.Windows.Forms.Button button_save;
		private System.Windows.Forms.Button button_load;
		private System.Windows.Forms.Button button_new;
		private System.Windows.Forms.Button button_addLevel;
		private System.Windows.Forms.Button button_deleteLevel;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ImageList imageList;
		private System.Windows.Forms.PictureBox pictureBox_level;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.SaveFileDialog saveFileDialog;
		private System.Windows.Forms.GroupBox groupBox_info;
		private System.Windows.Forms.Label label_info;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;

		private ArrayList levels = new ArrayList();

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			levels.Add(new Level());
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.groupBox_levelEditor = new System.Windows.Forms.GroupBox();
			this.hScrollBar_levels = new System.Windows.Forms.HScrollBar();
			this.comboBox_tile = new System.Windows.Forms.ComboBox();
			this.button_save = new System.Windows.Forms.Button();
			this.button_load = new System.Windows.Forms.Button();
			this.button_new = new System.Windows.Forms.Button();
			this.pictureBox_level = new System.Windows.Forms.PictureBox();
			this.button_addLevel = new System.Windows.Forms.Button();
			this.button_deleteLevel = new System.Windows.Forms.Button();
			this.imageList = new System.Windows.Forms.ImageList(this.components);
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			this.groupBox_info = new System.Windows.Forms.GroupBox();
			this.label_info = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.groupBox_levelEditor.SuspendLayout();
			this.groupBox_info.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox_levelEditor
			// 
			this.groupBox_levelEditor.Controls.Add(this.pictureBox_level);
			this.groupBox_levelEditor.Location = new System.Drawing.Point(8, 8);
			this.groupBox_levelEditor.Name = "groupBox_levelEditor";
			this.groupBox_levelEditor.Size = new System.Drawing.Size(144, 248);
			this.groupBox_levelEditor.TabIndex = 0;
			this.groupBox_levelEditor.TabStop = false;
			this.groupBox_levelEditor.Text = "Level";
			// 
			// hScrollBar_levels
			// 
			this.hScrollBar_levels.LargeChange = 1;
			this.hScrollBar_levels.Location = new System.Drawing.Point(8, 256);
			this.hScrollBar_levels.Maximum = 0;
			this.hScrollBar_levels.Name = "hScrollBar_levels";
			this.hScrollBar_levels.Size = new System.Drawing.Size(144, 16);
			this.hScrollBar_levels.TabIndex = 1;
			this.hScrollBar_levels.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_levels_Scroll);
			// 
			// comboBox_tile
			// 
			this.comboBox_tile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_tile.Items.AddRange(new object[] {
															   "Empty",
															   "Block",
															   "Exit",
															   "Player",
															   "Forward Shot",
															   "Split Shot",
															   "Cross Shot",
															   "Range Up",
															   "Health",
															   "Pauser",
															   "Monster - UpDown",
															   "Monster - LeftRight",
															   "Monster - DownRight",
															   "Monster - UpRight",
															   "Monster - UpLeft",
															   "Monster - DownLeft",
															   "Monster - Random",
															   "Boss - UpDown",
															   "Boss - LeftRight",
															   "Boss - DownRight",
															   "Boss - UpRight",
															   "Boss - UpLeft",
															   "Boss - DownLeft",
															   "Boss - Random"});
			this.comboBox_tile.Location = new System.Drawing.Point(168, 16);
			this.comboBox_tile.Name = "comboBox_tile";
			this.comboBox_tile.Size = new System.Drawing.Size(184, 21);
			this.comboBox_tile.TabIndex = 2;
			// 
			// button_save
			// 
			this.button_save.Location = new System.Drawing.Point(232, 248);
			this.button_save.Name = "button_save";
			this.button_save.Size = new System.Drawing.Size(56, 24);
			this.button_save.TabIndex = 3;
			this.button_save.Text = "save";
			this.button_save.Click += new System.EventHandler(this.button_save_Click);
			// 
			// button_load
			// 
			this.button_load.Location = new System.Drawing.Point(296, 248);
			this.button_load.Name = "button_load";
			this.button_load.Size = new System.Drawing.Size(56, 24);
			this.button_load.TabIndex = 4;
			this.button_load.Text = "load";
			this.button_load.Click += new System.EventHandler(this.button_load_Click);
			// 
			// button_new
			// 
			this.button_new.Location = new System.Drawing.Point(168, 248);
			this.button_new.Name = "button_new";
			this.button_new.Size = new System.Drawing.Size(56, 24);
			this.button_new.TabIndex = 7;
			this.button_new.Text = "new";
			this.button_new.Click += new System.EventHandler(this.button_new_Click);
			// 
			// pictureBox_level
			// 
			this.pictureBox_level.Location = new System.Drawing.Point(8, 16);
			this.pictureBox_level.Name = "pictureBox_level";
			this.pictureBox_level.Size = new System.Drawing.Size(128, 224);
			this.pictureBox_level.TabIndex = 0;
			this.pictureBox_level.TabStop = false;
			this.pictureBox_level.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox_level_Paint);
			this.pictureBox_level.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox_level_MouseDown);
			// 
			// button_addLevel
			// 
			this.button_addLevel.Location = new System.Drawing.Point(168, 224);
			this.button_addLevel.Name = "button_addLevel";
			this.button_addLevel.Size = new System.Drawing.Size(88, 23);
			this.button_addLevel.TabIndex = 8;
			this.button_addLevel.Text = "Add Level";
			this.button_addLevel.Click += new System.EventHandler(this.button_addLevel_Click);
			// 
			// button_deleteLevel
			// 
			this.button_deleteLevel.Location = new System.Drawing.Point(264, 224);
			this.button_deleteLevel.Name = "button_deleteLevel";
			this.button_deleteLevel.Size = new System.Drawing.Size(88, 23);
			this.button_deleteLevel.TabIndex = 9;
			this.button_deleteLevel.Text = "Delete Level";
			this.button_deleteLevel.Click += new System.EventHandler(this.button_deleteLevel_Click);
			// 
			// imageList
			// 
			this.imageList.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
			this.imageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// groupBox_info
			// 
			this.groupBox_info.Controls.Add(this.label4);
			this.groupBox_info.Controls.Add(this.label3);
			this.groupBox_info.Controls.Add(this.label2);
			this.groupBox_info.Controls.Add(this.label1);
			this.groupBox_info.Controls.Add(this.label_info);
			this.groupBox_info.Location = new System.Drawing.Point(168, 40);
			this.groupBox_info.Name = "groupBox_info";
			this.groupBox_info.Size = new System.Drawing.Size(184, 176);
			this.groupBox_info.TabIndex = 6;
			this.groupBox_info.TabStop = false;
			this.groupBox_info.Text = "information";
			// 
			// label_info
			// 
			this.label_info.Location = new System.Drawing.Point(8, 16);
			this.label_info.Name = "label_info";
			this.label_info.Size = new System.Drawing.Size(168, 16);
			this.label_info.TabIndex = 0;
			this.label_info.Text = "Maximum of 16 monsters.";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(168, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Maximum of 10 bosses.";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(168, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Maximum of 12 items.";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 72);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(168, 40);
			this.label3.TabIndex = 3;
			this.label3.Text = "If you do not place a player start then the level will start from the last level\'" +
				"s start position";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 120);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(168, 48);
			this.label4.TabIndex = 4;
			this.label4.Text = "If you do not place an exit then the only way to beat the stage would be to defea" +
				"t all monsters/bosses";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 277);
			this.Controls.Add(this.button_deleteLevel);
			this.Controls.Add(this.button_addLevel);
			this.Controls.Add(this.button_new);
			this.Controls.Add(this.groupBox_info);
			this.Controls.Add(this.button_load);
			this.Controls.Add(this.button_save);
			this.Controls.Add(this.comboBox_tile);
			this.Controls.Add(this.hScrollBar_levels);
			this.Controls.Add(this.groupBox_levelEditor);
			this.Name = "Form1";
			this.Text = "Monster Block Editor";
			this.groupBox_levelEditor.ResumeLayout(false);
			this.groupBox_info.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		

		private void button_new_Click(object sender, System.EventArgs e)
		{
			levels.Clear();
			levels.Add(new Level());
			
			//Reset the form to starting position
			hScrollBar_levels.Value = 0;
			hScrollBar_levels.Maximum = 0;
			pictureBox_level.Refresh();
		}

		private void pictureBox_level_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			if(levels.Count > 0 && hScrollBar_levels.Value < levels.Count)
			{
				for(int cnt_lines = 0; cnt_lines < 14; cnt_lines++)
				{
					for(int cnt_width = 0; cnt_width < 8; cnt_width++)
					{
						Level l = (Level)levels[hScrollBar_levels.Value];
						e.Graphics.DrawImage(imageList.Images[(int)l.data[cnt_width,cnt_lines]],cnt_width * 16, cnt_lines * 16);
					}
				}
			}
			else
			{
				for(int cnt_lines = 0; cnt_lines < 14; cnt_lines++)
				{
					for(int cnt_width = 0; cnt_width < 8; cnt_width++)
					{
						e.Graphics.DrawImage(imageList.Images[0],cnt_width * 16, cnt_lines * 16);
					}
				}

			}
		}

		bool updating = false;

		private void pictureBox_level_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			int tile_x = e.X / 16;
			int tile_y = e.Y / 16;
			

			if(levels.Count > 0 && hScrollBar_levels.Value < levels.Count)
			{
				Level l = (Level)levels[hScrollBar_levels.Value];
				
				if(e.Button == MouseButtons.Right)
				{
					comboBox_tile.SelectedIndex = l.data[tile_x,tile_y];
				}
				else if(comboBox_tile.SelectedIndex != -1)
				{
					l.data[tile_x,tile_y] = comboBox_tile.SelectedIndex;

					//This is just in case it does something funky when mouse is down
					if(!updating)
					{
						updating = true;
						pictureBox_level.Refresh();
						updating = false;
					}
						
				}
			}
		}

		private void button_addLevel_Click(object sender, System.EventArgs e)
		{
			levels.Add(new Level());
			hScrollBar_levels.Maximum = levels.Count - 1;
		}

		private void hScrollBar_levels_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			pictureBox_level.Refresh();
		}

		private void button_deleteLevel_Click(object sender, System.EventArgs e)
		{
			if(levels.Count > 1)
			{
				levels.RemoveAt(hScrollBar_levels.Value);
				if(hScrollBar_levels.Value == hScrollBar_levels.Maximum)
				{
					hScrollBar_levels.Value--;
					pictureBox_level.Refresh();
				}
				hScrollBar_levels.Maximum--;
			}
		}

		private void button_load_Click(object sender, System.EventArgs e)
		{
			if(openFileDialog.ShowDialog(this) == DialogResult.OK)
			{
				//Time to load the File
				StreamReader sr = new StreamReader(openFileDialog.OpenFile());
				
				//Read in the #include "...
				sr.ReadLine();
				//Read in empty
				sr.ReadLine();
				//Read in the const char levelData[] =
				sr.ReadLine();
				//Read in the {
				sr.ReadLine();

				//Read in the levels
				levels.Clear();
				while(true)
				{
					levels.Add(new Level(sr));
					if(sr.ReadLine().Trim().Length > 0)
					{
						break;
					}
				}

				sr.Close();
				
				hScrollBar_levels.Value = 0;
				hScrollBar_levels.Maximum = levels.Count - 1;
				pictureBox_level.Refresh();
			}
		}

		private void button_save_Click(object sender, System.EventArgs e)
		{
			if(saveFileDialog.ShowDialog(this) == DialogResult.OK)
			{
				StreamWriter sw = new StreamWriter(saveFileDialog.OpenFile());
				
				//Dump the #include line
				sw.WriteLine("#include \"leveldata.h\"");
				//Dump a spaced line
				sw.WriteLine("");
				//dump the const char levelData[] = line
				sw.WriteLine("const char levelData[] =");
				//dump the {
				sw.WriteLine("{");

				//Save the levels
				for(int cnt_levels = 0; cnt_levels < levels.Count; cnt_levels++)
				{
					((Level)levels[cnt_levels]).save(sw,cnt_levels + 1);
					if(cnt_levels + 1 < levels.Count)
					{
						sw.WriteLine("");
					}
					else
					{
						sw.WriteLine("};");
					}
				}

				sw.Close();
			}
		}
	}
}
